/**
 * Service Worker - PWA 離線支持
 *
 * 策略：緩存優先（cache-first）+ 後台更新（stale-while-revalidate）。
 * 先立即回傳快取（命中即秒開），同時在背景嘗試拉取網絡更新快取。
 *
 * ⚠️ 為何不用「網絡優先」：iOS 上「徹底斷網」時 fetch 會立即失敗（可即時回退快取），
 * 但「連著蜂窩數據、卻到不了內網 192.168.x.x 服務器」時，fetch 不會立刻失敗，
 * 而是卡在 DNS/TCP 超時裡 → 頁面一直打不開。緩存優先可徹底規避這種「有網但到不了」的卡死。
 */

// 快取名帶版本：每次改資源內容或 SW 邏輯都要 bump 版本號，
// 讓舊快取名自動失效、activate 階段清掉，確保用戶一定拿到最新資源。
// v186：備註 checkbox 子事件的 建立日(cr) 標記在 LITE/手機版正確渲染——calRenderNoteMarkers 補上 [[cr:...]]→🆕（建立日）轉換（原本只處理 dl→📅/cp→✅，導致 [[cr:...]] 被下游 calRenderInlineMarkdown 當成未知 marker 渲染成只顯「cr」的徽章、丟掉日期）；與桌面版 tlRenderNotes 對齊（cr→🆕 排最前先轉）；calendar-editor.js 改，bump 讓手機重拉
// v187：編輯子事件編輯框新增「自動標示術語」——calCollectTerms（掃描全事件 [[term...]] 建術語字典）＋ calAutoMarkTermsInText：把編輯框內「未標註的已知術語」包成 [[term]] / [[term:釋文]]；規則＝①已位於 [[...]] 內的不重複標註 ②多術語重疊時最長匹配優先 ③僅標註未在 [[...]] 內的出現；編輯框加 #calMdEditAutoTerm 按鈕（#calMdEditOverlay）。與桌面版 tlAutoMarkTermsInText 同邏輯；calendar-editor.js/index.html 改，bump 讓手機重拉
// v105：標籤樹過濾升級——①標籤條併入 ## TAGS 樹登記的全部標籤（父階標籤即使無事件直接掛靠也顯示）；②calEventMatchesTag 改 BOM 展開：選中標籤＝匹配自身＋全部子階＋孫階（新增 calTagDescendants 沿樹向下收集，seen 防成環）；③繼承選中：被選中主標籤 BOM 覆蓋的子/孫標籤顯示 ghost 藍 active-desc 樣式（與 .active 實心藍白配色有差異）；calendar-editor.js/style.css 改，bump 讓手機重拉
// v104：統計彈層與桌面對齊——①「只顯示事件主體」過濾（calBuildStats 加 mainOnly：有子事件的事件本身不算主體，其子事件照常計入子事件欄；無子事件的事件才是主體；calStatsFilter.mainOnly＋篩選區 checkbox＋匯總卡標題改「主事件（無子事件＝主體）」）；②同一主事件的子事件行交替色帶分組（紫↔藍 band-a/band-b）；③明細表狀態列前移到內容列前、狀態改 ○＝完成/✕＝未完成 圖標；calendar-editor.js/style.css 改，bump 讓手機重拉
// v103：展開明細子事件內容懸停 → tooltip 顯示所屬主事件標題（原生 title 屬性，*BuildStats 子事件推送補 ptitle: ev.title；主事件行不加；d-content[title] cursor:help＋點狀底線提示可懸停）；calendar-editor.js/style.css 改，bump 讓手機重拉
// v102：統計彈層加寬（max-width 720px → min(1080px, 96vw)）＋展開明細表加「項次」序號欄（首欄 d-no）與「跳轉」按鈕欄（末欄，calJumpToEvent＝關閉彈層＋scrollIntoView 滾動到主畫面該事件位置＋金色描邊閃爍 2 秒；子事件跳到其所屬主事件——*BuildStats 子事件推送補 uid；找不到/不可見→toast 提示）；calendar-editor.js/style.css 改，bump 讓手機重拉
// v101：統計完成狀態過濾修正為同時作用於子事件——原只過濾主事件（ev.done），子事件全量計入/推送，導致「未完成」篩選下明細仍顯示已完成子事件；現於 *BuildStats 內子事件按自身 done 再過濾（all=不過濾/done=只留完成子/undone=只留未完成子），子事件隨主事件為過濾單位（主事件被過濾掉→其子事件一併排除）；calendar-editor.js 改，bump 讓手機重拉
// v100：統計展開明細表改版——同色顯示主/子事件（連結 a{color:inherit}）+ 新增「主/子事件」欄位值區分；內容欄左對齊（修正 .ev-stats-table td 居中壓過明細表的特異性問題，改用 .ev-stats-table .ev-stats-detail-table 前綴）；狀態直接顯示「完成/未完成」文字；子事件含 dl:→📅 / cp:→✅ 圖標（calParseNoteChecks 捕獲 dl/cp）；calendar-editor.js/style.css 改，bump 讓手機重拉
// v99：事件統計彈層重做——固定標題欄（標題＋✕關閉）不滾動；新增篩選區（標籤勾選 OR 過濾 ＋ 完成狀態 全部/已完成/未完成，預設全部）；列表明細改為表格（日期/事件/狀態 左對齊）；calendar-editor.js/index.html/style.css 改，bump 讓手機重拉
// v98：標籤右鍵選單＋編輯標籤畫面（樹形父階）——## TAGS 區塊存標籤名→父標籤名、成環防呆；右鍵標籤 chip→「編輯標籤屬性」→畫面顯示子標籤列表＋分類（該標籤的子分類，與表單下拉同源）＋可設父階（select 排除自身與後代）；事件內聯標籤 .ev-tag-view 補 data-tag 也可右鍵；calendar-editor.js 改，bump 讓手機重拉
// v97：勾選「只顯示未完成」後畫面儘量不自動滾動——切換前捕獲視口頂部日期組＋偏移，切換後重錨（錨點存活→保持偏移＝不滾；被過濾掉→滾到最近未過濾組）；calendar-editor.js 改，bump 讓手機重拉
// v96：備註 checkbox 勾選時無論有無 [[dl:...]] 都一律補 [[cp:今天]]（原為「有 dl 才補 cp」）；取消勾選仍刪 cp 保留 dl（calNoteCheckTransform）；calendar-editor.js 改，bump 讓手機重拉
// v95：統計彈層檔案大小顯示再調整——固定 byte ＋千分位逗號＋單位「Bytes」（如 38099 → 38,099 Bytes）；calendar-editor.js 改，bump 讓手機重拉
// v94：統計彈層表頭檔案大小改為固定以 byte 顯示（不再走 formatFileSizeShort 的 KB 縮寫，如 37.2KB → 38099 B）；calendar-editor.js 改，bump 讓手機重拉
// v93：備註 checkbox 子事件支援 deadline(dl)/completed(cp) 標記——裸日期 [[YYYY-MM-DD]] 歸一為 [[dl:...]]；勾選 [x] 且含 dl 自動追加 [[cp:今天]]、取消勾選移除 cp（保留 dl）；渲染 dl→📅、cp→✅（calRenderNoteMarkers + calToggleNoteCheck）；calendar-editor.js 改，bump 讓手機重拉
// v92：統計彈層表頭顯示 calendar.md 內容大小（calFileSizeLabel 取編輯器緩衝 UTF-8 字節）；統計按鈕改為與平台 .btn 一致的圖標按鈕（桌面圓形📊／LITE 藥丸📊統計）；calendar-editor.js/index.html/style.css 改，bump 讓手機重拉
// v91：事件統計按鈕（📊 統計，放在 日/週/月/年 旁）——calBuildStats/calOpenStats 主事件×備註子事件(-[ ])按標籤·完成狀態分類＋詳情可展開；calendar-editor.js/index.html/style.css/app.js 改，bump 讓手機重拉
// v90：行程編輯「標籤」補齊子標籤（分類）datalist 下拉（與桌面對齊）——calFormCatNames(tagName) 按標籤從屬過濾＋cat 輸入 list/showPicker/change；calendar-editor.js 改，bump 讓手機重拉
// v89：進入程式自動「按今天」→ 年視圖滾到當月（setView 首次進入 events 視圖設 calYearAutoScrollPending；calStartupAutoScrollDone 守衛只觸發一次）；app.js/calendar-editor.js 改，bump 讓手機重拉
// v88：年視圖「今天」按鈕 / 切到年模式 → 12 個月迷你月曆自動滾動到今天所在月份卡片（calScrollYearToCurrentMonth，與桌面對齊）；calendar-editor.js/app.js 改，bump 讓手機重拉
// v87：月視圖「今天」按鈕 / 切到月模式 → 上半月曆網格自動滾動到今天日期格（calScrollMonthToToday，與桌面對齊）；calendar-editor.js/app.js 改，bump 讓手機重拉
// v86：備註 Markdown 表格補網格線——style.css 為 .ev-notes / .ev-block .notes / .ev-tip-notes 三容器
//      加 border-collapse + th/td 邊框（淺色 var(--border)、深色 .dark-mode 金色 #fbbf24 !important，與桌面對齊）；
//      style.css 改，bump 讓手機重拉
// v12：備註框自繪拖拽手柄（iOS 無原生 resize）
// v15：更換 App 圖示（3D 紫葡萄），一併預緩存圖示檔
// v16：Calendar 特性編輯器抽離為獨立 calendar-editor.js（預緩存新文件）
// v17：備註 checkbox 可點擊勾選/取消（寫回 notes 原文），calendar-editor.js 內部變動
// v18：行程視圖 .events-list 去 720px 居中限寬（列表模式 + 月視圖日明細清單滿寬填充，橫屏充分用左右空間）
// v19：日/週視圖時間網格下方新增「行程明細文字清單」（#ev-grid-list，對齊月視圖 #ev-day-list），保證日周也顯示事件詳情
// v20：行程視圖四模式對齊（時間網格＋重疊並列＋當前時間線）、標籤過濾(OR)、跨天色條
// v21：行事历首开默认月模式（app.js calMode 默认 'month'），bump 让手机重拉 app.js
// v22：悬停行程事件显示放大提示框（app.js/calendar-editor.js 加 data-ev-edit 委托 + style.css 加 .ev-tip），bump 让手机重拉
// v23：.ev-tip 背景改为不透明（显式回退色 var(--bg-secondary, #fff)），避免透明看不清资料
// v24：触屏设备禁用悬停提示框（app.js 加 (hover:hover)+(pointer:fine) 媒体查询守卫 + style.css 加 @media (hover:none) 强制隐藏），避免手机点事件时提示框与编辑表单重叠
// v25：触屏点事件改为弹小选单（编辑 / 详情）：app.js 月历 chip + calendar-editor.js onEvListClick 触屏改调 calShowEventMenu；新增 .ev-act-menu / .ev-detail-pop 样式与 calShowEventMenu/calShowEventDetail
// v26：手机「详情」浮层字号加大一码（.ev-detail-pop 13→14、标题 16→18、meta 13→14、tags 12→13、notes 13→14），style.css 又改
// v27：列表项取消「編輯/刪除」按钮（被整行 data-ev-edit 遮蔽致删除失效），动作统一收进触屏选单：详情/编辑/删除/取消 四项
// v28：手机「详情」浮层字号再加 2 码（.ev-detail-pop 14→16、标题 18→20、meta 14→16、tags 13→15、notes 14→16），style.css 又改
// v29：列表模式日期标题旁显示倒计时徽章（今天/N天后/N天前；今天高亮、其余灰底）：calDateHeaderHtml + calCountdownLabel + .ev-today-badge.dim
// v30：表单「日期/结束日期」输入框旁依输入日期即时显示星期（calUpdateFormDow + .ev-f-dow；change/input 监听 + openEventForm 刷新）
// v31：星期改为「（星期五）」带括号全名，并与正文同色同字號（去掉难读的金色加粗）：calUpdateFormDow + .ev-f-dow 样式
// v32：農民曆 / 老黃曆：新增 lunar.js（lunar-javascript 離線曆法庫，預緩存）+ calendar-editor.js 加 calAlmanac/常顯農曆·節氣/老黃曆彈層
// v33：農民曆簡→繁術語對照（新增 almanac-s2t.js，暴露 almanacToTrad；宜忌/彭祖/吉神/凶神/納音/宿/建除轉繁體），bump 讓手機重拉
// v34：HOLIDAY 多地區 region 欄位（cn/hk/tw/us 地區色＋pill＋圖例）＋ 明細範圍切換（日<->月/週，默認日；月/週列表頭部與日/週明細頂部加 .ev-scope-seg），calendar-editor.js/app.js/style.css 改，bump 讓手機重拉
// v35：範圍切換頭部收成單行：去掉獨立 toggle 條（.ev-scope-row /「9月 全部N條」彙總條），toggle 內聯進第一個日期標題條（與「日」範圍同構）；修復 LITE 週「日」toggle 重複兩次；空月/空週回退獨立條保證可切換
// v36：假日地區過濾（圖例改 checkbox 勾選，默認只勾大陸 cn）：只影響顯示不改數據；過濾收口在 calHolidaysOnDay/calVisibleHolidays（修復「列表/整月」直讀 calHolidays 繞過過濾）；calSetRegionChecked 直接分派重渲染＋同步圖例
// v37：日期標題補「· N 條」當日條數（calDateHeaderHtml 加 count 參數；列表/整月/整週分組標題都顯示，與「日」範圍單日標題一致）
// v38：修復事件備注「貪婪」吞掉緊隨其後的 ## HOLIDAY 原文（Remark 正則改非貪婪；解析時事件塊在 ## HOLIDAY 處截斷、假日塊在 ## EVENT 處截斷，避免字段互相污染）
// v39：跨天行程/假日「逐日展開」——分組收口到唯一入口 calEventsByDate()/calDayItems()（日/週/月/列表共用），
//      修復 by月/列表只認起始日 → 同一天 by日 4 條、by月 3 條。只影響顯示（不改數據）
// v40：月/週「整月/整週」明細自動滾動到選中日（calPickScrollTarget 精確命中→其後最近→其前最近；
//      calScrollListToDate 用 offsetTop 換算避開 .ev-date sticky 干擾；月模式滾 #ev-month-wrap、週/日滾清單自身）
// v41：月/週上下區域改「上區獨立滾動＋下區固定在底部」（與週模式同構）：.ev-split/.ev-split-top/.ev-detail/.ev-hsplit
//      ＋ calBindSplit 拖動分割條即時改 --ev-detail-h（鬆手才落盤 localStorage calDetailH；雙擊復位 30%）。
//      月模式下區不再被月格滾走；滾動目標改為明細自身（#ev-day-list / #ev-grid-list）
// v42：修復日/週模式拖條沉底且拖不動——#ev-grid-list 這條 ID 規則(1,0,0)原寫了 flex/min-height，
//      壓過 .ev-split .ev-detail(0,2,0) 使下區 flex-basis 歸 0 塌成 0 高（拖條被擠到畫面最底、改 CSS 變數無效）。
//      現只保留盒子裝飾，高度一律由 .ev-split 系列決定；橫屏 50/50 改用 .ev-split .ev-split-top 覆寫
// v43：修復月（by月）/週明細「點更早日期不會向前（向上）回滾」——`.ev-date` 是 position:sticky，
//      被吸頂時它的 offsetTop / getBoundingClientRect() 返回的是「位移後」的渲染位置（≈ 當前
//      scrollTop），故算出的目標 scrollTop 恰好＝當前值 → 原地不動（點更晚日期才有效）。
//      現由 calScrollElToTop 讀佈局位置前先臨時摘掉 sticky；列表模式的 scrollIntoView 也改用同一入口。
// v53：「日」範圍日期標題改用 calDateHeaderHtml（補日記按鈕/農曆/倒計時）+ 日記表單加寬（正文主導、三欄並排）；calendar-editor.js/index.html/style.css 改
// v52：日記圖標 hover 顯示內容 tips（複用行程事件 .ev-tip 機制，僅當天有日記時）；calendar-editor.js/app.js 改，bump 讓手機重拉
// v51：新增 ## DIARY 日記（桌面 + LITE 共用結構）：日期標題旁日記按鈕（有日記打勾）、專用日記編輯視窗；
//      calendar-editor.js/app.js/index.html/style.css 改，bump 讓手機重拉
// v85：標籤支援「分類」——標籤資料結構由純字串升級為 {name, cat}（舊資料自動相容）；表單選中標籤可點擊內聯輸入分類，有分類時顯示為「標籤·分類」；列表/假日/日記/tooltip 同步顯示
// v84：修正標籤樣式作用域——.ev-tag-view 提升為全域可用，tooltip/列表/假日/日記一致；並去掉所有 # 前綴
// v83：懸停 tooltip 內的標籤改為與列表一致的膠囊樣式（.ev-tag-view），並去掉 # 前綴；兩端同步
// v82：懸停 tooltip 最大寬度加大 1/3（320px → 426px），兩端同步
// v81：懸停 tooltip 的備註區最大高度加大（200px → 320px），讓長備註顯示更完整；兩端同步
// v80：假日地區/類型標籤從膠囊形改為圓角矩形（border-radius 999px → 6px），兩端同步
// v79：行程/假日/日記的標題與備註支持基礎 Markdown 渲染（renderMarkdown），兩端視覺一致；
//      calendar-editor.js / style.css 改，bump 讓手機重拉（桌面同步改 calendar-editor.js / index.html）
// v78：年視圖「今天所在月份」卡片加金色外框描邊——renderCalYear 給含今天的月份卡片加 .cur-month
//      類別；style.css 加 .ev-year-month.cur-month 金色 box-shadow 外框。calendar-editor.js/style.css
//      改，bump 讓手機重拉（桌面同樣改 tlRenderYear + index.html）
// v77：年視圖下方明細（表身）預設「整年」（calScope 預設 'full' 僅年視圖；月/週/日仍 'day'）：
//      桌面 tlCalScope 初始 'full' ＋ tlSetMode 年→full 其餘→day；LITE app.js calScope 'full' ＋ setCalMode 同款。
//      calendar-editor.js / app.js 改，bump 讓手機重拉
// v76：預設設定調整（依使用者截圖，桌面＋LITE 兩端同步）：①預設視圖 'month'→'year'；
//      ②HOLIDAY 地區過濾 ['cn']→[]（預設不顯示任何地區假日）；③REPEAT 三態 'some'→'next'
//      （只顯示未來最近一次）；④「只顯示未完成」預設關→開（calUndoneOnly 缺省回退 true）。
//      app.js / calendar-editor.js 改，bump 讓手機重拉
// v75：列表模式「框選日（金色描邊）」修正——原邏輯把「今天無行程 → 回退最近未來日」的結果同時用於
//      滾動與框選、且寫回 calListSel，導致今天沒有行程時卻把未來某天框金邊。改為：框選僅在錨點日
//      （今天 / < > 導航日）真有分組時才生效，回退值只作滾動定位、不寫回；< > 導航在錨點日缺失時以
//      「最近未來日」為基準。calendar-editor.js 改，bump 讓手機重拉
// v74：把「只顯示未完成」從「只列表模式」提升為「全模式生效」（年/月/週/日/列表）——收口於共享過濾鏈
//      calEventShown（所有「按日期分組」入口統一走這裡），圖例勾選框移出 calMode==='list' 守衛；
//      renderEventsList 的冗餘再過濾移除，單一可信來源。calendar-editor.js/app.js 改，bump 讓手機重拉
// v73：修正年視圖「年」範圍明細只顯示某一個月——renderCalYearDayList 的 full 分支一律沿用選中日
//      所在月份（prefix=YYYY-MM），年模式下應取整年（prefix=YYYY、重複展開窗口＝整年）；空態文案也
//      由「本月沒有行程」改為年模式「本年沒有行程」。calendar-editor.js 改，bump 讓手機重拉
// v72：列表模式新增「只顯示未完成」勾選（在「只顯示日記」旁）——勾選後隱藏已完成（done ✓）的行程，
//      只看未完成；假日無完成態不受影響。純 UI 偏好（內存 + localStorage 鍵 calUndoneOnly，絕不寫回
//      calendar.md），只在列表模式生效；renderEventsList 過濾後為空顯示「沒有未完成的行程」空態；
//      calendar-editor.js/app.js(state.calUndoneOnly) 改，bump 讓手機重拉
// v71：修正 REPEAT 三態的 some「未來4次」被當前視圖窗口裁剪——calEventOccurrences 的 repeat 分支在
//      展開前臨時切換到寬窗口（2000-01-01..2100-01-01）再截取「最近前一次+未來4次」，用完恢復原窗口；
//      calendar-editor.js 改，bump 讓手機重拉
// v70：REPEAT 勾選框改為「三態」——未勾選(none)＝完全隱藏全部；半勾選(next)＝只顯示「今天及之後最近
//      一次」（未來最近待生效）；全勾選(some)＝最近的前一次(date<今天)＋未來4次(date>=今天)（最多5次）。
//      calEventVisible 僅判 none 才隱藏；收斂邏輯在 calEventOccurrences 的 repeat 分支（none 回[]、
//      next 回最小>=今天的1次、some 回 past[past.length-1]+future.slice(0,4)）；圖例 checkbox 改
//      onclick="calCycleRepeat()" 循環 none→next→some→none，indeterminate 表半勾選/checked 表全勾選；
//      calSetCategoryChecked 移除 repeat 分支、新增 calCycleRepeat；calendar-editor.js/app.js(state.calShowRepeat) 改，bump 讓手機重拉
// v69：REPEAT 勾選框語意改為「顯示幾次」——勾選＝顯示全部發生日（多次）；取消勾選＝只顯示「今天及之後
//      最近的一次」（未來最近待生效），不再整體隱藏。calEventVisible 對重複行程永遠 return true，
//      收斂邏輯移入 calEventOccurrences（勾選回全部、未勾選回最近一次）；圖例 tooltip 同步改；
//      calendar-editor.js 改，bump 讓手機重拉
// v68：跨天行程的懸停提示框（tips）與「詳情」浮層也顯示「(第幾天/共幾天)」——calTipHtml/calShowTip 加
//      occDate 參數＋緩存 key 改 uid@occDate（跨天同 uid 多天不串檔）；calSpanChipHtml 加 occDate 並在兩個
//      div 加 data-occ-date；月格 chip、時間網格全天條/定時塊、列表行、詳情浮層觸發點全補 data-occ-date；
//      app.js 兩處監聽改傳 data-occ-date；calendar-editor.js/app.js 改，bump 讓手機重拉
// v67：跨天行程/跨天節日標題後顯示「(第幾天/共幾天)」（如 回上海 (3/7)）——列表行、假日列、時間網格
//      （全天條／定時塊／假期條）全覆蓋；新增 calSpanDaySuffix（由「出現日」直接算序號，呼叫方不必
//      握有 occurrence 的 idx/total）；calSpanSuffix 統一改帶括號；calendar-editor.js 改，bump 讓手機重拉
// v66：年視圖修復「週日整列消失」——.ev-year-grid 由 repeat(7,1fr) 改 repeat(7,minmax(0,1fr))，
//      並放開 .ev-year-day/.n 的 min-width（1fr=minmax(auto,1fr)，被 min-width:18px 頂住使 7 列最小需 146px
//      > 手機卡片內寬 ~110px，第 7 列溢出被裁，表頭少了「日」）；style.css 改，bump 讓手機重拉
// v65：週/日檢視「欄頭日期旁」也顯示 📕 日記標記；月格標記與欄頭標記收成同一入口/同一類
//      （calDiaryMarkHtml + .ev-diary-mark，原 .ev-cell-diary 更名）；calendar-editor.js/style.css 改，bump 讓手機重拉
// v64：月格「當天有日記」標記——有日記的日期在日期數字旁顯示 📕（純顯示，不掛 onclick）；
//      calendar-editor.js/style.css 改，bump 讓手機重拉
// v63：「只顯示日記」正文不再截斷——去掉舊的「3 行 / 120 字 + 省略號」上限，改為完整渲染、靠列錶整體滾動條查看
//      （calDiaryPreview → calDiaryBody）；calendar-editor.js 改，bump 讓手機重拉
// v111：子事件 checkbox 框線加粗金黃（1px var(--border) → 2px #fbbf24），深色主題下清晰可見；style.css 改，bump 讓手機重拉
// v110：術語（term）渲染移植到 Lite —— calRenderInlineMarkdown（標題）＋ calRenderNotes（備註）接入 calRenderTermDefs
//      （[[term]]／[[term:釋義]]／[[term:釋義:領域]] 立體金膠囊＋tooltip＋內嵌領域小膠囊；dl/cp/裸日期排除、跳代碼圍欄）；
//      style.css 新增 .tl-term-cap/.tl-term-domain。calendar-editor.js/style.css/sw.js 改，bump 讓手機重拉
// v109：Lite 行程列表补充备注 checkbox 数量胶囊与跨天模式字母胶囊；calendar-editor.js/style.css 改，bump 让手机重拉
// v113：修復 ## DIARY 被誤解析為行程事件（帶勾選框）的問題——parseCalendarEvents/parseCalendarHolidays 切塊時一併在 ## DIARY 處截斷，與 parseCalendarDiaries 已在 ## EVENT/## HOLIDAY 處截斷對齊；calendar-editor.js 改，bump 讓手機重拉
// v114：帶文字的分割線（與桌面端同一套私有語法）——整行「--- 文字 ---」（星號／下劃線三種記號同、首尾須同款）在 marked 前提成 %%HRTEXT_n%% 佔位符（跳代碼圍欄、前後補空行確保獨佔一段），渲染後還原成 span.hr-text＋標籤過 parseInline；style.css 加 .hr-text（橫線左右各半由偽元素畫、顏色取 currentColor 混色，不依賴背景遮罩）。md-renderer.js/style.css 改，bump 讓手機重拉
// v115：每事件「只顯示該事件未完成的 checkbox 子事件」開關（與桌面對齊）——列表/日/週/月共用列的標題尾加金色膠囊 ☐/☑（.ev-undone-filter-btn），點擊在該列 toggle .only-undone-checks，CSS 讓 .ev-md-check.done 整行隐藏；偏好存 localStorage（calUndoneChecksByEvent，以 uid 為鍵，只影響顯示、絕不改寫 calendar.md）；委派分支必須排在 data-ev-edit 前否則被整列選單吃掉；calendar-editor.js/style.css 改，bump 讓手機重拉
// v116：LITE 便利貼（翻頁模式，calendar.md 專用）——combo 菜單新增「🗒 便利貼（翻頁）」動作項，平時不顯示、按下才開；
//      資料源＝行程的 `- sticky: \`N\``（N>0 展開 N 張）；翻頁/清單開關/每張背景色·透明度·字色·字重·字級/只顯示未完成 checkbox/
//      上次頁次全部存 localStorage（每份 calendar.md 各自一份），只讀不寫 calendar.md（checkbox 仍走編輯緩衝→保存）；
//      行程表單補「便利貼張數」欄位（載入＋存檔保留）；新增 sticky-notes.js，index.html/style.css/app.js/calendar-editor.js/sw.js 改，bump 讓手機重拉
// v117：LITE 備註可編輯化（與桌面同口徑）——非 checkbox 的「最小 MD 區塊」注入 ✎ 圓點、checkbox 行加行內 ✎；
//      底部彈層可編輯區塊原文／子事件（多行＝拆分，第一行保留勾選狀態）／＋☐ 加入子事件；清空保存＝刪除（先確認）。
//      便利貼 meta 補＋☐ 與逐張 ☐/☑「只看未完成」，列表行補＋☐；時間格因只顯示前 400 字，維持唯讀避免截斷回寫。
//      calendar-editor.js/sticky-notes.js/index.html/style.css/app.js/sw.js 改，bump 讓手機重拉
// v118：LITE 便利貼翻頁手勢——整個彈層支援手指左右滑（touchmove 軸鎖定＋橫滑 preventDefault），
//      移除卡片兩側 ‹ › 常駐按鈕與其 44px 預留內距，正文恢復全寬；底部翻頁鈕與鍵盤方向鍵保留。
//      index.html/style.css/sticky-notes.js 改，bump 讓手機重拉
// v119：LITE 便利貼設定持久化補強——除 lastId（標題|日期|序號）外另存 lastIdx，標題／日期被改導致身分認不到時
//      退回上次停留的頁次而非一律回第 1 張；設定面板提示改為明示「開關/樣式/上次頁次會自動記住」。
//      sticky-notes.js/index.html/sw.js 改，bump 讓手機重拉
// v120：修復便利貼備註在正文含 ``` 處被截斷——Remark/content 解析改為 CommonMark 圍欄規則（整行 3+ 反引號、
//      閉合長度 ≥ 開啟），寫入時圍欄長度動態取 max(3, 正文最長反引號串+1)，與桌面 calendar 插件一致；
//      桌面已寫出的 4 反引號 Remark 內含行內 ``` 時不再吞掉後續內容。calendar-editor.js 改，bump 讓手機重拉
// v121：LITE 便利貼／行程備註的表格區塊支援「MD 表格網格編輯器」——點表格區塊的 ✎ 圓點直接開格子網格
//      （＋行／列、建立空白表、改 Markdown 原文），格子改動即時寫回區塊 textarea，保存仍走既有區間回寫；
//      新增 md-table-grid.js（桌面引擎的鏡像），index.html/style.css/calendar-editor.js/sw.js 改，bump 讓手機重拉
// v122：LITE 便利貼「＋☐」改成三模式下拉（＋☐▾ → checkbox 子事件／MD 表格／自由編輯），
//      對齊桌面便利貼；表格入口從零建空白網格、加入後不關窗可連續建立。
//      index.html/style.css/sticky-notes.js/calendar-editor.js 改，bump 讓手機重拉
// v123：手機 LITE 認 calendar 檔改為「檔名 calendar*.md 前綴匹配」（原本只認 calendar.md）——
//      calendar-event-draft.md 等草稿/分包檔可直接以行程方式開啟編輯；並補上「重畫整份文件時
//      保留 ## TAGS / ## INCLUDE 元區塊」（原本會被整段清掉）。calendar-editor.js/sticky-notes.js/
//      index.html/sw.js 改，bump 讓手機重拉
// v124：行程行新增「便利貼徽標」（該行程設了 - sticky: N（N>0）才顯示，與桌面 calendar 清單行同一位置＋同一圖示）；
//      點徽標＝開便利貼並跳到該行程的第一張（原本只會回到上次停留的那張）。
//      calendar-editor.js/style.css/sticky-notes.js/sw.js 改，bump 讓手機重拉
// v125：手機 LITE 多檔聯運——開啟 calendar*.md 主檔後，可用行程工具列「📎 加入档案」多次/多選載入
//      其它 calendar*.md（只讀併入顯示，不寫回主檔；iCloud 無法一次全載，故採分段多次加入）。include 事件
//      標 ro+⛔、禁用編輯/刪除/勾選，內容快取 localStorage（按主檔名），重開主檔自動重併。
//      app.js/calendar-editor.js/index.html/style.css/sw.js 改，bump 讓手機重拉
// v126：便利貼（翻頁）清單改用「主档 + include 只讀事件」併集建目錄——修「點 include 事件的便利貼徽標
//      卻翻不到、顯示別張」的 bug（原 calStickyBuildCatalog 只解析 elements.editor.value 主檔）。
//      便利貼內的寫入（＋☐/✎/勾選）對 ro 事件一律攔阻並提示。
//      sticky-notes.js/calendar-editor.js/sw.js 改，bump 讓手機重拉
// v127：便利貼加上「來源檔案徽標」📄 <檔名>（對齊桌面便利貼 #docBadge 的做法）——只有來自
//      「📎 加入檔案」的只讀聯運行程才顯示，金色虛線膠囊，右上角不佔位；翻頁清單同名項也加 📄 記號。
//      非聯運便利貼（主档）完全看不出差別。sticky-notes.js/index.html/style.css/sw.js 改，bump 讓手機重拉
// v128：權限與桌面對齊——聯運（include）行程只鎖「行程本體」（標題／日期／刪除／完成），
//      **便利貼內容可改**：勾子事件、＋☐ 加子事件/表格/文本、編輯區塊與子事件都開放，
//      寫回只動來源檔「那一個 ## EVENT 區塊」的 Remark（其餘原文逐字保留），
//      內容存本機快取並在 📎 chip 打 ● 出現 ↓ 匯出（覆寫原檔才真正落回 iCloud）。
//      calendar-editor.js/app.js/sticky-notes.js/style.css/sw.js 改，bump 讓手機重拉
// v129：「保存」鍵納入聯運檔——只改聯運檔時保存鍵不再灰掉（狀態列顯示「● N 個聯運檔未寫回」），
//      按下即匯出；行動端把「主檔＋全部待寫回聯運檔」塞進**同一次分享面板**（選一次資料夾全部存回），
//      桌面 Chromium 逐檔 picker 直接寫回。取消（AbortError）整批不標已存。
//      app.js/calendar-editor.js/sw.js 改，bump 讓手機重拉
// v130：「開啟」與「📎 加入檔案」合併成單一入口——按一次「開啟」可多選檔案，
//      calendar.md（不分大小寫）優先當主檔＝行程本體可編輯，其餘 calendar*.md 自動成為只讀聯運
//      （行程本體不可編輯，只有便利貼內容可改）。整組替換舊聯運清單；有未匯出修改時先確認。
//      工具列的 📎 按鈕與其隱藏 input 移除。index.html/app.js/calendar-editor.js/sw.js 改，bump 讓手機重拉
// v131：LITE 行程檢視的備註可寫性對齊桌面——include(ro) 行程在「行程檢視」的備註降級為唯讀
//      （不給區塊 ✎／子事件 ✎，勾選與各編輯入口一律攔下並提示去便利貼改）；便利貼那邊仍可改並寫回來源檔。
//      兩邊共用同一組編輯函式，靠 DOM 歸屬（#calStickyOverlay）判斷這次動作來自哪個介面。
//      calendar-editor.js/sticky-notes.js/sw.js 改，bump 讓手機重拉
// v132：combo 選單新增三項——「＋ 建立 calendar 檔案」（前綴固定 calendar-，建空檔→設為當前文檔並標髒，
//      資料未載入也能用，按「保存」存回 iCloud）、「＋ 新建便利貼」（標題＋寫入檔案下拉：主檔或已併入聯運檔，
//      sticky=1 新行程，建好跳轉翻頁）、便利貼 ☰ 清單「🗑 删除便利貼」（刪當前翻頁那張，主檔→編輯緩衝、
//      ro 聯運→來源檔快取標髒，window.confirm 確認）。calendar-editor.js/sticky-notes.js/index.html/style.css/app.js/sw.js 改
// v141：狀態列版本號同時顯示 SW 版本——頁面透過 MessageChannel 問 SW（GET_VERSION），
//      SW 回 CACHE_NAME 尾碼，顯示成「v0.7.44 · sw.js v141」。
//      app.js/sw.js 改，bump 讓手機重拉
// v142：📎 聯運檔案清單從工具列下方搬進 combo 菜單——平時收合不占畫面，點「📎 聯運檔案 ▸」展開看 chip
//      清單（含 dirty ● / ↓ 匯出 / ✕ 移除）；數量與 dirty 狀態同步顯示在 toggle 按鈕上。
//      index.html/style.css/calendar-editor.js/sw.js 改，bump 讓手機重拉
// v143：📅 事件過濾（EVENT/HOLIDAY/REPEAT/只顯示未完成）與 🏷 標籤過濾 一併搬進 combo 菜單——
//      平時全部收合不占畫面，各自獨立 toggle 展開；combo 關閉時自動把三個面板都收回去。
//      index.html/style.css/calendar-editor.js/sw.js 改，bump 讓手機重拉
// v144：＋ 新增行程 也搬進 combo 菜單——工具列移除獨立按鈕，改在 combo 最底部用主動作樣式顯示；
//      點擊直接呼叫 openEventForm(null)，預設日期為今天。
//      index.html/style.css/calendar-editor.js/sw.js 改，bump 讓手機重拉
// v145：📱 啟動恢復草稿時（iOS 關閉前的自動備份），若是 calendar.md 自動切 events 視圖並滾到今天——
//      原本 restoreDraft() 只恢復文字與檔名、不做資料感知分派，就算草稿是 calendar.md 也停留
//      在 edit/split 視圖；補一行 dispatchDataAwareEditor() 即串起 setView('events') →
//      updatePreview → calStartupAutoScrollDone 守衛 → calAutoScrollToTodayPending →
//      renderEventsContent 雙 rAF 後滾到今天（月視圖置今日格於中央、列表視圖滾到最近今日）。
//      app.js 改，bump 讓手機重拉
// v146：修復啟動自動滾今天不生效的兩個 race condition——
//      (1) restoreDraft() 先 dispatchDataAwareEditor() 跑 render → init() 又 setView() 再跑一次，
//          第二次消費 calAutoScrollToTodayPending（已是 false）→ 不滾；改為 restoreDraft 只設
//          state.view='events'，讓 init() 走單次 setView 即可。
//      (2) 双 rAF 不夠——panel.offsetHeight 還沒出來就執行滾；改 desktop 同套路徑的 waitPane
//          迴圈（最多 120 帧）確保滾動容器真有高度才滾。
//      app.js/calendar-editor.js 改，bump 讓手機重拉
// v147：月視圖下方「今日行程列表」也要滾到今日——原來只在 calScope==='full' 時才滾，
//      預設月視圖 calScope='day'（setCalMode 設的），導致「行事曆（上）滾了、日程事件（下）沒滾」；
//      改為 month 模式只要有 elements.evDayList 就滾。calendar-editor.js 改，bump 讓手機重拉
// v148：修復「多选開啟（含 calendar.md）不滚到今天」的回歸——openSingleFile 那次渲染已消費掉
//      calAutoScrollToTodayPending（startup 守衛只觸發一次），隨後 calReplaceIncludes 重建列表把滾動
//      重置到頂部、flag 已為 false 不再滾；改在 calReplaceIncludes 的「最終併入後」渲染前重設 flag。
//      calendar-editor.js 改，bump 讓手機重拉
// v161：手機 LITE 只讀（ro / include）事件的「完成」checkbox 補視覺暗化——HTML 早已加 disabled（不觸發
//       change/click，故本就點不動），但缺 .ev-check:disabled 暗化 CSS，導致看起來「亮的但點不動」；
//       補 .ev-item .ev-check:disabled { cursor:default; opacity:.45 } 對齊桌面。style.css 改，bump 讓手機重拉
// v162：手機版主版本號升版 0 → 1（1.8.0）——APP_VERSION 與 manifest.json 長期停在 0.x 不恰當；
//       app.js APP_VERSION '0.7.64'→'1.8.0'、manifest.json version '0.8.0'→'1.8.0' 拉齊（原兩者已不同步）；
//       CACHE_NAME 跟進 v161→v162（app.js 內容變更，須讓手機重拉最新資源）。純版本號維護，無功能變動。
// v163：頂欄「保存」按鈕改為 combo——主按鈕＝保存全部（原行為），右側 ▾ 下拉可選單一檔案保存
//       （只存主檔 / 只存某個聯運檔），dirty 角標隨之遞減。app.js/style.css/index.html 改，bump 讓手機重拉；
//       APP_VERSION 與 manifest.json 同步 1.8.0→1.8.1。
// v164：修正保存 combo 下拉選單定位——原 right:0 讓選單向左延伸出螢幕左緣、裁掉檔名開頭；
//       改 left:0（按鈕在頂部最左，向右展開）並加 max-width 防極窄屏溢出。純 style.css 改，bump 讓手機重拉；
//       APP_VERSION 與 manifest.json 同步 1.8.1→1.8.2。
// v165：列表模式按「今天」、今天無行程時不再「一動不動」——calQueueScrollActiveViewToToday 的 list 分支
//       原把 target 限定為「今天那天的 .ev-date 頭」，今天無行程→target=null→整個滾動流程被略過；
//       改為「只要有任一有行程的日期就放行」。scrollToNearestDate 同步由「只找最近未來日」改為
//       「取離今天絕對距離最小的有行程日」（過去/未來皆可，天數相同取較早日），並補 calDayDiff 輔助。
//       calendar-editor.js 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.8.2→1.8.3。
// v166：收緊列表事件項「內容行」行盒——原 TERM 膠囊 line-height 1.7（高 ~25px）、標籤膠囊 line-height 1.35 + padding 3px、
//       ✎ 最小高 17px，把標題行（被撐到 ~48px）與 notes 內 checkbox 子事件行（被撐到 ~25px）整行撐高，視覺上「內容行間距太大」。
//       改 TERM 膠囊 line-height 1.7→1.3 + padding 0 .55em→0 .5em + font .9em→.88em、標籤膠囊 line-height 1.35→1.2 + padding 3px 12px→2px 10px、
//       ✎ 最小 17px→15px + vertical-align -.2em→-.15em；行盒降約 24%（checkbox 子事件行 25→19px、TERM 膠囊 25→17-20px）。
//       純 style.css 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.8.3→1.8.4。
// v167：進一步收緊列表事件項「內容行」行盒（上輪 v166 使用者仍嫌鬆）——在 v166 基礎上再降 line-height 與膠囊尺寸：
//       .ev-title 顯式 line-height 1.3、.ev-notes line-height 1.35；TERM 膠囊 line-height 1.3→1.15 + padding 0 .5em→0 .42em + font .88em→.85em、
//       TERM 領域小膠囊 line-height 1.6→1.15 + padding 0 .4em→0 .35em + font .76em→.72em；標籤膠囊 padding 2px 10px→1px 8px + line-height 1.2→1.1；
//       ✎/MD 編輯圓點 width/height 1.3em→1.2em + min 15px→13px + font .7em→.62em。
//       實測（Electron 真引擎）：checkbox 子事件行盒 19→18px、TERM 膠囊(標題)20→17px、(notes)17→14px、標籤 20→17px、✎ 15→13px、標題行 45→43px，
//       事件內容行(18px) 已小於事件間距(~21px＝padding 10+10 + 1px border)，符合「內容行距應小於事件間距」的原訴求。
//       純 style.css 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.8.4→1.8.5。
// v168：年視圖「今天」滾動邏輯對齊列表模式——原年模式下方「全年行程列表」按 today 滾動走 calScrollListToDate
//       （calPickScrollTarget 只偏好「未來日」），今天無行程時定位不確定、且與列表模式的「絕對距離最近、tie 取較早」不一致。
//       改為呼叫與列表模式同款的 scrollToNearestDate(elements.evYearDayList)：今天無行程時滾到「離今天絕對距離最小且有行程」的那天
//       （過去/未來皆可、天數相同取較早），與 v165 列表邏輯完全一致。年網格本身仍由 calScrollYearToCurrentMonth 置中當月，不受影響。
//       calendar-editor.js 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.8.5→1.8.6。
// v169：便利貼（兩端）下拉選單支援搜尋——LITE `#calStickySheet` 與桌面 `#tlStickyMenu` 各加一個搜尋框，
//       輸入即過濾清單：LITE 匹配「標題（去裝飾）＋ 內容(notes)」、桌面匹配「標題＋日期＋內容」，皆不區分大小寫；
//       LITE 清單標題同步顯示「符合 N 項」、無符合時提示「沒有符合「xxx」的便利貼」；兩端開啟選單時清空搜尋框。
//       實作：LITE 在 sticky-notes.js 增 calStickyMatchQuery ＋ 改 calStickyRenderSheetList（oninput 觸發）、
//       index.html 加 #calStickySearch、style.css 加 .cal-sticky-search；桌面在 index.html 改 tlRenderStickyMenuList
//       （oninput 觸發）＋ 加 #tlStickySearch ＋ 加 .ev-sticky-search。清單重繪只替換列表容器、不動搜尋框，故輸入焦點不丟。
//       LITE sticky-notes.js/index.html/style.css 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.8.6→1.8.7。
// v170：便利貼搜尋升級為 combo 搜尋框（定位開關）——在搜尋框旁加「📍 定位」開關：有搜尋內容時預設開啟（可手動關）、
//       無內容時固定關閉（disabled，不可開啟）。開啟時在便利貼「渲染模式」把搜尋詞以 <mark class="search-highlight">
//       金底高亮標示（LITE 標題＋內容；桌面便利貼窗 #body/#title 同樣高亮），方便快速查找結果。
//       實作：LITE sticky-notes.js 增 calStickyOnSearchInput/calStickyToggleLocate/calStickySyncLocate/calStickyWrap ＋
//       calStickyRenderPage 渲染模式注入高亮；index.html 加 #calStickyLocateBtn、style.css 加 .cal-sticky-locate ＋
//       search-highlight。桌面同款 combo（index.html 加 #tlStickyLocateBtn ＋ .ev-sticky-locate）並經由新 IPC
//       sticky-note-locate（windows.js 廣播給所有便利貼窗）／sticky-note-locate-get（新窗啟動補種）把定位詞送進
//       desktop-note.js 的 noteApplyHighlight；刷新載荷亦帶 hl（tlPushStickyRefreshes / refresh-complete）。
//       LITE index.html/sticky-notes.js/style.css 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.8.7→1.8.8。
// v171：搜尋高亮改 reverse 渲染（承接 v170）——使用者回饋金底高亮與 TERM 術語膠囊顏色太近，改為「字/底對調」：
//       高標底＝便利貼字色(--note-fg / --cal-sticky-fg)、高標字＝紙張實色(--note-bg / --cal-sticky-bg)，
//       與金色膠囊明確區分，對比度由便利貼自身字/底配對保證（深淺便條皆清楚）。
//       實作：desktop-note.js applyColor 增設 --note-bg（tint 實色 100）；LITE calStickyApplyStyle 增設 --cal-sticky-bg；
//       desktop-note.html 與 style.css 的 .search-highlight 由金底黑字改為 var(--note-fg/--cal-sticky-fg) 底 + 紙色字。
//       LITE sticky-notes.js/style.css 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.8.8→1.8.9。
// v172：便利貼設定可攜 JSON（承接「改程式／重開後設定不見」）——LITE localStorage 對 origin + 檔名敏感，
//       換 port／LAN IP 或清網站資料就整份消失。便利貼 ☰ 清單新增「📥 載入設定 JSON／📤 匯出設定 JSON」：
//       匯出檔名 sticky-notes-settings-<calendar檔名>.json，內含每張樣式、關閉清單、上次頁次；
//       載入時同時認得桌面原生存檔 sticky-notes-state.json（自動逐筆轉換），確認後取代目前 calendar 檔的 storage。
//       轉換與欄位驗證抽成共用 sticky-settings.js（桌面主程序 require 同一份，避免兩端口徑分歧）。
//       LITE index.html/sticky-notes.js/style.css/sticky-settings.js/sw.js 改，bump 讓手機重拉；
//       APP_VERSION 與 manifest.json 同步 1.8.9→1.9.0。
// v184：外框流星（每张便利贴可配置：开关/飞速/大小/形状/颜色/焰尾/彩色）落地——
//       ① 修复关键 bug：--m-color/--m-dur/--m-head/--m-flame 原写在 ::after 伪元素规则里，
//          自身宣告遮蔽继承值 → 颜色/速度/大小/焰尾全失效（流星恒为金 12s 12° 60°）；
//          改挂本体规则 .cal-sticky-note.meteor-on，JS 行内值经继承覆盖才生效。
//       ② 大小(size) 上限 40→120（3×）；环厚 --m-thick 随 size 放大 2→6px。
//       ③ 焰尾(flame) 范围 20–160(8×)→20–200(10×)，head+flame≤320<360 不破。
//       ④ 新增「彩色」(rainbow)：@property --m-hue + hue-rotate(var(--m-hue))，
//          .meteor-rainbow::after 加 meteorHueSpin 动画循环过整圈色相。
//       LITE index.html/style.css/sticky-notes.js/sw.js 改，bump 讓手機重拉；
//       APP_VERSION 與 manifest.json 同步 1.10.1→1.10.2。
// v183：🔔 提醒「view 便利貼」顯示升級——分組標題改走 MD 語意（calStickyViewHeadMd）：行程標題本身是
//       「# …」就照原樣交給渲染器（變成真的標題），純文字標題才補 **粗體**；先前一律包 ** 會讓
//       「# 在我的iPhone上的便利貼草稿」顯示成字面符號。桌面端同步（tlViewStickyHeadMd），
//       投影貼的編輯小圓點另在桌面便利貼窗支援右鍵「複製／找出相同的项目」（LITE 無右鍵功能，維持隱住）。
//       LITE sticky-notes.js/sw.js ＋ 桌面 calendar-editor.js/desktop-note.js/html 改，bump 讓手機重拉；
//       APP_VERSION 與 manifest.json 同步 1.10.0→1.10.1。
// v182：🔔 提醒「view 便利貼」——每次重建便利貼目錄時，把「全部行程（含聯運檔）備註裡帶 [[remind:標題:規則]]
//       的行」彙集成一張排在第一張的投影貼（calStickyViewEntry）：checkbox 只收未完成（- [ ]，已打勾的不必
//       再提醒），列表項／段落／引用／標題沒有完成狀態＝一律收；代碼圍欄內不算；列表項後接非列表行補空行
//       （防 CommonMark lazy continuation 把兩條並成一條）。
//       [[remind:]] 另新增術語渲染（紅框金膠囊＋🔔，規則進 title；calRenderTermDefs）。
//       ⚠️ 投影贴不落盘：样式 calStickyViewPrefsLive／关闭 calStickyViewHidden 只活在本会话，绝不写
//       localStorage；也不给任何异动数据的入口（编辑钮／✎ 小圆点／＋☐／新增／删除全隐，
//       calStickySetEditMode・calStickyEditCurrent・calStickyDeleteCurrent 加守门），浏览功能与一般贴一致。
//       LITE calendar-editor.js/sticky-notes.js/style.css/sw.js 改，bump 讓手機重拉；
//       APP_VERSION 與 manifest.json 同步 1.9.9→1.10.0。
// v181：便利貼內 checkbox 視覺規格化——內框用字體色（var(--cal-sticky-fg)）、外框套金色 #D4AF37，
//       兩框皆用最細 1px 線、緊密嵌套（外框用 box-shadow 0 0 0 1px 直接貼在內框外、無任何間隙），
//       方框大小＝字體大小（width/height:1em，font-size:inherit 隨便利貼字級縮放）。
//       僅作用於便利貼正文 .cal-sticky-body，桌面端同步改 desktop-note.html 的 .ev-cb。
//       LITE style.css/sw.js 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.9.8→1.9.9。
// v180：便利貼「設定資料缺失」提醒改為常駐（不自動關閉）——toast 加 ✕ 關閉鈕，由使用者手動關閉；
//       showToast 加 persistent 參數（第 4 參，預設 false），persistent 時不排程自動消失、顯示 ✕；
//       #toast 結構改成 <span id="toast-msg">＋<button id="toast-close">，.toast 改 flex 並加 .closable（換行＋最大寬度）。
//       LITE index.html/style.css/app.js/sticky-notes.js/sw.js 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.9.7→1.9.8。
// v179：便利貼「設定資料缺失」提醒——手機 LITE 啟動／開啟 calendar 時，若本機 localStorage 找不到該檔的
//       便利貼設定、且本次「開啟」又沒帶入 sticky-notes-settings-*.json，就 toast 提醒使用者去「開啟」一次
//       選 calendar 檔＋該設定 JSON 來還原（承接「換 origin／清網站資料後設定不見」）。
//       判斷點 calStickyHasStoredSettings()（以 storage 鍵是否存在為準）；同一 session 同一 calendar 只提醒一次。
//       LITE app.js/sticky-notes.js/sw.js 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.9.6→1.9.7。
// v178：修正便利貼摺疊 ▸ 標記位置偏移——掃描摺疊塊時外層 for 迴圈在內層跳過整塊後又 i++，
//       漏算「摺疊塊後第一條可見行」，每個前置摺疊塊就讓後面的 ▸ 再往上偏一條可見行
//       （多塊時偏移累積十幾行，出現 tooltip 寫「第 89–91 行」卻畫在第 57 行附近）。
//       改以 while 逐行推進。桌面 desktop-note.js 與 LITE sticky-notes.js 同修，
//       bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.9.5→1.9.6。
// v177：便利貼編輯模式「折疊已完成 checkbox」與既有「只顯示未完成 checkbox」設定聯動——勾選才折疊，
//       未勾選時編輯框顯示全文、行號 1..n、不顯示 chip 與 ▸ 標記；編輯中切換設定立即折疊／還原全文。
//       保存仍沿 LCS 合併隱藏行（未勾選時本來就是全文，無隱藏行）。桌面 desktop-note.js 與
//       LITE sticky-notes.js 同口徑；bump 讓手機重拉，APP_VERSION 與 manifest.json 同步 1.9.4→1.9.5。
// v176：便利貼編輯模式「折疊已完成 checkbox」定稿——折疊不是刪除也不是隱藏：原文行數不變、行號不重排
//       （折 3 行後可見行仍顯示 1,2,5…）；每個摺疊塊在行號邊條縫隙上有 ▸N 標記，點哪塊只展開哪塊；
//       右上角 chip 全部展開／全部折疊（無完成項時不顯示）。保存時沿 LCS 錨點把折疊行按原順序插回全文，
//       折疊期間新增／修改／刪除可見行都不會丟已完成內容；圍欄程式碼塊內的 [x] 不折。
//       桌面 desktop-note.js/html 與 LITE sticky-notes.js/index.html/style.css/app.js 同口徑。
//       bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.9.3→1.9.4。
// v174：手機版「開啟」一次選 calendar.md ＋ sticky-notes-settings-*.json 時，主檔開好就自動套用設定
//       （不必再進便利貼選單按「載入設定 JSON」）；只選設定 JSON 也能套用到目前 calendar 檔；
//       剛啟動還沒開檔時先選設定 JSON → 依 JSON 自帶的 calendarFile 寫入該檔設定槽，開啟後即生效。
//       app.js/sticky-notes.js/sw.js 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.9.1→1.9.2。
// v173：便利貼設定接進主保存流程——改樣式／關閉清單後頂欄「保存」亮角標，
//       按保存時設定 JSON 與主檔、聯運檔一起交付（iOS 逐檔各彈一次分享面板）；
//       交付成功才清角標，取消則保留。頁次不列入比對（翻頁不會亮角標）。
//       app.js/calendar-editor.js/sticky-notes.js 改，bump 讓手機重拉；APP_VERSION 1.9.0→1.9.1。
// v185：🆕 外框流星設定納入「可攜 JSON」與「保存角標比對」——sticky-settings.js 的 pickPrefs 原本只收
//       字體大小/字色/底色/透明度/字重/只看未完成，漏掉 meteor，導致手機匯出設定 JSON 時流星設定被丟掉、
//       改流星也不會亮「保存」角標。現補上（含逐欄夾值＋白名單形狀）。
// v186→v187：🆕 需求更正——取消「開啟後自動滾到尾部」開關（scrollEnd），
//       改為統一行為：每張便利貼記住並還原「上次離開前」的捲動位置（scrollPos，非設定項、不進可攜 JSON）。
//       sticky-notes.js / index.html 改，bump 讓手機重拉；APP_VERSION 與 manifest.json 同步 1.10.4→1.10.5。
// v187→v188：🆕 VIEW 便利貼「啟動通知」——規則新增 notify（通知訊息）＋ notifySeconds（保持秒數，預設 15），
//       便利貼啟動時先把勾了通知的 VIEW 贴以外框閃爍依序顯示，秒數到或按 ✕ 關閉後才進正常顯示。
//       sticky-notes.js / index.html / style.css 改；APP_VERSION 與 manifest 同步 1.10.5→1.10.6。
// v188→v189：🔧 啟動通知的外框閃爍改為「明顯硬閃爍」——亮態 4px 亮金環＋強發光（不透明度 1），
//       滅態光環完全消失，42%→44% 硬切（≈16ms 瞬跳），週期 .8s（≈1.25 次/秒），對比遠強於原本的「呼吸」。
//       style.css 改（桌面 desktop-note.html 同步）；APP_VERSION 與 manifest 同步 1.10.6→1.10.7。
// v189→v190：🔧 啟動通知仍看不到閃爍——根因是 #note(inset:0 填滿視窗) 與 .cal-sticky-note(flex:1 撐滿＋overflow:hidden)
//       上「向外 box-shadow」會被視窗/卡片邊界裁掉，視窗內根本看不到，只剩 1px 邊框色在黃底上的微弱變化。
//       改為 ::before 偽元素（inset:0 在卡片內、不被裁）畫 6px 亮白粗邊＋內發光＋微白染，整層 opacity 硬切閃爍；
//       亮白色在黃底上對比最高。桌面 desktop-note.html 與 LITE style.css 同步；APP_VERSION/manifest 1.10.7→1.10.8。
// v190→v191：🔧 流星「焰火長度」(flame 角寬) 下限 20°→10°（用戶設到最短仍嫌長，再減半）；上限與預設不變。
//       index.html(滑桿 min) / sticky-notes.js / sticky-settings.js 三處 LITE 前端改，bump 讓手機重拉；APP_VERSION/manifest 1.10.8→1.10.9。
// v191→v192：🔧 流星「焰火長度」(flame 角寬) 下限 10°→1°（用戶接受角度對應長度，但要求最小角度 1°）；滑桿 step 5→1 以便小角度微調；上限與預設不變。
//       index.html(滑桿 min/step) / sticky-notes.js / sticky-settings.js 三處 LITE 前端改，bump 讓手機重拉；APP_VERSION/manifest 1.10.9→1.10.10。
// v192→v193：🔧 流星「焰火長度」(flame) 由「圈上的角度(deg)」改為「亮頭+拖尾總可見長度(px)」，渲染端依便利貼周長反推角度，使任何尺寸便利貼上總長一致（預設 160px≈10中文字、範圍 10–600）。
//       index.html(滑桿 min/max/step/value 與標籤) / sticky-notes.js(applyStyle+normalize+sync+listener) / sticky-settings.js(夾值) 改，bump 讓手機重拉；APP_VERSION/manifest 1.10.10→1.10.11。
// v193→v194：🔧 修正 flame=總長預算的實作——亮頭不再固定 12° 吃掉預算（否則 flame 設很小仍只見亮頭），改為亮頭不超過總長一半、隨預算縮放，使 flame=10px 真的≈10px。
//       sticky-notes.js(applyStyle 頭/尾切分) 改，bump 讓手機重拉；APP_VERSION/manifest 1.10.11→1.10.12。
// v194→v195：🔧 VIEW 投影贴非 task 行（段落/列表/标题/含 [[…]] 胶囊的行）也补一颗只读 .ev-md-edit 圆点（与 checkbox 行同口径，右键 复制/找出相同），
//       修正「VIEW 便利贴的非 task 行没有编辑小圆点」的不一致（view-sticky-rules.js::groupsToHtml 改）。桌面 desktop-note.html 加 .md-unit>.ev-md-edit 凹槽定位；
//       LITE 端 .cal-sticky-view 本就隐藏所有 VIEW 圆点，本次不变。bump 让手机重拉 view-sticky-rules.js；APP_VERSION/manifest 1.10.12→1.10.13。
// v196（2026-10-30）：VIEW 投影贴的非 task 行改为按「最小 MD 单元」分组（连续 list/para/quote 合并成 1 个 .md-unit + 1 颗圆点），与来源便利贴 tlSplitMdBlocks 口径一致；
//       圆点 data-text 携带整块原文（多行 \n 连接）。桌面 desktop-note.js find-same 增加整块比对分支。APP_VERSION/manifest 1.10.13→1.10.14。
//       同版追加：.md-unit 补 data-start/data-end（0-based 行区间），供桌面便利贴窗「找出相同 → 切换」定位并闪烁该区块。LITE 视觉不变。
// v197（2026-10-30）：VIEW 便利贴「搜索段落」多段落能力——一条规则可含多段（每段＝一个完整搜索），结果按序显示为多个「段落 N」区块；
//       引擎 view-sticky-rules.js（normalizeRule 增 segments／buildRef 多段渲染，单段与 🔔 外观不变）＋ 维护窗 view-sticky-rules.html（段落列表＋每段条件编辑）。
//       /vsr.js 引擎经桌面共享、LITE 同款渲染，故 bump + 刷新 ?v 戳让手机重拉；APP_VERSION/manifest 1.10.14→1.10.15。
// v200（2026-11-02）：VIEW 多段落便利贴新增「顺序平铺／页签方式」随时切换（便利贴正文内控件，偏好记忆在 localStorage）；
//       LITE 端 calStickyBuildCatalog 自定义 VIEW 携带 ref.html（与桌面同款富渲染，含 .vsr-display 页签结构）、
//       calStickyRenderPage 对 VIEW 改用 html、新增 calStickyInitViewDisplay 点击切换；style.css 补 .vsr-* 样式。
//       /vsr.js 引擎 buildRef 多段落包 .vsr-display（桌面 sticky-note-html IPC 与 LITE 同源），故 bump + 刷新 ?v 让手机重拉；
//       APP_VERSION/manifest 1.10.15→1.10.16。
// v201（2026-11-04）：修 VIEW 投影贴「非 checkbox 单元」漏做建立日／截止／完成标记转换，致 [[cr:…]] 以原文显示
//       （普通便利贴走母本 tlRenderNoteMarkersLines 已正确）。/vsr.js 引擎 nonTaskUnitHtml 补 noteMarkersLines
//       （逐行、跳过代码围栏），bump + 刷新 ?v 戳让手机重拉；顺手把落后的 app.js APP_VERSION 1.10.15
//       与 manifest 1.10.16 一并拉齐到 1.10.17。
// v202（2026-11-04）：行程編輯窗體新增「唯讀模式」——被 include 的外部檔行程（ev.ro）不再 toast 拒絕，
//       改開「檢視行程（唯讀）」：欄位 disabled／備註 readOnly、隱藏寫入與刪除、金色唯讀橫幅標來源檔；
//       calSetEventFormReadonly 為單一可信來源，saveEventForm／deleteEventFromForm／closeEventForm 都有守衛。
//       calendar-editor.js / index.html / style.css 改，bump + 刷新 ?v 戳讓手機重拉；APP_VERSION/manifest 1.10.17→1.10.18。
// v203（2026-11-06）：新增 {gp} / {gp:名稱} 分組標記 —— 連續同名標記行合併成「一個小事件／一顆編輯小圓點」。
//       桌面 calendar-editor.js（tlSplitMdBlocks / tlStripGpMarkers / tlEnsureCrMarkerForBlock）與 LITE
//       calendar-editor.js（calSplitMdBlocks / calStripGpMarkers）同口徑；共享引擎 view-sticky-rules.js 的
//       groupHitsIntoUnits 也以 gp 組為 1 個 .vsr-sort-unit，VIEW 排序不會把 5 行當 5 個小事件。
//       bump + 刷新 /vsr.js 與 calendar-editor.js 的 ?v 戳讓手機重拉；APP_VERSION/manifest 1.10.18→1.10.19。
// v204（2026-11-06）：編輯內容區塊新增「group 啟用（唯一小事件）」勾選 —— 預設不啟用，勾選後保存時
//       逐行行尾補 {gp}，整塊視為一個小事件；原本已整組時預勾，取消可拆組。桌面主窗／便利貼窗／LITE
//       三端同口徑（tlApplyGroupMarkers / noteApplyGroupMarkers / calApplyGroupMarkers）。
//       style.css / index.html / app.js / calendar-editor.js 皆有改動 → 全部 ?v 戳刷為 lite-group-20261106；
//       APP_VERSION/manifest 1.10.19→1.10.20。
// v205（2026-11-06）：group 啟用勾選補齊「加入子事件（CheckBox）」與「編輯子事件（CheckBox）」兩種模式
//       （桌面主窗／便利貼窗／LITE 三端同口徑）：勾選後把整批生成的 - [ ] 行逐行補 {gp}，整批＝一個唯一小事件；
//       原本整組預勾、取消拆組；表格網格與自由文本新增不提供。?v 戳刷為 lite-group2-20261106；
//       APP_VERSION/manifest 1.10.20→1.10.21。
// v206（2026-11-06）：修正「gp 群組內的 checkbox 前面多一個 . 項目符號」。根因＝可編輯分塊視圖的 gp 區塊
//       直接把 - [ ] 原文餵 renderMarkdown（漏了 tlNotesWithChecks/calNotesWithChecks 那一層）→ GFM 產 <ul><li>
//       ＋ .body ul li{list-style:disc}；三端（桌面主窗 tlRenderNotes／LITE calRenderNotes／VIEW 引擎
//       nonTaskUnitHtml）都補上自訂 .ev-md-check/.ev-cb 轉換，整組仍只掛一顆編輯圓點、組內不互動。
//       ?v 戳刷為 lite-gpcb-20261106；APP_VERSION/manifest 1.10.21→1.10.22。
// v207（2026-11-06）：寬放 {gp} 標記語法 —— 花括號內開頭是 gp 或 group 即算、大小寫不拘、冒號可省略：
//       {GP}＝{GroUP}＝{gp}；{gp:ABC}＝{gpABC}＝{GROUP:ABC}；{gp1}＝{gp:1}。四端（桌面主窗／LITE／
//       便利貼窗／VIEW 引擎）的取 key／剝離／cr 定位共 14 處正則同步；前綴 group 優先於 gp，組名仍區分大小寫。
//       ?v 戳刷為 lite-gpsyn-20261106；APP_VERSION/manifest 1.10.22→1.10.23。
// v208（2026-11-06）：{gp} 標記「位置規則」定死 —— 只有出現在行尾、或行尾 [[...]] 標記序列之前的
//       {gp} 才算結構標記（才隱藏、才分組）；行中出現的 {gp} 一律是普通文字，必須原樣顯示。
//       三式正則（取 key／剝離／cr 定位）四端 14 處同步加 lookahead (?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)，
//       lookahead 不消費 [[...]]，故剝離時不會吃掉 cr/dl/cp/term。?v 戳刷為 lite-gpeol-20261106；
//       APP_VERSION/manifest 1.10.23→1.10.24。
// v209（2026-11-06）：「編輯內容區塊」浮層關閉路徑鎖死 —— 除了窗體下緣／標題的「關閉」「取消」「✕」按鈕，
//       點背罩、Esc（window／textarea／表格網格）一律不關窗，避免誤觸打斷編輯；桌面主窗／便利貼窗／LITE 三端同口徑，
//       所有「Esc 關閉」提示文案同步改為「請按下方按鈕」。?v 戳刷為 lite-noclose-20261106；
//       APP_VERSION/manifest 1.10.24→1.10.25。
// v210（2026-11-06）：Group（{gp} 分組）內的 checkbox 恢復可勾選 —— 之前 plain 模式連 interactive/onclick/data-line
//       一起拿掉，點了沒反應。改為 plain 只拿掉「行內 ✎」，勾選互動與一般 checkbox 完全相同；補 opts.baseLine
//       （＝區塊 start）把區塊內索引換成全域行號，勾選回寫才不會改錯行。順手修主窗 tlToggleNoteCheck 的
//       showToast(done?) 未定義變數（應為 wasDone）。v209 關閉路徑鎖死規則不變。三端同口徑；VIEW 投影貼仍唯讀。
//       ?v 戳刷為 lite-gpcheck-20261106；APP_VERSION/manifest 1.10.25→1.10.26。
// v211（2026-11-06）：小事件群（連續同組 {gp} 行＝一個編輯小圓點區塊）顯示時加「最細 1px、與字色相同」外框。
//       只給 gp 區塊的 .md-unit 掛 is-gp，CSS 用 border:1px solid currentColor（明暗主題自動跟隨字色），
//       padding 只補上/右/下三邊、不動 padding-left 圓點凹槽。桌面主窗／便利貼窗／LITE 三端 CSS，
//       來源貼 .md-unit 與 VIEW 投影貼 .vsr-sort-unit > .md-unit 共用同一個 class。?v 戳刷為 lite-gpframe-20261106；
//       APP_VERSION/manifest 1.10.26→1.10.27。v210 的 gp 內 checkbox 可勾選與 v209 關閉路徑鎖死規則不變。
// v212（2026-11-06）：小事件群外框改「真正最細」的 hairline —— 原本 CSS 1px 在 2x Retina 會被畫成
//       2 個實體像素（使用者目視回報「看起來挺粗」）。三端 CSS 加 @media (min-resolution:2dppx)
//       覆寫 border-width:.5px（＝1 個實體像素），1x 屏維持 1px；LITE 另加 -webkit-min-device-pixel-ratio
//       相容 iOS Safari。邊框色仍是 currentColor、選擇器特異性不變、padding 凹槽不變。?v 戳刷為
//       lite-gphair-20261106；APP_VERSION/manifest 1.10.27→1.10.28。
// v213（2026-11-06）：{gp} 小事件群的「空白行延续」規則 —— 夾在「前後相同 {gp} 行」之間的
//       1~n 行純空白行視為上一行標記的延續，前後兩段合併成同一個小事件群（不再拆成兩顆編輯圓點）。
//       桌面 tlSplitMdBlocks／LITE calSplitMdBlocks 反覆延伸掃描並把空白行納入 [start,end]，
//       VIEW 投影貼本來就只收命中行（純空白行不進 hits），被空行隔開的兩段同 key {gp} 天然相鄰、
//       照舊合併成 1 個排序單元；虛擬分隔 h.sep 維持丟棄，不塞進 gp 單元（避免多出來源沒有的空行）。
//       空行後是異名組或非 gp 行仍舊斷開；末尾空行不屬任何區塊。三端 *ApplyGroupMarkers 同步補
//       「純空白行不寫 {gp}」，避免 group 啟用保存後把空行改成內容行。?v 戳刷為
//       lite-gpblank-20261106；APP_VERSION/manifest 1.10.28→1.10.29。
// v217（2026-11-08）：新增「塊級／圍欄式」{gpX}…{/gpX} 小事件群語法 —— 單獨一行 {gpX} 開啟、
//       單獨一行 {/gpX} 結束，中間的 Markdown 整體算「一個」小事件群（一顆編輯圓點＋一個外框）。
//       與既有「行尾 {gpX}」並存且互為硬邊界：前後即使同名也絕不融合；標記行只在顯示層剝成空行、
//       行數不變，底稿原文保留（start/end、baseLine、勾選回寫全部照舊）。
//       四端同步：桌面 tl*／LITE cal*／便利貼 note*／共用 /vsr.js 的 gpFenceScan + blockGp 排序單元。
//       group 啟用對塊級群改為「保持／拆組／forceMark 整段改名」，不再逐行補行尾標記；
//       塊級語法不逐行加標記，故含程式碼圍欄也能安全啟用 group。
//       ?v 戳刷為 lite-gpfence-20261108；APP_VERSION/manifest 1.10.32→1.10.33。
// v218（2026-11-08）：勾選「group 啟用」按保存時，寫入端一律改成「塊級」{gpX}…{/gpX}，
//       不再逐行補行尾標記。新增「＋☐ 加入子事件」整批包成一個塊級群；編輯既有內容區塊時
//       舊的行尾式群就地升級（剝掉每行行尾標記、沿用原群名包成塊級）。
//       編輯「單個 CheckBox 子事件」維持行尾式（target 只是群內局部行，包塊會巢狀）。
//       便利貼新增後切成「整塊編輯」並把整段原文放進編輯框，避免再按 ⌘S 把行尾標記補回來。
//       三端 *WrapGpFence + *ResolveGroupText/*GroupMd(fenceWrap) 同步。?v 戳刷為
//       lite-gpfence-write-20261108；APP_VERSION/manifest 1.10.33→1.10.34。
// v219（2026-11-08）：手機 LITE 的 VIEW 便利貼補上「排序」功能（與桌面 desktop-note.js 同口徑）。
//       sticky-notes.js 新增 VIEW 貼專屬下拉（原序／升冪／降冪）＋排序引擎：鍵＝max(cr,cp) 取最晚、
//       組鍵＝組內最大單元日期、穩定排序、原序還原；模式按 identity 存 localStorage（不進設定簽名）。
//       style.css 加 .cal-sticky-view-sort；⚠️ index.html 的 sticky-notes.js 是獨立 ?v 戳，必須一併刷，
//       否則手機只會重拉四個主資源、仍用舊 sticky-notes.js。?v 戳刷為 lite-viewsort-20261108；
//       APP_VERSION/manifest 1.10.34→1.10.35。共享 /vsr.js 零改動。
// v220（2026-11-08）：小事件存檔 cr/cp 日期標記追加「本機 HH:mm」（24H、無秒）＋ VIEW 排序改用 date+time。
//       三端寫入工具 tlFmtDateTime／calendarFmtDateTime／localTimeString；所有 cr/cp 正則放寬為
//       YYYY-MM-DD(?: HH:mm)?；VIEW 規則 dateCondMatch 仍只取日曆日比較；桌面／LITE 排序鍵正規化成
//       "YYYY-MM-DD HH:mm"（舊標記無時間＝當天 00:00），對外回傳仍保留原始標記值。⚠️ 改了
//       sticky-notes.js 與共享 /vsr.js，故四個主 ?v 戳＋sticky-notes.js 獨立戳都要刷為
//       lite-datetime-20261108；APP_VERSION/manifest 1.10.35→1.10.36。
// v221（2026-11-08）：cr / dl / cp 日期標記改渲染成「一顆長徽標」＝圖示＋月-日（小字），
//       完整「日期+時間」放 title（hover tooltip）與 data-date（VIEW 排序讀取）；底稿 [[...]] 原文零改動。
//       三端 tlDateMarkHtml / calDateMarkHtml / noteDateMarkElement 同口徑；便利貼兜底
//       normalizeViewNoteMarkers 改成插入 DOM 元素；三端 CSS 加 .ev-date-mark / .ev-date-mark-md；
//       排序補一條從 .ev-date-mark[data-date] 讀完整 date+time 的路徑（dl 不參與）。
//       ?v 戳刷為 lite-datebadge-20261108；APP_VERSION/manifest 1.10.36→1.10.37。
// v222（2026-11-08）：術語語法擴充 [[term:釋義:領域:發行]]，第 4 段「發行」渲染成青綠小膠囊
//       .tl-term-release（首發／發布等創作節點，便於整理作品開發履歷）；桌面／LITE 解析與
//       Glossary 完整度、搜尋 haystack 同步；三端 CSS 加樣式。四主 ?v 戳＋sticky-notes.js
//       獨立戳刷為 lite-termrelease-20261108；APP_VERSION/manifest 1.10.37→1.10.38。
// v223（2026-11-11）：鬧鈴標記 [[alert:內容:下次提醒:間隔:是/否]] 改渲染成「⏰ 徽標＋提醒內容原文＋
//       提醒時間（月-日 時:分）＋☐未完成／☑已完成」——原本它落到術語膠囊路徑，畫面顯示成「alert 1m 是」
//       這種記號名稱＋參數、把使用者寫的內容吞進 tooltip；現在 calRenderTermDefs 先攔 alert: 走
//       calAlertBadgeHtml（桌面 tlAlertBadgeHtml 同口径），間隔與完整年份改放 title，並把 alert 從術語
//       字典（calCollectTerms）排除；已完成整顆徽標壓低飽和與不透明度。
//       calendar-editor.js/style.css 改，bump 讓手機重拉；APP_VERSION/manifest 1.10.38→1.10.39。
// v224（2026-11-12）：alert 闹铃标记新格式将时间写为 YYYY-MM-DD HHmm（字段内不含冒号），
//       只解析 HHmm；新建、稍后提醒和完成操作统一写 HHmm，徽标显示仍格式化为 HH:mm。
//       calendar-editor.js 改，index.html 资源戳和 APP_VERSION/manifest 1.10.39→1.10.40。
// v225（2026-11-12）：alert 徽标显示每日/星期循环时间；calendar-editor.js 改，缓存版本升级。
// v226（2026-11-13）：alert 支持 anniversary YYYY-MM-DD HHmm 年度循环，徽标显示每年日期时间；
//       calendar-editor.js 与 index.html 资源戳更新，升级缓存确保 PWA 载入新版解析器。
// v227（2026-11-13）：alert 支持 w1,w3,w5 这类自选星期循环规则。
const CACHE_NAME = 'md-editor-lite-v227';
const ASSETS = [
  './',
  './index.html',
  './style.css',
  './lunar.js',
  './almanac-s2t.js',
  './app.js',
  './md-renderer.js',
  './md-table-grid.js',
  './calendar-editor.js',
  './sticky-settings.js',
  './sticky-notes.js',
  './manifest.json',
  './icon.svg',
  './icon-180.png',
  './icon-192.png',
  './icon-512.png'
];

// 網絡超時上限（ms）：超過就視為「連不上」，立刻回退快取，避免內網不可達時無限等待。
const FETCH_TIMEOUT = 3000;

// 包一層帶超時的 fetch：到時間未完成 → 拋錯（觸發回退快取）
function fetchWithTimeout(req, timeout) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout')), timeout);
    fetch(req)
      .then((res) => { clearTimeout(timer); resolve(res); })
      .catch((err) => { clearTimeout(timer); reject(err); });
  });
}

// 安裝事件 - 預緩存資源
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('緩存資源...');
        return cache.addAll(ASSETS);
      })
      .then(() => self.skipWaiting())
  );
});

// 激活事件 - 清理舊緩存
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

// 請求事件 - 緩存優先 + 後台更新；CDN 資源只緩存 GET 成功響應
self.addEventListener('fetch', (event) => {
  const req = event.request;

  // 只處理 GET 請求（POST/PUT 等直接放行）
  if (req.method !== 'GET') return;

  // 只處理同源資源或 https 的 CDN（其它跨域請求直接放行，避免干擾）
  const url = new URL(req.url);
  const isSameOrigin = url.origin === self.location.origin;
  const isCdn = /cdn\.jsdelivr\.net$/.test(url.hostname) || /unpkg\.com$/.test(url.hostname);
  if (!isSameOrigin && !isCdn) return;

  event.respondWith(
    (async () => {
      const cached = await caches.match(req);

      // 後台更新：有快取也要嘗試拉新（不阻塞回應），成功則覆寫快取
      const networkUpdate = fetchWithTimeout(req, FETCH_TIMEOUT)
        .then((response) => {
          if (response && response.status === 200 && (response.type === 'basic' || response.type === 'cors')) {
            const responseClone = response.clone();
            caches.open(CACHE_NAME)
              .then((cache) => cache.put(req, responseClone))
              .catch(() => {});
          }
          return response;
        })
        .catch(() => null); // 網絡失敗/超時 → 忽略，繼續用快取

      // 若有快取：立即回傳快取，同時讓網絡更新在背景跑（stale-while-revalidate）
      if (cached) {
        event.waitUntil(networkUpdate);
        return cached;
      }

      // 無快取：只能等網絡，失敗則 SPA 兜底到首頁
      try {
        return await networkUpdate;
      } catch (_) {
        if (req.mode === 'navigate') {
          const indexHtml = await caches.match('./index.html');
          if (indexHtml) return indexHtml;
        }
        return Response.error();
      }
    })()
  );
});

// 消息事件 - 處理來自頁面的消息
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  // 回報自身版本（CACHE_NAME 尾碼），頁面狀態列拿來顯示 sw.js 版本
  if (event.data && event.data.type === 'GET_VERSION') {
    const reply = { type: 'VERSION', cacheName: CACHE_NAME };
    if (event.ports && event.ports[0]) event.ports[0].postMessage(reply);
    else if (event.source) event.source.postMessage(reply);
  }
});
