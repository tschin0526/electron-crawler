/* ============================================================
 * 📅 Calendar 特性編輯器（手機 LITE 版的資料感知編輯器 #1）
 * ------------------------------------------------------------
 * 由 app.js 抽離成獨立程式文件（index.html 在 app.js 之後載入）。
 * 職責：calendar.md 的解析 / 序列化 / 列表·月·週·日渲染 / 表單 / 導航。
 * 宿主（app.js）提供：state / elements（含 cal* 字段）、escapeHtml、
 * showToast、editor 編輯緩衝、events-* 樣式。
 * 約定：本文件只含 calendar 邏輯；未來新增其它特性編輯器時各自一個
 * xxx-editor.js，互不干擾。
 * ============================================================ */
// ===== 📅 行程視圖（calendar 檔專用） =====
// calendar 檔＝行程應用（桌面版 calendar 插件）的數據文件：以 `## EVENT` 分隔的塊 + 反引號字段 + Remark 代碼塊。
// 解析邏輯與 calendar 插件的 parseMarkdownEvents 對齊。
//
// 🆕 「哪些檔案算 calendar 檔」：檔名以 calendar 開頭、副檔名 .md 的都算
//    —— calendar.md（正式檔）、calendar-event-draft.md（草稿）、calendar-2026.md（分包）…
//    全部自動以行程方式開啟/編輯，不必再改名成 calendar.md。
function isCalendarMd() {
  const name = String((state.currentFile && state.currentFile.name) || '').toLowerCase();
  return /^calendar.*\.md$/.test(name);
}

// 當前 calendar 檔名（統計表頭 / 空狀態文案用；拿不到就退回通用說法）
function calDocName() {
  const name = String((typeof state !== 'undefined' && state.currentFile && state.currentFile.name) || '');
  return name || 'calendar.md';
}

// 🗒 便利貼圖示（與桌面 calendar 清單行 .ev-sticky-flag 內用的 SVG 同一份，13×13 自帶黃紙配色，
//    深淺主題都不用另調色）：行程有 `- sticky: N`（N>0）時才在行內顯示，點它開便利貼並跳到該行程。
const CAL_STICKY_IC_SVG = '<svg class="ev-sticky-ic" viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><rect x="2.8" y="2.8" width="18.4" height="18.4" rx="2.2" fill="#FCEFA4"/><path d="M3 18.4c0 1.5 1.2 2.8 2.8 2.8h14.4v-2.8H3Z" fill="#F7E694"/><path d="M21.2 14.8v3.6c0 1.5-1.2 2.8-2.8 2.8h-3.6l6.4-6.4Z" fill="#FDF6C8"/><path d="M21.2 14.8 14.8 21.2" stroke="#E8CE7C" stroke-width=".7" stroke-linecap="round" fill="none"/><rect x="8.6" y="6.1" width="6.8" height="1.9" rx=".95" fill="#F0C860"/><rect x="9.1" y="6.5" width="5.8" height=".8" rx=".4" fill="#FFF3C0"/><path d="M6.6 11.4h10.8M6.6 14.2h7.6" stroke="#EBD88F" stroke-width=".9" stroke-linecap="round" fill="none"/></svg>';

// 顯示/隱藏「行程」頁簽；文件不是 calendar 檔時若停在行程視圖則退回分屏
function updateEventsTabVisibility() {
  if (!elements.tabEvents) return;
  const show = isCalendarMd();
  elements.tabEvents.style.display = show ? '' : 'none';
  if (!show && state.view === 'events') setView('split');
}

function parseCalendarArrField(s) {
  s = (s || '').trim();
  if (!s) return [];
  try { const a = JSON.parse(s); return Array.isArray(a) ? a : []; }
  catch (e) { return []; }
}
// ===== 標籤結構：{name, cat?, subcat?}；舊資料純字串自動升級 =====
function calTagName(t) { return (t && typeof t === 'object') ? (t.name || '') : (t || ''); }
function calTagCat(t) { return (t && typeof t === 'object') ? (t.cat || '') : ''; }
function calTagSubcat(t) { return (t && typeof t === 'object') ? (t.subcat || '') : ''; }
function calTagLabel(t) { const n = calTagName(t), c = calTagCat(t), s = calTagSubcat(t); return n + (c ? '·' + c : '') + (s ? '·' + s : ''); }
function calNormalizeTags(arr) {
  return (Array.isArray(arr) ? arr : []).map((t) => (t && typeof t === 'object')
    ? { name: t.name || '', cat: t.cat || '', subcat: t.subcat || '' }
    : { name: String(t || ''), cat: '', subcat: '' });
}
// ===== 標籤父階（樹形結構）：標籤名 → 父標籤名，集中存於 calendar.md 的 ## TAGS 區塊 =====
function calParseTagsMeta(md) {
  const map = {};
  const blocks = String(md || '').split(/^##[ \t]*TAGS[ \t]*$/m);
  if (blocks.length < 2) return map;
  let chunk = blocks[1];
  const cut = chunk.search(/^##[ \t]/m);
  if (cut >= 0) chunk = chunk.slice(0, cut);
  const m = chunk.match(/\{[\s\S]*\}/);
  if (m) { try { const o = JSON.parse(m[0]); if (o && typeof o === 'object') { for (const k in o) if (typeof o[k] === 'string') map[k] = o[k]; } } catch (e) {} }
  return map;
}
function calSerializeTagsMeta(map) {
  const clean = {};
  for (const k in map) if (k) clean[k] = (map[k] || '');
  return '## TAGS\n' + JSON.stringify(clean);
}
function calWriteTagsMeta(map) {
  let md = (elements.editor && elements.editor.value) || '';
  const body = calSerializeTagsMeta(map);
  const idx = md.search(/^##[ \t]*TAGS[ \t]*$/m);
  if (idx >= 0) {
    const after = md.slice(idx);
    const next = after.search(/\n##[ \t]/m);
    const end = next >= 0 ? idx + next : md.length;
    md = md.slice(0, idx) + body + md.slice(end);
  } else {
    md = md.replace(/\s*$/, '') + '\n\n' + body + '\n';
  }
  if (elements.editor) elements.editor.value = md;
}
function calTagMeta() { return calParseTagsMeta((elements.editor && elements.editor.value) || ''); }
function calTagParent(name) { return (calTagMeta()[name] || ''); }
function calTagChildren(name) { const m = calTagMeta(); return Object.keys(m).filter((k) => m[k] === name); }
function calAllTagNames() {
  const set = new Set();
  (state.calEvents || []).forEach((ev) => (ev.tags || []).forEach((t) => { const n = calTagName(t); if (n) set.add(n); }));
  const m = calTagMeta();
  Object.keys(m).forEach((k) => { if (k) set.add(k); });
  Object.keys(m).forEach((k) => { if (m[k]) set.add(m[k]); });
  return Array.from(set).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
}
function calIsDescendant(start, root, m) {
  m = m || calTagMeta();
  let cur = start, guard = 0;
  while (cur && guard++ < 1000) { if (cur === root) return true; cur = m[cur]; }
  return false;
}
function calSetTagParent(name, parent) {
  parent = (parent || '').trim();
  if (!name || parent === name) return false;
  const m = calTagMeta();
  if (parent && calIsDescendant(parent, name, m)) return false;
  if (parent) m[name] = parent; else delete m[name];
  calWriteTagsMeta(m);
  return true;
}
let calEvTagEditIndex = -1;   // 正在内联编辑分類的选中標籤下标（-1＝无）
let calEvTagEditLevel = 'cat';

// Remark / content 的圍欄：正文本身可能含 ``` 代碼圍欄 → 依 CommonMark 規則處理
//   寫入：圍欄長度取 max(3, 正文最長反引號串 + 1)，正文的 ``` 不可能閉合外層
//   讀取：開啟＝首個整行 3+ 反引號；閉合＝其後首個長度 ≥ 開啟長度的整行反引號
function calMdFence(text) {
  const runs = String(text || '').match(/`+/g) || [];
  let longest = 0;
  runs.forEach((r) => { if (r.length > longest) longest = r.length; });
  return '`'.repeat(Math.max(3, longest + 1));
}
// 回傳 { found, body, endAbs }：endAbs＝閉合圍欄末端在 rest 內的索引（找不到閉合為 -1）
function calExtractFenced(rest) {
  const text = String(rest || '');
  const re = /^(`{3,})[ \t]*\r?$/gm;
  let open = null;
  let m;
  while ((m = re.exec(text))) {
    if (!open) {
      open = { len: m[1].length, bodyStart: re.lastIndex };
      continue;
    }
    if (m[1].length >= open.len) {
      const body = text.slice(open.bodyStart, m.index).replace(/^\r?\n/, '').replace(/\r?\n$/, '');
      return { found: true, body: body.trim() === '' ? '' : body, endAbs: re.lastIndex };
    }
  }
  if (!open) return { found: false, body: '', endAbs: -1 };
  const body = text.slice(open.bodyStart).replace(/^\r?\n/, '');
  return { found: true, body: body.trim() === '' ? '' : body, endAbs: -1 };
}
function parseCalendarEventBlock(block, idx) {
  // 先把 Remark 代碼塊與字段頭部切開，避免備注內容干擾字段解析（與 calendar 插件一致）
  let remark = '';
  let head = block;
  const ri = block.indexOf('- Remark:');
  if (ri >= 0) {
    head = block.slice(0, ri);
    // ⚠️ 不能用非貪婪 /```([\s\S]*?)```/：備注正文含 ```（例如表格儲存格裡寫 ``` 或 ~~~）時
    //    會在正文首個 ``` 處提前閉合，後面整段被吞掉（2026-10-21 手機端回報；桌面 2026-09-30 已修）
    remark = calExtractFenced(block.slice(ri + '- Remark:'.length)).body;
  }
  const get = (name) => {
    const m = head.match(new RegExp('- ' + name + ': `([^`]*)`'));
    return m ? m[1] : '';
  };
  const title = get('title');
  if (!title) return null;
  let color = get('color').trim();
  if (color.length >= 2 && color[0] === '"' && color[color.length - 1] === '"') color = color.slice(1, -1);
  return {
    idx,
    uid: 'evp' + idx,  // 确定性 uid：同一內容多次解析結果一致，供編輯/刪除定位
    title,
    date: get('date'),
    endDate: get('endDate'),
    spanDisplay: get('spanDisplay') || 'daily',
    allDay: get('allDay') === 'true',
    // 完成狀態：舊檔案沒有 - done 欄位 → 視為未設定 = 未完成
    done: get('done') === 'true',
    startTime: get('startTime'),
    endTime: get('endTime'),
    location: get('location'),
    color: color || '#3b82f6',
    tags: calNormalizeTags(parseCalendarArrField(get('tags'))),
    // 修復：此前缺讀 todoIds，往返保存會把 calendar 插件寫入的關聯卡片清空
    todoIds: parseCalendarArrField(get('todoIds')),
    // ## HOLIDAY 比 ## EVENT 多一個 holidayType 字段（workday/holiday/festival），事件解析為空字符串即可
    holidayType: get('holidayType') || '',
    // 地區：cn 中國大陸 / hk 香港 / tw 台灣 / us 美國（可擴展）；缺省 '' 渲染時回退 cn（向後兼容舊數據）
    region: get('region') || '',
    notes: remark,
    // ===== ## EVENT(REPEAT) 重複事件字段（空＝不重複）=====
    repeatMode: get('repeatMode') || '',
    repeatInterval: get('repeatInterval') || '',
    repeatWeekDay: parseCalendarArrField(get('repeatWeekDay')),
    repeatMonthDay: get('repeatMonthDay') || '',
    repeatYearMonthDay: get('repeatYearMonthDay') || '',
    repeatEndType: get('repeatEndType') || '',
    repeatEndValue: get('repeatEndValue') || '',
    repeatExcludeDates: parseCalendarArrField(get('repeatExcludeDates')),
    // 🆕 桌面便利贴：instance 数（缺省 0 = 不显示为便利贴）；同事件可同时显示多张
    sticky: parseInt(get('sticky'), 10) || 0
  };
}

function parseCalendarEvents(md) {
  if (!md) return [];
  const events = [];
  const blocks = String(md).split(/^##[ \t]*EVENT(?:\([^)]*\))?[ \t]*$/m);
  for (let i = 0; i < blocks.length; i++) {
    // ⚠️ 切塊只按 ## EVENT → 本塊尾巴會黏著緊隨其後的 ## HOLIDAY / ## DIARY 塊。
    //    必須先在該標記處截斷，否則 remark / holidayType / region 等會被後面的塊污染；
    //    更重要的是：## DIARY 含 - title / - date，會被 parseCalendarEventBlock 誤當成行程事件（帶勾選框）參與渲染（2026-10-17 修復）
    const cut = blocks[i].search(/^##[ \t]*(HOLIDAY|DIARY)[ \t]*$/m);
    const ev = parseCalendarEventBlock(cut >= 0 ? blocks[i].slice(0, cut) : blocks[i], i);
    if (ev) events.push(ev);
  }
  return events;
}

// ========== 📎 多檔聯運（手機 LITE 版：iCloud 無法一次多選，改以「分段多次加入」方式併入多個 calendar*.md）==========
// 設計對齊桌面 include 機制：
//   • 主檔＝當前編輯緩衝（elements.editor.value）的 calendar*.md，可編輯、可存回；
//   • 加入的檔案＝只讀來源（ro），只併入顯示，絕不寫回主檔緩衝。
//   • 每個 include 事件打 ro:true + src:檔名，uid 加 'ro-<序>-' 前綴避免與主檔 evpN 撞名。
//   • 主檔緩衝重解析（saveEventForm/deleteEventByUid/applyEventsToEditor）一律只用主檔內容，故 include 永遠不會被改寫。

// 解析某個 include 檔內容，標記 ro + 改寫 uid，使其與主檔/其它 include 的 uid 全域名唯一
//   ⚠️ 與桌面同一口徑：ro 只鎖「行程本體」（標題／日期／刪除／完成），**便利貼內容（Remark）可以改**，
//      改完寫回這個來源檔。所以要留 roFileIdx / roBlockIdx 兩個定位資訊：
//      roBlockIdx＝該事件在檔案裡是第幾個 ## EVENT 標記（與 parseCalendarEvents 的 split 序同一個數，
//      uid 的 evpN 用的就是這個 N，含無標題塊），寫回時靠它精準命中原始區塊，不重排整份檔案。
function calParseIncludeContent(content, fileIdx, fileName, fileDirty) {
  const events = parseCalendarEvents(content).map((ev) => {
    const rawIdx = parseInt(String(ev.uid).replace(/^evp/, ''), 10);
    ev.ro = true;
    ev.src = fileName;
    ev.roFileIdx = fileIdx;
    ev.roBlockIdx = Number.isInteger(rawIdx) ? rawIdx : -1;
    ev.roDirty = !!fileDirty;
    ev.uid = 'ro-' + fileIdx + '-' + ev.uid;
    return ev;
  });
  const holidays = parseCalendarHolidays(content).map((h) => {
    h.ro = true; h.src = fileName; h.uid = 'ro-' + fileIdx + '-h-' + h.uid; return h;
  });
  const diaries = parseCalendarDiaries(content).map((d) => {
    d.ro = true; d.src = fileName; return d;
  });
  return { events, holidays, diaries };
}

// 單一可信來源：把主檔 + 所有 include 併成 state.calEvents / calHolidays / calDiaries（含 ro 標記）
// 所有「顯示」路徑都走這裡；「編輯/存檔」路徑仍只用主檔內容（見 saveEventForm 等）。
function calRefreshAll() {
  const content = (elements.editor && elements.editor.value) || '';
  let events = parseCalendarEvents(content);
  let holidays = parseCalendarHolidays(content);
  let diaries = [];
  (state.calIncludeFiles || []).forEach((inc, fi) => {
    const p = calParseIncludeContent(inc.content, fi, inc.name, inc.dirty);
    events = events.concat(p.events);
    holidays = holidays.concat(p.holidays);
    if (DIARY_FEATURE_ENABLED) diaries = diaries.concat(p.diaries);
  });
  state.calEvents = events;
  calHolidays = holidays;
  calDiaries = diaries;
}

// 註：原本的 calAddIncludeFile（單檔加入 / 同檔名刷新）已移除——
//   2026-10-23 起「開啟」一次多選就是唯一入口，整組替換（calReplaceIncludes）已涵蓋「重選同一批」的刷新情境。

// 「開啟」一次多選時決定誰是主檔（純函數，便於單測；app.js 只負責把檔名映射回 File）
//   規則（使用者 2026-10-23 定）：calendar.md（不分大小寫）優先當主檔＝行程本體可編輯；
//   其餘 calendar*.md 一律只讀聯運（行程不可編輯，只有便利貼內容可改）；
//   選單裡沒有 calendar.md 時用第一個 calendar*.md 當主檔（否則整組都只讀，沒人能編輯）。
function calPlanOpenSet(names) {
  const list = (Array.isArray(names) ? names : []).map((n) => String(n || ''));
  const calendars = list.filter((n) => /^calendar.*\.md$/i.test(n));
  const others = list.filter((n) => calendars.indexOf(n) < 0);
  if (!calendars.length) return { main: '', includes: [], others };
  const main = calendars.find((n) => /^calendar\.md$/i.test(n)) || calendars[0];
  return { main, includes: calendars.filter((n) => n !== main), others };
}

// 用「剛選的這一組」整組替換聯運清單（「開啟」多選時用）：不保留舊快取裡的檔案，
//   否則舊檔會混進新組合。回傳 false＝使用者選擇保留既有修改（呼叫端要中止後續提示）。
//   ⚠️ 修改只存在本機快取，整組替換會蓋掉還沒匯出的修改 → 有 dirty 時必須先確認（預設保留）。
function calReplaceIncludes(list) {
  const clean = (Array.isArray(list) ? list : []).filter((f) => f && f.name && typeof f.content === 'string');
  const dirty = (state.calIncludeFiles || []).filter((f) => f.dirty);
  if (dirty.length) {
    const names = dirty.map((f) => f.name).join('、');
    const okToReplace = window.confirm(
      '有 ' + dirty.length + ' 個聯運檔的修改還沒匯出寫回原檔：\n' + names +
      '\n\n重新開啟會用檔案內容蓋掉這些修改（本機快取）。\n\n要繼續嗎？'
    );
    if (!okToReplace) {
      showToast('已保留現有聯運檔與未匯出的修改', 'info');
      return false;
    }
  }
  state.calIncludeFiles = clean.map((f) => ({ name: f.name, content: f.content, dirty: !!f.dirty }));
  calPersistIncludes();
  calRenderIncludeBar();
  // 🐞 修復：多选開啟時不滾到今天——openSingleFile 那次的渲染已消費掉 calAutoScrollToTodayPending
  //   （startup 守衛只觸發一次），隨後這裡重建列表把滾動重置到頂部，flag 已是 false → 不再滾今天。
  //   在「最終併入後」的渲染前重設 flag，讓這次渲染滾到今天（與單檔開啟行為一致）。
  calAutoScrollToTodayPending = true;
  renderEventsContent();
  if (typeof updateStatus === 'function') updateStatus();
  return true;
}

// 從聯運清單移除（確認後才移除；不刪檔案本身）
function calRemoveIncludeFile(name) {
  if (!window.confirm('從聯運清單移除「' + name + '」？\n\n（僅從本次顯示移除，不會刪除檔案本身；已修改的內容仍在本機快取裡）')) return;
  state.calIncludeFiles = (state.calIncludeFiles || []).filter((f) => f.name !== name);
  calPersistIncludes();
  calRenderIncludeBar();
  renderEventsContent();
  if (typeof updateStatus === 'function') updateStatus();
}

// 目前有修改還沒寫回原檔的聯運檔（狀態列／頂欄「保存」按鈕靠它判斷，否則只改聯運檔時保存鍵是灰的）
function calPendingIncludes() {
  return (state.calIncludeFiles || []).filter((f) => f.dirty);
}

// 行動端投遞：把一批檔案一次交給系統（iOS 的「儲存到檔案」可整批存進同一資料夾）
//   多檔且支援 canShare → 一次 share；否則逐檔走 saveViaMobile（它自己會先試分享再退回下載）
// 🛟 行動端（iOS）逐檔交付：
//   iOS 系統分享面板的「儲存到檔案」擴展在 **多檔批量** 模式下不會逐檔彈「替換」確認，
//   而是直接把同名檔加數字後綴存成新檔（calendar.md → calendar 2.md）。
//   解決方案：逐檔調 navigator.share，每次只塞 1 個檔——這樣每個檔都會單獨彈面板，
//   用戶可在每次面板裡選原資料夾 + 確認替換。代價是面板要開 N 次，但結果正確。
//
//   退後路徑（fallback）：`canShareFiles()` 不可用時逐檔走 downloadFile（每個產生一個下載項）。
//
//   回傳 how：'shareMulti'（逐檔各彈一次分享面板）| 'fallback'（逐檔下載）| 'none'（空 list）
async function calDeliverFilesMobile(list) {
  if (!list || !list.length) return 'none';
  const mk = (f) => new File([f.content], f.name, { type: mimeFor(f.name) });

  // 單檔可以走原本的快速路徑——一次面板就解決
  if (list.length === 1) {
    if (canShareFiles()) {
      await navigator.share({ files: [mk(list[0])] });
      return 'share';
    }
    downloadFile(list[0].content, list[0].name);
    return 'downloaded';
  }

  // 多檔：逐檔交付（iOS 批量模式不彈替換確認是硬傷，只能這樣繞）
  let usingShare = false;
  if (canShareFiles()) {
    // 探測是否真的能一次 share 全部檔案（部分 Android Safari 可能支援，但 iOS 不行）
    const multiOk = typeof navigator.canShare === 'function'
      && navigator.canShare({ files: list.map(mk) });
    if (multiOk) {
      // 多檔 share 是可行的（iOS 會把全部檔列在面板裡），但「儲存到檔案」擴展
      // 還是會不彈替換確認——所以寧願逐檔，結果才是用戶想要的。
      usingShare = true;
    }
  }

  for (const f of list) {
    if (usingShare) {
      await navigator.share({ files: [mk(f)] });   // 每檔各開一次面板，用戶選替換
    } else {
      downloadFile(f.content, f.name);              // 退後：每檔一個下載項
    }
  }
  return usingShare ? 'shareMulti' : 'fallback';
}

// 匯出聯運檔（可一次多檔，也可把主檔一起塞進同一批）——真正把內容交回檔案系統的入口。
//   桌面 Chromium：逐檔 showSaveFilePicker 直接寫回，不產生下載檔；
//   行動端：一次分享多檔 → 分享面板「儲存到檔案」→ 選原資料夾 → 覆蓋。取消（AbortError）＝整批都不標為已存。
//   opts.extra：額外要一起交出去的檔案 [{name, content}]（主檔用；它們不屬於 include，不在此改 dirty）
//   回傳 { saved:[檔名], how, canceled }
async function calExportIncludes(names, opts) {
  opts = opts || {};
  const want = (names && names.length) ? names : calPendingIncludes().map((f) => f.name);
  const files = (state.calIncludeFiles || []).filter((f) => want.indexOf(f.name) >= 0);
  const extra = Array.isArray(opts.extra) ? opts.extra.filter((f) => f && f.name) : [];
  if (!files.length && !extra.length) return { saved: [], how: 'none', canceled: false };
  const canPick = ('showSaveFilePicker' in window) && (typeof window.showSaveFilePicker === 'function');
  const saved = [];
  let how = 'none';
  let canceled = false;
  try {
    if (canPick) {
      how = 'picker';
      for (const f of files) {
        try {
          const handle = await window.showSaveFilePicker({ suggestedName: f.name });
          const w = await handle.createWritable();
          await w.write(new Blob([f.content], { type: mimeFor(f.name) + ';charset=utf-8' }));
          await w.close();
          f.dirty = false;
          saved.push(f.name);
        } catch (err) {
          if (err && err.name === 'AbortError') { canceled = true; break; }   // 取消＝後面的不寫，保留 dirty
          throw err;
        }
      }
      // 🆕 extras（例如便利貼設定 JSON）在桌面也要逐檔寫回；主檔由 handleSave 自己存，不會出現在這裡
      if (!canceled) {
        for (const f of extra) {
          try {
            const handle = await window.showSaveFilePicker({ suggestedName: f.name });
            const w = await handle.createWritable();
            await w.write(new Blob([f.content], { type: mimeFor(f.name) + ';charset=utf-8' }));
            await w.close();
            saved.push(f.name);
          } catch (err) {
            if (err && err.name === 'AbortError') { canceled = true; break; }
            throw err;
          }
        }
      }
    } else {
      // 主檔排最前面：分享面板裡的順序＝使用者剛剛在編輯的那份最先看到
      how = await calDeliverFilesMobile(extra.map((f) => ({ name: f.name, content: f.content }))
        .concat(files.map((f) => ({ name: f.name, content: f.content }))));
      files.forEach((f) => { f.dirty = false; saved.push(f.name); });
      extra.forEach((f) => { saved.push(f.name); });
    }
  } catch (err) {
    if (err && err.name === 'AbortError') canceled = true;
    else {
      console.error('匯出聯運檔失敗:', err);
      showToast('匯出失敗：' + (err && err.message ? err.message : err), 'error');
    }
  } finally {
    calPersistIncludes();
    calRenderIncludeBar();
    renderEventsContent();
    if (typeof calStickyRefreshIfOpen === 'function') calStickyRefreshIfOpen();
    if (typeof updateStatus === 'function') updateStatus();
  }
  const n = saved.length;
  if (opts.silent) return { saved, how, canceled };
  if (canceled && !saved.length) {
    showToast('已取消匯出，修改仍保留在本機（下次仍可再存）', 'info');
  } else if (n > 0) {
    if (how === 'picker') showToast('已寫回 ' + n + ' 個檔案', 'success');
    else if (how === 'shareMulti') showToast('已送出 ' + n + ' 個檔案：在分享面板選「儲存到檔案」→ 選原資料夾 → 覆蓋', 'success');
    else if (how === 'share') showToast('已送出「' + (saved[0] || '') + '」：選「儲存到檔案」→ 選原位置 → 覆蓋', 'success');
    else showToast('已逐檔送出 ' + n + ' 個檔案：逐一在分享面板選「儲存到檔案」→ 選原位置 → 覆蓋', 'success');
  }
  return { saved, how, canceled };
}

// 單檔匯出（📎 chip 上的 ↓ 走這條）
async function calSaveIncludeFile(name) {
  await calExportIncludes([name]);
}

// 渲染聯運清單（chip + ✕）：有就地修改（dirty）的檔加 ● 與 ↓ 匯出
//   現在改顯示在 combo 菜單裡（不再佔用工具列下方畫面空間）。
//   同時驅動：
//     1) combo 菜單「📎 聯運檔案」toggle — 顯示總數 + dirty 紅色角標
//     2) 頂部工具列「保存」按鈕 — dirty 紅色角標（讓用戶隨時知道還有幾個檔要存）
function calRenderIncludeBar() {
  const bar = document.getElementById('cal-include-bar');
  const panel = document.getElementById('cal-include-panel');
  const body = document.getElementById('cal-include-body');
  const count = document.getElementById('cal-include-count');
  const toggle = document.getElementById('cal-include-toggle');
  const saveBadge = document.getElementById('btn-save-badge');   // 🆕 頂欄保存按鈕角標
  const calStickySaveBadge = document.getElementById('calStickySaveBadge');   // 🆕 ☰ 選單保存按鈕角標（與頂欄同來源）
  const files = state.calIncludeFiles || [];
  // 🆕 角標來源 = include dirty 數 + 主檔 dirty（state.isDirty 來自 app.js 的 textarea input）
  //    ＋ 便利貼設定 dirty（與上次寫回的 sticky-notes-settings JSON 不同）
  const includeDirtyCount = files.filter((f) => f.dirty).length;
  const mainDirty = (typeof state !== 'undefined' && state.isDirty) ? 1 : 0;
  const stickyDirty = (typeof calStickySettingsDirty === 'function' && calStickySettingsDirty()) ? 1 : 0;
  const dirtyCount = includeDirtyCount + mainDirty + stickyDirty;

  // 🆕 頂欄「保存」按鈕角標：顯示總 dirty 數量（主檔 + include），0 則隱藏
  if (saveBadge) {
    if (dirtyCount > 0) {
      saveBadge.textContent = dirtyCount > 99 ? '99+' : String(dirtyCount);
      saveBadge.style.display = '';
    } else {
      saveBadge.style.display = 'none';
    }
  }
  // 🆕 ☰ 選單「💾 保存」角標：與頂欄保存鍵共用同一份 dirtyCount（主檔＋include＋便利貼設定）
  if (calStickySaveBadge) {
    if (dirtyCount > 0) {
      calStickySaveBadge.textContent = dirtyCount > 99 ? '99+' : String(dirtyCount);
      calStickySaveBadge.style.display = '';
    } else {
      calStickySaveBadge.style.display = 'none';
    }
  }

  // combo toggle 上的 cal-include-count：紅色圓角角標（CSS 已設 badge 樣式）
  if (count) {
    if (dirtyCount > 0) {
      count.textContent = dirtyCount > 99 ? '99+' : String(dirtyCount);
      count.classList.add('has-dirty');
    } else {
      count.textContent = '× ' + files.length;   // 無 dirty 時顯示總數（純文字）
      count.classList.remove('has-dirty');
    }
  }

  // 面板顯隱邏輯（維持舊行為：有 include 檔才顯示面板）
  if (!panel && bar) {
    if (!files.length) { bar.style.display = 'none'; bar.innerHTML = ''; return; }
    bar.style.display = '';
  } else if (panel) {
    if (!files.length) { panel.style.display = 'none'; bar && (bar.innerHTML = ''); if (body) body.style.display = 'none'; return; }
    panel.style.display = '';
    const anyDirty = files.some((f) => f.dirty);
    if (toggle) toggle.title = '聯運檔案 ' + files.length + ' 個' +
      (anyDirty ? '（有 ' + dirtyCount + ' 個待匯出寫回）' : '；便利貼內容可改');
  } else {
    return;
  }

  // chip 清單（combo body 裡）
  if (!bar) return;
  const chip = (f) => {
    const dirty = !!f.dirty;
    const title = dirty
      ? '已在便利貼中修改（只存本機快取）——按 ↓ 匯出檔案，覆寫原檔後才會真正落回 iCloud'
      : '來源檔：' + f.name + '（行程本體不可編輯；便利貼內容可修改）';
    return '<span class="ev-ib-chip' + (dirty ? ' dirty' : '') + '" title="' + escapeHtml(title) + '">' +
      '<span class="ev-ib-name">' + escapeHtml(f.name) + '</span>' +
      (dirty ? '<span class="ev-ib-dirty" aria-label="有未寫回的修改">●</span>' : '') +
      (dirty ? '<button type="button" class="ev-ib-save" data-ib-save="' + escapeHtml(f.name) + '" title="匯出這個檔案（覆寫原檔）" aria-label="匯出">↓</button>' : '') +
      '<button type="button" class="ev-ib-x" data-ib-x="' + escapeHtml(f.name) + '" aria-label="移除">✕</button></span>';
  };
  const anyDirty = files.some((f) => f.dirty);
  bar.innerHTML = '<span class="ev-ib-label">📎 聯運檔案</span>' + files.map(chip).join('') +
    '<span class="ev-ib-hint">' + (anyDirty ? '按頂欄「保存」或 chip 的 ↓ 匯出寫回' : '便利貼內容可改') + '</span>';
}

// 內容快取到 localStorage（按主檔名索引），重新開啟主檔可免於 iCloud 重選
//   dirty 一併存：重開後 chip 仍會提醒「這些修改還沒匯出寫回檔案」
function calPersistIncludes() {
  try {
    const main = (state.currentFile && state.currentFile.name) || '';
    if (!main) return;
    const store = JSON.parse(localStorage.getItem('md-editor-cal-includes') || '{}');
    store[main] = (state.calIncludeFiles || []).map((f) => ({ name: f.name, content: f.content, dirty: !!f.dirty }));
    localStorage.setItem('md-editor-cal-includes', JSON.stringify(store));
  } catch (e) { /* 容量超限 / 儲存禁用 → 靜默忽略，僅影響下次自動重併 */ }
}

// 開啟主檔時還原其曾加入過的 include（僅從快取讀內容，不觸發檔案選擇器）
function calRestoreIncludes(mainName) {
  state.calIncludeFiles = [];
  try {
    const store = JSON.parse(localStorage.getItem('md-editor-cal-includes') || '{}');
    const list = store[mainName] || [];
    state.calIncludeFiles = list.map((f) => ({ name: f.name, content: f.content, dirty: !!f.dirty }));
  } catch (e) { state.calIncludeFiles = []; }
  calRenderIncludeBar();
}

// 只讀事件圖標（⛔）；title 帶來源檔名，便於辨識
function calRoIcon(ev) {
  if (!ev || !ev.ro) return '';
  const src = ev.src ? '：' + escapeHtml(ev.src) : '';
  return '<span class="ev-ro-icon" title="來自被包含的檔案' + src + '：行程本體（標題／日期／刪除）與備註在行程檢視皆為唯讀，便利貼內容可修改">⛔</span>';
}

// ===== ✍️ 便利貼內容（Remark）寫回 =====
// 與桌面 `tlReplaceRemarkInBlock` / `tlSaveIncludedEventNotes` 同一套做法：
//   ① 主檔事件 → 照舊序列化整份回編輯緩衝（applyEventsToEditor）；
//   ② include（ro）事件 → 只改來源檔「那一個 ## EVENT 區塊」的 Remark，其餘原文逐字保留
//      （絕不整份重畫：來源檔可能有 ## TAGS / ## INCLUDE / 手寫註解，重畫會清掉）。
// 定位＝roBlockIdx（parseCalendarEvents 的 split 序，evpN 的 N）。定位不到／標題對不上就寧可不寫。

// 取第 blockIdx 個 ## EVENT 區塊在原文中的 [start, end)
function calEventBlockRange(content, blockIdx) {
  const text = String(content || '');
  if (!Number.isInteger(blockIdx) || blockIdx < 1) return null;
  const re = /^##[ \t]*EVENT(?:\([^)]*\))?[ \t]*$/gm;
  const starts = [];
  let m;
  while ((m = re.exec(text))) starts.push(m.index);
  const s = starts[blockIdx - 1];
  if (s === undefined) return null;
  // 區塊結束＝下一個 ## 標題（不限 EVENT，HOLIDAY/DIARY/TAGS/INCLUDE 都算）或檔尾
  const nr = text.slice(s + 1).search(/^##[ \t]/m);
  const e = nr >= 0 ? s + 1 + nr : text.length;
  return { start: s, end: e };
}

// 把區塊內的 Remark 換成 notes；沒有 Remark 欄位就補在區塊末尾（塊尾空行保持原樣）
function calReplaceRemarkInBlock(blockText, notes) {
  const nl = '\n';
  const lines = String(blockText == null ? '' : blockText).replace(/\r\n/g, nl).split(nl);
  const newNotes = String(notes == null ? '' : notes);
  const fence = calMdFence(newNotes);
  const repl = [fence].concat(newNotes === '' ? [''] : newNotes.split(nl)).concat([fence]);
  const ri = lines.findIndex((l) => /^-[ \t]*Remark:/.test(l));
  if (ri < 0) {
    let at = lines.length;
    while (at > 0 && lines[at - 1].trim() === '') at--;
    return lines.slice(0, at).concat(['- Remark:'], repl, lines.slice(at)).join(nl);
  }
  // 圍欄正文範圍：`- Remark:` 下一行起是開啟圍欄；找不到閉合就吃到區塊尾
  let end = ri + 1;
  const open = (lines[ri + 1] || '').match(/^(`{3,})[ \t]*$/);
  if (open) {
    const closeRe = new RegExp('^`{' + open[1].length + ',}[ \\t]*$');
    let k = ri + 2;
    while (k < lines.length && !closeRe.test(lines[k])) k++;
    end = Math.min(k + 1, lines.length);
  }
  return lines.slice(0, ri + 1).concat(repl, lines.slice(end)).join(nl);
}

// 便利貼內容提交：ro → 寫回來源檔那一塊（內容存本機快取，需匯出才落回檔案）；非 ro → 照舊序列化
function calCommitEventNotes(ev) {
  if (!ev) return false;
  if (!ev.ro) { applyEventsToEditor(); return true; }
  const files = state.calIncludeFiles || [];
  let inc = (Number.isInteger(ev.roFileIdx) && files[ev.roFileIdx]) ? files[ev.roFileIdx] : null;
  if (!inc || inc.name !== ev.src) inc = files.find((f) => f.name === ev.src) || null;
  if (!inc) { showToast('找不到來源檔案「' + String(ev.src || '') + '」，已取消寫入', 'error'); return false; }
  const range = calEventBlockRange(inc.content, ev.roBlockIdx);
  if (!range) { showToast('來源檔的區塊位置已變動，已取消寫入', 'error'); return false; }
  const blockText = inc.content.slice(range.start, range.end);
  // 安全閥：命中的區塊必須還是同一條行程（標題一致），否則寧可不寫，避免把 A 的備註蓋到 B
  const tm = blockText.match(/- title: `([^`]*)`/);
  if (!tm || tm[1] !== String(ev.title || '')) {
    showToast('來源檔的區塊內容已變動，已取消寫入', 'error');
    return false;
  }
  inc.content = inc.content.slice(0, range.start) + calReplaceRemarkInBlock(blockText, ev.notes) + inc.content.slice(range.end);
  inc.dirty = true;   // 只存在本機快取；chip 上打 ● 並出現 ↓，提醒使用者匯出寫回
  calPersistIncludes();
  renderEventsContent();
  if (typeof calStickyRefreshIfOpen === 'function') calStickyRefreshIfOpen();
  // 主档路徑由 applyEventsToEditor 內的 updateStatus 處理；ro 路徑要自己叫，
  // 否則頂欄「保存」仍是灰的 → 使用者以為沒東西可存（2026-10-23 實測回饋）
  if (typeof updateStatus === 'function') updateStatus();
  return true;
}

// 提交後的提示文案：主檔＝回編輯緩衝、等頂欄「保存」落盤；include＝已改來源檔本機副本、等 ↓ 匯出
//   （把「按保存存回文件」這種對 include 不成立的說法集中換掉，免得六個呼叫點各寫一份）
function calNotesHint(ev, mainMsg) {
  const msg = String(mainMsg || '');
  if (!ev || !ev.ro) return msg;
  const stripped = msg.replace(/，按「保存」存回文件$/, '').replace(/；?按頂欄「保存」才存回文件$/, '');
  return stripped + '，已寫入「' + (ev.src || '來源檔') + '」（本機快取，按 📎 清單的 ↓ 匯出寫回檔案）';
}

// ## HOLIDAY 解析結果（與 ## EVENT 同結構，多 holidayType 字段）；僅列表/日志視圖顯示，不進時間網格/月格 chip
let calHolidays = [];
// ## DIARY 解析結果（每天一條，keyed by date）；行事曆日期旁顯示日記按鈕，有則打勾
let calDiaries = [];
// 日記功能已停用；後續日曆內容請使用 VIEW 便利貼承載。
const DIARY_FEATURE_ENABLED = false;
// ## HOLIDAY：與 ## EVENT 同一套字段（多 holidayType），僅分割符不同；複用 parseCalendarEventBlock 解析（無 title 的塊會被跳過）
// ⚠️ 從 i=1 開始：split 後 blocks[0] 是「第一個 ## HOLIDAY 之前的所有內容」（通常含 ## EVENT 塊），
//    那段裡的 - title 會被誤當成 holiday；holiday 必然跟在它自己的 ## HOLIDAY 標記之後，故跳過 blocks[0] 即正確。
function parseCalendarHolidays(md) {
  if (!md) return [];
  const out = [];
  const blocks = String(md).split(/^##[ \t]*HOLIDAY[ \t]*$/m);
  for (let i = 1; i < blocks.length; i++) {
    // 同理：假日塊尾巴可能黏著後面的 ## EVENT（含 (REPEAT)）/ ## DIARY 塊 → 先在該標記處截斷
    //    （## DIARY 含 - title / - date，不截斷會被誤當成假日渲染）
    const cut = blocks[i].search(/^##[ \t]*(EVENT(?:\([^)]*\))?|DIARY)[ \t]*$/m);
    const h = parseCalendarEventBlock(cut >= 0 ? blocks[i].slice(0, cut) : blocks[i], i);
    if (h) out.push(h);
  }
  return out;
}

// ===== ## DIARY 解析 / 序列化（每天一條，keyed by date；行事曆日期旁按鈕打勾）=====
// 塊格式（桌面 + LITE 共用）：
// ## DIARY
// - date: `2026-09-20`
// - title: `今日交易复盘`
// - mood: `平穩`
// - tags: `["投資","自我總結"]`
// - weather: `多雲`
// - content:        ← 多行正文走代碼塊（與 Remark 同約定：按整行圍欄長度截取，正文含 ``` 也不會提前閉合）
// ```
// 今天大盤震盪，持倉觀察。
// ```
// - remark: `晚間復盤再核對數據`
function parseCalendarDiaryBlock(block, idx) {
  let content = '';
  let head = block;
  const ci = block.indexOf('- content:');
  if (ci >= 0) {
    const base = ci + '- content:'.length;
    // 與 Remark 同一個坑：正文含 ``` 時不能在首個 ``` 處提前閉合
    const f = calExtractFenced(block.slice(base));
    if (f.found) {
      content = f.body;
      // ⚠️ 只摘掉整段 content 區（含 - content: 與首尾圍欄），讓 remark 等「位於 content 之後」的欄位不被它隔斷而丟失
      if (f.endAbs >= 0) head = block.slice(0, ci) + block.slice(base + f.endAbs);
    }
  }
  const get = (name) => {
    const m = head.match(new RegExp('- ' + name + ': `([^`]*)`'));
    return m ? m[1] : '';
  };
  const date = get('date');
  if (!date) return null;       // 無日期的塊無效（日記必須掛在某個日期上）
  let tags = [];
  try { const a = JSON.parse(get('tags') || '[]'); if (Array.isArray(a)) tags = calNormalizeTags(a); } catch (e) {}
  return {
    idx,
    date,
    title: get('title'),
    mood: get('mood'),
    tags,
    weather: get('weather'),
    content,
    remark: get('remark')
  };
}
function parseCalendarDiaries(md) {
  if (!md) return [];
  const out = [];
  const blocks = String(md).split(/^##[ \t]*DIARY[ \t]*$/m);
  for (let i = 1; i < blocks.length; i++) {
    // ⚠️ 塊尾可能黏著緊隨其後的 ## EVENT / ## HOLIDAY / ## DIARY → 在最靠前的標記處截斷
    const cut = blocks[i].search(/^##[ \t]*(EVENT(?:\([^)]*\))?|HOLIDAY|DIARY)[ \t]*$/m);
    const d = parseCalendarDiaryBlock(cut >= 0 ? blocks[i].slice(0, cut) : blocks[i], i);
    if (d) out.push(d);
  }
  return out;
}
function calDiaryToMarkdown(d) {
  const tagsJson = JSON.stringify(Array.isArray(d.tags) ? d.tags : []);
  let s = '## DIARY \n';
  s += '- date: `' + calMdEscape(d.date) + '`\n';
  s += '- title: `' + calMdEscape(d.title || '') + '`\n';
  s += '- mood: `' + calMdEscape(d.mood || '') + '`\n';
  s += '- tags: `' + tagsJson + '`\n';
  s += '- weather: `' + calMdEscape(d.weather || '') + '`\n';
  const contentFence = calMdFence(d.content);
  s += '- content:\n' + contentFence + '\n' + String(d.content || '') + '\n' + contentFence + '\n';
  s += '- remark: `' + calMdEscape(d.remark || '') + '`\n';
  return s;
}
function calDiaryOnDate(dateStr) {
  if (!DIARY_FEATURE_ENABLED) return null;
  if (!calDiaries || !calDiaries.length) return null;
  return calDiaries.find((x) => x.date === dateStr) || null;
}
// 📕「當天有日記」標記（月格日期數字旁、週/日檢視欄頭日期旁**共用**，一個入口一處樣式）。
// ⚠️ 純顯示、故意不掛 onclick：這些格子單擊＝選日，在 ~12px 的小圖標上再開一個點擊熱區只會造成誤點；
//    要看/改日記 → 點格子選日，下方明細的日期標題上有可點的日記按鈕 .ev-day-diary。
function calDiaryMarkHtml(date) {
  const dy = calDiaryOnDate(date);
  if (!dy) return '';
  return '<span class="ev-diary-mark" title="' + escapeHtml('日記：' + (dy.title || '（無標題）')) + '">\ud83d\udcd5</span>';
}

function calendarFmtDate(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
// 🆕 2026-11-08：cp 存檔用「本機 date + 本機 HH:mm」（24H、無秒）；只給 calNoteCheckTransform 呼叫點。
function calendarFmtDateTime(d) {
  return calendarFmtDate(d) + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

function calendarTimeToMin(t) {
  const m = String(t || '').match(/^(\d{1,2}):(\d{2})/);
  return m ? (+m[1]) * 60 + (+m[2]) : 0;
}

// ===== 跨天行程輔助 =====
function calIsMultiDay(ev) { return !!(ev && ev.endDate && ev.endDate !== ev.date); }
// 🆕 显示方式＝「显示在今天」：真实 date/endDate 区间已被锚定到今天，不要再显示
//    「开始日期 – 结束日期 · 共N天」，改显示固定字样（桌面主窗 / 便利贴三端同口径）。
const CAL_SPAN_TODAY_TEXT = '显示在今天';
function calIsSpanToday(ev) { return !!(ev && ev.spanDisplay === 'today'); }
function calMdShort(d) { const m = String(d || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/); return m ? (+m[1]) + '/' + (+m[2]) + '/' + (+m[3]) : (d || ''); }
function calSpanDays(a, b) {
  const d1 = new Date(a + 'T00:00:00'), d2 = new Date(b + 'T00:00:00');
  if (isNaN(d1) || isNaN(d2)) return 1;
  return Math.round((d2 - d1) / 86400000) + 1;
}
function calRangeLabel(a, b, st, et) {
  if (st || et) return calMdShort(a) + ' ' + (st || '') + ' – ' + calMdShort(b) + ' ' + (et || '');
  return calMdShort(a) + ' – ' + calMdShort(b);
}
// 把一條行程展開成「逐日出現」陣列（跨天行程每天一條，帶 start/middle/end 位置）
function calEventOccurrences(ev) {
  // 🆕 显示方式＝「显示在今天」：无论真实 date/endDate 为何，都只在「今天」出现一笔
  //   （与 首末天/每天 同列于「显示方式」下拉；覆盖跨天、单日、重复所有类型；真实日期原样保留在编辑器里）
  if (ev && ev.spanDisplay === 'today') {
    const today = calendarFmtDate(new Date());
    return [{ date: today, ev, pos: 'single', idx: 1, total: 1 }];
  }
  const out = [];
  if (calIsMultiDay(ev)) {
    let cur = new Date(ev.date + 'T00:00:00');
    const end = new Date(ev.endDate + 'T00:00:00');
    if (!isNaN(cur) && !isNaN(end)) {
      const total = Math.round((end - cur) / 86400000) + 1;
      let idx = 0;
      while (cur <= end) {
        idx++;
        const ds = calendarFmtDate(cur);
        const pos = ds === ev.date ? 'start' : (ds === ev.endDate ? 'end' : 'middle');
        out.push({ date: ds, ev, pos, idx, total });
        cur.setDate(cur.getDate() + 1);
      }
      return calFilterSpanDisplay(ev, out);
    }
  }
  // ===== ## EVENT(REPEAT) 重複事件：展開為可見範圍內的發生日 =====
  // REPEAT 三態：none=隱藏全部；next=只顯示「今天及之後最近的一次」；some=最近的前一次+未來4次（最多5次）
  if (ev.repeatMode && ev.repeatMode !== '') {
    // ⚠️ some 需要「未來 4 次」但當前視圖窗口（calRepeatFrom/To）可能只覆蓋未來 1~3 次，
    //    故 some 分支改用「寬窗口」重新展開，拿到完整序列再截取，不受視圖窗口裁剪。
    const savedFrom = calRepeatFrom, savedTo = calRepeatTo;
    calSetRepeatWindow('2000-01-01', '2100-01-01');
    const occ = calExpandRepeats(ev);
    calSetRepeatWindow(savedFrom, savedTo);
    if (state.calShowRepeat === 'none') return [];
    const today = calendarFmtDate(new Date());
    if (state.calShowRepeat === 'next') {
      let best = null;
      for (let i = 0; i < occ.length; i++) { if (occ[i].date >= today && (!best || occ[i].date < best.date)) best = occ[i]; }
      return best ? [best] : [];
    }
    // some：最近的前一次（date < today）+ 未來 4 次（date >= today），最多 5 次
    const past = [], future = [];
    for (let i = 0; i < occ.length; i++) { if (occ[i].date < today) past.push(occ[i]); else future.push(occ[i]); }
    return (past.length ? [past[past.length - 1]] : []).concat(future.slice(0, 4));
  }
  out.push({ date: ev.date, ev, pos: 'single', idx: 1, total: 1 });
  return calFilterSpanDisplay(ev, out);
}
function calFilterSpanDisplay(ev, occurrences) {
  if (!calIsMultiDay(ev)) return occurrences;
  const mode = ev && (ev.spanDisplay === 'first' || ev.spanDisplay === 'last') ? ev.spanDisplay : 'daily';
  if (mode === 'first') return occurrences.filter((o) => o.pos === 'start');
  if (mode === 'last') return occurrences.filter((o) => o.pos === 'end');
  return occurrences;
}
function calSubProgressBadge(ev) {
  const subs = calParseNoteChecks(ev && ev.notes);
  if (!subs.length) return '';
  const done = subs.filter((sub) => sub.done).length;
  const allDone = done === subs.length;
  return '<span class="ev-sub-progress' + (allDone ? ' all-done' : '') +
    '" title="备注子事件：' + done + ' / ' + subs.length + ' 已完成">' + done + '/' + subs.length + '</span>';
}
function calSpanDisplayModeBadge(ev) {
  const isToday = ev && ev.spanDisplay === 'today';
  if (!calIsMultiDay(ev) && !isToday) return '';
  const mode = ev.spanDisplay === 'first' ? 'first' : ev.spanDisplay === 'last' ? 'last' : isToday ? 'today' : 'daily';
  const letter = mode === 'first' ? 'H' : mode === 'last' ? 'E' : mode === 'today' ? '今' : 'A';
  const label = mode === 'first' ? '首天显示' : mode === 'last' ? '末天显示' : mode === 'today' ? '显示在今天' : '每天显示';
  return '<span class="ev-span-display-mode" title="显示方式：' + label + '">' + letter + '</span>';
}
// ☐「只顯示該事件未完成的 checkbox 子事件」：每事件一個開關（純 UI 偏好 → localStorage，絕不改寫 calendar.md）
const CAL_UNDONE_CHECKS_KEY = 'calUndoneChecksByEvent';
let calUndoneChecksByEvent = (function () {
  try {
    const saved = JSON.parse(localStorage.getItem(CAL_UNDONE_CHECKS_KEY) || '{}');
    if (saved && typeof saved === 'object' && !Array.isArray(saved)) return saved;
    console.warn('[LITE] 忽略無效的每事件 checkbox 篩選設定');
  } catch (e) { console.warn('[LITE] 讀取每事件 checkbox 篩選設定失敗', e); }
  return {};
})();
function calEventUndoneChecksOnly(uid) { return calUndoneChecksByEvent[uid] === true; }
function calToggleEventUndoneChecks(uid, button) {
  if (!uid) return;
  const next = !calEventUndoneChecksOnly(uid);
  if (next) calUndoneChecksByEvent[uid] = true; else delete calUndoneChecksByEvent[uid];
  try { localStorage.setItem(CAL_UNDONE_CHECKS_KEY, JSON.stringify(calUndoneChecksByEvent)); }
  catch (e) { showToast('無法保存該事件的 checkbox 顯示設定：' + ((e && e.message) || e), 'error'); }
  const item = button && button.closest('.ev-item');
  if (item) item.classList.toggle('only-undone-checks', next);
  if (button) {
    button.classList.toggle('active', next);
    button.textContent = next ? '☑' : '☐';
    button.setAttribute('aria-pressed', next ? 'true' : 'false');
    button.title = next ? '仅显示该事件未完成的 checkbox 子事件（点击显示全部）' : '只显示该事件未完成的 checkbox 子事件';
  }
}
// 重複展開視窗：各視圖渲染前用 calSetRepeatWindow 設定，避免 never 模式無限展開
let calRepeatFrom = '2000-01-01', calRepeatTo = '2100-01-01';
function calSetRepeatWindow(from, to) { calRepeatFrom = from || '2000-01-01'; calRepeatTo = to || '2100-01-01'; }
const CAL_WD = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
function calWdKey(d) { return CAL_WD[d.getDay()]; }
function calPad2(n) { n = parseInt(n, 10); return isNaN(n) ? '' : (n < 10 ? '0' + n : '' + n); }
function calAddDaysStr(ds, n) { const d = new Date(ds + 'T00:00:00'); d.setDate(d.getDate() + n); return calendarFmtDate(d); }
// 由重複定義生成發生日陣列（受 [calRepeatFrom, calRepeatTo] 約束）；idx＝實際收錄序號，total＝count 模式總次數
function calExpandRepeats(ev) {
  // 去掉用户手写时可能带的最外层双引号（如 repeatYearMonthDay: `"05-26"`），保证比较正确且不改写文件
  const strip = (s) => { s = String(s == null ? '' : s); return (s.length >= 2 && s[0] === '"' && s[s.length - 1] === '"') ? s.slice(1, -1) : s; };
  const mode = strip(ev.repeatMode);
  if (!mode) return [];
  const interval = Math.max(1, parseInt(strip(ev.repeatInterval), 10) || 1);
  let exclude = ev.repeatExcludeDates;
  if (typeof exclude === 'string') { try { exclude = JSON.parse(exclude); } catch (e) { exclude = []; } }
  if (!Array.isArray(exclude)) exclude = [];
  const endType = strip(ev.repeatEndType) || 'never';
  const endVal = strip(ev.repeatEndValue);
  const from = calRepeatFrom, to = calRepeatTo;
  const out = [];
  const cur = new Date(ev.date + 'T00:00:00');
  if (isNaN(cur)) return out;
  const bD = cur.getDate(), bM = cur.getMonth(), bY = cur.getFullYear();
  const wds = (ev.repeatWeekDay && ev.repeatWeekDay.length) ? ev.repeatWeekDay : [calWdKey(cur)];
  const mDay = ev.repeatMonthDay ? parseInt(strip(ev.repeatMonthDay), 10) : bD;
  const ymd = ev.repeatYearMonthDay ? strip(ev.repeatYearMonthDay) : (calPad2(bM + 1) + '-' + calPad2(bD));
  let idx = 0, guard = 0;
  while (guard++ < 8000) {
    const ds = calendarFmtDate(cur);
    if (ds > to) break;
    if (ds >= from) {
      let hit = false;
      if (mode === 'daily') hit = true;
      else if (mode === 'weekly') hit = wds.indexOf(calWdKey(cur)) >= 0;
      else if (mode === 'monthly') {
        const months = (cur.getFullYear() - bY) * 12 + (cur.getMonth() - bM);
        hit = cur.getDate() === mDay && months % interval === 0;
      } else if (mode === 'yearly') {
        const curMd = calPad2(cur.getMonth() + 1) + '-' + calPad2(cur.getDate());
        hit = curMd === ymd && (cur.getFullYear() - bY) % interval === 0;
      }
      if (hit && exclude.indexOf(ds) < 0) {
        idx++;
        if (endType === 'count' && idx > (parseInt(endVal, 10) || 0)) break;
        if (endType === 'date' && ds > endVal) break;
        out.push({ date: ds, ev, pos: 'single', idx, total: endType === 'count' ? (parseInt(endVal, 10) || 0) : 0 });
      }
    }
    cur.setDate(cur.getDate() + 1);
  }
  return out;
}
function calOccSort(a, b) {
  const aSpan = a.pos === 'single' ? 1 : 0, bSpan = b.pos === 'single' ? 1 : 0;
  if (aSpan !== bSpan) return aSpan - bSpan;
  if (a.ev.date !== b.ev.date) return a.ev.date < b.ev.date ? -1 : 1;
  if (a.ev.allDay !== b.ev.allDay) return a.ev.allDay ? -1 : 1;
  return calendarTimeToMin(a.ev.startTime) - calendarTimeToMin(b.ev.startTime);
}
// 跨天行程的「第幾天」後綴（單一來源）：total>1 時回傳「 (idx/total)」（如 回上海 (1/7)），單日行程不加
// 使用點：月格色條、時間網格（全天條／定時塊／假期條）、列表行、假日列
function calSpanSuffix(idx, total) { return (total > 1 && idx > 0) ? ' (' + idx + '/' + total + ')' : ''; }
// 由「出現日」直接算跨天序號——呼叫方不必手上握有 occurrence 的 idx/total（列表行/假日列走的是
// 「按日期分組」入口，那份資料只有 ev + 日期，沒有產生 seq）。
// ⚠️ 只認「跨天」（date ≠ endDate）：重複事件的 idx/total 是「第幾次」而非「第幾天」，兩者不可混用。
function calSpanDaySuffix(item, occDate) {
  // 🆕 显示方式＝「显示在今天」：真实区间已锚定成「今天一笔」，不再显示 (第几天/共几天)
  if (calIsSpanToday(item)) return '';
  if (!calIsMultiDay(item)) return '';
  const total = calSpanDays(item.date, item.endDate);
  if (total <= 1) return '';
  const idx = Math.min(Math.max(calSpanDays(item.date, occDate || item.date), 1), total);
  return calSpanSuffix(idx, total);
}
// 📝 備註裡的 Markdown checkbox（- [ ] / - [x]）渲染成 ☐/☑ 樣式，且可點擊勾選/取消（寫回 notes 原文）。
//    入參必須是「已 escape」的文本；支援任意縮進的 `- [ ]` / `- [x]` / `- [X]`。
//    uid 為所屬行程（點擊時定位用）；fenced code block 內的行不當成 checkbox，避免誤判代碼。
// 🆕 鬧鈴（alert）徽標渲染：固定與循環標記共用提醒內容膠囊（與桌面 tlAlertBadgeHtml 同口径）。
//   固定時間顯示「月-日 時:分」與完成狀態；每日／週間／周年循環顯示週期與時間，不顯示完成狀態。
//   非標準格式（如 [[alert:買東西]]）仍走 ⏰ 徽標，內容照原樣顯示、不掛時間與狀態膠囊。
function calAlertBadgeHtml(inner) {
  const body = String(inner);
  const parsed = body.match(/^alert:([\s\S]*?):((?:\d{4}-\d{2}-\d{2} \d{4})|(?:anniversary\s+\d{4}-\d{2}-\d{2}\s+\d{4})|(?:everyday\s+\d{4})|(?:w[1-7]\s*-\s*w[1-7]\s+\d{4})|(?:w[1-7](?:\s*,\s*w[1-7])+\s+\d{4}))\s*:\s*([1-9]\d*)\s*(m|h|d)(?:\s*:\s*([^\]]*))?$/i);
  const message = (parsed ? parsed[1] : body.slice(body.indexOf(':') + 1)).trim();
  const head = '<span class="tl-alert-ic">⏰</span>' + escapeHtml(message);
  if (!parsed) return '<span class="tl-alert">' + head + '</span>';
  if (!/^\d{4}-\d{2}-\d{2} \d{4}$/.test(parsed[2])) {
    const anniversary = parsed[2].match(/^anniversary\s+\d{4}-(\d{2})-(\d{2})\s+(\d{4})$/i);
    const daily = parsed[2].match(/^everyday\s+(\d{4})$/i);
    const weekdays = parsed[2].match(/^w([1-7])\s*-\s*w([1-7])\s+(\d{4})$/i);
    const weekdayList = parsed[2].match(/^(w[1-7](?:\s*,\s*w[1-7])+) (\d{4})$/i);
    if (!anniversary && !daily && !weekdays && !weekdayList) return '<span class="tl-alert">' + head + '</span>';
    const weekdayNames = '一二三四五六日';
    const time = anniversary ? anniversary[3] : (daily ? daily[1] : (weekdayList ? weekdayList[2] : weekdays[3]));
    const weekdayDisplay = weekdayList
      ? '每周' + weekdayList[1].match(/w[1-7]/gi).map((token) => weekdayNames[Number(token.slice(1)) - 1]).join('、')
      : (weekdays ? '周' + weekdayNames[Number(weekdays[1]) - 1] +
        '至周' + weekdayNames[Number(weekdays[2]) - 1] : '');
    const displayWhen = (anniversary ? '每年 ' + anniversary[1] + '月' + anniversary[2] + '日'
      : (daily ? '每日' : weekdayDisplay)) + ' ' + time.slice(0, 2) + ':' + time.slice(2);
    const tooltip = ['循環提醒 ' + displayWhen,
      '間隔 ' + parsed[3] + ({ m: '分鐘', h: '小時', d: '天' })[parsed[4]]].join(' · ');
    return '<span class="tl-alert" title="' + escapeHtml(tooltip) + '">' + head +
      '<span class="tl-alert-when">' + escapeHtml(displayWhen) + '</span></span>';
  }
  const displayWhen = parsed[2].replace(/^(\d{4}-\d{2}-\d{2} )(\d{2})(\d{2})$/, '$1$2:$3');
  const done = parsed[5] === '是';
  const tooltip = ['下次提醒 ' + displayWhen,
    '間隔 ' + parsed[3] + ({ m: '分鐘', h: '小時', d: '天' })[parsed[4]],
    done ? '已完成' : '未結束'].join(' · ');
  return '<span class="tl-alert' + (done ? ' done' : '') + '" title="' + escapeHtml(tooltip) + '">' + head +
    '<span class="tl-alert-when">' + escapeHtml(displayWhen.slice(5)) + '</span>' +
    '<span class="tl-alert-state">' + (done ? '☑ 已完成' : '☐ 未完成') + '</span></span>';
}
// 🆕 術語（term）渲染（立體膠囊＋tooltip 顯示釋義；與桌面 calendar 雙端對齊）：
//   [[term]]                → 立體膠囊（term）
//   [[term:釋義]]            → 立體膠囊(term) ＋ 釋義以 tooltip 呈現（hover）
//   [[term:釋義:領域]]       → 立體膠囊(term) ＋ 領域為內嵌小膠囊 ＋ 釋義 tooltip
//   [[term:釋義:領域:發行]]  → 再加一顆「發行」小膠囊（首發／發布等創作節點，與桌面 calendar 同口徑）
//   4 段以上：末段＝發行、倒數第二段＝領域、其餘（可含冒號）併回釋義；1~3 段沿用舊口徑（末段＝領域）。
//   dl / cp 前綴（日期標記）與裸日期 [[YYYY-MM-DD]] 排除（留給 📅/✅ 機制）。逐行處理並跳過代碼圍欄。
function calRenderTermDefs(text) {
  let inFence = false;
  return String(text).split('\n').map(function (line) {
    if (/^\s*```/.test(line)) { inFence = !inFence; return line; }
    if (inFence) return line;
    return line.replace(/\[\[([^\]\n]+)\]\]/g, function (m, inner) {
      // 🆕 提醒標記 [[remind:名稱:規則]] → 紅框膠囊＋鈴鐺（與桌面 tlRenderTermDefs 同口径）；
      //    它同時是「🔔 提醒」VIEW 便利貼的收集判據。
      if (/^remind:/i.test(inner)) {
        const body = inner.slice(inner.indexOf(':') + 1).trim();
        const c2 = body.indexOf(':');
        const rTitle = c2 === -1 ? body : body.slice(0, c2).trim();
        const rRule = c2 === -1 ? '' : body.slice(c2 + 1).trim();
        return '<span class="tl-remind"' + (rRule ? ' title="' + escapeHtml(rRule) + '"' : '') + '>' +
          '<span class="tl-remind-ic">🔔</span>' + escapeHtml(rTitle) + '</span>';
      }
      // 🆕 收藏標記 [[bookmark:名稱:備註]] → 藍框膠囊＋🌟星星（與桌面 tlRenderTermDefs 同口径）
      if (/^bookmark:/i.test(inner)) {
        const body = inner.slice(inner.indexOf(':') + 1).trim();
        const c2 = body.indexOf(':');
        const bTitle = c2 === -1 ? body : body.slice(0, c2).trim();
        const bNote = c2 === -1 ? '' : body.slice(c2 + 1).trim();
        return '<span class="tl-bookmark"' + (bNote ? ' title="' + escapeHtml(bNote) + '"' : '') + '>' +
          '<span class="tl-bookmark-ic"><svg viewBox="0 0 24 24" width="1em" height="1em" focusable="false" aria-hidden="true"><path fill="currentColor" d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg></span>' + escapeHtml(bTitle) + '</span>';
      }
      // 🆕 鬧鈴標記 [[alert:內容:下次提醒:間隔:是/否]] → ⏰ 徽標＋內容原文（不顯示「alert」字樣）
      if (/^alert:/i.test(inner)) return calAlertBadgeHtml(inner);
      const full = inner.trim();
      if (!full) return m;
      const firstColon = full.indexOf(':');
      let term, rest;
      if (firstColon === -1) {
        term = full; rest = '';
        if (term === 'dl' || term === 'cp') return m;                       // 日期標記名稱
        if (/^remind$/i.test(term)) return m;                                // 提醒標記字，不屬術語
        if (/^bookmark$/i.test(term)) return m;                               // 收藏標記字，不屬術語
        if (/^alert$/i.test(term)) return m;                                  // 鬧鈴標記字，不屬術語
        if (/^\d{4}-\d{2}-\d{2}$/.test(term)) return m;                     // 裸日期 → dl 機制
      } else {
        term = full.slice(0, firstColon).trim();
        rest = full.slice(firstColon + 1);
        if (term === 'dl' || term === 'cp') return m;                       // 日期標記（dl:/cp: 後接日期）
      }
      // 4 段以上（rest 有 ≥2 個冒號）→ [[term:釋義:領域:發行]]；其餘沿用舊 1~3 段口徑。
      const parts = rest.split(':');
      let def, domain, release = '';
      if (parts.length >= 3) {
        release = parts[parts.length - 1].trim();
        domain = parts[parts.length - 2].trim();
        def = parts.slice(0, -2).join(':').trim();
      } else {
        const lastColon = rest.lastIndexOf(':');
        def = lastColon === -1 ? rest.trim() : rest.slice(0, lastColon).trim();
        domain = lastColon === -1 ? '' : rest.slice(lastColon + 1).trim();
      }
      const termHtml = '<span class="tl-term-cap"' +
        (def ? ' title="' + escapeHtml(def) + '"' : '') + '>' +
        escapeHtml(term) +
        (domain ? '<span class="tl-term-domain">' + escapeHtml(domain) + '</span>' : '') +
        (release ? '<span class="tl-term-release">' + escapeHtml(release) + '</span>' : '') +
        '</span>';
      return '<span class="tl-term">' + termHtml + '</span>';
    });
  }).join('\n');
}
// 🆕 術語字典：掃描所有事件（title+notes）裡出現過的 [[term...]]，彙整成 {term, def}（供編輯框「自動標示術語」使用）
function calCollectTerms() {
  const map = new Map();
  const scan = (text) => {
    if (!text) return;
    let inFence = false;
    String(text).split('\n').forEach((line) => {
      if (/^\s*```/.test(line)) { inFence = !inFence; return; }
      if (inFence) return;
      String(line).replace(/\[\[([^\]\n]+)\]\]/g, (m, inner) => {
        if (/^remind:/i.test(inner)) return m;
        if (/^bookmark:/i.test(inner)) return m;
        if (/^alert:/i.test(inner)) return m;
        const full = inner.trim();
        if (!full) return m;
        const firstColon = full.indexOf(':');
        let term, rest;
        if (firstColon === -1) {
          term = full; rest = '';
          if (term === 'dl' || term === 'cp') return m;
          if (/^remind$/i.test(term)) return m;
          if (/^bookmark$/i.test(term)) return m;
          if (/^\d{4}-\d{2}-\d{2}$/.test(term)) return m;
        } else {
          term = full.slice(0, firstColon).trim();
          rest = full.slice(firstColon + 1);
          if (term === 'dl' || term === 'cp') return m;
        }
        if (!term) return m;
        // 與桌面同口徑：4 段以上末段＝發行、倒數第二段＝領域、其餘併回釋義；字典只取釋義。
        const parts = rest.split(':');
        const lastColon = rest.lastIndexOf(':');
        const def = parts.length >= 3
          ? parts.slice(0, -2).join(':').trim()
          : (lastColon === -1 ? rest.trim() : rest.slice(0, lastColon).trim());
        const key = term.toLowerCase();
        if (!map.has(key)) map.set(key, { term: term, def: def });
        return m;
      });
    });
  };
  (state.calEvents || []).forEach((ev) => { scan(ev.title); scan(ev.notes); });
  return Array.from(map.values());
}
// 🆕 編輯子事件編輯框：自動把文本裡「未標註的已知術語」包成 [[term]] / [[term:釋文]] 標記。
//   規則：① 已位於 [[...]] 內的字串不重複標註；② 多術語重疊時最長匹配優先；③ 僅標註未在 [[...]] 內的出現。
function calAutoMarkTermsInText(text) {
  const terms = calCollectTerms();
  const dict = (terms || [])
    .map((t) => ({ term: t.term, def: (t.def || '').trim() }))
    .filter((t) => t.term && t.term.length >= 2)
    .sort((a, b) => b.term.length - a.term.length);   // 長詞優先
  if (!dict.length) return { text: String(text), count: 0 };
  const src = String(text);
  const protectedSpans = [];
  let m; const br = /\[\[[^\]\n]*\]\]/g;
  while ((m = br.exec(src)) !== null) protectedSpans.push([m.index, m.index + m[0].length]);
  const inProtected = (i) => protectedSpans.some((sp) => i >= sp[0] && i < sp[1]);
  const cands = [];
  for (const d of dict) {
    const term = d.term; let from = 0, idx;
    while ((idx = src.indexOf(term, from)) !== -1) {
      const end = idx + term.length;
      if (!inProtected(idx) && !inProtected(end - 1)) cands.push({ start: idx, end: end, term: term, def: d.def });
      from = idx + 1;
    }
  }
  if (!cands.length) return { text: src, count: 0 };
  cands.sort((a, b) => (b.end - b.start) - (a.end - a.start) || a.start - b.start);
  const used = new Array(src.length).fill(false);
  const accepted = [];
  for (const c of cands) {
    let overlap = false;
    for (let i = c.start; i < c.end; i++) { if (used[i]) { overlap = true; break; } }
    if (overlap) continue;
    for (let i = c.start; i < c.end; i++) used[i] = true;
    accepted.push(c);
  }
  accepted.sort((a, b) => a.start - b.start);
  let out = '', cursor = 0;
  for (const c of accepted) {
    out += src.slice(cursor, c.start);
    const marker = (c.def && c.def.indexOf(']]') === -1) ? ('[[' + c.term + ':' + c.def + ']]') : ('[[' + c.term + ']]');
    out += marker;
    cursor = c.end;
  }
  out += src.slice(cursor);
  return { text: out, count: accepted.length };
}
function calAutoMarkTermsInEditBox() {
  const inp = document.getElementById('calMdEditInput');
  if (!inp) return;
  if (!inp.value.trim()) { showToast('編輯框為空，無可標示的內容', 'error'); return; }
  const res = calAutoMarkTermsInText(inp.value);
  if (!res.count) { showToast('沒有發現可標示的未標註術語', 'info'); return; }
  inp.value = res.text;
  inp.dispatchEvent(new Event('input', { bubbles: true }));
  showToast('已自動標示 ' + res.count + ' 處術語（最長匹配優先，已標註不重複）', 'success');
}
// 基礎 Markdown 渲染（標題/備註共用）。
// 標題行內使用：若 marked 只產出單個 <p>，去掉 <p> 包裝，避免在 .ev-title 裡產生多餘段間距。
function calRenderInlineMarkdown(text) {
  if (!text) return '';
  // 🆕 標題也支援術語渲染（見 calRenderTermDefs）：先轉 term 膠囊再 renderMarkdown
  const html = renderMarkdown(calRenderTermDefs(String(text).trim()));
  const trimmed = html.trim();
  if (/^<p>/i.test(trimmed) && /<\/p>$/i.test(trimmed)) {
    const inner = trimmed.slice(3, -4);
    if (!/<p>/i.test(inner)) return inner;
  }
  return html;
}
// 備註「是否給編輯入口」：與桌面 tlRenderNotes 的 canEdit 同構——uid 有值且該行程屬主檔（非 include 只讀）。
//   forceEditable=true 是唯一例外：便利貼才是 include 備註的唯一編輯場所，那邊一律給編輯入口。
function calNotesCanEdit(uid, forceEditable) {
  if (forceEditable === true) return !!uid;
  if (!uid) return false;
  const ev = (state.calEvents || []).find((x) => x.uid === uid);
  return !!(ev && !ev.ro);
}
// 備註編輯「介面歸屬」：同一組備註編輯函式被 行程檢視 與 便利貼 兩邊共用，
//   但 include(ro) 行程只准在便利貼裡改 → 動作當下要知道來自哪一邊。
//   判定一律靠 DOM 歸屬（#calStickyOverlay），不靠全域旗標——重繪順序不會把它翻掉。
function calNotesFromSticky(e) {
  const t = e && e.target;
  return !!(t && t.closest && t.closest('#calStickyOverlay'));
}
// ro 行程的備註編輯守門：行程檢視一律拒（與桌面 ev.ro 攔截同口徑），便利貼放行。
//   回傳 true＝已攔下，呼叫端立刻 return。
//   文案刻意短：「來自被包含的檔案」的完整說明在 ⛔ 徽標的 title 裡，toast 太長在手機上會被裁。
function calNotesRoLocked(ev, fromSticky) {
  if (!ev || !ev.ro || fromSticky) return false;
  showToast('唯讀行程：備註請到便利貼修改', 'error');
  return true;
}
// 備註：可編輯時依「最小 MD 表達單元」分塊，非 checkbox 區塊注入 ✎ 圓點；
//   唯讀（uid=null 的節日／tooltip，或 include 進來的 ro 行程）整段渲染，與桌面 tlRenderNotes 一致。
//   ⚠️ ro 行程在「行程檢視」只讀：不給任何 ✎，checkbox 仍渲染但點擊由 calToggleNoteCheck 兜住並提示；
//      要改 include 備註只能到便利貼——那邊呼叫時傳 forceEditable=true。
// ── group 標記語法（2026-11-06 寬放）：花括號內「開頭」是 gp 或 group 即算；大小寫不拘、冒號可省略 ──
//   {gp}＝{GP}＝{GroUP}＝{group} → 無名組（key ''）；{gp:ABC}＝{gpABC}＝{GROUP:ABC} → 'ABC'；
// ── 顏色名解析（2026-11-09，擴展：深/浅/淡 級別前綴） ──
const calCN_COLORS = {
  '红': '#e74c3c', '橙': '#e67e22', '黄': '#f1c40f', '金': '#d4af37',
  '粉': '#ff6b9d', '紫': '#8e44ad', '蓝': '#3498db',
  '绿': '#27ae60', '青': '#1abc9c', '灰': '#95a5a6', '黑': '#2c3e50', '白': '#ecf0f1',
  '卡其': '#bdb76b', '棕': '#8b5a2b', '酒红': '#722f37', '米': '#f5f0dc'
};
function calHexToHsl(hex) {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0, 2), 16) / 255;
  const g = parseInt(h.slice(2, 4), 16) / 255;
  const b = parseInt(h.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let hh, s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) { case r: hh = (g - b) / d + (g < b ? 6 : 0); break; case g: hh = (b - r) / d + 2; break; default: hh = (r - g) / d + 4; }
    hh /= 6;
  } else hh = 0;
  return { h: hh * 360, s: s * 100, l: l * 100 };
}
function calHslToHex(hsl) {
  const h = hsl.h / 360, s = hsl.s / 100, l = hsl.l / 100;
  function hue2rgb(p, q, t) {
    if (t < 0) t += 1; if (t > 1) t -= 1;
    if (t < 1/6) return p + (q - p) * 6 * t;
    if (t < 1/2) return q;
    if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
    return p;
  }
  let r, g, b;
  if (s === 0) { r = g = b = l; }
  else {
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1/3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1/3);
  }
  const toHex = (v) => Math.round(v * 255).toString(16).padStart(2, '0');
  return '#' + toHex(r) + toHex(g) + toHex(b);
}
function calShiftBrightness(baseHex, op, n) {
  const hsl = calHexToHsl(baseHex);
  let newL = hsl.l;
  if (op === '+') newL = hsl.l * (1 - Math.min(10, n) / 10 * 0.75);
  else if (op === '-') newL = hsl.l + (100 - hsl.l) * Math.min(10, n) / 10 * 0.75;
  else if (op === '深') newL = hsl.l * 0.65;
  else if (op === '浅') newL = hsl.l + (100 - hsl.l) * 0.28;
  else if (op === '淡') newL = hsl.l + (100 - hsl.l) * 0.48;
  newL = Math.max(3, Math.min(97, newL));
  return calHslToHex({ h: hsl.h, s: hsl.s, l: newL });
}
function calResolveColorName(input) {
  if (!input) return '';
  const s = String(input).trim();
  if (!s) return '';
  const gm = s.match(/^渐变\s*\(\s*([^→)]+)\s*→\s*([^)]+)\s*\)$/);
  if (gm) {
    const a = calResolveColorName(gm[1]);
    const b = calResolveColorName(gm[2]);
    if (a && b) return 'linear-gradient(135deg, ' + a + ', ' + b + ')';
  }
  const nm = s.match(/^(.+?)\s*([+\-])\s*(\d+)$/);
  if (nm) {
    const base = nm[1].trim(), op = nm[2], n = parseInt(nm[3], 10);
    const baseHex = calCN_COLORS[base];
    if (baseHex && n >= 1 && n <= 10) return calShiftBrightness(baseHex, op, n);
  }
  const tm = s.match(/^(深|浅|淡)(.+)$/);
  if (tm) {
    const op = tm[1], base = tm[2].trim();
    const baseHex = calCN_COLORS[base];
    if (baseHex) return calShiftBrightness(baseHex, op);
  }
  if (calCN_COLORS[s]) return calCN_COLORS[s];
  if (/^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(s)) return s;
  if (/^(rgb|rgba|hsl|hsla)\s*\(/i.test(s)) return s;
  return s;
}
// 🆕 2026-11-14 升级为多 pipe 版本（与 desktop-note.js noteExtractGpAttrs 对齐）
// 格式：{gpX|attrs段|term段}
//   attrs 段用 , 分隔 fg=红,bg=黄,anim=pulse
//   term 段用 | 分隔 alert|TERM=便利贴
function calParseGpAttrs(raw) {
  const s = String(raw == null ? '' : raw).trim();
  if (!s) return { key: '', fg: '', bg: '', anim: '', alert: false, extra: [], term: '', termName: '', railStyle: '', railA: '', railB: '' };
  const pipe1 = s.indexOf('|');
  if (pipe1 < 0) return { key: s, fg: '', bg: '', anim: '', alert: false, extra: [], term: '', termName: '', railStyle: '', railA: '', railB: '' };
  const key = s.slice(0, pipe1).trim();
  const rest = s.slice(pipe1 + 1);
  const pipe2 = rest.indexOf('|');
  const attrsPart = pipe2 >= 0 ? rest.slice(0, pipe2) : rest;
  const termPart = pipe2 >= 0 ? rest.slice(pipe2 + 1) : '';
  // 解析 attrs 段
  const extra = [];
  let fg = '', bg = '', anim = '', alert = false, termName = '', railStyle = '', railA = '', railB = '';
  attrsPart.split(',').forEach((pair) => {
    const p = pair.trim();
    if (!p) return;
    const eq = p.indexOf('=');
    if (eq < 0) { extra.push(p); return; }
    const k = p.slice(0, eq).trim().toLowerCase();
    const v = p.slice(eq + 1).trim();
    if (k === 'fg') fg = calResolveColorName(v);
    else if (k === 'bg') bg = calResolveColorName(v);
    else if (k === 'anim' && /^(pulse|scan|data|aurora|orbit|arc|holo|signal|glitch)$/.test(v)) anim = v;
    else if (k === 'rail') {
      const rp = v.split('#');
      if (rp.length >= 3 && ['斜栏', '直栏', '>形栏', '圆弧栏'].indexOf(rp[0].trim()) >= 0) {
        railStyle = rp[0].trim();
        railA = calResolveColorName(rp[1].trim());
        railB = calResolveColorName(rp[2].trim());
      }
    }
    else extra.push(p);
  });
  // 兜底：attrs 段里可能有 TERM=xxx（没有第二个 pipe 的情况），移到 termName
  const termInAttrs = extra.find((x) => /^TERM\s*=/i.test(x));
  if (termInAttrs) {
    termName = termInAttrs.replace(/^TERM\s*=\s*/i, '').trim();
    const idx = extra.indexOf(termInAttrs);
    if (idx >= 0) extra.splice(idx, 1);
  }
  // 解析 term 段（支持逗号混写：TERM=xxx,rail=斜栏#白#黑）
  if (termPart) {
    termPart.split('|').forEach((seg) => {
      seg.split(',').forEach((item) => {
        const segTrim = item.trim();
        if (!segTrim) return;
        const eq = segTrim.indexOf('=');
        if (eq < 0) {
          if (/^(dl|cp|cr|alert|remind|bookmark)$/i.test(segTrim)) alert = true;
          return;
        }
        const k = segTrim.slice(0, eq).trim().toUpperCase();
        const v = segTrim.slice(eq + 1).trim();
        if (k === 'TERM' && v) termName = v;
        else if (k === 'ALERT') alert = v.toLowerCase() === 'true';
        else if (k === 'RAIL') {
          const rp = v.split('#');
          if (rp.length >= 3 && ['斜栏', '直栏', '>形栏', '圆弧栏'].indexOf(rp[0].trim()) >= 0) {
            railStyle = rp[0].trim();
            railA = calResolveColorName(rp[1].trim());
            railB = calResolveColorName(rp[2].trim());
          }
        }
      });
    });
  }
  return { key: key, fg: fg, bg: bg, anim: anim, alert: alert, extra: extra, term: termPart, termName: termName, railStyle: railStyle, railA: railA, railB: railB };
}
function calExtractGpAttrsFromLine(line) {
  const s = String(line == null ? '' : line);
  let m = s.trim().match(/^\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}]*)\}[ \t]*$/i);
  if (m) return calParseGpAttrs(m[1]);
  m = s.match(/\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}]*)\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
  if (m) return calParseGpAttrs(m[1]);
  return { key: '', fg: '', bg: '', anim: '', alert: false, extra: [], term: '', termName: '' };
}
//   ⚠️ 位置：標記必須在行尾、或行尾 [[...]] 標記序列之前才算結構標記；行中的 {gp} 是普通文字，原樣顯示也不分組。
//   {gp1}＝{gp:1} → '1'。前綴 group 優先於 gp；組名仍區分大小寫；三式正則與桌面／便利貼窗／VIEW 引擎同口徑。
// 🆕 {gp} / {gp:名稱} 分組標記（與桌面 tlGpKeyOfLine / tlStripGpMarkers 同口徑）：
//   連續且「名稱相同」的行視為一個小事件／一顆編輯小圓點；名稱不同或中間夾無標記行就斷開。
function calGpKeyOfLine(line) {
  const m = String(line == null ? '' : line).match(/\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}|]*)(?:\|[^{}]*)?\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
  if (!m) return null;
  return String(m[1] || '').trim();
}
// ── 🆕 塊級（圍欄式）小事件群（2026-11-08）：單獨一行 {gpX} 開啟、
//    單獨一行 {/gpX} 結束，兩行之間的 Markdown 整體算「一個」[[小事件群]]。 ──
//  · 與「行尾 {gpX}」並存：行尾寫法靠連續同 key，塊級寫法靠成對標記行，是**硬邊界**，
//    絕不與前後群合併；塊內各行也不必再加行尾標記。
//  · 標記行是結構控制行：顯示層剝成空行（行數不變 → start/end/baseLine/勾選回寫全部照舊），底稿保留原文。
//  · 只認「整行就是一個花括號標記」；行中的 {gpX} 仍是普通文字（沿用 11-06 位置規則）。
//  · 代碼圍欄內不解析；未配對／孤立標記行不形成群（容錯，完全退回既有行尾語義，零回歸）。
//  · 不支援巢狀：遇到第一個同名結束行即閉合。與桌面 tlGpFenceOfLine／tlGpFenceScan 同口徑。
function calGpFenceOfLine(line) {
  const s = String(line == null ? '' : line).trim();
  let m = s.match(/^\{[ \t]*\/[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}|]*)(?:\|[^{}]*)?\}[ \t]*$/i);
  if (m) return { kind: 'close', key: String(m[1] || '').trim() };
  m = s.match(/^\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}|]*)(?:\|[^{}]*)?\}[ \t]*$/i);
  if (m) return { kind: 'open', key: String(m[1] || '').trim() };
  return null;
}
function calGpFenceScan(lines) {
  const ranges = [], markers = [];
  let inFence = false, open = null;
  for (let i = 0; i < lines.length; i++) {
    const line = String(lines[i] == null ? '' : lines[i]);
    if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; continue; }
    if (inFence) continue;
    const f = calGpFenceOfLine(line);
    if (!f) continue;
    if (f.kind === 'open') {
      if (!open) {
        const a = (typeof calExtractGpAttrsFromLine === 'function') ? calExtractGpAttrsFromLine(line) : { fg: '', bg: '', alert: false, extra: [] };
        open = { i: i, key: f.key, fg: a.fg || '', bg: a.bg || '', anim: a.anim || '', alert: a.alert === true, extra: a.extra || [], term: a.term || '', termName: a.termName || '', railStyle: a.railStyle || '', railA: a.railA || '', railB: a.railB || '' };
      }
      continue;
    }
    if (open && open.key === f.key) {
      ranges.push({ start: open.i, end: i, key: f.key, fg: open.fg, bg: open.bg, anim: open.anim, alert: open.alert, extra: open.extra || [], term: open.term || '', termName: open.termName || '', railStyle: open.railStyle || '', railA: open.railA || '', railB: open.railB || '' });
      markers.push(open.i, i);
      open = null;
    }
  }
  return { ranges: ranges, markers: markers };
}
// ── 從 block.fg / block.bg 生成 .md-unit.is-gp 的 inline style（2026-11-09，與桌面 tlGpInlineStyle 同口徑） ──
function calGpInlineStyle(b) {
  const parts = [];
  if (b.fg) parts.push('--gp-fg:' + b.fg);
  if (b.bg) {
    parts.push('--gp-bg:' + b.bg);
    if (b.fg) parts.push('--gp-border:' + b.fg);
  }
  // 🆕 rail 轨道
  if (b.railStyle) {
    parts.push('--gp-rail-style:' + b.railStyle);
    if (b.railA) parts.push('--gp-rail-a:' + b.railA);
    if (b.railB) parts.push('--gp-rail-b:' + b.railB);
  }
  return parts.length ? ' style="' + parts.join(';') + '"' : '';
}
// 🆕 2026-11-14：gp 围栏属性徽标 HTML — TERM（📌 金色）+ ALERT（🔔 红色）
function calGpBadgesHtml(b) {
  const badges = [];
  if (b && b.termName) {
    badges.push('<span class="gp-badge gp-badge-term" title="TERM=' + escapeHtml(b.termName) + '">\u{1F4CC}</span>');
  }
  if (b && b.alert) {
    badges.push('<span class="gp-badge gp-badge-alert" title="ALERT 闹铃">\u{1F514}</span>');
  }
  if (!badges.length) return '';
  return '<span class="gp-badges">' + badges.join('') + '</span>';
}
function calGpFenceWrap(text) {
  const lines = String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
  let s = 0, e = lines.length - 1;
  while (s <= e && !lines[s].trim()) s++;
  while (e >= s && !lines[e].trim()) e--;
  if (s > e) return null;
  const scan = calGpFenceScan(lines);
  const hit = scan.ranges.find((r) => r.start === s && r.end === e);
  // 🆕 2026-11-09：把 hit.fg / hit.bg 也帶出來，供 calWrapGpFence 重寫時保留 attrs
  return hit ? { lines: lines, start: s, end: e, key: hit.key, fg: hit.fg || '', bg: hit.bg || '', anim: hit.anim || '', alert: hit.alert === true, extra: hit.extra || [], term: hit.term || '', termName: hit.termName || '', railStyle: hit.railStyle || '', railA: hit.railA || '', railB: hit.railB || '', scan: scan } : null;
}
// ── 🆕 2026-11-08：勾選「group 啟用」按保存時一律改寫成「塊級」{gpX}…{/gpX}，不再逐行補行尾標記 ──
//  · 已是塊級群且沒給新標記 → 原樣保留；給了 mark → 整段改名（兩行一起改）。
//  · 舊「行尾式」群 → 剝掉每行行尾標記，沿用原本群名包成塊級；mark 為空時從原文取第一個標記字面量。
//  · 🆕 2026-11-09：attrs（fg/bg）從原文提取，保存時永不丟失。
function calWrapGpFence(text, mark) {
  const lines = String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
  const wrap = (typeof calGpFenceWrap === 'function') ? calGpFenceWrap(text) : null;
  if (wrap) {
    if (!mark) return lines.join('\n');
    // 🆕 給了新 mark → 組裝新 open 行：key 用新 mark，attrs 沿用原文（包括 alert 等）
    const newOpen = calBuildGpOpenLine(mark, wrap.fg, wrap.bg, wrap.anim, wrap.extra || [], wrap.alert === true, wrap.railStyle || '', wrap.railA || '', wrap.railB || '');
    const out = lines.slice();
    out[wrap.start] = newOpen;
    out[wrap.end] = calBuildGpCloseLine(wrap.key);  // 🆕 close 只寫 key，不帶 attrs！
    return out.join('\n');
  }
  // 🆕 行尾式 → 塊級：從第一個行尾標記提取「完整字面量」（key + attrs 全都要）
  let open = '';
  for (const line of lines) {
    const m = line.match(/(\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\})(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
    if (m) { open = m[1]; break; }
  }
  // 🆕 用 mark（只有 key）組裝：attrs 沿用原文（包括 alert 等非 fg/bg/anim 屬性）
  if (mark) {
    const origAttrs = (typeof calExtractGpAttrsFromLine === 'function')
      ? calExtractGpAttrsFromLine(open || '') : { fg: '', bg: '', anim: '', alert: false, extra: [], railStyle: '', railA: '', railB: '' };
    open = calBuildGpOpenLine(mark, origAttrs.fg, origAttrs.bg, origAttrs.anim, origAttrs.extra || [], origAttrs.alert === true, origAttrs.railStyle || '', origAttrs.railA || '', origAttrs.railB || '');
  }
  open = open || '{gp}';
  const close = calBuildGpCloseLine(calKeyFromGpMarker(open));  // 🆕 close 只寫 key，不帶 attrs！
  const stripped = (typeof calStripGpMarkers === 'function') ? calStripGpMarkers(lines.join('\n')) : lines.join('\n');
  const body = stripped.split('\n');
  while (body.length && !body[0].trim()) body.shift();
  while (body.length && !body[body.length - 1].trim()) body.pop();
  if (!body.length) return '';
  return [open].concat(body, [close]).join('\n');
}
// 🆕 2026-11-09：用 key + attrs 組裝 open 行（與桌面 tlBuildGpOpenLine 同口径）
// 🆕 2026-11-13：加 extra 保留 alert 等非 fg/bg/anim 屬性
function calBuildGpOpenLine(keyName, fg, bg, anim, extra, alert, railStyle, railA, railB) {
  let s = String(keyName == null ? '' : keyName).trim();
  if (!s.startsWith('{')) s = '{' + s;
  if (!s.endsWith('}')) s = s + '}';
  if (s.indexOf('|') >= 0) return s;
  const parts = [];
  if (fg) parts.push('fg=' + fg);
  if (bg) parts.push('bg=' + bg);
  if (anim) parts.push('anim=' + anim);
  if (Array.isArray(extra)) extra.forEach((x) => { if (x) parts.push(x); });  // 🆕 保留 alert 等
  if (alert) parts.push('alert');
  if (railStyle && railA && railB) parts.push('rail=' + railStyle + '#' + railA + '#' + railB);
  if (!parts.length) return s;
  return s.replace(/\}$/, '|' + parts.join(',') + '}');
}
// 🆕 2026-11-09：純 key 提取（從 `{gpE|bg=白}` 或 `gpE` 或 `E` 提取 `E`）
function calKeyFromGpMarker(marker) {
  const s = String(marker == null ? '' : marker).trim();
  if (!s) return '';
  // 已經是純 key（不含花括號、豎線、group/gp 前綴）→ 直接返回
  if (!s.includes('{') && !s.includes('}') && !s.includes('|')) return s;
  // 完整 marker → 用正則提取 key
  const m = s.match(/\{?\s*\/?\s*(?:group|gp)\s*:?\s*([^{}|]*)/i);
  return m ? String(m[1] || '').trim() : s;
}
// 🆕 2026-11-09：close 行構造 — 帶 gp/group 前綴 + key，永不帶 attrs！
function calBuildGpCloseLine(markerOrKey) {
  let s = String(markerOrKey == null ? '' : markerOrKey).trim();
  if (!s) return '{/gp}';
  if (s.includes('{')) {
    const m = s.match(/\{[ \t]*(\/?)\s*(group|gp)\s*:?\s*([^{}|]*)/i);
    if (m) return '{/' + m[2].toLowerCase() + String(m[3] || '').trim() + '}';
  }
  const prefixM = s.match(/^(gp|group)\s*:?/i);
  if (prefixM) {
    const prefix = prefixM[1].toLowerCase();
    const key = s.slice(prefixM[0].length).trim();
    return '{/' + prefix + key + '}';
  }
  return '{/gp' + s + '}';
}
// 顯示層剝掉 {gp}（代碼圍欄內原樣保留）；只有真的剝到標記的那行才清尾隨空白。
function calStripGpMarkers(text) {
  let inFence = false;
  return String(text == null ? '' : text).split('\n').map(function (line) {
    if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; return line; }
    if (inFence) return line;
    // 🆕 塊級標記行整行剝成空行（行數不變，底稿原文由對話框讀寫）。
    //    與 calGpFenceOfLine 同口徑但刻意內聯：顯示層純函式常被單獨抽出載入，不能依賴外部定義。
    if (/^\{[ \t]*\/?[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\}[ \t]*$/i.test(line.trim())) return '';
    const stripped = line.replace(/[ \t]*\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/gi, '');
    return stripped === line ? line : stripped.replace(/[ \t]+$/, '');
  }).join('\n');
}
// ── 🆕 group 啟用（唯一小事件）：保存時把編輯框裡「每一行」行尾標成同一個群標記，
//    使 calSplitMdBlocks / view-sticky-rules 的「連續同 key 段」把整塊認成一個小事件。
//  · 與 calStripGpMarkers 完全對稱：代碼圍欄行與圍欄內文原樣保留。
//  · 2026-11-07：既有具名組（{gp:名稱}／{gpABC}）是使用者自訂的分組邊界，**絕不改寫**。
//    舊版一律歸一成 {gp}，會讓當前群與前後同為 {gp} 的群連成一片（3 群融合成 1 群）。
//    新口徑：已有行尾標記的行原樣保留；沒有標記的新行補上「本塊第一個標記的字面量」；
//    整塊都沒有標記才補 {gp}（保留「主動把一般文字改成唯一小事件」的既有行為）。
//  · 行數不變 → 保存後區塊 start/end 區間仍有效。
//  · 三端同口徑：桌面主窗 tlApplyGroupMarkers／便利貼窗 noteApplyGroupMarkers。
function calHasCodeFence(text) {
  return /^\s*(```|~~~)/m.test(String(text == null ? '' : text));
}
//  · **純空白行保持空白**：空白行在 {gp} 規則裡是「上一行的延續」，不能被寫成內容行，
//    否則 group 啟用保存後空行會變成 '{gp}'，段落間隔就被破壞了（2026-11-06 空白行規則）。
function calApplyGroupMarkers(text, on) {
  const lines = String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
  // 🆕 塊級群：邊界本身已經是硬分組，勾選時絕不逐行補行尾標記；取消勾選才把兩行標記「置空」
  //    （不是刪除 → 行數不變），內容行自然散回各自的小事件。與桌面 tlApplyGroupMarkers 同口徑。
  const fenceScan = (typeof calGpFenceScan === 'function') ? calGpFenceScan(lines) : { ranges: [] };
  if (fenceScan.ranges.length) {
    if (on) return lines.join('\n');
    const out = lines.slice();
    fenceScan.ranges.forEach((r) => { out[r.start] = ''; out[r.end] = ''; });
    return out.join('\n');
  }
  // 本塊基準標記：只掃圍欄外的行，避免把程式碼裡的字串當成設定
  let baseMark = '', fence = false;
  for (const line of lines) {
    if (/^\s*(```|~~~)/.test(line)) { fence = !fence; continue; }
    if (fence) continue;
    const m = line.match(/[ \t]*(\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\})(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
    if (m) { baseMark = m[1]; break; }
  }
  let inFence = false;
  return lines.map(function (line) {
    if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; return line; }
    if (inFence) return line;
    if (!line.trim()) return line;
    const stripped = line.replace(/[ \t]*\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/gi, '');
    // 沒標記的行原樣回傳（尤其 on=false）：行尾兩空格是 Markdown 換行語義，不能順手清掉
    const clean = stripped === line ? line : stripped.replace(/[ \t]+$/, '');
    if (!on) return clean;                  // 拆組：沿用既有行為
    if (stripped !== line) return line;     // 已有標記：原樣保留（含具名組，絕不歸一）
    return clean + (baseMark || '{gp}');    // 新行補齊成同一組
  }).join('\n');
}
function calIsWholeGpBlock(text) {
  const raw = String(text == null ? '' : text).replace(/\r\n/g, '\n');
  // 🆕 塊級群本身已是「唯一小事件」：即使內容含代碼圍欄也照樣預勾（不逐行加標記，圍欄安全）
  if (typeof calGpFenceWrap === 'function' && calGpFenceWrap(raw)) return true;
  if (calHasCodeFence(raw)) return false;
  const lines = raw.split('\n');
  let key = null, seen = false;
  for (let i = 0; i < lines.length; i++) {
    if (!lines[i].trim()) continue;
    const m = lines[i].match(/\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}]*)\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
    if (!m) return false;
    const k = String(m[1] || '').trim();
    if (!seen) { key = k; seen = true; }
    else if (k !== key) return false;
  }
  return seen;
}
function calResolveGroupText(raw, checked, wasOn) {
  // 🆕 2026-11-08：編輯「內容區塊」勾選 group 啟用 → 一律改寫成塊級 {gpX}…{/gpX}（舊行尾式就地升級）
  if (checked) return (typeof calWrapGpFence === 'function') ? calWrapGpFence(raw, '') : calApplyGroupMarkers(raw, true);
  if (wasOn) return calApplyGroupMarkers(raw, false);   // 原本整組、使用者主動取消 → 拆回多個小事件
  return raw;                                          // 原本不是整組：手寫的 {gp} 原樣保留
}
function calGroupChecked() {
  const box = calMdEditEl('calGroupEnable');
  return !!(box && box.checked && !box.disabled);
}
// ＋☐ 加入 / 編輯 CheckBox 子事件共用（LITE 這兩條路徑原本就不補 cr，保持既有口徑）：
//   勾選 → 整批逐行補 {gp}；原本整組卻取消 → 移除 {gp} 拆組；其餘走 fallback 原樣。
function calGroupMd(rawMd, fallback, fenceWrap) {
  const on = calGroupChecked();
  if (!on && !calGroupWasOn) return fallback();
  if (fenceWrap) {
    // 🆕 新增「加入子事件」：整批包成一個塊級小事件群
    return (typeof calWrapGpFence === 'function')
      ? (on ? calWrapGpFence(rawMd, '') : (calGroupWasOn ? calApplyGroupMarkers(rawMd, false) : rawMd))
      : calResolveGroupText(rawMd, on, calGroupWasOn);
  }
  // 編輯「單個 CheckBox 子事件」：target 只是群內局部行，包塊會巢狀 → 沿用舊行尾式
  return on ? calApplyGroupMarkers(rawMd, true)
    : (calGroupWasOn ? calApplyGroupMarkers(rawMd, false) : rawMd);
}
function calRenderNotes(notes, uid, forceEditable) {
  if (!notes) return '';
  const raw = String(notes).replace(/\r\n/g, '\n');
  if (!calNotesCanEdit(uid, forceEditable)) {
    // 🆕 2026-11-07：唯讀（include / ro）行程也要顯示小事件群外框（與桌面 tlRenderNotes 同口徑）。
    //   舊版整段渲染直接 return，沒走 calSplitMdBlocks，故不會產生 .md-unit.is-gp。
    //   以 gp 區塊為切點：只把 type==='gp' 那段包外框（不掛編輯小圓點），其餘維持整段渲染；
    //   沒有 gp 區塊時沿用原本單次 renderMarkdown，零回歸。
    const display = calNotesWithChecks(calStripGpMarkers(raw), uid, false);
    const renderChunk = (s) => renderMarkdown(calRenderTermDefs(s));
    const gpBlocks = calSplitMdBlocks(raw).filter((b) => b.type === 'gp');
    if (!gpBlocks.length) return renderChunk(display);
    const dLines = display.split('\n');
    let out = '', cursor = 0;
    gpBlocks.forEach((b) => {
      if (cursor < b.start) out += renderChunk(dLines.slice(cursor, b.start).join('\n'));
      out += '<div class="md-unit is-gp"' + (b.anim ? ' data-gp-anim="' + b.anim + '"' : '') + calGpInlineStyle(b) + '>' +
        renderChunk(dLines.slice(b.start, b.end + 1).join('\n')) + '</div>';
      cursor = b.end + 1;
    });
    if (cursor < dLines.length) out += renderChunk(dLines.slice(cursor).join('\n'));
    return out;
  }
  const lines = raw.split('\n');
  let out = '';
  calSplitMdBlocks(raw).forEach((b) => {
    if (b.type === 'task') {
      // checkbox 行逐行獨立：一律沿用行內「編輯子事件」小圓點，不加外層區塊圓點
      out += calNoteCheckLineHtml(lines[b.start], uid, b.start, true) + '\n';
      return;
    }
    // 🆕 只剝「顯示副本」的 {gp}；編輯對話框讀的是 notes 原文，標記必須留著才能維持分組
    const chunk = calStripGpMarkers(lines.slice(b.start, b.end + 1).join('\n'));
    // 🆕 gp 組內的 - [ ] 行要比照一般 checkbox 轉成 .ev-md-check/.ev-cb，
    //    不能直接餵 renderMarkdown（會變 <ul><li> → 多一個「.」項目符號 + 原生灰框）。
    //    calNotesWithChecks 已自帶 marker 轉換，故 gp 分支不再重複跑 calRenderNoteMarkersLines。
    //    baseLine＝b.start 把區塊內索引補成整份 notes 的全域行號，供 calToggleNoteCheck 回寫。
    const prepared = (b.type === 'gp')
      ? calNotesWithChecks(chunk, uid, false, { plain: true, baseLine: b.start })
      : calRenderNoteMarkersLines(chunk);
    // 🆕 小事件群（連續同組 {gp} 行＝一個編輯小圓點區塊）：只給 gp 區塊掛 is-gp，
    //    由 CSS 畫 1px currentColor 外框；其它單元不受影響。
    //    🆕 2026-11-09：gp 區塊若有 fg/bg attrs，追加 inline style 覆蓋便利貼預設色
    const gpCls = b.type === 'gp' ? ' is-gp' : '';
    const gpStyle = b.type === 'gp' ? calGpInlineStyle(b) : '';
    const gpBadges = (b.type === 'gp') ? calGpBadgesHtml(b) : '';
    out += '<div class="md-unit' + gpCls + '"' +
      (b.type === 'gp' && b.anim ? ' data-gp-anim="' + b.anim + '"' : '') +
      (b.type === 'gp' && b.railStyle ? ' data-gp-rail="' + b.railStyle + '"' : '') +
      gpStyle + '>' + gpBadges + '<button type="button" class="md-unit-edit" title="編輯' +
      calMdUnitTypeName(b.type) + '" onclick="calOpenEditBlockDialog(event,\'' + escapeHtml(uid) +
      '\',' + b.start + ',' + b.end + ',\'' + b.type + '\')">✎</button>' +
      renderMarkdown(calRenderTermDefs(prepared)) + '</div>';
  });
  return out;
}
// 最小 MD 表達單元切分（與桌面 tlSplitMdBlocks 同演算法）：回傳 [{start,end,type}]（行索引含頭尾，end 不是開區間）。
//   code 代碼圍欄整塊原子 / table 表格 / heading 標題 / hr 分隔線 / quote 引用 / task 勾選行（逐行）/
//   list 普通列表（連續整段）/ para 段落。空行與空列表項只作分隔，不屬於任何區塊；
//   **例外**：夾在「前後相同 {gp} 行」之間的連續空行視為上一行 {gp} 的延續，併入同一個 gp 區塊。
function calSplitMdBlocks(text) {
  const lines = String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
  const gpKey = (l) => calGpKeyOfLine(l);
  const isGp = (l) => gpKey(l) !== null;
  const isBlank = (l) => /^\s*$/.test(l);
  const isFence = (l) => /^\s*(```|~~~)/.test(l);
  const isHeading = (l) => /^#{1,6}(\s|$)/.test(l);
  const isHrText = (l) => /^[ \t]{0,3}(-{3,}|\*{3,}|_{3,})[ \t]+(.+?)[ \t]+\1[ \t]*$/.test(l); // 「--- 文字 ---」＝帶文字分割線
  const isHr = (l) => /^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(l) || isHrText(l);
  const isQuote = (l) => /^\s{0,3}>/.test(l);
  const isTask = (l) => /^\s*[-*+]\s+\[[ xX]\]/.test(l);
  const isBullet = (l) => /^\s*[-*+]\s+\S/.test(l);
  const isOrdered = (l) => /^\s*\d{1,9}[.)]\s+\S/.test(l);
  const isList = (l) => !isTask(l) && !isFence(l) && (isBullet(l) || isOrdered(l));
  const isEmptyListItem = (l) => /^\s*[-*+]\s*$/.test(l) || /^\s*\d{1,9}[.)]\s*$/.test(l);
  const isTableRow = (l) => !isBlank(l) && l.includes('|');
  const isTableDelim = (l) => /^[\s|:-]+$/.test(l) && l.includes('-') && l.includes('|');
  const isTableStart = (j) => j + 1 < lines.length && isTableRow(lines[j]) && isTableDelim(lines[j + 1]);
  const blocks = [];
  // 🆕 塊級 {gpX}…{/gpX} 區間索引：開啟行 → 完整 range 物件（含 fg/bg），整段當一個 gp 原子區塊
  const fenceStart = new Map();
  const fenceInfo = (typeof calGpFenceScan === 'function') ? calGpFenceScan(lines) : { ranges: [], markers: [] };
  const fenceMarkers = new Set(fenceInfo.markers);
  fenceInfo.ranges.forEach((r) => fenceStart.set(r.start, r));
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (isBlank(line) || isEmptyListItem(line)) { i++; continue; }
    // 代碼圍欄整塊原子優先：圍欄內的 {gp} 不解析
    if (isFence(line)) {
      const marker = line.trim().slice(0, 3);
      let j = i + 1;
      while (j < lines.length && !(isFence(lines[j]) && lines[j].trim().slice(0, 3) === marker)) j++;
      blocks.push({ start: i, end: Math.min(j, lines.length - 1), type: 'code' });
      i = j + 1; continue;
    }
    // 🆕 塊級小事件群：優先於 isGp / task / list / table 等所有分支，整段（含兩行標記）原子化。
    if (fenceStart.has(i)) {
      const fe = fenceStart.get(i);
      blocks.push({ start: i, end: fe.end, type: 'gp', fg: fe.fg || '', bg: fe.bg || '', alert: fe.alert === true, termName: fe.termName || '', railStyle: fe.railStyle || '', railA: fe.railA || '', railB: fe.railB || '' });
      i = fe.end + 1; continue;
    }
    // 🆕 連續且「group 名相同」的 {gp} 行＝一個小事件（一顆編輯小圓點），覆蓋 task/list/para 等型態
    //    **例外（2026-11-06）**：純空白行（可多行連續）視為「上一行 {gp} 的延續」——
    //    只有當空白行之後的第一行仍是同 key 的 {gp} 行，才把空白行連同後段併進同一群。
    if (isGp(line)) {
      const key = gpKey(line);
      let j = i + 1;
      // 🆕 塊級標記行是硬邊界：前一個同 key 的行尾群絕對不能把它吞進來（與桌面同口徑）。
      while (j < lines.length && gpKey(lines[j]) === key && !fenceMarkers.has(j)) j++;
      // 反覆延伸，支援「gp 段 / 空行 / gp 段 / 空行 / gp 段」；
      // 空白行納入 [start,end]，baseLine 索引才連續、勾選回寫才不會改錯行。
      while (j < lines.length && isBlank(lines[j])) {
        let k = j;
        while (k < lines.length && isBlank(lines[k])) k++;
        if (k < lines.length && !fenceMarkers.has(k) && gpKey(lines[k]) === key) {
          j = k;
          while (j < lines.length && gpKey(lines[j]) === key && !fenceMarkers.has(j)) j++;
        } else break;
      }
      // 🆕 從行尾式 gp 第一行提取 fg/bg attrs（連續同名行之間 attrs 應一致；若不同，以第一行為準）
      const headAttrs = (typeof calExtractGpAttrsFromLine === 'function')
        ? calExtractGpAttrsFromLine(line) : { fg: '', bg: '' };
      blocks.push({ start: i, end: j - 1, type: 'gp', fg: headAttrs.fg || '', bg: headAttrs.bg || '', alert: headAttrs.alert === true, termName: headAttrs.termName || '', railStyle: headAttrs.railStyle || '', railA: headAttrs.railA || '', railB: headAttrs.railB || '' });
      i = j; continue;
    }
    if (isHeading(line)) { blocks.push({ start: i, end: i, type: 'heading' }); i++; continue; }
    if (isHr(line)) { blocks.push({ start: i, end: i, type: 'hr' }); i++; continue; }
    if (isQuote(line)) { let j = i; while (j < lines.length && isQuote(lines[j]) && !isGp(lines[j])) j++; blocks.push({ start: i, end: j - 1, type: 'quote' }); i = j; continue; }
    if (isTableStart(i)) { let j = i + 2; while (j < lines.length && isTableRow(lines[j]) && !isBlank(lines[j]) && !isGp(lines[j])) j++; blocks.push({ start: i, end: j - 1, type: 'table' }); i = j; continue; }
    if (isTask(line)) { blocks.push({ start: i, end: i, type: 'task' }); i++; continue; }
    if (isList(line)) {
      let j = i + 1;
      while (j < lines.length) {
        if (isBlank(lines[j]) || isEmptyListItem(lines[j])) {
          let k = j + 1;
          while (k < lines.length && (isBlank(lines[k]) || isEmptyListItem(lines[k]))) k++;
          if (k < lines.length && isList(lines[k]) && !isGp(lines[k])) { j = k; continue; }
          break;
        }
        if (isList(lines[j]) && !isGp(lines[j])) { j++; continue; }
        break;
      }
      blocks.push({ start: i, end: j - 1, type: 'list' });
      i = j; continue;
    }
    { let j = i;
      while (j < lines.length && !isBlank(lines[j]) && !isFence(lines[j]) && !isHeading(lines[j]) && !isHr(lines[j]) &&
             !isQuote(lines[j]) && !isTask(lines[j]) && !isList(lines[j]) && !isTableStart(j) && !isGp(lines[j])) j++;
      if (j === i) j = i + 1;
      blocks.push({ start: i, end: j - 1, type: 'para' }); i = j; continue;
    }
  }
  return blocks;
}
function calMdUnitTypeName(type) {
  return ({ code: '代碼塊', table: '表格', heading: '標題', hr: '分隔線', quote: '引用', list: '列表', para: '段落', gp: '分組' })[type] || '區塊';
}
// 備註 checkbox 行內的 建立日(cr) / deadline(dl) / completed(cp) 標記（顯示層轉換，不改寫源）：
//   [[cr:...]] → 🆕（建立日）、裸日期與 [[dl:...]] → 📅、[[cp:...]] → ✅（cr 須排在最前，先轉才不會被 dl 規則吃掉）
// 🆕 2026-11-08：cr / dl / cp（含裸日期）統一渲染成「一顆長徽標」＝圖示＋月-日（小字），
//   完整「日期+時間」放 title（hover tooltip）與 data-date（VIEW 排序讀取）；底稿原文不改。
//   與桌面 calendar-editor.js::tlDateMarkHtml 完全同口径。
function calDateMarkHtml(kind, full) {
  const meta = { cr: ['\u{1F195}', '建立日'], dl: ['\u{1F4C5}', '预计完成'], cp: ['\u2705', '完成日'] }[kind];
  return '<span class="ev-date-mark ev-date-' + kind + '" title="' + escapeHtml(meta[1] + ' ' + full) +
    '" data-date="' + escapeHtml(full) + '">' + meta[0] + ' <span class="ev-date-mark-md">' +
    escapeHtml(full.slice(5, 10)) + '</span></span>';
}
function calRenderNoteMarkers(text) {
  return String(text)
    .replace(/\[\[cr:(\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?)\]\]/g, (m, d) => calDateMarkHtml('cr', d))
    .replace(/\[\[(?:dl:)?(\d{4}-\d{2}-\d{2})\]\]/g, (m, d) => calDateMarkHtml('dl', d))
    .replace(/\[\[cp:(\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?)\]\]/g, (m, d) => calDateMarkHtml('cp', d));
}
// 逐行套用 cr/dl/cp 顯示轉換（跳過代碼圍欄）；讓「非 checkbox 行」也能正確渲染 [[cr:…]]→🆕（與桌面 tlRenderNoteMarkersLines 同口徑）
function calRenderNoteMarkersLines(text) {
  let inFence = false;
  return String(text).split('\n').map(function (line) {
    if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; return line; }
    if (inFence) return line;
    return calRenderNoteMarkers(line);
  }).join('\n');
}
function calNoteCheckLineHtml(line, uid, i, canEdit, opts) {
  const m = line.match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
  if (!m) return line;
  const done = m[2] !== ' ';
  // 🆕 plain＝gp 組內的 checkbox：整組只有外層一顆編輯圓點 → 不掛行內 ✎，
  //    但 checkbox 本身與一般 checkbox 一樣可勾選（2026-11-06 使用者要求 Group 與否同作用）。
  //    外觀共用 .ev-md-check/.ev-cb，避免 renderMarkdown 產出 <ul><li> 項目符號。
  const plain = !!(opts && opts.plain);
  // 🆕 gp 區塊傳 baseLine＝該區塊在整份 notes 的起始行號；勾選回寫必須用全域行號。
  const baseLine = (opts && Number.isInteger(opts.baseLine)) ? opts.baseLine : 0;
  const lineNo = baseLine + i;
  // ✎（編輯子事件）與桌面 tlTaskLineHtml 同口徑：只有真的可編輯才給；ro 行程在行程檢視不給。
  //   canEdit 由呼叫端算好傳進來（每個事件只查一次 state.calEvents，不在行級重複 find）。
  const editButton = (!plain && canEdit)
    ? '<button type="button" class="ev-md-edit" title="編輯 checkbox 子事件" onclick="calOpenEditNoteCheckDialog(event,\'' +
      escapeHtml(uid) + '\',' + i + ')">✎</button>'
    : '';
  // ⚠️ 勾選互動（onclick/onkeydown/role）只掛在「框框本身」.ev-cb 上，與桌面 tlTaskLineHtml 同口徑——
  //   整行（含文字 .ev-md-check-text）不再觸發，避免手機上點到文字就誤勾（原先 onclick 掛在外層 .ev-md-check 整行）。
  // 🆕 plain 只代表「共用外層圓點、不掛行內 ✎」；勾選互動與一般 checkbox 完全相同，
  //    data-line／onclick 一律用全域行號 lineNo（gp 區塊由 baseLine 補上偏移）。
  const cbAttr = uid
    ? ' class="ev-cb interactive" data-uid="' + escapeHtml(uid) + '" data-line="' + lineNo + '"' +
      ' onclick="calToggleNoteCheck(event,\'' + escapeHtml(uid) + '\',' + lineNo + ')"' +
      ' onkeydown="calCalCheckKey(event,\'' + escapeHtml(uid) + '\',' + lineNo + ')"' +
      ' role="checkbox" aria-checked="' + (done ? 'true' : 'false') + '" tabindex="0"'
    : ' class="ev-cb"';
  return m[1] + '<span class="ev-md-check' + (done ? ' done' : '') + '">' + editButton +
    '<span' + cbAttr + '>' + (done ? '✓' : '') + '</span>' +
    '<span class="ev-md-check-text">' + calRenderInlineMarkdown(calRenderNoteMarkers(m[3])) + '</span></span>';
}
function calNotesWithChecks(text, uid, canEdit, opts) {
  let inFence = false;
  return text.split('\n').map((line, i) => {
    if (/^\s*```/.test(line)) { inFence = !inFence; return line; }
    if (inFence) return line;
    // checkbox 行由 calNoteCheckLineHtml 內建 cr 渲染；其餘行（段落/列表/引用…）也套用 cr/dl/cp 顯示轉換（與桌面同口徑）
    // plain 模式靠 opts.baseLine 把局部 i 補成全域行號（勾選回寫要定位原文行）；非 plain 時 baseLine=0
    if (/^\s*[-*+]\s+\[[ xX]\]/.test(line)) return calNoteCheckLineHtml(line, uid, i, canEdit, opts);
    return calRenderNoteMarkers(line);
  }).join('\n');
}
// 🖱 日/週時間網格雙擊空白處快速新增：15 分鐘取整，默認時長 1 小時；全天條＝日期(全天)
function calGridDblClickNew(e) {
  if (e.target.closest('.ev-block') || e.target.closest('button')) return; // 點在已有行程上不新增
  const col = e.target.closest('.ev-tg-col[data-date]');
  if (col) {
    const rect = col.getBoundingClientRect();
    if (rect.height <= 0) return;
    const mins = Math.max(0, Math.min(23 * 60, Math.floor((e.clientY - rect.top) / rect.height * 24 * 60 / 15) * 15));
    const pad = (x) => String(x).padStart(2, '0');
    const endM = mins + 60;
    openEventForm(null, col.getAttribute('data-date'), {
      allDay: false,
      startTime: pad(Math.floor(mins / 60)) + ':' + pad(mins % 60),
      endTime: endM >= 24 * 60 ? '' : pad(Math.floor(endM / 60)) + ':' + pad(endM % 60),
    });
    return;
  }
  const ad = e.target.closest('.ev-allday-col[data-date]');
  if (ad) openEventForm(null, ad.getAttribute('data-date'), { allDay: true });
}
// 月格連點檢測的狀態（見 setupEventListeners 的 evMonthGrid click）
let calLastCellClick = { date: null, t: 0 };
// 月視圖單元格內的跨天色條 / 普通 chip
// ⚠️ 帶 data-ev-edit：月格上的 chip 點擊直接開表單（走事件委派，見 setupEventListeners 的 evMonthGrid）
// 🔁 重複事件小圖標（## EVENT(REPEAT)）：雙箭頭環形，隨文色（灰）；月格 chip / 時間網格 / 列表行 / 懸停提示通用
function calRepeatIcon(ev) {
  if (!ev || !ev.repeatMode) return '';
  return '<svg class="ev-repeat-ic" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="重複"><title>重複事件</title><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>';
}
function calSpanChipHtml(ev, pos, idx, total, occDate) {
  const links = calEventTodoLinks(ev);
  const edit = ' data-ev-edit="' + escapeHtml(ev.uid) + '"';
  const occ = ' data-occ-date="' + escapeHtml(occDate || ev.date) + '"';
  // 单日 → 普通 chip（圆点+标题）
  if (pos === 'single') {
    return '<div class="ev-chip' + (ev.done ? ' done' : '') + '"' + edit + occ + '><span class="dot" style="background:' + escapeHtml(ev.color) + '"></span>' + (ev.done ? '✓ ' : '') + calRepeatIcon(ev) + calRenderInlineMarkdown(ev.title) + calRoIcon(ev) + links + '</div>';
  }
  // 跨天：start/end 显示标题作起止标识，middle 渲染为连续色条（不重复标题，悬停可见）
  const cls = 'ev-chip span ' + pos + (ev.done ? ' done' : '');
  const dot = '<span class="dot" style="background:' + escapeHtml(ev.color) + '"></span>';
  const titlePart = (ev.done ? '✓ ' : '') + calRepeatIcon(ev) + calRenderInlineMarkdown(ev.title) + calSpanSuffix(idx, total) + calRoIcon(ev) + links;
  // 每一段（start/middle/end）都顯示「標題 k/N」——空色條看不出是哪條行程的延續
  let inner = (pos === 'start' ? dot : '') + titlePart;
  const tip = (pos === 'middle') ? ' title="' + escapeHtml(ev.title) + '"' : '';
  return '<div class="' + cls + '" style="--ev-color:' + escapeHtml(ev.color) + '"' + tip + edit + occ + '>' + inner + '</div>';
}

// ===== 🏷 標籤過濾 / 跨天展開 / 時間網格 輔助（移植自桌面 TodoList 日曆模式）=====
// 事件是否滿足當前標籤過濾（空＝全部；OR 邏輯：任一標籤命中即顯示）
// 🆕 父階標籤 BOM 展開：選中某標籤＝匹配「自身＋全部子階＋孫階…」的事件（沿 ## TAGS 樹向下收集）
function calTagDescendants(name) {
  const m = calTagMeta();
  const out = [name];
  const queue = [name];
  const seen = new Set(queue);
  let guard = 0;
  while (queue.length && guard++ < 1000) {
    const cur = queue.shift();
    Object.keys(m).forEach((k) => { if (m[k] === cur && !seen.has(k)) { seen.add(k); out.push(k); queue.push(k); } });
  }
  return out;
}
function calEventMatchesTag(ev) {
  if (!state.calTagFilter.length) return true;
  const tags = ev.tags || [];
  return state.calTagFilter.some((f) => {
    const fam = calTagDescendants(f);
    return tags.some((tg) => fam.indexOf(calTagName(tg)) >= 0);
  });
}
// 分類顯示過濾（頂欄 EVENT / REPEAT 三態勾選）：
//   EVENT 勾選＝顯示普通行程；REPEAT 三態＝none 隱藏全部 / next 只顯示未來最近一次 / some 最近前一次+未來4次（最多5次）。
// ⚠️ 重複行程是否「可見」由 calEventVisible 決定（none 才隱藏），「顯示幾次」由 calEventOccurrences 決定。
function calEventVisible(ev) {
  if (ev && ev.repeatMode) return state.calShowRepeat !== 'none';
  return state.calShowEvents;
}
// 事件是否應顯示＝標籤過濾 ∩ 分類過濾（所有「按日期分組」入口統一走這裡）
// ⚠️ 「只顯示未完成」全模式生效（年/月/週/日/列表）：勾選後隱藏已完成（done ✓）的行程；假日無完成態不受影響
function calEventShown(ev) { if (state.calUndoneOnly && ev && ev.done) return false; return calEventMatchesTag(ev) && calEventVisible(ev); }
// 取某天出現的所有事件（含跨天展開），並套用標籤過濾
function calEventsOnDay(dateStr) {
  const out = [];
  state.calEvents.forEach((ev) => {
    if (!calEventShown(ev)) return;
    calEventOccurrences(ev).forEach((o) => { if (o.date === dateStr) out.push({ ev: o.ev, pos: o.pos, idx: o.idx, total: o.total }); });
  });
  return out;
}
// 日期加減（回傳新的本地日期物件，避免改到原物件）
function calAddDays(d, n) { const r = new Date(d.getFullYear(), d.getMonth(), d.getDate()); r.setDate(r.getDate() + n); return r; }
// 取某天所在週的 7 天（週一開頭）
function calWeekDays(d) {
  const cur = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const dow = (cur.getDay() + 6) % 7; // 週一 = 0
  cur.setDate(cur.getDate() - dow);
  const out = [];
  for (let i = 0; i < 7; i++) out.push(new Date(cur.getFullYear(), cur.getMonth(), cur.getDate() + i));
  return out;
}
// 重疊佈局：把時間衝突的事件分配到並排列（移植自桌面 layoutDay 的 cluster packing）
function calLayoutDay(evs) {
  const items = evs.map((e) => ({
    e,
    start: calendarTimeToMin(e.startTime),
    end: Math.max(calendarTimeToMin(e.endTime), calendarTimeToMin(e.startTime) + 15),
  })).sort((a, b) => a.start - b.start || a.end - b.end);
  const result = [];
  let cluster = [], clusterEnd = -1;
  const flush = () => {
    if (!cluster.length) return;
    const cols = [];
    cluster.forEach((it) => {
      let placed = false;
      for (let ci = 0; ci < cols.length; ci++) {
        if (cols[ci] <= it.start) { cols[ci] = it.end; it.col = ci; placed = true; break; }
      }
      if (!placed) { it.col = cols.length; cols.push(it.end); }
    });
    cluster.forEach((it) => { it.cols = cols.length; result.push(it); });
    cluster = [];
    clusterEnd = -1;
  };
  items.forEach((it) => {
    if (it.start >= clusterEnd) flush();
    cluster.push(it);
    clusterEnd = Math.max(clusterEnd, it.end);
  });
  flush();
  return result;
}
// 行程條上的 🔗 關聯標記
// ⚠️ 與桌面的差異：LITE 是通用 MD 編輯器，沒有 todo 卡片清單可解析標題 → 直接顯示卡片 id
function calEventTodoLinks(ev) {
  const ids = ev.todoIds || [];
  if (!ids.length) return '';
  return ids.map((id) => '<span class="ev-link" title="🔗 ' + escapeHtml(id) + '">🔗</span>').join('');
}

// ===== 🖱 悬停行程事件 → 放大提示框（更大字体显示事件内容；手机无 hover，桌面浏览器看 PWA 时生效） =====
let calTipEl = null, calTipUid = null;
function calGetTipEl() {
  if (!calTipEl) {
    calTipEl = document.createElement('div');
    calTipEl.className = 'ev-tip';
    calTipEl.setAttribute('role', 'tooltip');
    calTipEl.style.display = 'none';
    document.body.appendChild(calTipEl);
  }
  return calTipEl;
}
// occDate＝該列所屬「出現日」：跨天行程要標 (第幾天/共幾天)，與列表行/月格 chip 同款
function calTipHtml(ev, occDate) {
  const multi = calIsMultiDay(ev);
  let when;
  if (calIsSpanToday(ev)) when = CAL_SPAN_TODAY_TEXT;   // 显示在今天：不显示真实日期区间
  else if (multi) when = ev.allDay
    ? (calRangeLabel(ev.date, ev.endDate) + ' · 共' + calSpanDays(ev.date, ev.endDate) + '天')
    : calRangeLabel(ev.date, ev.endDate, ev.startTime, ev.endTime);
  else when = ev.allDay ? '全天' : ((ev.startTime || '') + (ev.endTime ? '-' + ev.endTime : ''));
  const tags = (ev.tags && ev.tags.length) ? '<div class="ev-tip-tags">' + ev.tags.map((t) => '<span class="ev-tag-view" data-tag="' + escapeHtml(calTagName(t)) + '">' + escapeHtml(calTagLabel(t)) + '</span>').join('') + '</div>' : '';
  const loc = ev.location ? '\ud83d\udccd ' + escapeHtml(ev.location) : '';
  const notes = ev.notes ? '<div class="ev-tip-notes">' + calRenderNotes(ev.notes, null) + '</div>' : '';
  const links = calEventTodoLinks(ev);
  return '<div class="ev-tip-title">' + calRepeatIcon(ev) + calRenderInlineMarkdown(ev.title) + calSpanDaySuffix(ev, occDate) + (ev.done ? ' <span class="ev-tip-done">\u2713</span>' : '') + '</div>' +
    '<div class="ev-tip-meta">' + escapeHtml(when) + (loc ? ' · ' + loc : '') + '</div>' + tags + links + notes;
}
function calShowTip(uid, occDate, x, y) {
  const ev = state.calEvents.find((e) => e.uid === uid);
  if (!ev) return;
  const tip = calGetTipEl();
  // ⚠️ 跨天行程同一 uid 会出现在多天 → 缓存 key 必须带上 occDate，否则在「第1天」悬停后切到「第3天」仍显示 (1/7)
  const key = uid + '@' + (occDate || '');
  if (calTipUid !== key) { tip.innerHTML = calTipHtml(ev, occDate); calTipUid = key; }
  tip.style.display = 'block';
  const r = tip.getBoundingClientRect();
  let left = x + 16, top = y + 16;
  if (left + r.width > window.innerWidth - 8) left = Math.max(8, x - r.width - 16);
  if (top + r.height > window.innerHeight - 8) top = Math.max(8, y - r.height - 16);
  tip.style.left = left + 'px';
  tip.style.top = top + 'px';
}
function calHideTip() { if (calTipEl) { calTipEl.style.display = 'none'; calTipUid = null; } }

// ===== 📓 悬停日记图标 → 放大提示框（复用 .ev-tip 结构，仅当天有日记时显示；触屏设备由 app.js 媒体查询守卫禁用） =====
function calDiaryTipHtml(d) {
  const meta = [d.date, d.mood, d.weather].filter(Boolean).join(' · ');
  const tags = (d.tags && d.tags.length) ? '<div class="ev-tip-tags">' + d.tags.map((t) => '<span class="ev-tag-view" data-tag="' + escapeHtml(calTagName(t)) + '">' + escapeHtml(calTagLabel(t)) + '</span>').join('') + '</div>' : '';
  const body = d.content ? '<div class="ev-tip-notes">' + calDiaryBody(d.content) + '</div>' : '';
  const remark = d.remark ? '<div class="ev-tip-meta" style="margin-top:6px;">備註：' + calRenderInlineMarkdown(d.remark) + '</div>' : '';
  return '<div class="ev-tip-title">\ud83d\udcd5 ' + calRenderInlineMarkdown(d.title || '日記') + '</div>' +
    (meta ? '<div class="ev-tip-meta">' + escapeHtml(meta) + '</div>' : '') + tags + body + remark;
}
function calShowDiaryTip(date, x, y) {
  const d = calDiaryOnDate(date);
  if (!d) return;
  const tip = calGetTipEl();
  const key = 'diary:' + date;
  if (calTipUid !== key) { tip.innerHTML = calDiaryTipHtml(d); calTipUid = key; }
  tip.style.display = 'block';
  const r = tip.getBoundingClientRect();
  let left = x + 16, top = y + 16;
  if (left + r.width > window.innerWidth - 8) left = Math.max(8, x - r.width - 16);
  if (top + r.height > window.innerHeight - 8) top = Math.max(8, y - r.height - 16);
  tip.style.left = left + 'px';
  tip.style.top = top + 'px';
}

// ===== 📱 触屏：点事件 → 小选单（编辑 / 详情）替代「直接开表单」+「hover 提示框」 =====
// 手机无真 hover：hover 提示框已禁用（app.js 媒体查询守卫 + @media (hover:none) 隐藏），
// 故把「放大详情」做成点击可达——点事件先弹选单，再选「编辑」或「详情（类似 tips 显示）」。
const calCanHover = window.matchMedia('(hover: hover) and (pointer: fine)');
let calMenuEl = null, calDetailEl = null;
// 文档级外部点击关闭（capture，绑定一次复用）；选单/详情各自移除时一并解绑，避免重复监听。
function calDocClick(e) {
  if (calMenuEl && !calMenuEl.contains(e.target)) calRemoveMenu();
  if (calDetailEl && !calDetailEl.contains(e.target)) calRemoveDetail();
  if (calAlmanacEl && !calAlmanacEl.contains(e.target)) calRemoveAlmanac();
}
function calRemoveMenu() {
  if (calMenuEl) { calMenuEl.remove(); calMenuEl = null; }
  document.removeEventListener('click', calDocClick, true);
}
function calRemoveDetail() {
  if (calDetailEl) { calDetailEl.remove(); calDetailEl = null; }
  document.removeEventListener('click', calDocClick, true);
}
// 点事件：弹小选单（编辑 / 详情）。只在触屏（!calCanHover.matches）调用，桌面保持点开表单。
function calShowEventMenu(anchorEl, uid) {
  calRemoveMenu(); calRemoveDetail();
  const menu = document.createElement('div');
  menu.className = 'ev-act-menu';
  menu.setAttribute('role', 'menu');
  menu.setAttribute('data-uid', uid);
  menu._anchor = anchorEl;
  // 🆕 多檔聯運：ro 事件給「檢視（唯讀）」，刪除依舊不給（2026-11-04）
  calRefreshAll();
  const ev = (state.calEvents || []).find((x) => x.uid === uid);
  const ro = !!(ev && ev.ro);
  menu.innerHTML =
    '<button type="button" data-act="detail" role="menuitem">🔍 详情</button>' +
    (ro
      ? '<button type="button" data-act="edit" role="menuitem">🔒 检视（只读）</button>'
      : '<button type="button" data-act="edit" role="menuitem">✏️ 编辑</button>' +
        '<button type="button" data-act="del" role="menuitem">🗑 删除</button>') +
    '<button type="button" data-act="cancel" role="menuitem">✕ 取消</button>';
  document.body.appendChild(menu);
  calMenuEl = menu;
  const r = anchorEl.getBoundingClientRect();
  const mw = menu.offsetWidth || 150, mh = menu.offsetHeight || 80;
  let left = r.left, top = r.bottom + 6;
  if (left + mw > window.innerWidth - 8) left = window.innerWidth - mw - 8;
  if (top + mh > window.innerHeight - 8) top = r.top - mh - 6;
  menu.style.left = Math.max(8, left) + 'px';
  menu.style.top = Math.max(8, top) + 'px';
  menu.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const act = btn.getAttribute('data-act');
    const u = menu.getAttribute('data-uid');
    if (act === 'detail') { calRemoveMenu(); calShowEventDetail(u, anchorEl); }
    else if (act === 'edit') { calRemoveMenu(); openEventForm(u); }
    else if (act === 'del') { calRemoveMenu(); deleteEventByUid(u); }
    else { calRemoveMenu(); } // 取消：仅关闭选单
  });
  // 延后绑定外部点击，避开「开启当次 click」把自己关掉
  setTimeout(() => document.addEventListener('click', calDocClick, true), 0);
}
// 选单「详情」：以可点闭的浮层显示放大内容（复用 calTipHtml），pointer-events:auto 可交互。
function calShowEventDetail(uid, anchorEl) {
  // 📎 多檔聯運：詳情需能看見 include 進來的只讀事件 → 用併集定位
  calRefreshAll();
  const ev = state.calEvents.find((x) => x.uid === uid);
  if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); return; }
  calRemoveMenu(); calRemoveDetail();
  const pop = document.createElement('div');
  pop.className = 'ev-detail-pop';
  pop.setAttribute('role', 'dialog');
  pop.innerHTML = '<button type="button" class="ev-detail-close" aria-label="关闭">✕</button>' + calTipHtml(ev, anchorEl ? anchorEl.getAttribute('data-occ-date') : undefined);
  document.body.appendChild(pop);
  calDetailEl = pop;
  const pw = pop.offsetWidth || 300, ph = pop.offsetHeight || 160;
  let left = anchorEl ? anchorEl.getBoundingClientRect().left : (window.innerWidth - pw) / 2;
  let top = anchorEl ? anchorEl.getBoundingClientRect().bottom + 6 : (window.innerHeight - ph) / 2;
  if (left + pw > window.innerWidth - 8) left = window.innerWidth - pw - 8;
  if (top + ph > window.innerHeight - 8) top = window.innerHeight - ph - 8;
  pop.style.left = Math.max(8, left) + 'px';
  pop.style.top = Math.max(8, top) + 'px';
  pop.querySelector('.ev-detail-close').addEventListener('click', calRemoveDetail);
  setTimeout(() => document.addEventListener('click', calDocClick, true), 0);
}
// 標籤過濾條：無標籤時整條隱藏
function renderCalTagBar() {
  const bar = elements.evTagBar;
  const filter = elements.evTagFilter;
  if (!bar || !filter) return;
  const tags = new Set();
  state.calEvents.forEach((ev) => (ev.tags || []).forEach((t) => { if (calTagName(t)) tags.add(calTagName(t)); }));
  // 🆕 父階標籤（無事件直接掛靠，但是其他標籤的父/祖階）也要顯示：併入 ## TAGS 樹登記的全部標籤
  calAllTagNames().forEach((t) => tags.add(t));
  const options = document.getElementById('ev-tag-options');
  if (options) options.innerHTML = Array.from(tags).sort().map((t) => '<option value="' + escapeHtml(t) + '"></option>').join('');
  if (!tags.size) { bar.style.display = 'none'; filter.innerHTML = '';
    const tagPanel = document.getElementById('cal-tagbar-panel'); if (tagPanel) tagPanel.style.display = 'none'; return; }
  // ⚠️ 必須顯式給 'flex'：CSS 裡 .ev-tagbar 預設 display:none，清空 inline style 會被 CSS 覆蓋回隱藏
  bar.style.display = 'flex';
  // 🏷 標籤過濾外層面板（combo 菜單裡的 toggle 區塊）：有 tag 才顯示
  const tagPanel = document.getElementById('cal-tagbar-panel');
  if (tagPanel) tagPanel.style.display = '';
  const calIsTagInherited = (t) => {
    if (state.calTagFilter.indexOf(t) >= 0) return false;
    return state.calTagFilter.some((f) => calTagDescendants(f).indexOf(t) >= 0);
  };
  filter.innerHTML = Array.from(tags).map((t) => {
    const active = state.calTagFilter.indexOf(t) >= 0;
    const desc = !active && calIsTagInherited(t);
    const cls = active ? ' active' : (desc ? ' active-desc' : '');
    return '<span class="ev-tag-chip' + cls + '" data-tag="' + escapeHtml(t) + '">' + escapeHtml(t) + '</span>';
  }).join('');
}

function renderCalTagOptions() {
  const options = document.getElementById('ev-tag-options');
  if (!options) return;
  const tags = new Set();
  state.calEvents.forEach((ev) => (ev.tags || []).forEach((t) => { if (calTagName(t)) tags.add(calTagName(t)); }));
  options.innerHTML = Array.from(tags).sort().map((t) => '<option value="' + escapeHtml(t) + '"></option>').join('');
}
// ===== 标签右键菜单 + 编辑标签画面（树形父阶）=====
function calInjectTagTreeStyle() {
  if (document.getElementById('cal-tag-tree-style')) return;
  const s = document.createElement('style');
  s.id = 'cal-tag-tree-style';
  s.textContent = [
    '.cal-tag-ctx-menu{position:fixed;z-index:9999;min-width:150px;background:var(--ev-card,#1e293b);color:var(--ev-text,#e2e8f0);border:1px solid var(--ev-border,#334155);border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.35);padding:6px;font-size:13px}',
    '.cal-tag-ctx-menu button{display:block;width:100%;text-align:left;background:none;border:0;color:inherit;padding:8px 10px;border-radius:6px;cursor:pointer;font-size:13px}',
    '.cal-tag-ctx-menu button:hover{background:var(--ev-hover,#334155)}',
    '#calTagEditOverlay{position:fixed;inset:0;z-index:9000;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.45)}',
    '#calTagEditOverlay .cal-tag-edit-box{background:var(--ev-card,#1e293b);color:var(--ev-text,#e2e8f0);border:1px solid var(--ev-border,#334155);border-radius:14px;box-shadow:0 10px 40px rgba(0,0,0,.45);width:min(440px,92vw);max-height:86vh;overflow:auto;padding:18px 20px}',
    '#calTagEditOverlay h3{margin:0 0 4px;font-size:16px}',
    '.cal-tag-edit-sec{margin-top:16px}',
    '.cal-tag-edit-sec .lbl{font-size:12px;opacity:.7;margin-bottom:8px}',
    '.cal-tag-children{display:flex;flex-wrap:wrap;gap:8px}',
    '.cal-tag-child{display:inline-flex;align-items:center;gap:6px;background:var(--ev-hover,#334155);border-radius:999px;padding:5px 12px;cursor:pointer;font-size:13px}',
    '.cal-tag-child:hover{outline:1px solid var(--primary,#3b82f6)}',
    '.cal-tag-cat-item{display:inline-flex;align-items:center;background:var(--ev-hover,#334155);border-radius:999px;padding:5px 12px;font-size:13px}',
    '.cal-tag-edit-actions{margin-top:20px;display:flex;justify-content:flex-end;gap:10px}',
    '.cal-tag-edit-actions button{padding:8px 16px;border-radius:8px;border:1px solid var(--ev-border,#334155);background:var(--ev-hover,#334155);color:inherit;cursor:pointer;font-size:13px}',
    '.cal-tag-edit-actions button.primary{background:var(--primary,#3b82f6);color:#fff;border-color:transparent}',
  ].join('');
  document.head.appendChild(s);
}
function calEnsureTagCtxMenu() {
  let menu = document.getElementById('calTagCtxMenu');
  if (menu) return menu;
  calInjectTagTreeStyle();
  menu = document.createElement('div');
  menu.id = 'calTagCtxMenu';
  menu.className = 'cal-tag-ctx-menu';
  menu.style.display = 'none';
  menu.innerHTML = '<button type="button" data-cal-tag-edit="1">✎ 编辑标签属性</button>';
  document.body.appendChild(menu);
  menu.addEventListener('click', (ev) => {
    if (ev.target.getAttribute && ev.target.getAttribute('data-cal-tag-edit')) { menu.style.display = 'none'; calOpenTagEdit(menu.__tag); }
  });
  document.addEventListener('click', () => { menu.style.display = 'none'; }, true);
  return menu;
}
function calShowTagCtxMenu(name, x, y) {
  const menu = calEnsureTagCtxMenu();
  menu.__tag = name;
  menu.style.display = 'block';
  const pw = menu.offsetWidth || 160, ph = menu.offsetHeight || 40;
  let left = x, top = y;
  if (left + pw > window.innerWidth - 8) left = window.innerWidth - pw - 8;
  if (top + ph > window.innerHeight - 8) top = window.innerHeight - ph - 8;
  menu.style.left = Math.max(4, left) + 'px';
  menu.style.top = Math.max(4, top) + 'px';
}
function calEnsureTagEditOverlay() {
  let ov = document.getElementById('calTagEditOverlay');
  if (ov) return ov;
  calInjectTagTreeStyle();
  ov = document.createElement('div');
  ov.id = 'calTagEditOverlay';
  document.body.appendChild(ov);
  ov.addEventListener('click', (e) => { if (e.target === ov) ov.style.display = 'none'; });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && ov.style.display !== 'none') ov.style.display = 'none'; });
  return ov;
}
function calOpenTagEdit(name) {
  if (!name) return;
  const ov = calEnsureTagEditOverlay();
  const parent = calTagParent(name);
  const children = calTagChildren(name);
  const m = calTagMeta();
  const candidates = calAllTagNames().filter((t) => t !== name && !calIsDescendant(t, name, m));
  const cats = calFormCatNames(name);
  const opts = ['<option value="">（无／根标签）</option>'].concat(
    candidates.map((t) => '<option value="' + escapeHtml(t) + '"' + (t === parent ? ' selected' : '') + '>' + escapeHtml(t) + '</option>')
  ).join('');
  const childHtml = children.length
    ? '<div class="cal-tag-children">' + children.map((c) => '<span class="cal-tag-child" data-cal-tag-child="' + escapeHtml(c) + '">' + escapeHtml(c) + '</span>').join('') + '</div>'
    : '<div class="lbl">（暂无子标签）</div>';
  // 分类 chip：只读展示（勿用 .cal-tag-child，避免命中「点子标签递归打开」的委托）
  const catHtml = cats.length
    ? '<div class="cal-tag-children">' + cats.map((c) => '<span class="cal-tag-cat-item">' + escapeHtml(c) + '</span>').join('') + '</div>'
    : '<div class="lbl">（暂无分类）</div>';
  ov.innerHTML =
    '<div class="cal-tag-edit-box">' +
      '<h3>编辑标签「' + escapeHtml(name) + '」</h3>' +
      '<div class="cal-tag-edit-sec"><div class="lbl">子标签列表（以其为父的标签）</div>' + childHtml + '</div>' +
      '<div class="cal-tag-edit-sec"><div class="lbl">分类（该标签的子分类）</div>' + catHtml + '</div>' +
      '<div class="cal-tag-edit-sec"><div class="lbl">父阶标签（上级）</div>' +
        '<select id="calTagParentSel" style="width:100%;padding:8px;border-radius:8px;background:var(--ev-hover,#334155);color:inherit;border:1px solid var(--ev-border,#334155);font-size:13px">' + opts + '</select>' +
      '</div>' +
      '<div class="cal-tag-edit-actions"><button type="button" id="calTagEditClose">关闭</button></div>' +
    '</div>';
  ov.style.display = 'flex';
  ov.querySelector('#calTagEditClose').addEventListener('click', () => { ov.style.display = 'none'; });
  ov.querySelector('#calTagParentSel').addEventListener('change', (e) => {
    const ok = calSetTagParent(name, e.target.value);
    if (!ok) { if (typeof showToast === 'function') showToast('不能将上级设为自身的下级（会造成循环）', 'danger'); e.target.value = parent; return; }
    if (typeof handleSave === 'function') handleSave();
    renderCalTagBar();
    if (typeof showToast === 'function') showToast('已更新「' + name + '」的父阶标签', 'success');
  });
  ov.querySelectorAll('.cal-tag-child').forEach((c) => c.addEventListener('click', () => calOpenTagEdit(c.getAttribute('data-cal-tag-child'))));
}
// 标签（过滤条 chip 或 事件/日志卡片上的内联标签 .ev-tag-view）右键 → 弹出菜单（委托监听，覆盖重绘后的新节点）
document.addEventListener('contextmenu', (e) => {
  const tagEl = e.target.closest('[data-tag]');
  if (!tagEl) return;
  e.preventDefault();
  calShowTagCtxMenu(tagEl.getAttribute('data-tag'), e.clientX, e.clientY);
});

function calFormTagNames() {
  const tags = new Set();
  state.calEvents.forEach((ev) => (ev.tags || []).forEach((t) => { if (calTagName(t)) tags.add(calTagName(t)); }));
  return Array.from(tags).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
}
// 子標籤（分類）歷史：只從「該標籤」所屬事件的 cat 收集（標籤與子標籤有從屬關係）
// tagName 為空 → 空列表（非編輯態時不需要下拉選項）
function calFormCatNames(tagName) {
  const cats = new Set();
  if (!tagName) return [];
  state.calEvents.forEach((ev) => (ev.tags || []).forEach((t) => { if (calTagName(t) === tagName) { const c = calTagCat(t); if (c) cats.add(c); } }));
  return Array.from(cats).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
}
function calFormSubcatNames(tagName, cat) {
  const subcats = new Set();
  if (!tagName || !cat) return [];
  state.calEvents.forEach((ev) => (ev.tags || []).forEach((t) => {
    if (calTagName(t) === tagName && calTagCat(t) === cat) {
      const subcat = calTagSubcat(t);
      if (subcat) subcats.add(subcat);
    }
  }));
  return Array.from(subcats).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
}
function calRenderTagPicker() {
  const picker = document.getElementById('ev-tag-picker');
  const selected = document.getElementById('ev-tag-selected');
  const menu = document.getElementById('ev-tag-menu');
  if (!picker || !selected || !menu || !elements.evFTags) return;
  selected.innerHTML = state.evFormTags.map((t, i) => {
    if (i === calEvTagEditIndex) {
      const isSubcat = calEvTagEditLevel === 'subcat';
      const value = isSubcat ? calTagSubcat(t) : calTagCat(t);
      const listId = isSubcat ? 'ev-subcat-options' : 'ev-cat-options';
      return '<span class="ev-tag-selected-chip"><input type="text" class="ev-tag-cat-input" data-ev-tag-cat="' + i + '" maxlength="40" value="' + escapeHtml(value) + '" placeholder="' + (isSubcat ? '第3段標籤' : '次標籤') + '" list="' + listId + '"></span>';
    }
    const name = escapeHtml(calTagName(t));
    const cat = calTagCat(t);
    const subcat = calTagSubcat(t);
    const catHtml = cat ? '<span class="ev-tag-cat" data-ev-tag-subcat-edit="' + i + '" title="點擊輸入第3段標籤">·' + escapeHtml(cat) + '</span>' : '';
    const subcatHtml = subcat ? '<span class="ev-tag-cat" data-ev-tag-subcat-edit="' + i + '" title="點擊編輯第3段標籤">·' + escapeHtml(subcat) + '</span>' : '';
    return '<span class="ev-tag-selected-chip">' + '<span class="ev-tag-name" data-ev-tag-edit="' + i + '" title="點擊輸入次標籤">' + name + '</span>' + catHtml + subcatHtml + '<button type="button" data-ev-tag-remove="' + escapeHtml(calTagName(t)) + '" aria-label="刪除標籤">×</button></span>';
  }).join('');
  const query = elements.evFTags.value.trim().toLowerCase();
  const names = calFormTagNames().filter((t) => !query || t.toLowerCase().includes(query));
  menu.innerHTML = names.length ? names.map((t) => '<button type="button" class="ev-tag-option' + (state.evFormTags.some((x) => calTagName(x) === t) ? ' selected' : '') + '" data-ev-tag-option="' + escapeHtml(t) + '">' + (state.evFormTags.some((x) => calTagName(x) === t) ? '✓ ' : '') + escapeHtml(t) + '</button>').join('') : '<div class="ev-tag-option">暂无可选标签</div>';
  // 子標籤（分類）歷史下拉：原生 datalist，按當前編輯標籤從屬過濾（與桌面對齊）
  let catList = picker.querySelector('#ev-cat-options');
  if (!catList) { catList = document.createElement('datalist'); catList.id = 'ev-cat-options'; picker.appendChild(catList); }
  const editingTag = calEvTagEditIndex >= 0 ? state.evFormTags[calEvTagEditIndex] : null;
  const catNames = calFormCatNames(editingTag ? calTagName(editingTag) : null);
  catList.innerHTML = catNames.map((c) => '<option value="' + escapeHtml(c) + '"></option>').join('');
  let subcatList = picker.querySelector('#ev-subcat-options');
  if (!subcatList) { subcatList = document.createElement('datalist'); subcatList.id = 'ev-subcat-options'; picker.appendChild(subcatList); }
  const subcatNames = editingTag ? calFormSubcatNames(calTagName(editingTag), calTagCat(editingTag)) : [];
  subcatList.innerHTML = subcatNames.map((c) => '<option value="' + escapeHtml(c) + '"></option>').join('');
  if (calEvTagEditIndex >= 0) {
    const ci = selected.querySelector('.ev-tag-cat-input[data-ev-tag-cat="' + calEvTagEditIndex + '"]');
    if (ci) {
      ci.focus(); ci.select();
      const editIndex = calEvTagEditIndex;
      const editLevel = calEvTagEditLevel;
      // 有歷史分類時自動彈下拉（showPicker 需使用者手勢；此處由點擊標籤名觸發，正處手勢鏈路內）
      try { if (catNames.length && typeof ci.showPicker === 'function') ci.showPicker(); } catch (err) { /* 無手勢等場景忽略，仍可手動點箭頭 */ }
      ci.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); calCommitTagCat(editIndex, ci.value, editLevel); }
        else if (e.key === 'Escape') { e.preventDefault(); calEvTagEditIndex = -1; calRenderTagPicker(); }
      });
      // datalist 選中歷史分類後立即提交（change 在 blur 前觸發；重複提交無副作用）
      ci.addEventListener('change', () => calCommitTagCat(editIndex, ci.value, editLevel));
      ci.addEventListener('blur', () => calCommitTagCat(editIndex, ci.value, editLevel));
    }
  }
}
function calCommitTagCat(i, val, level) {
  if (state.evFormTags[i]) {
    const value = (val || '').trim();
    if (level === 'subcat') state.evFormTags[i].subcat = value;
    else {
      if (state.evFormTags[i].cat !== value) state.evFormTags[i].subcat = '';
      state.evFormTags[i].cat = value;
    }
  }
  calEvTagEditIndex = -1;
  calRenderTagPicker();
}
function calAddFormTag(value) {
  String(value || '').split(/[,，]/).map((t) => t.trim()).filter(Boolean).forEach((t) => { if (!state.evFormTags.some((x) => calTagName(x) === t)) state.evFormTags.push({ name: t, cat: '', subcat: '' }); });
  elements.evFTags.value = '';
  calRenderTagPicker();
}
function calRemoveFormTag(tag) {
  state.evFormTags = state.evFormTags.filter((t) => calTagName(t) !== tag);
  calRenderTagPicker();
}
function calToggleFormTag(tag) {
  if (state.evFormTags.some((t) => calTagName(t) === tag)) calRemoveFormTag(tag); else calAddFormTag(tag);
}

// ========== 📊 事件統計：主事件 × 備註子事件（- [ ]），按標籤·完成狀態分類 ==========
// 解析備註中的 Markdown checkbox 行 → 子事件數組 [{text, done, dl, cp}]
function calParseNoteChecks(text) {
  const out = [];
  if (!text) return out;
  let inFence = false;
  text.split('\n').forEach((line) => {
    if (/^\s*```/.test(line)) { inFence = !inFence; return; }
    if (inFence) return;
    const m = line.match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
    if (!m) return;
    // 捕获 dl/cp 日期（裸日期视同 dl，與渲染約定一致），供統計明細顯示 📅/✅
    const raw = m[3] || '';
    const dlM = raw.match(/\[\[(?:dl:)?(\d{4}-\d{2}-\d{2})\]\]/);
    const cpM = raw.match(/\[\[cp:(\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?)\]\]/);
    const txt = raw
      .replace(/\[\[(?:dl:)?\d{4}-\d{2}-\d{2}\]\]/g, '')
      .replace(/\[\[cp:\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/g, '')
      .replace(/\s{2,}/g, ' ').trim();
    out.push({ text: txt, done: m[2] !== ' ', dl: dlM ? dlM[1] : '', cp: cpM ? cpM[1] : '' });
  });
  return out;
}
// 收集統計數據：僅統計 EVENT（state.calEvents），REPEAT 系列按 1 條主事件計；子事件繼承主事件標籤
// filter: { tags: Set<string>|null, status: 'all'|'done'|'undone' }；tags 非空集合才生效；status 缺省 'all'
function calBuildStats(filter) {
  const fTags = (filter && filter.tags && filter.tags.size) ? filter.tags : null;
  const fStatus = (filter && filter.status) || 'all';
  // 「只顯示事件主體」：無子事件的事件本身＝主體；有子事件的事件不算主體（由其子事件代表）
  const fMainOnly = !!(filter && filter.mainOnly);
  const tagMap = new Map();
  const ensure = (k) => { if (!tagMap.has(k)) tagMap.set(k, { mainTotal: 0, mainDone: 0, mainUndone: 0, subTotal: 0, subDone: 0, subUndone: 0, mains: [], subs: [] }); return tagMap.get(k); };
  let mainT = 0, mainD = 0, mainU = 0, subT = 0, subD = 0, subU = 0;
  state.calEvents.forEach((ev) => {
    const tagNames = (ev.tags || []).map((t) => calTagName(t)).filter(Boolean);
    if (fTags) {
      const hit = tagNames.some((t) => fTags.has(t));
      const noTagHit = (tagNames.length === 0 && fTags.has('(無標籤)'));
      if (!hit && !noTagHit) return;
    }
    const allSubs = calParseNoteChecks(ev.notes);
    const matchesMainStatus = fStatus === 'all' || (fStatus === 'done' ? ev.done : !ev.done);
    // mainOnly：有子事件的事件本身不算主體 → 主事件欄（計數＋明細）不計，其子事件照常計入子事件欄
    const countMain = matchesMainStatus && !(fMainOnly && allSubs.length > 0);
    const subs = fStatus === 'all' ? allSubs : allSubs.filter((s) => (fStatus === 'done' ? s.done : !s.done));
    if (!countMain && subs.length === 0) return;
    if (countMain) { mainT++; if (ev.done) mainD++; else mainU++; }
    const subDoneCount = subs.filter((s) => s.done).length;
    subT += subs.length; subD += subDoneCount; subU += (subs.length - subDoneCount);
    const groups = tagNames.length ? tagNames : ['(無標籤)'];
    groups.forEach((g) => {
      if (fTags && !fTags.has(g)) return;
      const r = ensure(g);
      if (countMain) { r.mainTotal++; if (ev.done) r.mainDone++; else r.mainUndone++; }
      r.subTotal += subs.length; r.subDone += subDoneCount; r.subUndone += (subs.length - subDoneCount);
      if (countMain) r.mains.push({ title: ev.title, done: !!ev.done, uid: ev.uid, date: ev.date });
      subs.forEach((s) => r.subs.push({ text: s.text, done: s.done, date: ev.date, dl: s.dl, cp: s.cp, uid: ev.uid, ptitle: ev.title }));
    });
  });
  const pct = (d, t) => (t ? Math.round((d / t) * 100) : 0);
  return { mainT, mainD, mainU, subT, subD, subU, mainRate: pct(mainD, mainT), subRate: pct(subD, subT), mainOnly: fMainOnly, rows: tagMap, pct };
}
function calStatsSummaryHtml(s) {
  const card = (title, t, d, u, rate) =>
    '<div class="ev-stats-card"><h4>' + title + '</h4>' +
    '<div class="row"><span>總計</span><b>' + t + '</b></div>' +
    '<div class="row"><span>已完成 ✓</span><b>' + d + '</b></div>' +
    '<div class="row"><span>未完成 ☐</span><b>' + u + '</b></div>' +
    '<div class="rate">完成率 ' + rate + '%<div class="bar"><i style="width:' + rate + '%"></i></div></div>' +
    '</div>';
  return '<div class="ev-stats-summary">' +
    card(s.mainOnly ? '主事件（無子事件＝主體）' : '主事件', s.mainT, s.mainD, s.mainU, s.mainRate) +
    card('子事件（備註 - [ ]）', s.subT, s.subD, s.subU, s.subRate) +
    '</div>';
}
function calStatsDetailHtml(group) {
  // 主/子事件同色顯示（連結 color:inherit），用「主/子事件」欄位值區分；狀態直接顯示文字；
  // 首欄「項次」序號；末欄「跳轉」＝關閉彈層並滾動到主畫面該事件位置（子事件跳到其所屬主事件）；
  // 子事件內容懸停 → tooltip 顯示所屬主事件標題（原生 title）
  let no = 0;
  const row = (kind, date, contentHtml, done, uid, tip, extraCls) => {
    no++;
    // 狀態列在內容列之前；○＝完成、✕＝未完成，懸停 title 保留文字說明
    return '<tr class="' + (done ? 'done ' : '') + (extraCls || '') + '">' +
      '<td class="d-no">' + no + '</td>' +
      '<td class="d-date">' + escapeHtml(date || '') + '</td>' +
      '<td class="d-kind">' + kind + '</td>' +
      '<td class="d-status" title="' + (done ? '完成' : '未完成') + '"><span class="st-ic ' + (done ? 'st-done' : 'st-undone') + '">' + (done ? '\u25CB' : '\u2715') + '</span></td>' +
      '<td class="d-content"' + (tip ? ' title="' + tip + '"' : '') + '>' + contentHtml + '</td>' +
      '<td class="d-jump"><button class="cal-stats-jump" onclick="calJumpToEvent(\'' + escapeHtml(uid) + '\')">跳转</button></td>' +
    '</tr>';
  };
  const mainRows = group.mains.map((m) => row('主事件', m.date,
    '<a href="javascript:void(0)" onclick="openEventForm(\'' + escapeHtml(m.uid) + '\')">' + calRenderInlineMarkdown(m.title) + '</a>',
    m.done, m.uid)).join('');
  // 同一主事件的子事件行打同一「色帶」class，切換主事件即交替換色（build 層按事件順序 push，同 uid 必連續）
  let prevUid = null, band = false;
  const subRows = group.subs.map((x) => {
    if (x.uid !== prevUid) { prevUid = x.uid; band = !band; }
    return row('子事件', x.date,
      escapeHtml(x.text) +
      (x.dl ? ' <span class="d-dl">📅 ' + escapeHtml(x.dl) + '</span>' : '') +
      (x.cp ? ' <span class="d-cp">✅ ' + escapeHtml(x.cp) + '</span>' : ''),
      x.done, x.uid, '主事件：' + escapeHtml(x.ptitle || ''), band ? 'band-a' : 'band-b');
  }).join('');
  return '<table class="ev-stats-detail-table">' +
    '<thead><tr><th>项次</th><th>日期</th><th>主/子事件</th><th>状态</th><th>事件 / 子事件</th><th>跳转</th></tr></thead><tbody>' +
    (mainRows + subRows || '<tr><td colspan="6" class="muted">—</td></tr>') +
    '</tbody></table>';
}
// 關閉統計彈層並滾動定位到事件在主畫面的渲染位置（子事件＝跳到其所屬主事件）
function calJumpToEvent(uid) {
  calCloseStats();
  const el = document.querySelector('[data-ev-edit="' + uid + '"]');
  if (!el || !el.offsetParent) { showToast('当前视图未显示该事件，请切换到包含它的视图后再试', 'danger'); return; }
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  el.classList.remove('cal-jump-flash');
  void el.offsetWidth;  // 強制 reflow 重啟動畫
  el.classList.add('cal-jump-flash');
  setTimeout(() => el.classList.remove('cal-jump-flash'), 2000);
}
function calStatsTableHtml(s) {
  const head = '<thead><tr><th>標籤</th><th>主事件<br>總計</th><th>主·完成</th><th>主·未完成</th><th>子事件<br>總計</th><th>子·完成</th><th>子·未完成</th></tr></thead>';
  const body = Array.from(s.rows.entries()).sort((a, b) => a[0].localeCompare(b[0], 'zh-Hans')).map(([name, r]) => {
    const detail = '<tr class="ev-stats-detail"><td class="ev-stats-detail" colspan="7"><details><summary>展開明細</summary>' + calStatsDetailHtml(r) + '</details></td></tr>';
    return '<tr><td class="ev-stats-tag">' + (name === '(無標籤)' ? '<span class="muted">(無標籤)</span>' : escapeHtml(name)) + '</td>' +
      '<td>' + r.mainTotal + '</td><td>' + r.mainDone + '</td><td>' + r.mainUndone + '</td>' +
      '<td>' + r.subTotal + '</td><td>' + r.subDone + '</td><td>' + r.subUndone + '</td></tr>' + detail;
  }).join('');
  const total = '<tr class="ev-stats-total"><td class="ev-stats-tag">總計</td>' +
    '<td>' + s.mainT + '</td><td>' + s.mainD + '</td><td>' + s.mainU + '</td>' +
    '<td>' + s.subT + '</td><td>' + s.subD + '</td><td>' + s.subU + '</td></tr>';
  return '<table class="ev-stats-table">' + head + '<tbody>' + body + total + '</tbody></table>';
}
let calStatsFilter = { tags: new Set(), status: 'all', mainOnly: false };  // 默认：全部（mainOnly＝只顯示事件主體）
function calStatsTagOptions() {
  const set = new Set();
  state.calEvents.forEach((ev) => (ev.tags || []).forEach((t) => { const n = calTagName(t); if (n) set.add(n); }));
  const arr = Array.from(set).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
  arr.push('(無標籤)');
  return arr;
}
function calRenderStatsFilters() {
  const box = document.getElementById('ev-stats-filters');
  if (!box) return;
  const tags = calStatsTagOptions();
  const tagChips = tags.map((t) =>
    '<label class="ev-stats-tag-filter"><input type="checkbox" data-cal-stats-tag="' + escapeHtml(t) + '"' + (calStatsFilter.tags.has(t) ? ' checked' : '') + '> ' + escapeHtml(t) + '</label>'
  ).join('');
  const st = calStatsFilter.status;
  const radio = (v, label) => '<label class="ev-stats-status"><input type="radio" name="calStatsStatus" value="' + v + '"' + (st === v ? ' checked' : '') + '> ' + label + '</label>';
  box.innerHTML =
    '<div class="ev-stats-filter-row"><span class="lbl">標籤：</span><div class="ev-stats-tag-filters">' + (tagChips || '<span class="muted">（無標籤可選）</span>') + '</div></div>' +
    '<div class="ev-stats-filter-row"><span class="lbl">完成狀態：</span>' + radio('all', '全部') + radio('done', '已完成') + radio('undone', '未完成') +
    '<label class="ev-stats-status ev-stats-mainonly" title="事件主體：無子事件的事件本身＝主體；有子事件的事件由其子事件代表（主事件本身不計入主事件欄）"><input type="checkbox" data-cal-stats-mainonly="1"' + (calStatsFilter.mainOnly ? ' checked' : '') + '> 只顯示事件主體</label></div>';
  box.querySelectorAll('input[data-cal-stats-tag]').forEach((cb) => {
    cb.addEventListener('change', () => {
      const v = cb.getAttribute('data-cal-stats-tag');
      if (cb.checked) calStatsFilter.tags.add(v); else calStatsFilter.tags.delete(v);
      calRenderStatsBody();
    });
  });
  box.querySelectorAll('input[name="calStatsStatus"]').forEach((rb) => {
    rb.addEventListener('change', () => { if (rb.checked) { calStatsFilter.status = rb.value; calRenderStatsBody(); } });
  });
  box.querySelectorAll('input[data-cal-stats-mainonly]').forEach((cb) => {
    cb.addEventListener('change', () => { calStatsFilter.mainOnly = cb.checked; calRenderStatsBody(); });
  });
}
function calRenderStatsBody() {
  const body = document.getElementById('ev-stats-body');
  if (!body) return;
  const s = calBuildStats(calStatsFilter);
  const emptyMsg = (state.calEvents.length === 0) ? calDocName() + ' 中還沒有任何行程事件' : '沒有符合篩選條件的事件';
  body.innerHTML = (s.mainT || s.subT)
    ? calStatsSummaryHtml(s) + calStatsTableHtml(s)
    : '<div class="ev-stats-empty">' + emptyMsg + '</div>';
}
function calOpenStats() {
  const overlay = document.getElementById('ev-stats-overlay');
  if (!overlay) return;
  // 📎 多檔聯運：統計需含 include 進來的只讀事件 → 先重併
  calRefreshAll();
  const fileEl = document.getElementById('ev-stats-file');
  if (fileEl) fileEl.textContent = calFileSizeLabel();
  calRenderStatsFilters();
  calRenderStatsBody();
  overlay.style.display = 'flex';
}
function calCloseStats() {
  const overlay = document.getElementById('ev-stats-overlay');
  if (overlay) overlay.style.display = 'none';
}
// 🆕 工具列 combo（曝露/自定義顯示的功能）：移植自桌面 calendar 的 tlInitCalendarToolbarCombo
//   當前 LITE 僅掛「事件統計」一項（LITE 無便利贴/Include/左右布局；術語表彈層未移植）。勾選／取消→顯隱對應按鈕並存 localStorage。
const CAL_TOOLBAR_EXPOSE_KEY = 'calToolbarExposed';
function calInitCalendarToolbarCombo() {
  const combo = document.getElementById('calToolbarCombo');
  const exposed = document.getElementById('calToolbarExposed');
  const trigger = document.getElementById('calToolbarComboTrigger');
  const menu = document.getElementById('calToolbarComboMenu');
  if (!combo || !exposed || !trigger || !menu || combo.dataset.initialized === '1') return;
  combo.dataset.initialized = '1';
  const definitions = [{ key: 'stats', id: 'ev-stats-btn' }];
  const controls = new Map();
  let selected = definitions.map((item) => item.key);
  try {
    const stored = JSON.parse(localStorage.getItem(CAL_TOOLBAR_EXPOSE_KEY) || 'null');
    if (Array.isArray(stored)) selected = stored.filter((key) => definitions.some((item) => item.key === key));
  } catch (e) { console.warn('[LITE] 讀取日曆工具列偏好失敗:', e); }
  const items = new Map();
  definitions.forEach((item) => {
    const control = document.getElementById(item.id);
    if (!control) return;
    controls.set(item.key, control);
    const wrapper = document.createElement('span');
    wrapper.className = 'ev-toolbar-combo-item';
    wrapper.dataset.toolbarItem = item.key;
    const parent = control.parentElement;
    if (parent && parent !== combo) parent.removeChild(control);
    wrapper.appendChild(control);
    exposed.appendChild(wrapper);
    items.set(item.key, wrapper);
  });
  const checkboxes = Array.from(menu.querySelectorAll('input[data-toolbar-expose]'));
  const apply = () => {
    checkboxes.forEach((input) => {
      const key = input.getAttribute('data-toolbar-expose');
      const wrapper = items.get(key);
      input.checked = selected.includes(key);
      if (wrapper) wrapper.hidden = !input.checked;
    });
  };
  let closeMenu = () => { menu.classList.remove('open'); trigger.setAttribute('aria-expanded', 'false'); };
  apply();
  trigger.addEventListener('click', (event) => {
    event.stopPropagation();
    const open = !menu.classList.contains('open');
    menu.classList.toggle('open', open);
    trigger.setAttribute('aria-expanded', String(open));
  });
  menu.addEventListener('click', (event) => event.stopPropagation());
  // 動作型項目：不曝露成工具列常駐按鈕，按下直接執行（便利貼平時完全不佔畫面，只從這裡開）
  const actionHandlers = {
    sticky: () => { if (typeof calStickyOpen === 'function') calStickyOpen(); },
    'new-cal': () => { if (typeof calOpenNewCalDialog === 'function') calOpenNewCalDialog(); },
    'add-event': () => { openEventForm(null); }
  };
  menu.querySelectorAll('button[data-toolbar-action]').forEach((button) => {
    button.addEventListener('click', () => {
      const key = button.getAttribute('data-toolbar-action');
      const control = controls.get(key);
      closeMenu();
      if (control) control.click();
      else if (actionHandlers[key]) actionHandlers[key]();
    });
  });
  // 🆕 建立 calendar 檔案 / 新建便利貼：combo 裡的動作型項目（data-cal-action），按下後開各自對話框
  menu.querySelectorAll('button[data-cal-action]').forEach((button) => {
    button.addEventListener('click', () => {
      const key = button.getAttribute('data-cal-action');
      closeMenu();
      if (actionHandlers[key]) actionHandlers[key]();
    });
  });
  checkboxes.forEach((input) => input.addEventListener('change', () => {
    const key = input.getAttribute('data-toolbar-expose');
    selected = input.checked ? Array.from(new Set(selected.concat(key))) : selected.filter((item) => item !== key);
    apply();
    try { localStorage.setItem(CAL_TOOLBAR_EXPOSE_KEY, JSON.stringify(selected)); } catch (e) { console.warn('[LITE] 儲存日曆工具列偏好失敗:', e); }
  }));
  document.addEventListener('click', (event) => { if (!combo.contains(event.target)) closeMenu(); });

  // 📎 聯運檔案：combo 菜單裡可折疊的 chip 清單（平時收合不占畫面）
  const incToggle = document.getElementById('cal-include-toggle');
  const incBody = document.getElementById('cal-include-body');
  // 📅 事件過濾：combo 菜單裡可折疊的 legend（EVENT / HOLIDAY / REPEAT / 只顯示未完成）
  const hToggle = document.getElementById('cal-holiday-toggle');
  const hBody = document.getElementById('cal-holiday-body');
  // 🏷 標籤過濾：combo 菜單裡可折疊的標籤條
  const tToggle = document.getElementById('cal-tagbar-toggle');
  const tBody = document.getElementById('cal-tagbar-body');
  // 菜單關閉時順手收合所有三個面板——下次打開菜單是乾淨初始態
  const _origCloseMenu = closeMenu;
  closeMenu = () => {
    _origCloseMenu();
    if (incBody) incBody.style.display = 'none';
    if (incToggle) incToggle.setAttribute('aria-expanded', 'false');
    if (hBody) hBody.style.display = 'none';
    if (hToggle) hToggle.setAttribute('aria-expanded', 'false');
    if (tBody) tBody.style.display = 'none';
    if (tToggle) tToggle.setAttribute('aria-expanded', 'false');
  };
  // 通用 toggle：點 header 按鈕在「none ↔ ''」間切換內層 body，同時更新 aria-expanded
  const wireToggle = (toggle, body) => {
    if (!toggle || !body) return;
    toggle.addEventListener('click', (event) => {
      event.stopPropagation();
      const open = body.style.display !== 'none';
      const willOpen = !open;
      body.style.display = willOpen ? '' : 'none';
      toggle.setAttribute('aria-expanded', String(willOpen));
    });
  };
  wireToggle(incToggle, incBody);
  wireToggle(hToggle, hBody);
  wireToggle(tToggle, tBody);
}

// ===== 🆕 建立 calendar 檔案 / 新建便利貼 / 刪除便利貼 共用工具 =====
const CAL_NL = String.fromCharCode(10);
function calRtrim(s) { s = String(s); while (s.length) { const c = s.charCodeAt(s.length - 1); if (c === 32 || c === 9 || c === 10 || c === 13) s = s.slice(0, -1); else break; } return s; }
function calLtrim(s) { s = String(s); while (s.length) { const c = s.charCodeAt(0); if (c === 32 || c === 9 || c === 10 || c === 13) s = s.slice(1); else break; } return s; }
function calSanitizeSuffix(s) {
  let res = ''; let lastSpace = false;
  for (const ch of String(s || '')) {
    const code = ch.charCodeAt(0);
    if (code === 47 || code === 92 || code === 58 || code === 42 || code === 63 || code === 34 || code === 60 || code === 62 || code === 124) continue;
    if (code === 32 || code === 9 || code === 10 || code === 13) { if (!lastSpace && res) { res += ' '; lastSpace = true; } continue; }
    res += ch; lastSpace = false;
  }
  return res.trim();
}

// ===== 🆕 建立 calendar 檔案（combo 選單）=====
//   前綴固定 calendar-，後綴由使用者輸入 → calendar-<後綴>.md 空文件。
//   建好即設為「當前文檔」（空內容）並標髒，頂欄「保存」即可存回 iCloud。
//   資料尚未加載（state.currentFile 為空）也能用；若當前檔有未保存更改則先擋下，避免靜默丟失。
let calNewCalBusy = false;
function calNewCalEl(id) { return document.getElementById(id); }
function calSetNewCalHint(text, isError) {
  const h = calNewCalEl('calNewCalHint');
  if (!h) return;
  h.textContent = text || '';
  h.classList.toggle('error', !!isError);
}
function calCloseNewCalDialog() {
  const ov = calNewCalEl('calNewCalOverlay');
  if (ov) ov.style.display = 'none';
  calNewCalBusy = false;
  const b = calNewCalEl('calNewCalCreate');
  if (b) { b.disabled = false; b.textContent = '建立'; }
}
function calOpenNewCalDialog() {
  const ov = calNewCalEl('calNewCalOverlay');
  const inp = calNewCalEl('calNewCalSuffix');
  if (!ov || !inp) return;
  if (state.currentFile && state.isDirty) {
    showToast('請先保存當前文件，或重新「開啟」後再建立新檔案', 'error');
    return;
  }
  inp.value = '';
  calSetNewCalHint('Enter 建立 · Esc 取消；建好後按頂欄「保存」即可存回 iCloud', false);
  calNewCalBusy = false;
  const b = calNewCalEl('calNewCalCreate');
  if (b) { b.disabled = false; b.textContent = '建立'; }
  ov.style.display = 'flex';
  setTimeout(function () { inp.focus(); }, 0);
}
function calSubmitNewCal() {
  if (calNewCalBusy) return;
  const inp = calNewCalEl('calNewCalSuffix');
  const suffix = String((inp && inp.value) || '').trim();
  if (!suffix) { calSetNewCalHint('請先輸入檔案後綴（例如 work / 工作）', true); if (inp) inp.focus(); return; }
  const clean = calSanitizeSuffix(suffix);
  if (!clean) { calSetNewCalHint('後綴含非法字元，請改用字母／數字／中文／-_ 空格', true); if (inp) inp.focus(); return; }
  const name = 'calendar-' + clean + '.md';
  calNewCalBusy = true;
  const b = calNewCalEl('calNewCalCreate');
  if (b) { b.disabled = true; b.textContent = '建立中…'; }
  calSetNewCalHint('正在建立…', false);
  state.currentFile = { name: name, file: null, path: name, type: 'md' };
  state.lastContent = '';
  state.isDirty = true;
  state.todoMode = false;
  state.originalTodo = null;
  if (typeof elements !== 'undefined' && elements.editor) elements.editor.value = '';
  if (typeof calRestoreIncludes === 'function') calRestoreIncludes(name);
  const fn = (typeof elements !== 'undefined' && elements.fileName) ? elements.fileName : null;
  if (fn) fn.textContent = name;
  if (typeof updateTodoModeBadge === 'function') updateTodoModeBadge();
  if (typeof updatePreview === 'function') updatePreview();
  if (typeof updateWordCount === 'function') updateWordCount();
  if (typeof updateStatus === 'function') updateStatus();
  if (typeof dispatchDataAwareEditor === 'function') dispatchDataAwareEditor();
  calCloseNewCalDialog();
  showToast('已建立 ' + name + '（空文件），按頂欄「保存」即可存回 iCloud', 'success');
}

// ===== 🆕 新建便利貼（combo 選單）=====
//   標題 ＋ 寫入檔案（主檔或已併入的聯運檔）。建出的行程 sticky=1，日期＝今天。
let calNewNoteBusy = false;
function calSetNewNoteHint(text, isError) {
  const h = calNewCalEl('calNewNoteHint');
  if (!h) return;
  h.textContent = text || '';
  h.classList.toggle('error', !!isError);
}
function calCloseNewNoteDialog() {
  const ov = calNewCalEl('calNewNoteOverlay');
  if (ov) ov.style.display = 'none';
  calNewNoteBusy = false;
  const b = calNewCalEl('calNewNoteCreate');
  if (b) { b.disabled = false; b.textContent = '建立'; }
}
function calOpenNewNoteDialog() {
  const ov = calNewCalEl('calNewNoteOverlay');
  const sel = calNewCalEl('calNewNoteTarget');
  const inp = calNewCalEl('calNewNoteTitle');
  if (!ov || !sel || !inp) return;
  const opts = [];
  if (state.currentFile && isCalendarMd()) {
    opts.push('<option value="__MAIN__">主檔：' + escapeHtml(state.currentFile.name) + '（可編輯，存回 iCloud）</option>');
  }
  (state.calIncludeFiles || []).forEach(function (f) {
    opts.push('<option value="' + escapeHtml(f.name) + '">聯運：' + escapeHtml(f.name) + '（只讀來源）</option>');
  });
  sel.innerHTML = opts.join('');
  const b = calNewCalEl('calNewNoteCreate');
  if (!opts.length) {
    calSetNewNoteHint('請先開啟或建立一個 calendar 文件，才能新建便利貼', true);
    if (b) b.disabled = true;
  } else {
    calSetNewNoteHint('Enter 建立 · Esc 取消；建好後會立即出現在便利貼翻頁中', false);
    if (b) b.disabled = false;
  }
  inp.value = '';
  ov.style.display = 'flex';
  setTimeout(function () { inp.focus(); }, 0);
}
function calSubmitNewNote() {
  if (calNewNoteBusy) return;
  const inp = calNewCalEl('calNewNoteTitle');
  const sel = calNewCalEl('calNewNoteTarget');
  const title = String((inp && inp.value) || '').trim();
  const target = String((sel && sel.value) || '');
  if (!title) { calSetNewNoteHint('請先填寫便利貼標題', true); if (inp) inp.focus(); return; }
  if (!target) { calSetNewNoteHint('請選擇要寫入的檔案', true); return; }
  calNewNoteBusy = true;
  const b = calNewCalEl('calNewNoteCreate');
  if (b) { b.disabled = true; b.textContent = '建立中…'; }
  const ok = calCreateStickyNote(title, target);
  calNewNoteBusy = false;
  if (b) { b.disabled = false; b.textContent = '建立'; }
  if (ok) calCloseNewNoteDialog();
  else calSetNewNoteHint('新建失敗，請稍後再試', true);
}
function calCreateStickyNote(title, targetName) {
  const ev = {
    title: title, date: calendarFmtDate(new Date()), endDate: '', allDay: true, done: false,
    startTime: '', endTime: '', location: '', color: '', tags: [], todoIds: [], sticky: 1, notes: ''
  };
  const block = calEventToMarkdown(ev);
  let roInc = null;
  if (targetName && targetName !== '__MAIN__') {
    const files = state.calIncludeFiles || [];
    roInc = files.find(function (f) { return f.name === targetName; }) || null;
    if (!roInc) { showToast('找不到目標檔「' + targetName + '」', 'error'); return false; }
    let text = roInc.content || '';
    if (text && text.charAt(text.length - 1) !== CAL_NL) text += CAL_NL;
    roInc.content = (text ? text + CAL_NL : '') + block + CAL_NL;
    roInc.dirty = true;
    if (typeof calPersistIncludes === 'function') calPersistIncludes();
  } else {
    if (!state.currentFile) { showToast('請先開啟或建立一個 calendar 文件', 'error'); return false; }
    let text = (typeof elements !== 'undefined' && elements.editor) ? elements.editor.value : '';
    if (text && text.charAt(text.length - 1) !== CAL_NL) text += CAL_NL;
    if (typeof elements !== 'undefined' && elements.editor) elements.editor.value = (text ? text + CAL_NL : '') + block + CAL_NL;
    state.isDirty = (typeof elements !== 'undefined' && elements.editor) ? (elements.editor.value !== state.lastContent) : true;
    if (typeof updateStatus === 'function') updateStatus();
    if (typeof updateWordCount === 'function') updateWordCount();
    if (typeof updatePreview === 'function') updatePreview();
  }
  if (typeof calRefreshAll === 'function') calRefreshAll();
  if (typeof renderEventsContent === 'function') renderEventsContent();
  if (roInc && typeof calRenderIncludeBar === 'function') calRenderIncludeBar();
  if (typeof calStickyRefreshIfOpen === 'function') calStickyRefreshIfOpen();
  const newEv = (state.calEvents || []).find(function (e) { return e.title === title && e.date === ev.date && e.sticky > 0 && (roInc ? (e.ro && e.src === targetName) : !e.ro); });
  const uid = newEv ? newEv.uid : '';
  if (typeof calStickyOpen === 'function') {
    calStickyOpen();
    if (uid && typeof calStickyPages !== 'undefined') {
      const i = calStickyPages.findIndex(function (n) { return n.uid === uid; });
      if (i >= 0 && typeof calStickyRenderPage === 'function') calStickyRenderPage(i, { toast: false });
    }
  }
  showToast('已新建便利貼「' + title + '」' + (roInc ? '（' + targetName + '）' : ''), 'success');
  return true;
}

// ===== 🆕 精準移除第 blockIdx 個 ## EVENT 區塊（blockIdx 與 uid 的 evpN 同一個數，1-based）=====
//   title 安全閥：命中區塊的標題必須一致，否則寧可不刪（避免把 A 的區塊刪成 B）。
function calRemoveEventBlockInContent(content, blockIdx, title) {
  const range = calEventBlockRange(content, blockIdx);
  if (!range) return null;
  const blockText = content.slice(range.start, range.end);
  if (title != null) {
    const tm = blockText.match(/- title: `([^`]*)`/);
    if (!tm || tm[1] !== String(title)) return null;
  }
  const head = calRtrim(content.slice(0, range.start));
  const tail = calLtrim(content.slice(range.end));
  const out = (head ? head + CAL_NL + CAL_NL : '') + tail;
  return out ? calRtrim(out) + CAL_NL : out;
}

// ===== 🆕 對話框按鈕綁定（只需一次）=====
function calInitNewDialogs() {
  const wire = function (id, ev, fn) { const el = calNewCalEl(id); if (el && !el.dataset.wired) { el.dataset.wired = '1'; el.addEventListener(ev, fn); } };
  wire('calNewCalCreate', 'click', function (e) { e.stopPropagation(); calSubmitNewCal(); });
  wire('calNewCalCancel', 'click', function (e) { e.stopPropagation(); calCloseNewCalDialog(); });
  wire('calNewCalClose', 'click', function (e) { e.stopPropagation(); calCloseNewCalDialog(); });
  wire('calNewNoteCreate', 'click', function (e) { e.stopPropagation(); calSubmitNewNote(); });
  wire('calNewNoteCancel', 'click', function (e) { e.stopPropagation(); calCloseNewNoteDialog(); });
  wire('calNewNoteClose', 'click', function (e) { e.stopPropagation(); calCloseNewNoteDialog(); });
  const ov = calNewCalEl('calNewCalOverlay');
  if (ov && !ov.dataset.wired) {
    ov.dataset.wired = '1';
    ov.addEventListener('click', function (e) { if (e.target === ov) { e.stopPropagation(); calCloseNewCalDialog(); } });
    ov.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.preventDefault(); calCloseNewCalDialog(); }
      else if (e.key === 'Enter' && e.target && e.target.id === 'calNewCalSuffix') { e.preventDefault(); calSubmitNewCal(); }
    }, true);
  }
  const nov = calNewCalEl('calNewNoteOverlay');
  if (nov && !nov.dataset.wired) {
    nov.dataset.wired = '1';
    nov.addEventListener('click', function (e) { if (e.target === nov) { e.stopPropagation(); calCloseNewNoteDialog(); } });
    nov.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.preventDefault(); calCloseNewNoteDialog(); }
      else if (e.key === 'Enter' && e.target && e.target.id === 'calNewNoteTitle') { e.preventDefault(); calSubmitNewNote(); }
    }, true);
  }
}

// UTF-8 字節長度（純 JS，無依賴）：用於估算當前加載的 calendar.md 內容大小
function calUtf8Len(s) {
  if (!s) return 0;
  let n = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 0x80) n += 1;
    else if (c < 0x800) n += 2;
    else if (c >= 0xD800 && c <= 0xDBFF) { n += 4; i++; } // 代理對
    else n += 3;
  }
  return n;
}
// 統計彈層表頭：展示「當前檔名 · 內容大小」（大小取當前編輯器緩衝，即正在統計的數據）
function calFileSizeLabel() {
  const ta = (typeof elements !== 'undefined' && elements.editor) ? elements.editor : null;
  const text = ta && ta.value ? ta.value : '';
  const bytes = calUtf8Len(text);
  const sizeStr = bytes.toLocaleString('en-US') + ' Bytes'; // 固定 byte 顯示＋千分位逗號（不走 formatFileSizeShort 的 KB 縮寫）
  return calDocName() + ' · ' + sizeStr;
}

// 地區圖例：列出當前 calendar.md 出現過的地區（去重），無假日則隱藏。顏色/圖標與渲染一致，零學習成本。
// 🔁 重複規則「說人話」：把 ## EVENT(REPEAT) 的字段翻成一句可讀文字（頂欄「重複事件一覽」面板用）
const CAL_REPEAT_MODE_LABEL = { daily: '每天', weekly: '每週', monthly: '每月', yearly: '每年' };
const CAL_WD_LABEL = { sun: '日', mon: '一', tue: '二', wed: '三', thu: '四', fri: '五', sat: '六' };
function calRepeatRuleText(ev) {
  const mode = ev.repeatMode || '';
  if (!mode) return '';
  const interval = Math.max(1, parseInt(ev.repeatInterval, 10) || 1);
  const unit = { daily: '天', weekly: '週', monthly: '月', yearly: '年' }[mode] || '';
  let s = interval > 1 ? ('每 ' + interval + ' ' + unit) : (CAL_REPEAT_MODE_LABEL[mode] || mode);
  if (mode === 'weekly') {
    // 未顯式指定星期時按「起始日的星期」回退，與展開引擎 calExpandRepeats 口徑一致
    let wds = ev.repeatWeekDay || [];
    if (!wds.length && ev.date) { const d = new Date(ev.date + 'T00:00:00'); if (!isNaN(d)) wds = [calWdKey(d)]; }
    if (wds.length) s += '（' + wds.map((w) => CAL_WD_LABEL[w] || w).join('、') + '）';
  } else if (mode === 'monthly' && ev.repeatMonthDay) {
    s += ' 第 ' + (parseInt(ev.repeatMonthDay, 10) || ev.repeatMonthDay) + ' 日';
  } else if (mode === 'yearly' && ev.repeatYearMonthDay) {
    s += ' ' + String(ev.repeatYearMonthDay).replace(/^"|"$/g, '');
  }
  return s;
}
function calRepeatEndText(ev) {
  const t = ev.repeatEndType || 'never';
  if (t === 'count') return '共 ' + (ev.repeatEndValue || '?') + ' 次';
  if (t === 'date') return '至 ' + (ev.repeatEndValue || '?');
  return '永不結束';
}
// 一覽按鈕圖標（截圖內的小「條列」字形）：三行 + 圓點
const CAL_REPEAT_OV_ICON = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>';

// 頂欄過濾條：EVENT | HOLIDAY(地區細項) | REPEAT 三類順序排列（EVENT/REPEAT 默認勾選）
// EVENT/REPEAT 過濾普通/重複行程；HOLIDAY 分組內為「出現過的地區」細項（顏色/圖標與渲染一致）
function calRenderHolidayLegend() {
  const el = document.getElementById('ev-holiday-legend');
  if (!el) return;
  const catEvent = '<label class="ev-legend-item ev-legend-cat' + (state.calShowEvents ? '' : ' off') + '" title="勾選顯示 / 取消勾選隱藏普通行程（EVENT）">' +
    '<input type="checkbox" ' + (state.calShowEvents ? 'checked' : '') + ' onchange="calSetCategoryChecked(\'event\', this.checked)">EVENT</label>';
  const catRepeat = '<label class="ev-legend-item ev-legend-cat' + (state.calShowRepeat === 'none' ? ' off' : '') + '" title="REPEAT 三態：未勾選＝隱藏全部 / 半勾選＝只顯示未來最近一次 / 全勾選＝最近的前一次＋未來4次（最多5次）；點擊循環切換">' +
    '<input type="checkbox" id="calRepeatChk" data-rep="repeat" onclick="calCycleRepeat()" title="點擊循環：隱藏全部 → 只顯示未來最近一次 → 顯示5次">REPEAT</label>';
  const items = [];
  const seen = {};
  for (const h of (calHolidays || [])) {
    const r = (h.region || 'cn').toLowerCase();
    if (seen[r]) continue;
    seen[r] = true;
    const m = calHolidayRegionMeta(r);
    const on = (state.calRegionFilter || []).indexOf(r) >= 0;
    items.push('<label class="ev-legend-item' + (on ? '' : ' off') + '" title="勾選顯示 / 取消勾選隱藏該地區假日">' +
      '<input type="checkbox" ' + (on ? 'checked' : '') + ' style="accent-color:' + escapeHtml(m.color) + '" onchange="calSetRegionChecked(\'' + r + '\', this.checked)">' +
      '<span class="ev-legend-dot" style="background:' + escapeHtml(m.color) + '"></span>' + m.icon + escapeHtml(m.label) + '</label>');
  }
  let html = catEvent;
  if (items.length) html += '<span class="ev-legend-sep"></span><span class="ev-legend-label">HOLIDAY:</span>' + items.join('');
  // REPEAT 後接「條列」圖標：點擊開一覽視窗（列出當前所有重複事件設定，點條目可直接編輯）
  const repeatMore = '<button type="button" class="ev-legend-more" title="查看全部重複事件設定" aria-label="查看全部重複事件設定" onclick="calOpenRepeatOverview()">' + CAL_REPEAT_OV_ICON + '</button>';
  html += '<span class="ev-legend-sep"></span>' + catRepeat + repeatMore;
  // 📓 「只顯示日記」勾選：只在列表模式出現（月/週/日不顯示，也不受其影響）
  if (state.calMode === 'list') {
    calLoadDiaryOnly();
    html += '<span class="ev-legend-sep"></span>' +
      '<label class="ev-legend-item ev-legend-cat' + (state.calDiaryOnly ? '' : ' off') + '" title="只在列表模式生效：勾選後只列出有寫日記的日期（行程與假日暫時隱藏）">' +
      '<input type="checkbox" ' + (state.calDiaryOnly ? 'checked' : '') + ' onchange="calSetDiaryOnly(this.checked)">只顯示日記</label>';
  }
  // ☐ 「只顯示未完成」：全模式生效（年/月/週/日/列表）——勾選後隱藏已完成（✓）的行程（假日無完成態，不受影響）
  calLoadUndoneOnly();
  html += '<span class="ev-legend-sep"></span>' +
    '<label class="ev-legend-item ev-legend-cat' + (state.calUndoneOnly ? '' : ' off') + '" title="勾選後隱藏已完成（✓）的行程，只看未完成（年/月/週/日/列表 全模式生效）">' +
    '<input type="checkbox" ' + (state.calUndoneOnly ? 'checked' : '') + ' onchange="calSetUndoneOnly(this.checked)">只顯示未完成</label>';
  el.style.display = '';
  el.innerHTML = html;
  // 📅 事件過濾外層面板（combo 菜單裡的 toggle 區塊）：legend 有內容才顯示面板
  const holidayPanel = document.getElementById('cal-holiday-panel');
  if (holidayPanel) holidayPanel.style.display = '';
  const repChk = el.querySelector('input[data-rep="repeat"]');
  if (repChk) { repChk.indeterminate = (state.calShowRepeat === 'next'); repChk.checked = (state.calShowRepeat === 'some'); }
}

// 🔁 重複事件一覽：條列當前 calendar.md 中所有 ## EVENT(REPEAT)；點條目 → 套用既有行程編輯表單
function calRepeatOvItemHtml(ev) {
  const rule = calRepeatRuleText(ev) + ' · ' + calRepeatEndText(ev);
  const ex = (ev.repeatExcludeDates && ev.repeatExcludeDates.length) ? ' · 排除 ' + ev.repeatExcludeDates.length + ' 天' : '';
  const when = ev.allDay ? '全天' : (ev.startTime ? ev.startTime + (ev.endTime ? '-' + ev.endTime : '') : '');
  return '<div class="ev-repeat-ov-item" data-uid="' + escapeHtml(ev.uid) + '" onclick="calOpenRepeatEvent(\'' + escapeHtml(ev.uid) + '\')">' +
    '<span class="ev-repeat-ov-swatch" style="background:' + escapeHtml(ev.color) + '"></span>' +
    '<div class="ev-repeat-ov-main">' +
    '<div class="ev-repeat-ov-title">' + calRepeatIcon(ev) + calRenderInlineMarkdown(ev.title) + '</div>' +
    '<div class="ev-repeat-ov-rule">' + escapeHtml(rule) + '</div>' +
    '<div class="ev-repeat-ov-meta">' + escapeHtml('起始 ' + ev.date + (when ? ' · ' + when : '') + ex) + '</div>' +
    '</div></div>';
}
function calOpenRepeatOverview() {
  if (!isCalendarMd()) return;
  const reps = parseCalendarEvents(elements.editor.value).filter(e => e.repeatMode)
    .sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  const cnt = document.getElementById('ev-repeat-ov-count');
  if (cnt) cnt.textContent = reps.length ? '（共 ' + reps.length + ' 條）' : '';
  const list = document.getElementById('ev-repeat-ov-list');
  if (list) {
    list.innerHTML = reps.length ? reps.map(calRepeatOvItemHtml).join('')
      : '<div class="ev-repeat-ov-empty">目前沒有任何重複事件<br><span class="ev-repeat-ov-empty-hint">點下方「＋ 新增重複事件」開始</span></div>';
  }
  const ov = document.getElementById('ev-repeat-overlay');
  if (ov) ov.style.display = 'flex';
}
// 點條目：先關一覽，再開既有編輯表單（uid 相同，編輯後寫回緩衝，按頂欄「保存」落盤）
function calOpenRepeatEvent(uid) { calCloseRepeatOverview(); openEventForm(uid); }
// 一覽面板的「新增重複事件」：關一覽 → 開「新增行程」表單並預置為重複模式（不另寫一套表單）
function calNewRepeatEvent() { calCloseRepeatOverview(); openEventForm(null, null, { repeat: true }); }
function calCloseRepeatOverview() {
  const ov = document.getElementById('ev-repeat-overlay');
  if (ov) ov.style.display = 'none';
}
// 點遮罩 / Esc 關閉（腳本載入時一次性綁定；LITE 變數定義在 :root，無桌面端的作用域坑）
(function calBindRepeatOverviewClicks() {
  const ov = document.getElementById('ev-repeat-overlay');
  if (!ov) return;
  ov.addEventListener('click', (e) => { if (e.target === ov) calCloseRepeatOverview(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && ov.style.display !== 'none') calCloseRepeatOverview(); });
})();
// 日 / 週視圖 時間網格（移植自桌面 renderTimeGrid；事件委派用 data-ev-edit）
// 日/週視圖「下半部明細清單」所顯示的那一天：永遠只有「選中日」一條（與月視圖一致）。
// 日模式＝游標那天；週模式＝calSelectedDate（須在當週內），否則今天（若在週內）否則週一。
function calGridSelectedDay() {
  if (state.calMode === 'day') return calendarFmtDate(state.calCursor);
  const wk = calWeekDays(state.calCursor);
  const wkSet = new Set(wk.map(calendarFmtDate));
  const today = calendarFmtDate(new Date());
  const ds = (state.calSelectedDate && wkSet.has(state.calSelectedDate)) ? state.calSelectedDate
    : (wkSet.has(today) ? today : calendarFmtDate(wk[0]));
  state.calSelectedDate = ds; // 跨週後把殘留的舊選日收斂回當週內
  return ds;
}
function renderCalTimeGrid(dayDates, preserveScroll = true) {
  const wrap = elements.evWeekWrap;
  if (!wrap) return;
  // 📎 多檔聯運：本函式也被 calRerenderCalendarView / calSetCalScope 直接呼叫（未先走 renderEventsContent），
  //    故在此確保 state.calEvents 是「主檔＋include 併集」，避免 include 事件在日/週視圖漏顯示。
  calRefreshAll();
  const timeGridScrollTop = preserveScroll ? (wrap.querySelector('.ev-timegrid-scroll')?.scrollTop || 0) : 0;
  const detailListScrollTop = preserveScroll ? (wrap.querySelector('#ev-grid-list')?.scrollTop || 0) : 0;
  // 重複展開視窗：網格首末日 ±7 天，避免 never 無限展開
  const gf = dayDates[0], gl = dayDates[dayDates.length - 1];
  calSetRepeatWindow(calendarFmtDate(new Date(gf.getFullYear(), gf.getMonth(), gf.getDate() - 7)), calendarFmtDate(new Date(gl.getFullYear(), gl.getMonth(), gl.getDate() + 7)));
  const hourH = dayDates.length > 1 ? 48 : 56;   // 週視圖列窄 → 小時格矮一點
  const n = dayDates.length;
  const todayStr = calendarFmtDate(new Date());
  const selDay = calGridSelectedDay();   // 下半部明細清單只顯示這一天（與月視圖選中日一致）
  const now = new Date();
  const allDayByCol = dayDates.map((d) => calEventsOnDay(calendarFmtDate(d)).filter((o) => o.ev.allDay));
  const hasAllDay = allDayByCol.some((arr) => arr.length > 0);
  const WD = ['日', '一', '二', '三', '四', '五', '六'];
  let html = '<div class="ev-timegrid-col ev-split-top">';  // 時間網格整列（標題+全天條+網格）包一層，便於橫屏與明細清單左右並排
  // 🗓 欄位日期標題：讓每一「直行」看得出是哪一天（與桌面端對齊）
  //    ⚠️ 與時間網格共用同一套 grid 模板，且 column-gap 必須為 0，否則會累積漂移導致對不齊
  html += '<div class="ev-tg-head" style="--cols:' + n + '"><div class="ev-tg-head-gutter"></div>';
  dayDates.forEach((d) => {
    const ds = calendarFmtDate(d);
    const dm = String(ds).match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    const label = dm ? (+dm[2]) + '/' + (+dm[3]) : ds;
    // 📕 當天有日記 → 日期旁掛標記（與月格共用 calDiaryMarkHtml）。
    // ⚠️ 必須放在 .dnum **內部**：.dnum 是 display:block，作為兄弟節點會另起一行 → 整行欄頭被頂高
    html += '<div class="ev-tg-head-cell' + (ds === todayStr ? ' today' : '') + (ds === selDay ? ' selected' : '') + '" data-date="' + ds + '">' +
      '<span class="dow">週' + WD[d.getDay()] + '</span><span class="dnum">' + label + calDiaryMarkHtml(ds) + '</span></div>';
  });
  html += '</div>';
  if (hasAllDay) {
    html += '<div class="ev-allday-strip" style="--cols:' + n + '"><div class="label">全天</div>';
    allDayByCol.forEach((arr, ci) => {
      html += '<div class="ev-allday-col" data-date="' + calendarFmtDate(dayDates[ci]) + '">';
      arr.forEach((o) => {
        const ev = o.ev;
        html += '<div class="ev-block all-day' + (ev.done ? ' done' : '') + '" data-ev-edit="' + escapeHtml(ev.uid) + '" data-occ-date="' + escapeHtml(calendarFmtDate(dayDates[ci])) + '" style="--ev-color:' + escapeHtml(ev.color || CAL_COLORS[0]) + '">' +
          (ev.done ? '✓ ' : '') + calRepeatIcon(ev) + calRenderInlineMarkdown(ev.title) + calSpanSuffix(o.idx, o.total) + calRoIcon(ev) + calEventTodoLinks(ev) + '</div>';
      });
      html += '</div>';
    });
        html += '</div>';
      }
      // ## HOLIDAY：日/週时间网格顶部「假期」条（与 EVENT 全天条视觉区隔：type 色块）
      const holByCol = dayDates.map((d) => calHolidaysOnDay(calendarFmtDate(d)));
      const hasHoliday = holByCol.some((arr) => arr.length > 0);
      if (hasHoliday) {
        html += '<div class="ev-holiday-strip" style="--cols:' + n + '"><div class="label">假期</div>';
        holByCol.forEach((arr, ci) => {
          html += '<div class="ev-holiday-col" data-date="' + calendarFmtDate(dayDates[ci]) + '">';
          arr.forEach((h) => {
            const region = calHolidayRegionMeta(h.region);
            // 跨天假日：與行程同款「(第幾天/共幾天)」，一天一格（ci＝所屬欄＝出現日）
            html += '<div class="ev-holiday-block" style="--holiday-color:' + escapeHtml(region.color) + '" title="' + escapeHtml(h.title) + '">' + region.icon + ' ' + calRenderInlineMarkdown(h.title) + calSpanDaySuffix(h, calendarFmtDate(dayDates[ci])) + calRoIcon(h) + '</div>';
          });
          html += '</div>';
        });
        html += '</div>';
      }
      html += '<div class="ev-timegrid-scroll"><div class="ev-timegrid" style="--cols:' + n + ';--hour-h:' + hourH + 'px;">';
  html += '<div class="ev-tg-gutter">';
  for (let h = 0; h <= 23; h++) html += '<div class="ev-tg-hour-label" style="top:' + (h * hourH) + 'px">' + String(h).padStart(2, '0') + ':00</div>';
  html += '</div>';
  dayDates.forEach((d) => {
    html += '<div class="ev-tg-col" data-date="' + calendarFmtDate(d) + '">';
    for (let h = 0; h <= 23; h++) html += '<div class="ev-tg-hour-line" style="top:' + (h * hourH) + 'px"></div>';
    const timed = calLayoutDay(calEventsOnDay(calendarFmtDate(d)).filter((o) => !o.ev.allDay).map((o) => o.ev));
    timed.forEach(({ e, start, end, col, cols }) => {
      const top = start / 60 * hourH;
      const height = Math.max((end - start) / 60 * hourH, 18);
      const width = 100 / cols;
      const left = col * width;
      const cbg = e.color || CAL_COLORS[0];
      // 時間範圍 + 備註（與桌面端對齊）：夠高（>=64px）才顯示備註，超出由 CSS line-clamp / overflow 裁掉
      const tm = (e.allDay || !e.startTime) ? '' : (e.startTime + (e.endTime ? '–' + e.endTime : ''));
      const notes = (!e.allDay && height >= 64 && e.notes) ? String(e.notes).slice(0, 400) : '';
      html += '<div class="ev-block' + (e.done ? ' done' : '') + '" data-ev-edit="' + escapeHtml(e.uid) + '" data-occ-date="' + escapeHtml(calendarFmtDate(d)) + '" style="top:' + top + 'px;height:' + height + 'px;left:calc(' + left + '% + 1px);width:calc(' + width + '% - 3px);--ev-color:' + escapeHtml(cbg) + '">' +
        // 跨天定時行程：該欄即「出現日」，標題後標 (第幾天/共幾天)
        '<div class="t">' + (e.done ? '✓ ' : '') + calRepeatIcon(e) + calRenderInlineMarkdown(e.title) + calSpanDaySuffix(e, calendarFmtDate(d)) + calRoIcon(e) + calEventTodoLinks(e) + '</div>' +
        (tm ? '<div class="tm">' + escapeHtml(tm) + '</div>' : '') +
        (e.location ? '<div class="loc">' + escapeHtml('📍 ' + e.location) + '</div>' : '') +
        // 時間格只顯示前 400 字（可能截斷區塊）→ 傳 null 走唯讀渲染，避免用截斷後的區間回寫原文
        (notes ? '<div class="notes">' + calRenderNotes(notes, null) + '</div>' : '') +
        '</div>';
    });
    html += '</div>';
  });
  // 現在時間線：僅當今天落在顯示範圍內
  dayDates.forEach((d) => {
    if (calendarFmtDate(d) === todayStr) {
      const mins = now.getHours() * 60 + now.getMinutes();
      html += '<div class="ev-tg-now-line" style="top:' + (mins / 60 * hourH) + 'px"></div>';
    }
  });
  html += '</div></div></div>';   // 關閉 .ev-timegrid / .ev-timegrid-scroll / .ev-timegrid-col
  // 日/週視圖「下半部」行程內容明細：時間網格下方補一列文字清單（與月視圖 #ev-day-list 對齊），
  // 保證事件標題/時間/地點/備註一定可見，不必依賴時間網格滾動。
  // 上下可拖動分割：時間網格（.ev-split-top）自動佔餘量，明細（.ev-detail）高度由 --ev-detail-h 決定
  html += '<div class="ev-hsplit" id="ev-week-split" title="拖動調整下方行程明細高度（雙擊復位）"></div>';
  html += '<div id="ev-grid-list" class="events-list ev-detail"></div>';
  wrap.innerHTML = html;
  calBindSplit(wrap, document.getElementById('ev-week-split'));
  renderCalGridDayList();
  if (preserveScroll) requestAnimationFrame(() => {
    const scroller = wrap.querySelector('.ev-timegrid-scroll');
    const detailList = wrap.querySelector('#ev-grid-list');
    if (scroller) scroller.scrollTop = timeGridScrollTop;
    if (detailList) detailList.scrollTop = detailListScrollTop;
  });
}

// 日/週視圖「下半部」行程明細：默認僅顯示「選中日」(calGridSelectedDay) 那一日的行程，與月視圖一致。
// 日模式選中日＝游標那天；週模式選中日＝所點的日期標題（預設今天/週一），點不同日期標題即切換。
// 明細範圍切換（日 <-> 月/週）：月模式切「整月」、週模式切「整週」；日模式無意義不顯示。默認「日」。
function calScopeToggleHtml() {
  if (state.calMode !== 'month' && state.calMode !== 'week' && state.calMode !== 'year') return '';
  const isFull = state.calScope === 'full';
  const fullLabel = (state.calMode === 'week') ? '週' : (state.calMode === 'year' ? '年' : '月');
  return '<span class="ev-scope-seg" role="group" title="切換下方明細顯示範圍">' +
    '<button type="button" class="' + (!isFull ? 'active' : '') + '" data-cal-scope="day">日</button>' +
    '<button type="button" class="' + (isFull ? 'active' : '') + '" data-cal-scope="full">' + fullLabel + '</button>' +
    '</span>';
}
function calSetCalScope(s) {
  state.calScope = (s === 'full') ? 'full' : 'day';
  const content = elements.editor.value;
  if (state.calMode === 'month') renderCalMonth(content);
  else if (state.calMode === 'week') renderCalTimeGrid(calWeekDays(state.calCursor));
  else if (state.calMode === 'day') renderCalTimeGrid([state.calCursor]);
  else if (state.calMode === 'year') renderCalYear(content);
  else renderEventsList(content);
}
function renderCalGridDayList() {
  const list = document.getElementById('ev-grid-list');
  if (!list) return;
  const today = calendarFmtDate(new Date());
  const toggle = calScopeToggleHtml();
  let html = '';
  // 整週（週模式切到「週」）：遍歷當週 7 天，跳過無內容日（與列表模式一致）
  if (state.calScope === 'full' && state.calMode === 'week') {
    let any = false;
    const sel = calGridSelectedDay();
    for (const d of calWeekDays(state.calCursor)) {
      const ds = calendarFmtDate(d);
      const dayItems = calDayItems(ds);
      const evs = sortedCalEvents(dayItems.events);
      const hols = dayItems.holidays;
      if (!evs.length && !hols.length) continue;
      // toggle 內聯進每個日期標題條，隨 sticky 一直可見（無需滾回週首）
      let g = calDateHeaderHtml(ds, today, toggle, evs.length + hols.length);
      any = true;
      for (const h of hols) g += calHolidayHtml(h, today, ds);
      for (const ev of evs) g += evItemHtml(ev, today, ds);
      html += (ds === sel) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
    }
    if (!any) html += '<div class="ev-scope-row">' + toggle + '</div><div class="ev-empty">本週沒有行程</div>';
    list.innerHTML = html;
    list.classList.add('scope-follow');
    calBindActiveDateScroll(list);
    calUpdateActiveDate(list);
    return;
  }
  // 單日（默認）：選中日明細
  const ds = calGridSelectedDay();
  const dayItems = calDayItems(ds);
  const evs = sortedCalEvents(dayItems.events);
  const hols = dayItems.holidays;
  // 與「月」範圍/列表模式共用 calDateHeaderHtml（含年月日/倒計時/農曆/日記按鈕），避免兩範圍頭部不一致
  html += calDateHeaderHtml(ds, today, toggle, evs.length + hols.length);
  if (!evs.length && !hols.length) html += '<div class="ev-empty">這一天沒有行程</div>';
  else {
    for (const h of hols) html += calHolidayHtml(h, today, ds);
    for (const ev of evs) html += evItemHtml(ev, today, ds);
  }
  list.classList.remove('scope-follow');
  list.innerHTML = html;
}
// 導航列標題：依模式顯示「月 / 週區間 / 單日」
function calCursorTitle() {
  const WD = ['日', '一', '二', '三', '四', '五', '六'];
  if (state.calMode === 'day') {
    const d = state.calCursor;
    return d.getFullYear() + '年' + (d.getMonth() + 1) + '月' + d.getDate() + '日 週' + WD[d.getDay()];
  }
  if (state.calMode === 'week') {
    const ds = calWeekDays(state.calCursor);
    const y0 = ds[0].getFullYear(), y1 = ds[6].getFullYear();
    // 週區間：起始帶年；跨年時結尾也補年，避免「12/29 – 1/4」看不出年份
    return y0 + '/' + (ds[0].getMonth() + 1) + '/' + ds[0].getDate() + ' – ' + (y1 === y0 ? '' : y1 + '/') + (ds[6].getMonth() + 1) + '/' + ds[6].getDate();
  }
  if (state.calMode === 'year') return state.calCursor.getFullYear() + '年';
  return state.calCursor.getFullYear() + '年' + (state.calCursor.getMonth() + 1) + '月';
}
// 上/下一期：按當前模式步進（月→月、週→週、日→日、年→年）
function calStepCursor(dir) {
  if (state.calMode === 'week') state.calCursor = calAddDays(state.calCursor, dir * 7);
  else if (state.calMode === 'day') { state.calCursor = calAddDays(state.calCursor, dir); state.calSelectedDate = calendarFmtDate(state.calCursor); }
  else if (state.calMode === 'year') state.calCursor = new Date(state.calCursor.getFullYear() + dir, state.calCursor.getMonth(), 1);
  else state.calCursor = new Date(state.calCursor.getFullYear(), state.calCursor.getMonth() + dir, 1);
  if (state.calMode === 'month' && !state.calSelectedDate) state.calSelectedDate = calendarFmtDate(state.calCursor);
  renderEventsContent();
}

// ===== 年視圖：12 個月迷你月曆（點日期選日→下部顯示明細；點月份名 → 月視圖） =====
// 月格連點檢測狀態（見 app.js 的 evYearGrid click）
let calYearLastCellClick = { date: null, t: 0 };
function renderCalYear(content) {
  const grid = elements.evYearGrid;
  if (!grid) return;
  // 📎 多檔聯運：主檔 + 所有 include 併成顯示用資料集（含 ro 標記）；編輯/存檔路徑仍只用主檔內容
  calRefreshAll();
  const y = state.calCursor.getFullYear();
  calSetRepeatWindow(y + '-01-01', y + '-12-31');
  if (elements.evMonthTitle) elements.evMonthTitle.textContent = y + '年';
  // 全年逐日事件出現（含跨天/重複展開，套用標籤/分類過濾）→ 12 個月共用同一份
  const occByDate = {};
  state.calEvents.filter(calEventShown).forEach(ev => { calEventOccurrences(ev).forEach(o => { (occByDate[o.date] = occByDate[o.date] || []).push(o); }); });
  const todayStr = calendarFmtDate(new Date());
  const todayY = +todayStr.slice(0, 4);
  const todayM = +todayStr.slice(5, 7) - 1; // 0-based：今天所在月份（年視圖月份卡片金色外框用）
  if (!state.calSelectedDate) state.calSelectedDate = todayStr;
  const WD = ['一', '二', '三', '四', '五', '六', '日'];
  let html = '';
  for (let m = 0; m < 12; m++) {
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const offset = (new Date(y, m, 1).getDay() + 6) % 7; // 週一=0
    // 第十一批续：今天所在月份加金色外框（.cur-month），随视图年份自动判定
    const isCurMonth = (y === todayY && m === todayM);
    html += '<div class="ev-year-month' + (isCurMonth ? ' cur-month' : '') + '"><div class="ev-year-mh" onclick="calGotoMonthFromYear(' + y + ',' + m + ')">' + (m + 1) + '月</div>';
    html += '<div class="ev-year-grid">';
    html += WD.map(w => '<div class="ev-year-wd">' + w + '</div>').join('');
    for (let k = 0; k < offset; k++) html += '<div></div>';
    for (let d = 1; d <= daysInMonth; d++) {
      const ds = y + '-' + String(m + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
      const occ = (occByDate[ds] || []).slice().sort(calOccSort);
      const hols = calHolidaysOnDay(ds);
      const marks = [];
      for (const o of occ) marks.push({ color: o.ev.color || CAL_COLORS[0], title: o.ev.title });
      for (const h of hols) marks.push({ color: calHolidayRegionMeta(h.region).color, title: h.title });
      let dots = '';
      for (let i = 0; i < Math.min(3, marks.length); i++) {
        dots += '<span class="ev-year-dot" style="background:' + escapeHtml(marks[i].color) + '"></span>';
      }
      if (marks.length > 3) dots += '<span class="ev-year-more">+' + (marks.length - 3) + '</span>';
      const tip = marks.length ? escapeHtml(marks.map(x => x.title).join(' / ')) : '';
      html += '<div class="ev-year-day' + (ds === todayStr ? ' today' : '') + (ds === state.calSelectedDate ? ' selected' : '') + '" data-date="' + ds + '"' + (tip ? ' title="' + tip + '"' : '') + '>' +
        '<span class="n">' + d + '</span>' +
        (dots ? '<span class="ev-year-dots">' + dots + '</span>' : '') +
        '</div>';
    }
    html += '</div></div>';
  }
  grid.innerHTML = html;
  calBindSplit(elements.evYearWrap, document.getElementById('ev-year-split'));
  renderCalYearDayList();
}
// 年視圖下部：選定日行程明細（「日」=當天；年模式「年」=整年；月模式「月」=選中日所在整月，與月視圖同口徑）
function renderCalYearDayList() {
  const list = elements.evYearDayList;
  if (!list) return;
  const today = calendarFmtDate(new Date());
  const sel = state.calSelectedDate || today;
  const toggle = calScopeToggleHtml();
  const mm = String(sel).match(/^(\d{4})-(\d{1,2})-\d{1,2}$/);
  const my = mm ? +mm[1] : state.calCursor.getFullYear();
  const mo = mm ? +mm[2] - 1 : state.calCursor.getMonth();
  if (state.calScope === 'full') {
    // ⚠️ 年模式下的「年」範圍必須取「整年」——曾一律沿用選中日所在月份 → 只看到某一個月
    const isYearScope = state.calMode === 'year';
    const prefix = isYearScope ? String(my) : (my + '-' + String(mo + 1).padStart(2, '0'));
    // 重複展開視窗：年＝整年；月＝選中日所在月 + 前 7 天
    if (isYearScope) calSetRepeatWindow(my + '-01-01', my + '-12-31');
    else calSetRepeatWindow(calendarFmtDate(new Date(my, mo, 1 - 7)), calendarFmtDate(new Date(my, mo + 1, 0)));
    const byDate = calEventsByDate(state.calEvents.filter(calEventShown), (ds) => typeof ds === 'string' && ds.slice(0, prefix.length) === prefix);
    const dates = Array.from(byDate.keys()).sort();
    let total = 0;
    byDate.forEach((g) => { total += g.events.length + g.holidays.length; });
    let html = '';
    if (!dates.length) html += '<div class="ev-date active">' + (isYearScope ? my + '年' : (mo + 1) + '月') + ' <span class="ev-week">全部 ' + total + ' 條</span>' +
      '<span class="ev-toolbar-flex"></span>' + toggle + '</div><div class="ev-empty">' + (isYearScope ? '本年沒有行程' : '本月沒有行程') + '</div>';
    else {
      for (let i = 0; i < dates.length; i++) {
        const grp = byDate.get(dates[i]);
        let g = calDateHeaderHtml(dates[i], today, toggle, grp.events.length + grp.holidays.length);
        for (const h of grp.holidays) g += calHolidayHtml(h, today, dates[i]);
        for (const ev of sortedCalEvents(grp.events)) g += evItemHtml(ev, today, dates[i]);
        html += (dates[i] === sel) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
      }
    }
    list.innerHTML = html;
    list.classList.add('scope-follow');
    calBindActiveDateScroll(list);
    calUpdateActiveDate(list);
    return;
  }
  // 「日」範圍（默認）：選定日單日
  calSetRepeatWindow(sel, sel);
  const dayItems = calDayItems(sel);
  const evs = sortedCalEvents(dayItems.events);
  const hols = dayItems.holidays;
  let html = calDateHeaderHtml(sel, today, toggle, evs.length + hols.length);
  if (!evs.length && !hols.length) html += '<div class="ev-empty">這一天沒有行程</div>';
  else {
    for (const h of hols) html += calHolidayHtml(h, today, sel);
    for (const ev of evs) html += evItemHtml(ev, today, sel);
  }
  list.classList.remove('scope-follow');
  list.innerHTML = html;
}
// 年視圖：點月份名 → 切到該月的「月」視圖
function calGotoMonthFromYear(y, m) {
  state.calCursor = new Date(y, m, 1);
  state.calSelectedDate = calendarFmtDate(new Date(y, m, 1));
  setCalMode('month');
}

// ===== 🔗 表單內「關聯 Todo 卡片」面板 =====
// ⚠️ LITE 端沒有 todo 卡片清單（無法像桌面一樣下拉選卡片標題），
//    故以「卡片 id」為單位顯示 / 移除，並提供輸入框手動新增；
//    寫回的字段與桌面完全一致（todoIds），桌面上仍會正常解析成卡片標題。
function calRenderEvTodoLinkPanel() {
  const panel = elements.evFTodoPanel;
  if (!panel) return;
  if (!state.evFormTodoIds.length) {
    panel.innerHTML = '<div class="ev-todo-placeholder">尚無關聯卡片（在下方輸入卡片 id 後按 ＋）</div>';
    return;
  }
  panel.innerHTML = state.evFormTodoIds.map((id) =>
    '<span class="ev-todo-chip" data-id="' + escapeHtml(id) + '" title="' + escapeHtml(id) + '">' +
    '<span class="ev-todo-chip-text">' + escapeHtml(id) + '</span>' +
    '<span class="ev-todo-chip-x" data-id="' + escapeHtml(id) + '" title="移除">✕</span></span>'
  ).join('');
}
function calEvAddTodoLink(id) {
  id = String(id || '').trim();
  if (!id) return;
  if (state.evFormTodoIds.indexOf(id) >= 0) { showToast('該卡片 id 已關聯', 'error'); return; }
  state.evFormTodoIds.push(id);
  calRenderEvTodoLinkPanel();
}
function calEvRemoveTodoLink(id) {
  const i = state.evFormTodoIds.indexOf(id);
  if (i >= 0) state.evFormTodoIds.splice(i, 1);
  calRenderEvTodoLinkPanel();
}

// ===== ## HOLIDAY 輔助（日志/列表視圖顯示，與 EVENT 視覺區隔：左側 type 色條＋類型徽章，無勾選框/編輯刪除）=====
// 地區調色板：決定假日「目視差別」的主色（與類型徽章正交）。可擴展：直接往此表加一項即可。
// 缺省 cn：舊數據無 region 字段時回退中國大陸；非空但未知的地區→中性灰＋原始代號（不靜默當大陸，避免誤判）。
const CAL_HOLIDAY_REGIONS = {
  cn: { label: '大陆', icon: '<span class="ev-region-icon ev-region-cn" aria-label="中国大陆旗帜"></span>', color: '#E4002B' },
  hk: { label: '港',   icon: '<span class="ev-region-icon ev-region-hk" aria-label="香港旗帜"></span>', color: '#7B2FBE' },
  tw: { label: '台',   icon: '<span class="ev-region-icon ev-region-tw" aria-label="台湾旗帜"></span>', color: '#00A3A3' },
  us: { label: '美',   icon: '<span class="ev-region-icon ev-region-us" aria-label="美国旗帜"></span>', color: '#1F4E79' },
};
function calHolidayRegionMeta(region) {
  const r = (region || '').toLowerCase();
  if (!r) return CAL_HOLIDAY_REGIONS.cn;
  if (CAL_HOLIDAY_REGIONS[r]) return CAL_HOLIDAY_REGIONS[r];
  return { label: r.toUpperCase(), icon: '🌐', color: '#6B7280' };
}
function calHolidayMeta(type) {
  switch ((type || '').toLowerCase()) {
    case 'workday': return { label: '補班', icon: '💼', color: '#FF9500' };
    case 'holiday': return { label: '假日', icon: '🎉', color: '#34C759' };
    case 'festival': return { label: '節日', icon: '🏮', color: '#FF3B30' };
    default: return { label: '假日', icon: '🎌', color: '#FF9500' };
  }
}
// 取某天出現的假日（含跨天展開）：dateStr 落在 [date, endDate] 區間內即命中
// ## HOLIDAY 地區過濾：圖例 checkbox 勾選要顯示的地區（默認只勾大陸 cn），只影響顯示不改數據
function calRegionVisible(h) {
  return (state.calRegionFilter || []).indexOf((h.region || 'cn').toLowerCase()) >= 0;
}
// 只保留「勾選地區」的假日（供按日期分組 / 空態判斷使用，避免繞過地區過濾）
function calVisibleHolidays() {
  return (calHolidays || []).filter(calRegionVisible);
}
// 按當前模式「直接」重渲染（勿走 renderEventsContent —— 它開頭有宿主守衛），再同步頂欄勾選態。分類/地區過濾共用。
function calRerenderCalendarView(preserveScroll = true) {
  const scrollPositions = preserveScroll ? calCaptureScrollPositions() : null;
  const content = elements.editor.value;
  if (state.calMode === 'month') renderCalMonth(content);
  else if (state.calMode === 'week') renderCalTimeGrid(calWeekDays(state.calCursor), preserveScroll);
  else if (state.calMode === 'day') renderCalTimeGrid([state.calCursor], preserveScroll);
  else if (state.calMode === 'year') renderCalYear(content);
  else renderEventsList(content);
  calRenderHolidayLegend();   // 同步圖例 checkbox 勾選態 / .off 類
  if (scrollPositions) calRestoreScrollPositions(scrollPositions);
}
// 頂欄分類過濾：EVENT（普通行程）/ REPEAT（重複行程）
function calSetCategoryChecked(kind, on) {
  if (kind === 'event') state.calShowEvents = !!on;
  else return;
  calRerenderCalendarView();
}
// REPEAT 三態循環：none → next → some → none（點擊圖例 checkbox 切換）
function calCycleRepeat() {
  const order = ['none', 'next', 'some'];
  let i = order.indexOf(state.calShowRepeat);
  if (i < 0) i = 0;
  state.calShowRepeat = order[(i + 1) % order.length];
  calRerenderCalendarView();
}
function calSetRegionChecked(code, on) {
  const r = (code || '').toLowerCase();
  if (!r) return;
  const arr = state.calRegionFilter = state.calRegionFilter || [];
  const i = arr.indexOf(r);
  if (on && i < 0) arr.push(r);
  else if (!on && i >= 0) arr.splice(i, 1);
  calRerenderCalendarView();
}
function calHolidaysOnDay(dateStr) {
  if (!calHolidays || !calHolidays.length) return [];
  return calHolidays.filter((h) => {
    const end = (h.endDate && h.endDate !== h.date) ? h.endDate : h.date;
    return calRegionVisible(h) && dateStr >= h.date && dateStr <= end;
  });
}
// 🗓 依日期分組的「唯一入口」：跨天行程/假日一律「逐日展開」——在涵蓋的每一天都出現，
//    與「日」範圍同口徑。（修復：by月/列表先前只認起始日 → 同一天 by日 4 條、by月 3 條）
//    dateOk(ds) 可選：只收符合條件的日期（如「整月」只收游標月）。
function calEventsByDate(events, dateOk) {
  const byDate = new Map();
  const add = (ds, key, item) => {
    if (!ds || (dateOk && !dateOk(ds))) return;
    if (!byDate.has(ds)) byDate.set(ds, { events: [], holidays: [] });
    byDate.get(ds)[key].push(item);
  };
  (events || []).forEach((ev) => { calEventOccurrences(ev).forEach((o) => add(o.date, 'events', ev)); });
  calVisibleHolidays().forEach((h) => {
    const s = new Date(h.date + 'T00:00:00');
    const en = new Date(((h.endDate && h.endDate !== h.date) ? h.endDate : h.date) + 'T00:00:00');
    if (isNaN(s) || isNaN(en) || en < s) { add(h.date, 'holidays', h); return; }
    for (const cur = new Date(s); cur <= en; cur.setDate(cur.getDate() + 1)) add(calendarFmtDate(cur), 'holidays', h);
  });
  return byDate;
}
// 某日明細的「唯一取數入口」（日/週/月三處明細都用它）→ 與列表/整月同口徑，不會再分叉
function calDayItems(ds) {
  return calEventsByDate(state.calEvents.filter(calEventShown), (d) => d === ds).get(ds) || { events: [], holidays: [] };
}
// occDate＝該列所屬的「出現日」：跨天假日（endDate ≠ date）用它算「(第幾天/共幾天)」，與行程同款。
// ⚠️ 必須由呼叫方傳入（分組入口只給 h + 日期，h 自身不知道自己被渲染在哪一天）。
function calHolidayHtml(h, today, occDate) {
  const meta = calHolidayMeta(h.holidayType);
  const region = calHolidayRegionMeta(h.region);
  const accent = region.color; // 假日主色＝地區色（地區為目視差別唯一來源；color 字段不參與假日著色）
  const multi = h.endDate && h.endDate !== h.date;
  const time = multi
    ? (calMdShort(h.date) + ' – ' + calMdShort(h.endDate) + ' · 共' + calSpanDays(h.date, h.endDate) + '天')
    : '全天';
  const tags = (h.tags && h.tags.length) ? '<span class="ev-tags">' + h.tags.map((t) => '<span class="ev-tag-view" data-tag="' + escapeHtml(calTagName(t)) + '">' + escapeHtml(calTagLabel(t)) + '</span>').join('') + '</span>' : '';
  return '<div class="ev-holiday" data-ev-holiday="' + escapeHtml(h.uid) + '" style="--holiday-color:' + escapeHtml(accent) + '">' +
    '<span class="ev-holiday-region" style="--region-color:' + escapeHtml(region.color) + '" title="' + escapeHtml(region.label + '地區假日') + '">' + region.icon + escapeHtml(region.label) + '</span>' +
    '<span class="ev-holiday-badge">' + meta.icon + ' ' + escapeHtml(meta.label) + '</span>' +
    '<div class="ev-body">' +
    '<div class="ev-title">' + calRenderInlineMarkdown(h.title) + calSpanDaySuffix(h, occDate) + tags + '</div>' +
    '<div class="ev-meta">' + escapeHtml(time) + (h.location ? ' · 📍' + escapeHtml(h.location) : '') + '</div>' +
    (h.notes ? '<div class="ev-notes">' + calRenderNotes(h.notes, null) + '</div>' : '') +
    '</div></div>';
}

// ===== 列表模式：「跨天行程」顯示方式（跨天一筆 / 跨天多筆）=====
// 純 UI 偏好（記憶體 + localStorage，鍵 calMultiDay；絕不寫回 calendar.md）。
// 只在列表模式生效：跨天行程要不要「跨幾天就顯示幾筆」——預設多筆（與「日」範圍同口徑）。
const CAL_MULTIDAY_KEY = 'calMultiDay';
let calMultiDayLoaded = false;
function calLoadMultiDayMode() {
  if (calMultiDayLoaded) return state.calMultiDayMode;
  calMultiDayLoaded = true;
  let v = '';
  try { v = localStorage.getItem(CAL_MULTIDAY_KEY) || ''; } catch (e) {}
  state.calMultiDayMode = (v === 'one') ? 'one' : 'multi';
  return state.calMultiDayMode;
}
// 同步「跨天一筆 / 跨天多筆」按鈕的文案與高亮（按鈕只在列表模式顯示）
function calUpdateMultiDayBtn() {
  const b = elements.evMultiDayBtn;
  if (!b) return;
  calLoadMultiDayMode();
  const one = state.calMultiDayMode === 'one';
  b.textContent = one ? '跨天一笔' : '跨天多笔';
  b.classList.toggle('active', one);
  b.title = one
    ? '当前「跨天一笔」：每天显示的事件集中在首天，首天/末天设置按事件设定显示 · 点击改为「跨天多笔」'
    : '当前「跨天多笔」：跨天行程跨几天就显示几笔 · 点击改为「跨天一笔」';
}
function calSetMultiDayMode(mode) {
  state.calMultiDayMode = (mode === 'one') ? 'one' : 'multi';
  calMultiDayLoaded = true;
  try { localStorage.setItem(CAL_MULTIDAY_KEY, state.calMultiDayMode); } catch (e) {}
  calUpdateMultiDayBtn();
  calRerenderCalendarView();
}
function calToggleMultiDayMode() { calSetMultiDayMode(state.calMultiDayMode === 'one' ? 'multi' : 'one'); }
// 「跨天一筆」：默认每天显示的跨天行程只保留首天；事件设为末天的则在末天显示。
// 被清空的日期（原本只掛著這一個跨天行程）整條刪掉，避免留下「· 0 條」的空標題。
// ⚠️ 就地改的是 renderEventsList 自己那份 byDate 副本——calEventsByDate 的「逐日展開」口徑不動，
//    所以月格 chip / 時間網格 / 日明細一律不受影響（只調列表模式）。
function calCollapseMultiDayRows(byDate) {
  const seen = new Set();
  for (const ds of Array.from(byDate.keys()).sort()) {
    const grp = byDate.get(ds);
    grp.events = grp.events.filter((ev) => {
      if (!calIsMultiDay(ev)) return true;   // 單日行程（含重複事件的每個出現日）逐日照顯
      if (seen.has(ev.uid)) return false;    // 跨天行程：後續天不再重複出現
      seen.add(ev.uid);
      return true;
    });
    if (!grp.events.length && !grp.holidays.length) byDate.delete(ds);
  }
}

// ===== 列表模式：「只顯示日記」過濾（勾選後行程/假日全部隱藏，只列有日記的日期）=====
// 純 UI 偏好（記憶體 + localStorage，鍵 calDiaryOnly；絕不寫回 calendar.md）。只在列表模式生效。
const CAL_DIARYONLY_KEY = 'calDiaryOnly';
let calDiaryOnlyLoaded = false;
function calLoadDiaryOnly() {
  if (calDiaryOnlyLoaded) return state.calDiaryOnly;
  calDiaryOnlyLoaded = true;
  let v = '';
  try { v = localStorage.getItem(CAL_DIARYONLY_KEY) || ''; } catch (e) {}
  state.calDiaryOnly = (v === '1');
  return state.calDiaryOnly;
}
function calSetDiaryOnly(on) {
  state.calDiaryOnly = !!on;
  calDiaryOnlyLoaded = true;
  try { localStorage.setItem(CAL_DIARYONLY_KEY, state.calDiaryOnly ? '1' : '0'); } catch (e) {}
  calRenderHolidayLegend();   // 同步頂欄勾選態（該勾選框只在列表模式渲染）
  calRerenderCalendarView();
}
// ===== 「只顯示未完成」過濾（勾選後隱藏已完成 done ✓ 的行程；假日無完成態不受影響）=====
// 純 UI 偏好（記憶體 + localStorage，鍵 calUndoneOnly；絕不寫回 calendar.md）。全模式生效（收口於 calEventShown）。
const CAL_UNDONEONLY_KEY = 'calUndoneOnly';
let calUndoneOnlyLoaded = false;
let calUndoneScrollResult = null;   // 测试 seam：undone 勾选切换后实际滚动到的日期组（null＝无列表/无锚点）
function calLoadUndoneOnly() {
  if (calUndoneOnlyLoaded) return state.calUndoneOnly;
  calUndoneOnlyLoaded = true;
  let v = '';
  try { v = localStorage.getItem(CAL_UNDONEONLY_KEY) || ''; } catch (e) {}
  // 第十一批依用户截图设定：缺省（從未設過該鍵）＝默認「開」；僅當用戶明確設過 '0' 才關閉
  state.calUndoneOnly = (v === '' ? true : v === '1');
  return state.calUndoneOnly;
}
function calSetUndoneOnly(on) {
  state.calUndoneOnly = !!on;
  calUndoneOnlyLoaded = true;
  try { localStorage.setItem(CAL_UNDONEONLY_KEY, state.calUndoneOnly ? '1' : '0'); } catch (e) {}
  calRenderHolidayLegend();   // 同步頂欄勾選態（該勾選框只在列表模式渲染）
  // 切換前：捕獲當前畫面頂部日期組＋偏移，用於切換後儘量不滾動（Feature #8）
  const list = calActiveDetailList();
  let anchorDate = null, anchorOffset = 0;
  if (list) {
    const info = calViewportTopDateInfo(list);
    if (info) { anchorDate = info.date; anchorOffset = info.offset; }
  }
  calRerenderCalendarView(false);
  // 切換後：把錨點日期組對齊回原偏移（錨點被過濾掉 → 回落到最近的未過濾組）；覆蓋重繪自帶的滾動
  if (list && anchorDate) calReanchorList(list, anchorDate, anchorOffset);
}
// 日記正文：壓掉行尾空白並 trim 後**原樣輸出**（不截斷）。
// ⚠️ 絕不在這裡截斷：被截掉的部分根本沒進 DOM，列表滾動條再怎麼滾也滾不出來。
// 正文過長由「只顯示日記」列表自身滾動查看；換行保留 → .ev-notes 是 pre-wrap。
function calDiaryBody(content) {
  const raw = String(content || '').replace(/\r\n/g, '\n').replace(/[ \t]+\n/g, '\n').trim();
  return raw ? renderMarkdown(raw) : '';
}
// 日記條目：標題 + 心情/天氣 + 標籤 + 完整正文；點條目或「編輯」開既有日記表單。
// ⚠️ 日記沒有 color 欄位 → 色點統一用日記綠 #16a34a（與日期標題上「已有日記」的 📕 勾同色）。
function calDiaryRowHtml(d) {
  const meta = [];
  if (d.mood) meta.push('心情 ' + d.mood);
  if (d.weather) meta.push(d.weather);
  const tags = (d.tags && d.tags.length)
    ? '<span class="ev-tags">' + d.tags.map((t) => '<span class="ev-tag-view" data-tag="' + escapeHtml(calTagName(t)) + '">' + escapeHtml(calTagLabel(t)) + '</span>').join('') + '</span>'
    : '';
  const body = calDiaryBody(d.content);
  return '<div class="ev-item ev-diary-item" data-ev-diary-row="' + escapeHtml(d.date) + '">' +
    '<span class="ev-swatch" style="background:#16a34a"></span>' +
    '<div class="ev-body">' +
    '<div class="ev-title">\ud83d\udcd5 ' + calRenderInlineMarkdown(d.title || '（無標題）') + tags + '</div>' +
    (meta.length ? '<div class="ev-meta">' + escapeHtml(meta.join(' · ')) + '</div>' : '') +
    (body ? '<div class="ev-notes">' + body + '</div>' : '') +
    '</div>' +
    '<div class="ev-actions">' +
    '<button type="button" data-ev-diary="' + escapeHtml(d.date) + '">\u7de8\u8f2f</button>' +
    '<button type="button" data-ev-diary-del="' + escapeHtml(d.date) + '">\u522a\u9664</button>' +
    '</div></div>';
}
// 「只顯示日記」的列表本體：日期組只來自 ## DIARY（行程/假日不參與），一天一條
function calRenderDiaryOnlyList(list) {
  const today = calendarFmtDate(new Date());
  // 同一天只應有一條日記，但解析層不做唯一性保證 → 這裡按日期去重（保留首條）
  const seen = {};
  const rows = (calDiaries || []).filter((d) => d.date && !seen[d.date] && (seen[d.date] = true));
  if (!rows.length) {
    list.innerHTML = '<div class="ev-empty">尚未有日記<br><span style="font-size:12px">取消勾選「只顯示日記」可回到行程清單；或在日期標題右側點 \ud83d\udcd5 寫一篇</span></div>';
    return;
  }
  const byDate = {};
  rows.forEach((d) => { byDate[d.date] = d; });
  const dates = rows.map((d) => d.date).sort();
  // 錨點日（「今天」或 < > 導航到的日期）：只用於判斷「是否該框金邊」與滾動，絕不因回退而漂移
  const anchor = state.calListSel || today;
  const anchorInList = dates.indexOf(anchor) >= 0;
  // ⚠️ 「框選」只在錨點日本身真有分組時才生效：今天（或所選日）無內容 → 不框任何其它日
  const highlight = anchorInList ? anchor : null;
  if (anchorInList) state.calListSel = anchor;
  let html = '';
  for (const ds of dates) {
    // 標題條不顯示「· N 條」（一天一條，計數無資訊量），並抑制「＋ 新增」（新增的是行程，此處不顯示）
    let g = calDateHeaderHtml(ds, today, '', undefined, { noAdd: true });
    g += calDiaryRowHtml(byDate[ds]);
    html += (ds === highlight) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
  }
  list.innerHTML = html;
}

// 渲染行程列表：日期升序分組，過去行程淡化，今天高亮；每條帶「編輯/刪除」
function renderEventsList(content) {
  const list = elements.eventsList;
  if (!list) return;
  // 📎 多檔聯運：主檔 + 所有 include 併成顯示用資料集（含 ro 標記）；編輯/存檔路徑仍只用主檔內容
  calRefreshAll();
  // 📓 「只顯示日記」：勾選後走專用分支（行程/假日不參與），連「尚未有行程 / 沒有符合標籤」兩個空態也不適用
  calLoadDiaryOnly();
  if (state.calDiaryOnly) { calRenderDiaryOnlyList(list); return; }
  if (!state.calEvents.length && !calVisibleHolidays().length) {
    list.innerHTML = '<div class="ev-empty">尚未有行程<br><span style="font-size:12px">點右上「＋ 新增行程」，或編輯 calendar.md 原文（以 ## EVENT 分隔）</span></div>';
    return;
  }
  const today = calendarFmtDate(new Date());
  // 重複展開視窗（列表無固定範圍）：今天前 1 年 ~ 後 3 年，避免 never 無限展開
  calSetRepeatWindow(calAddDaysStr(today, -365), calAddDaysStr(today, 1095));
  // 🏷 套用標籤過濾（過濾後為空 → 提示「沒有符合的行程」，與無行程區分）。假日不受標籤過濾影響（總是顯示）。
  // ☐ 「只顯示未完成」已收口於 calEventShown（全模式生效）：過濾鏈已排除 done ✓ 的行程
  calLoadUndoneOnly();
  let visible = state.calEvents.filter(calEventShown);
  if (!visible.length && !calVisibleHolidays().length) {
    const why = state.calUndoneOnly
      ? '沒有未完成的行程<br><span style="font-size:12px">取消勾選「只顯示未完成」可查看全部</span>'
      : (state.calEvents.length ? '沒有符合所選標籤的行程<br><span style="font-size:12px">點上方標籤可取消篩選</span>'
        : '尚未有行程<br><span style="font-size:12px">點右上「＋ 新增行程」，或編輯 calendar.md 原文（以 ## EVENT 分隔）</span>');
    list.innerHTML = '<div class="ev-empty">' + why + '</div>';
    return;
  }
  // 按日期分組（跨天行程/假日逐日展開，與「日」範圍同口徑）：每天先顯示該日假日，再顯示行程
  calLoadMultiDayMode();
  const byDate = calEventsByDate(visible);
  if (state.calMultiDayMode === 'one') calCollapseMultiDayRows(byDate);   // 跨天一筆：遵循事件首天/末天設定
  const dates = Array.from(byDate.keys()).sort();
  // 錨點日（「今天」或 < > 導航到的日期）：只用於判斷「是否該框金邊」與滾動，絕不因回退而漂移
  const anchor = state.calListSel || today;
  const anchorInList = dates.indexOf(anchor) >= 0;
  // ⚠️ 「框選」（金色描邊）只在錨點日本身真有分組時才生效：今天（或所選日）無行程 → 不框任何其它日
  const highlight = anchorInList ? anchor : null;
  if (anchorInList) state.calListSel = anchor;
  let html = '';
  for (const ds of dates) {
    const grp = byDate.get(ds);
    let g = calDateHeaderHtml(ds, today, '', grp.events.length + grp.holidays.length);
    for (const h of grp.holidays) g += calHolidayHtml(h, today, ds);
    for (const ev of sortedCalEvents(grp.events)) g += evItemHtml(ev, today, ds);
    html += (ds === highlight) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
  }
  list.innerHTML = html;
  // 滾動不在本函式內做：由 renderEventsContent → calQueueScrollActiveViewToToday（今天／最近日）擇機滾動
}

// 自動滾動到「離今天最近、且有行程資料的那一天」
// 規則：優先今天（距離 0）；今天無行程則取「日期距離最小」的那一天（過去或未來皆可，按絕對天數就近）；
//       天數相同（如今天前後各一天）則取較早的日期（過去那天），確保結果確定。
// ⚠️ 用 calScrollElToTop 而不是 scrollIntoView：`.ev-date` 吸頂後 rect 是「位移後」的位置，
//    scrollIntoView 會誤判「已在視口內」而不滾（與 2026-09-19 那個單向滾動 bug 同源）。
function calDayDiff(a, b) {
  // a, b: 'YYYY-MM-DD'；回傳整數天數差 a - b（走 UTC，不受時區/夏令時影響）
  const pa = a.split('-').map(Number), pb = b.split('-').map(Number);
  const da = Date.UTC(pa[0], pa[1] - 1, pa[2]);
  const db = Date.UTC(pb[0], pb[1] - 1, pb[2]);
  return Math.round((da - db) / 86400000);
}
function scrollToNearestDate(list) {
  if (!list) return;
  const headers = Array.from(list.querySelectorAll('.ev-date[data-ev-date]'));
  if (!headers.length) return;
  const today = calendarFmtDate(new Date());
  let best = headers[0], bestDist = Infinity;
  for (const h of headers) {
    const dist = Math.abs(calDayDiff(h.dataset.evDate, today));
    // 距離相同：優先較早的日期（過去那天），結果確定
    if (dist < bestDist || (dist === bestDist && h.dataset.evDate < best.dataset.evDate)) {
      best = h; bestDist = dist;
    }
  }
  calScrollElToTop(best, list);
}

// 列表模式：< > 逐日移動「選中日」（金色描邊隨其移動）並滾動到該日
function calListNavDay(dir) {
  const list = elements.eventsList;
  if (!list) return;
  const dates = Array.from(list.querySelectorAll('.ev-date[data-ev-date]')).map((h) => h.dataset.evDate);
  if (!dates.length) return;
  const today = calendarFmtDate(new Date());
  const anchor = state.calListSel || today;
  let idx = dates.indexOf(anchor);
  if (idx < 0) {
    // 錨點日不在列表（如今天無行程）：改以「最近未來日」為基準——dir>0 落在該未來日，dir<0 落在其前一日
    const fi = dates.findIndex((d) => d > today);
    if (fi < 0) idx = dates.length - 1;           // 全是過去日 → 以末日為基準
    else idx = (dir > 0) ? fi - 1 : fi;
  }
  const target = idx + dir;
  if (target < 0 || target >= dates.length) return;
  state.calListSel = dates[target];
  renderEventsContent();
}

// 把元素滾到 scroller 頂部（sticky 安全版，月/週明細 + 清單模式共用）
// ⚠️ 坑：`.ev-date` 是 position:sticky，**被「吸頂」時它的 offsetTop / getBoundingClientRect()
//    返回的是「位移後」的渲染位置（≈ 當前 scrollTop），不是佈局位置**（Chrome 實測：吸頂後
//    offsetTop === scroller.offsetTop + scrollTop）。於是「點更早的日期」時，目標標題正被吸在
//    滾動口頂部 → 算出的目標 scrollTop 恰好等於當前 scrollTop → 永遠滾不上去；點更晚的日期時
//    標題在下方、沒被吸頂，所以只有單向能滾（2026-09-19 用戶報告的 bug）。
//    修法：讀真實佈局位置前先把該元素的 sticky 臨時摘掉（同步 reflow，同一幀內還原，不會閃）。
//    只改 scroller.scrollTop，不觸碰祖先滾動容器。
function calScrollElToTop(el, scroller) {
  if (!el || !scroller) return;
  scroller.scrollTop = calElAbsTop(el, scroller);
}

// 在明細裡挑「要滾動到的日期標題」：精確命中 → 其後最近 → 其前最近 → 首個（＝附近位置回退）
function calPickScrollTarget(headers, ds) {
  if (!headers || !headers.length) return null;
  for (const h of headers) if (h.dataset.evDate === ds) return h;
  for (const h of headers) if (h.dataset.evDate > ds) return h;
  for (let i = headers.length - 1; i >= 0; i--) if (headers[i].dataset.evDate < ds) return headers[i];
  return headers[0];
}
// 把月/週明細滾動到指定日期（真實佈局位置換算見 calScrollElToTop：`.ev-date` 的 sticky
// 會讓 offsetTop / rect 變成「位移後」的渲染位置，必須先摘掉 sticky 再讀）
function calScrollListToDate(list, scroller, ds) {
  if (!list || !scroller || !ds) return;
  calScrollElToTop(calPickScrollTarget(list.querySelectorAll('.ev-date[data-ev-date]'), ds), scroller);
}
// 元素在 scroller 內的「絕對佈局 scrollTop」（sticky 安全：先臨時摘 .ev-date 再讀，見 calScrollElToTop）
function calElAbsTop(el, scroller) {
  const prevPos = el.style.position;
  el.style.position = 'static';
  const next = (el.offsetParent && el.offsetParent === scroller.offsetParent)
    ? el.offsetTop - scroller.offsetTop - (scroller.clientTop || 0)
    : scroller.scrollTop + (el.getBoundingClientRect().top - scroller.getBoundingClientRect().top);
  el.style.position = prevPos;
  return next;
}
// 當前模式下真正可見/可滾動的「明細列表」元素（undone 勾選切換只重錨這一條）
function calActiveDetailList() {
  if (state.calMode === 'list') return elements.eventsList;
  if (state.calMode === 'year') return elements.evYearDayList;
  return elements.evDayList; // month / week / day
}
// 切換前：捕獲「視口頂部日期組」及其在滾動容器內的相對偏移（用於切換後儘量不滾動）
function calViewportTopDateInfo(list) {
  if (!list) return null;
  const active = calPickActiveDate(list); // 複用頂部 sticky 日期條判定（已是 sticky 安全版）
  if (!active) return null;
  const offset = active.getBoundingClientRect().top - list.getBoundingClientRect().top;
  return { date: active.dataset.evDate, offset: offset };
}
// 給定一組日期標題，挑與 ds 日期距離最小者（tie → 較晚日期）；ds 已被過濾掉時用來回落到「最近的未過濾組」
function calNearestDateHeader(headers, ds) {
  if (!headers || !headers.length) return null;
  const base = parseInt(ds.replace(/-/g, ''), 10);
  let best = null, bestD = Infinity;
  for (const h of headers) {
    const d = Math.abs(parseInt(h.dataset.evDate.replace(/-/g, ''), 10) - base);
    if (d < bestD || (d === bestD && best && h.dataset.evDate > best.dataset.evDate)) { bestD = d; best = h; }
  }
  return best;
}
// 切換後把列表重錨：錨點存活→保持原偏移（＝不滾動）；錨點被過濾掉→滾到最近未過濾組（置頂）
function calReanchorList(list, anchorDate, anchorOffset) {
  const headers = list.querySelectorAll('.ev-date[data-ev-date]');
  if (!headers.length) { calUndoneScrollResult = null; return; }
  let target = null, survived = false;
  for (const h of headers) if (h.dataset.evDate === anchorDate) { target = h; survived = true; break; }
  if (!target) target = calNearestDateHeader(headers, anchorDate);
  if (!target) { calUndoneScrollResult = null; return; }
  const absTop = calElAbsTop(target, list);
  list.scrollTop = survived ? (absTop - anchorOffset) : absTop;
  calUndoneScrollResult = target.dataset.evDate;
}
// 「日/月」切換只顯示在當前畫面頂部（第一個可見）的日期標題條上：
// active = 已滾過頂部、當前貼著頂部的那條日期標題（sticky 頂條）。
function calPickActiveDate(list) {
  const heads = list.querySelectorAll('.ev-date[data-ev-date]');
  if (!heads.length) return null;
  const topLine = list.getBoundingClientRect().top + 16; // 16px：容納首條 margin-top 與容器內邊距
  let active = null;
  for (let i = 0; i < heads.length; i++) {
    if (heads[i].getBoundingClientRect().top <= topLine) active = heads[i];
  }
  return active;
}
function calUpdateActiveDate(list) {
  if (!list) return;
  const active = calPickActiveDate(list);
  list.querySelectorAll('.ev-date[data-ev-date].active').forEach((h) => h.classList.remove('active'));
  if (active) active.classList.add('active');
}
function calBindActiveDateScroll(list) {
  if (!list || list.dataset.activeBound === '1') return;
  list.dataset.activeBound = '1';
  let raf = 0;
  list.addEventListener('scroll', () => {
    if (raf) return;
    raf = requestAnimationFrame(() => { raf = 0; calUpdateActiveDate(list); });
  }, { passive: true });
}

// ===== 上下區域可拖動分割（月/週共用）=====
// 拖動横条調整「下方行程明細」高度：寫成 CSS 變數 --ev-detail-h（百分比）
// → 窗口尺寸變化時比例自然保持。純 UI 偏好：記憶體 + localStorage，絕不寫回資料檔。
const CAL_SPLIT_MIN_PX = 56;        // 明細最小高度（至少看得見一條日期條）
const CAL_SPLIT_TOP_MIN_PX = 120;   // 上區最小高度（仍看得見月格 / 時間網格）
const CAL_SPLIT_DEFAULT = 30;       // 預設佔比（%）
let calSplitPct = null;
function calLoadSplitPct() {
  if (calSplitPct != null) return calSplitPct;
  let v = NaN;
  try { v = parseFloat(localStorage.getItem('calDetailH')); } catch (e) {}
  calSplitPct = (isFinite(v) && v >= 10 && v <= 80) ? v : CAL_SPLIT_DEFAULT;
  return calSplitPct;
}
function calSaveSplitPct(v) {
  calSplitPct = Math.min(80, Math.max(10, Math.round(v * 10) / 10));
  try { localStorage.setItem('calDetailH', String(calSplitPct)); } catch (e) {}
}
// 指針 Y → 明細高度百分比（即時量 rect，不依賴快取尺寸）；只寫 CSS 變數，不落盤
function calApplySplitFromPointer(wrap, clientY) {
  const r = wrap.getBoundingClientRect();
  if (!r.height) return null;
  const maxPx = Math.max(CAL_SPLIT_MIN_PX, r.height - CAL_SPLIT_TOP_MIN_PX);
  const px = Math.min(Math.max(CAL_SPLIT_MIN_PX, r.bottom - clientY), maxPx);
  const pct = px / r.height * 100;
  wrap.style.setProperty('--ev-detail-h', pct + '%');
  return pct;
}
// 綁一次即可（重渲染換了新元素才會再綁）；每次調用都重新套用已存佔比
function calBindSplit(wrap, split) {
  if (!wrap || !split) return;
  wrap.style.setProperty('--ev-detail-h', calLoadSplitPct() + '%');
  if (split.dataset.splitBound === '1') return;
  split.dataset.splitBound = '1';
  let dragging = false;
  split.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    dragging = true;
    split.classList.add('dragging');
    try { split.setPointerCapture(e.pointerId); } catch (err) {}
    if (e.cancelable) e.preventDefault();   // 防止拖動時選中文字
  });
  // 有了 pointer capture，move/up 都會派發到 split 自身
  split.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    if ((e.buttons & 1) !== 1) { dragging = false; split.classList.remove('dragging'); return; }
    calApplySplitFromPointer(wrap, e.clientY);
  });
  const end = (e) => {
    if (!dragging) return;
    dragging = false;
    split.classList.remove('dragging');
    try { split.releasePointerCapture(e.pointerId); } catch (err) {}
    const pct = calApplySplitFromPointer(wrap, e.clientY);
    if (pct != null) calSaveSplitPct(pct);   // 放手才落盤
  };
  split.addEventListener('pointerup', end);
  split.addEventListener('pointercancel', end);
  split.addEventListener('dblclick', () => {
    calSaveSplitPct(CAL_SPLIT_DEFAULT);
    wrap.style.setProperty('--ev-detail-h', CAL_SPLIT_DEFAULT + '%');
  });
}

// 條目排序：日期升序 → 同日全天在前 → 開始時間
function sortedCalEvents(events) {
  return events.slice().sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    if (a.allDay !== b.allDay) return a.allDay ? -1 : 1;
    return calendarTimeToMin(a.startTime) - calendarTimeToMin(b.startTime);
  });
}

// 倒計時標籤：今天 / N天后 / N天前（日期字符串安全運算，不受時區/夏令時影響）
function calCountdownLabel(date, today) {
  const p = (s) => { const m = String(s || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
  const a = p(date), b = p(today);
  if (!a || !b) return '';
  const diff = Math.round((a - b) / 86400000);
  if (diff === 0) return '今天';
  return diff > 0 ? diff + '天后' : (-diff) + '天前';
}

// ===== 📅 農民曆 / 老黃曆取數（lunar-javascript，繁體）=====
// 以 <script> 載入的 window.Solar / window.Lunar 為資料源；Map 快取避免重複計算。
const calAlmanacCache = new Map();
function calAlmanac(dateStr) {
  if (calAlmanacCache.has(dateStr)) return calAlmanacCache.get(dateStr);
  let data = { error: 'lunar lib 未載入或日期無效' };
  try {
    if (typeof Solar === 'undefined' || typeof Lunar === 'undefined') throw new Error('lunar lib 未載入');
    const m = String(dateStr || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (!m) throw new Error('日期格式錯誤');
    const lunar = Solar.fromYmd(+m[1], +m[2], +m[3]).getLunar();
    data = {
      lunarMonth: lunar.getMonthInChinese(),   // 八 / 闰二
      lunarDay: lunar.getDayInChinese(),        // 初七
      lunarText: lunar.getMonthInChinese() + '月' + lunar.getDayInChinese(), // 八月初七（getMonthInChinese 只回「八」，需補「月」）
      isLeap: lunar.getMonth() < 0,
      yearGanZhi: lunar.getYearInGanZhi(),      // 丙午
      monthGanZhi: lunar.getMonthInGanZhi(),    // 丁酉
      dayGanZhi: lunar.getDayInGanZhi(),        // 甲午
      shengxiao: lunar.getYearShengXiao(),      // 馬
      yearChinese: lunar.getYearInChinese(),    // 二〇二六
      jieqi: lunar.getJieQi() || '',            // 秋分 / ''
      // 宜忌/彭祖/吉神/凶神/納音/宿/建除 均為簡體 → 逐詞轉繁體（almanacToTrad）
      yi: (lunar.getDayYi() || []).map(almanacToTrad),   // 宜
      ji: (lunar.getDayJi() || []).map(almanacToTrad),   // 忌
      chong: lunar.getDayChong() || '',         // 子
      chongShengXiao: almanacToTrad(lunar.getDayChongShengXiao() || ''), // 鼠
      sha: lunar.getDaySha() || '',             // 北
      pengZuGan: almanacToTrad(lunar.getPengZuGan() || ''),
      pengZuZhi: almanacToTrad(lunar.getPengZuZhi() || ''),
      jiShen: (lunar.getDayJiShen() || []).map(almanacToTrad),   // 吉神宜趨
      xiongSha: (lunar.getDayXiongSha() || []).map(almanacToTrad),   // 凶神宜忌
      naYin: almanacToTrad(lunar.getDayNaYin() || ''),  // 沙中金
      xiu: almanacToTrad(lunar.getXiu() || ''),         // 角
      xiuLuck: lunar.getXiuLuck() || '',        // 吉
      zhiXing: almanacToTrad(lunar.getZhiXing() || ''), // 收
      posXi: lunar.getDayPositionXiDesc() || '',    // 東北
      posCai: lunar.getDayPositionCaiDesc() || '',  // 東北
      posFu: lunar.getDayPositionFuDesc() || '',    // 正北
      posYangGui: lunar.getDayPositionYangGuiDesc() || '', // 西南
      posYinGui: lunar.getDayPositionYinGuiDesc() || ''    // 東北
    };
  } catch (e) {
    data = { error: String((e && e.message) || e) };
  }
  calAlmanacCache.set(dateStr, data);
  return data;
}

// 常顯用精簡標籤：有節氣顯示節氣（更實用），否則顯示農曆日（初七 / 廿三 …）
function calLunarCompact(dateStr) {
  const a = calAlmanac(dateStr);
  if (a.error) return { text: '', jieqi: '', lunar: '', lunarText: '', yearGanZhi: '', shengxiao: '', monthGanZhi: '', dayGanZhi: '' };
  return {
    text: a.jieqi || a.lunarDay,
    jieqi: a.jieqi || '',
    lunar: a.lunarDay,
    lunarText: a.lunarText,
    yearGanZhi: a.yearGanZhi,
    shengxiao: a.shengxiao,
    monthGanZhi: a.monthGanZhi,
    dayGanZhi: a.dayGanZhi
  };
}

// 老黃曆詳情浮層 HTML（繁體）
function calAlmanacHtml(dateStr) {
  const a = calAlmanac(dateStr);
  if (a.error) return '<div class="ev-alm-empty">無法取得農民曆：' + escapeHtml(a.error) + '</div>';
  const WD = ['日', '一', '二', '三', '四', '五', '六'];
  const m = String(dateStr || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  const d = m ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date();
  const solarLabel = m ? (+m[1]) + '年' + (+m[2]) + '月' + (+m[3]) + '日 週' + WD[d.getDay()] : dateStr;
  const E = escapeHtml;
  const join = (arr) => (arr && arr.length ? arr.map(E).join('、') : '—');
  const row = (k, v) => '<div class="ev-alm-row"><span class="ev-alm-k">' + k + '</span><span class="ev-alm-v">' + v + '</span></div>';
  let html = '';
  html += '<div class="ev-alm-head">';
  html += '<div class="ev-alm-solar">' + E(solarLabel) + '</div>';
  html += '<div class="ev-alm-lunar">農曆 ' + E(a.yearGanZhi) + '年（' + E(a.shengxiao) + '）' + E(a.lunarText) + (a.jieqi ? ' · ' + E(a.jieqi) : '') + '</div>';
  html += '</div>';
  html += '<div class="ev-alm-grid">';
  html += row('干支', E(a.yearGanZhi) + '（年） / ' + E(a.monthGanZhi) + '（月） / ' + E(a.dayGanZhi) + '（日）');
  html += row('五行納音', E(a.naYin));
  if (a.jieqi) html += row('節氣', E(a.jieqi));
  html += row('宜', '<span class="ev-alm-yi">' + join(a.yi) + '</span>');
  html += row('忌', '<span class="ev-alm-ji">' + join(a.ji) + '</span>');
  html += row('沖煞', '沖' + E(a.chongShengXiao) + '（' + E(a.chong) + '）· 煞' + E(a.sha) + '方');
  html += row('彭祖百忌', E(a.pengZuGan) + '；' + E(a.pengZuZhi));
  html += row('吉神宜趨', join(a.jiShen));
  html += row('凶神宜忌', join(a.xiongSha));
  html += row('二十八宿', E(a.xiu) + '（' + E(a.xiuLuck) + '）');
  html += row('十二建除', E(a.zhiXing));
  html += row('喜神', E(a.posXi));
  html += row('財神', E(a.posCai));
  html += row('福神', E(a.posFu));
  html += row('陽貴', E(a.posYangGui));
  html += row('陰貴', E(a.posYinGui));
  html += '</div>';
  return html;
}

// 老黃曆詳情浮層：點擊農曆文字 / 📜 觸發，複用 body 浮層 + 外部點擊關閉
let calAlmanacEl = null;
function calShowAlmanac(dateStr, anchorEl) {
  calRemoveMenu(); calRemoveDetail(); calRemoveAlmanac();
  const pop = document.createElement('div');
  pop.className = 'ev-almanac-pop';
  pop.setAttribute('role', 'dialog');
  pop.setAttribute('aria-label', '老黃曆');
  pop.innerHTML = '<button type="button" class="ev-almanac-close" aria-label="關閉">✕</button>' + calAlmanacHtml(dateStr);
  document.body.appendChild(pop);
  calAlmanacEl = pop;
  const pw = pop.offsetWidth || 320, ph = pop.offsetHeight || 320;
  const r = anchorEl ? anchorEl.getBoundingClientRect() : null;
  let left = r ? r.left : (window.innerWidth - pw) / 2;
  let top = r ? r.bottom + 6 : (window.innerHeight - ph) / 2;
  if (left + pw > window.innerWidth - 8) left = window.innerWidth - pw - 8;
  if (top + ph > window.innerHeight - 8) top = window.innerHeight - ph - 8;
  pop.style.left = Math.max(8, left) + 'px';
  pop.style.top = Math.max(8, top) + 'px';
  pop.querySelector('.ev-almanac-close').addEventListener('click', calRemoveAlmanac);
  setTimeout(() => document.addEventListener('click', calDocClick, true), 0);
}
function calRemoveAlmanac() {
  if (calAlmanacEl) { calAlmanacEl.remove(); calAlmanacEl = null; }
  // 若選單/詳情都已關，一併解綁外部點擊監聽
  if (!calMenuEl && !calDetailEl) document.removeEventListener('click', calDocClick, true);
}

// 表單日期輸入框旁的星期提示：根據輸入的日期即時顯示「（星期五）」；結束日留空則清除
// 同時顯示農曆 / 節氣（ev-f-*-lunar，點擊即開老黃曆詳情）
function calUpdateFormDow() {
  const WD = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
  const set = (id, val) => {
    const el = document.getElementById(id);
    if (!el) return;
    const m = String(val || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    el.textContent = m ? '（' + WD[new Date(+m[1], +m[2] - 1, +m[3]).getDay()] + '）' : '';
  };
  set('ev-f-date-dow', elements.evFDate && elements.evFDate.value);
  set('ev-f-enddate-dow', elements.evFEndDate && elements.evFEndDate.value);
  const setLunar = (id, val) => {
    const el = document.getElementById(id);
    if (!el) return;
    const cp = calLunarCompact(val);
    el.textContent = cp.jieqi || cp.lunarText || '';
  };
  setLunar('ev-f-date-lunar', elements.evFDate && elements.evFDate.value);
  setLunar('ev-f-enddate-lunar', elements.evFEndDate && elements.evFEndDate.value);
}

// opts.noAdd：抑制日期標題右側的「＋ 新增」（「只顯示日記」過濾下新增的是行程，此處不顯示，避免誤導）
function calDateHeaderHtml(date, today, extra, count, opts) {
  const m = String(date || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  const WD = ['日', '一', '二', '三', '四', '五', '六'];
  let label = '日期未知';
  let week = '';
  if (m) {
    const d = new Date(+m[1], +m[2] - 1, +m[3]);
    label = (+m[1]) + '年' + (+m[2]) + '月' + (+m[3]) + '日';
    week = WD[d.getDay()];
  }
  const isToday = date === today;
  const cd = calCountdownLabel(date, today);
  const cp = calLunarCompact(date);
  const lunarHdr = cp.lunarText ? '農曆 ' + cp.lunarText + (cp.jieqi ? ' · ' + cp.jieqi : '') : (cp.jieqi || '');
  const dy = calDiaryOnDate(date);
  const diaryBtn = '<button type="button" class="ev-day-diary' + (dy ? ' has' : '') + '" title="' + (dy ? '已有日記 · 點擊編輯' : '寫日記') + '" data-ev-diary="' + escapeHtml(date) + '">\ud83d\udcd5</button>';
  return '<div class="ev-date' + (isToday ? ' today' : '') + '" data-ev-date="' + escapeHtml(date) + '">' + label +
    (week ? '<span class="ev-week">週' + week + '</span>' : '') +
    // ⏳ 倒計時徽章：每天必顯示（今天＝高亮，其餘＝灰底），取代原先「僅今天顯示」
    (cd ? '<span class="ev-today-badge' + (isToday ? '' : ' dim') + '">' + cd + '</span>' : '') +
    // 當天條數（與「日」範圍單日標題的「· N 條」一致；列表/整月/整週分組標題都顯示）
    (typeof count === 'number' ? '<span class="ev-week">· ' + count + ' 條</span>' : '') +
    (lunarHdr ? '<span class="ev-lunar hdr" data-ev-almanac="' + escapeHtml(date) + '" title="農民曆 / 老黃曆">' + escapeHtml(lunarHdr) + '</span>' : '') +
    (extra || '') +
    diaryBtn +
    ((opts && opts.noAdd) ? '' : '<button type="button" class="ev-day-add" data-ev-add-on="' + escapeHtml(date) + '">＋ 新增</button>') +
    '</div>';
}

// 單條行程 HTML（列表視圖與月視圖日列表共用；含編輯/刪除按鈕，走事件委派）
// occDate＝該行所屬的「出現日」（重複事件為展開後的當天；非重複＝ev.date）。
// ⚠️ 重複事件的 ev.date 是「系列起始日」：若拿它算 past，則「過去開始的年度重複」在未來年份的實例會被誤判為過去而淡化。
function evItemHtml(ev, today, occDate) {
  const multi = calIsMultiDay(ev);
  const isRep = !!ev.repeatMode;
  // 重複事件：該行代表「出現日當天」（單日）；非重複：用自身 date/endDate。跨天進行中（今天落在區間內）不視為過去 → 不淡化
  const effEnd = isRep ? (occDate || ev.date) : ((ev.endDate && ev.endDate !== ev.date) ? ev.endDate : ev.date);
  const past = effEnd < today;
  let time;
  if (calIsSpanToday(ev)) {
    time = CAL_SPAN_TODAY_TEXT;   // 显示在今天：不显示真实日期区间
  } else if (multi) {
    time = ev.allDay
      ? (calRangeLabel(ev.date, ev.endDate) + ' · 共' + calSpanDays(ev.date, ev.endDate) + '天')
      : calRangeLabel(ev.date, ev.endDate, ev.startTime, ev.endTime);
  } else {
    time = ev.allDay ? '全天' : ((ev.startTime || '') + (ev.endTime ? '-' + ev.endTime : ''));
  }
  // 🆕 显示方式＝「显示在今天」：时间行已改固定字样，跨天徽标也不该再出现
  const spanBadge = (multi && !calIsSpanToday(ev)) ? '<span class="ev-span-badge" title="跨天行程">⤢ 跨' + calSpanDays(ev.date, ev.endDate) + '天</span>' : '';
  return '<div class="ev-item' + (past ? ' past' : '') + (ev.done ? ' done' : '') + (multi ? ' multi' : '') + (calEventUndoneChecksOnly(ev.uid) ? ' only-undone-checks' : '') + '" data-ev-edit="' + escapeHtml(ev.uid) + '" data-occ-date="' + escapeHtml(occDate || ev.date) + '">' +
    '<input type="checkbox" class="ev-check" data-ev-done="' + escapeHtml(ev.uid) + '"' +
    (ev.done ? ' checked' : '') + (ev.ro ? ' disabled' : '') + ' title="' + (ev.ro ? '來自只讀檔案，不可修改完成狀態' : '勾選＝已完成') + '">' +
    '<span class="ev-swatch" style="background:' + escapeHtml(ev.color) + '"></span>' +
    '<div class="ev-body">' +
    // 跨天行程（含跨天重複）標題後緊跟「(第幾天/共幾天)」——「回上海 (3/7)」一眼看出是第三天
    '<div class="ev-title">' + calRepeatIcon(ev) + calRenderInlineMarkdown(ev.title) + calSpanDaySuffix(ev, occDate) + spanBadge +
    (ev.tags && ev.tags.length ? '<span class="ev-tags">' + ev.tags.map(t => '<span class="ev-tag-view" data-tag="' + escapeHtml(calTagName(t)) + '">' + escapeHtml(calTagLabel(t)) + '</span>').join('') + '</span>' : '') +
    calSubProgressBadge(ev) +
    calSpanDisplayModeBadge(ev) +
    calRoIcon(ev) +
    // 🗒 便利貼徽標：該行程設了「便利貼張數 ≥1」才顯示（與桌面清單行同一位置/同一圖示）；
    //    點它＝開便利貼並跳到該行程的第一張
    (ev.sticky > 0 ? '<button type="button" class="ev-sticky-flag" data-ev-sticky="' + escapeHtml(ev.uid) + '" title="開啟便利貼（' + (parseInt(ev.sticky, 10) || 0) + ' 張）">' + CAL_STICKY_IC_SVG + '</button>' : '') +
    // 📎 多檔聯運：只讀（ro）事件不提供「＋☐ 加入子事件」與「只顯示未完成」按鈕（這些都會寫回主檔）
    (ev.ro ? '' :
      // ＋☐：在備註末尾加入 checkbox 子事件（與便利貼 meta 同一入口）
      '<button type="button" class="ev-addcheck-btn" data-ev-addcheck="' + escapeHtml(ev.uid) + '" title="在備註末尾加入 checkbox 子事件">＋☐</button>' +
      '<button type="button" class="ev-undone-filter-btn' + (calEventUndoneChecksOnly(ev.uid) ? ' active' : '') + '"' +
      ' data-ev-undone-filter="' + escapeHtml(ev.uid) + '" aria-pressed="' + (calEventUndoneChecksOnly(ev.uid) ? 'true' : 'false') + '"' +
      ' title="' + (calEventUndoneChecksOnly(ev.uid) ? '仅显示该事件未完成的 checkbox 子事件（点击显示全部）' : '只显示该事件未完成的 checkbox 子事件') + '">' +
      (calEventUndoneChecksOnly(ev.uid) ? '☑' : '☐') + '</button>') +
    calEventTodoLinks(ev) +
    '</div>' +
    '<div class="ev-meta">' + escapeHtml(time) + (ev.location ? ' · 📍' + escapeHtml(ev.location) : '') + '</div>' +
    (ev.notes ? '<div class="ev-notes">' + calRenderNotes(ev.notes, ev.uid) + '</div>' : '') +
    '</div>' +
    '</div>';
  // 📱 編輯/刪除按鈕已移除：點整列（data-ev-edit）→ 觸屏彈選單（詳情/編輯/刪除/取消）、桌面直接開表單。
  //    原按鈕被整行 data-ev-edit 遮蔽（closest 先命中行 → 刪除分支走不到）＋ 觸屏改選單後按鈕行為混亂，故統一收進選單。
}

// ===== 📅 行程月視圖 + 新增/編輯（寫回編輯緩衝，按頂欄「保存」落盤） =====

// 與桌面 calendar 插件完全一致的 11 色 iOS 色板
const CAL_COLORS = ['#FF3B30', '#FF9500', '#FFCC00', '#34C759', '#5AC8FA', '#007AFF', '#5856D6', '#AF52DE', '#FF2D55', '#A2845E', '#8E8E93'];

function genCalId() {
  return 'ev-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
}

// 序列化：與桌面 calendar 插件的 eventToMarkdown/eventsToMarkdown 逐字節對齊（桌面端要能讀回）
function calMdEscape(s) {
  return String(s == null ? '' : s).replace(/`/g, "'");
}
function calEventToMarkdown(ev) {
  const tagsJson = JSON.stringify(Array.isArray(ev.tags) ? ev.tags : []);
  const todoJson = JSON.stringify(Array.isArray(ev.todoIds) ? ev.todoIds : []);
  const color = '"' + String(ev.color || '').replace(/^"|"$/g, '') + '"';
  const rep = !!(ev.repeatMode && ev.repeatMode !== '');
  let s = (rep ? '## EVENT(REPEAT) ' : '## EVENT ') + '\n';
  s += '- title: `' + calMdEscape(ev.title) + '`\n';
  s += '- date: `' + calMdEscape(ev.date) + '`\n';
  if (ev.endDate && ev.endDate !== ev.date) s += '- endDate: `' + calMdEscape(ev.endDate) + '`\n';
  if (ev.spanDisplay === 'first' || ev.spanDisplay === 'last' || ev.spanDisplay === 'today') s += '- spanDisplay: `' + ev.spanDisplay + '`\n';
  s += '- allDay: `' + (ev.allDay ? 'true' : 'false') + '`\n';
  // 完成狀態：永遠顯式寫出（與桌面 calendar 插件同一欄位、同一順序）
  s += '- done: `' + (ev.done ? 'true' : 'false') + '`\n';
  s += '- startTime: `' + calMdEscape(ev.startTime) + '`\n';
  s += '- endTime: `' + calMdEscape(ev.endTime) + '`\n';
  s += '- location: `' + calMdEscape(ev.location) + '`\n';
  s += '- color: `' + color + '`\n';
  s += '- tags: `' + tagsJson + '`\n';
      s += '- todoIds: `' + todoJson + '`\n';
      // 🆕 桌面便利贴 instance 数（>0 才写出，缺省 0 不写）
      if (ev.sticky > 0) s += '- sticky: `' + (ev.sticky | 0) + '`\n';
      if (rep) {
        s += '- repeatMode: `' + String(ev.repeatMode || '') + '`\n';
        s += '- repeatInterval: `' + String(ev.repeatInterval || '1') + '`\n';
        s += '- repeatWeekDay: `' + JSON.stringify(Array.isArray(ev.repeatWeekDay) ? ev.repeatWeekDay : []) + '`\n';
        s += '- repeatMonthDay: `' + String(ev.repeatMonthDay || '') + '`\n';
        s += '- repeatYearMonthDay: `' + String(ev.repeatYearMonthDay || '') + '`\n';
        s += '- repeatEndType: `' + String(ev.repeatEndType || 'never') + '`\n';
        s += '- repeatEndValue: `' + String(ev.repeatEndValue || '') + '`\n';
        s += '- repeatExcludeDates: `' + JSON.stringify(Array.isArray(ev.repeatExcludeDates) ? ev.repeatExcludeDates : []) + '`\n';
      }
      const remarkFence = calMdFence(ev.notes);
      s += '- Remark:\n' + remarkFence + '\n' + String(ev.notes || '') + '\n' + remarkFence + '\n';
      return s;
}
// ## HOLIDAY 序列化：字段順序與用戶實際寫法對齊（todoIds 後多 holidayType，再 Remark），保證保存後 diff 乾淨
function calHolidayToMarkdown(h) {
  const tagsJson = JSON.stringify(Array.isArray(h.tags) ? h.tags : []);
  const todoJson = JSON.stringify(Array.isArray(h.todoIds) ? h.todoIds : []);
  const color = '"' + String(h.color || '').replace(/^"|"$/g, '') + '"';
  let s = '## HOLIDAY \n';
  s += '- title: `' + calMdEscape(h.title) + '`\n';
  s += '- date: `' + calMdEscape(h.date) + '`\n';
  if (h.endDate && h.endDate !== h.date) s += '- endDate: `' + calMdEscape(h.endDate) + '`\n';
  s += '- allDay: `' + (h.allDay ? 'true' : 'false') + '`\n';
  s += '- done: `' + (h.done ? 'true' : 'false') + '`\n';
  s += '- startTime: `' + calMdEscape(h.startTime) + '`\n';
  s += '- endTime: `' + calMdEscape(h.endTime) + '`\n';
  s += '- location: `' + calMdEscape(h.location) + '`\n';
  s += '- color: `' + color + '`\n';
  s += '- tags: `' + tagsJson + '`\n';
      s += '- todoIds: `' + todoJson + '`\n';
      s += '- holidayType: `' + calMdEscape(h.holidayType || '') + '`\n';
      s += '- region: `' + calMdEscape(h.region || 'cn') + '`\n';
      const holidayFence = calMdFence(h.notes);
      s += '- Remark:\n' + holidayFence + '\n' + String(h.notes || '') + '\n' + holidayFence + '\n';
  return s;
}
// 整份 calendar.md 序列化：events + holidays + diaries 都保留（保存任一類時若只寫該類會把用戶手寫的其它類整體覆蓋掉）
function calCalendarToMarkdown(events, holidays, diaries) {
  const head = '# 日历行程\n\n> 每条行程以 `## EVENT` 分隔，字段值写在反引号内，Remark 用代码块保存多行备注。\n\n';
  let body = (events && events.length) ? events.map(calEventToMarkdown).join('\n') : '';
  if (holidays && holidays.length) {
    body += (body ? '\n' : '') + holidays.map(calHolidayToMarkdown).join('\n');
  }
  if (diaries && diaries.length) {
    body += (body ? '\n' : '') + diaries.map(calDiaryToMarkdown).join('\n');
  }
  return head + (body || '');
}

const CAL_SCROLL_SELECTORS = [
  '#events-list',
  '#ev-month-wrap .ev-month-scroll',
  '#ev-day-list',
  '#ev-week-wrap .ev-timegrid-scroll',
  '#ev-grid-list',
  '#ev-year-wrap .ev-month-scroll',
  '#ev-year-day-list'
];
function calCaptureScrollPositions() {
  const positions = {};
  CAL_SCROLL_SELECTORS.forEach((selector) => {
    const el = document.querySelector(selector);
    if (el) positions[selector] = el.scrollTop;
  });
  return { x: window.scrollX, y: window.scrollY, elements: positions };
}
function calRestoreScrollPositions(snapshot) {
  requestAnimationFrame(() => {
    if (window.scrollX !== snapshot.x || window.scrollY !== snapshot.y) window.scrollTo(snapshot.x, snapshot.y);
    Object.keys(snapshot.elements).forEach((selector) => {
      const el = document.querySelector(selector);
      if (el) el.scrollTop = snapshot.elements[selector];
    });
  });
}
function calScrollActiveViewToToday() {
  const today = calendarFmtDate(new Date());
  if (state.calMode === 'list') {
    scrollToNearestDate(elements.eventsList);
  } else if (state.calMode === 'month') {
    calScrollMonthToToday();
    // 月視圖下方「今日行程列表」——不論 calScope 是 day 還是 full 都滾到今日
    if (elements.evDayList) calScrollListToDate(elements.evDayList, elements.evDayList, today);
  } else if (state.calMode === 'year') {
    calScrollYearToCurrentMonth();
    // 與列表模式同款：今天無行程時滾到「離今天絕對距離最小、且有行程」的那一天（過去/未來皆可，tie 取較早日），
    // 不再像 calScrollListToDate 只偏好未來日。年網格本身仍置中當月（calScrollYearToCurrentMonth）。
    if (state.calScope === 'full') scrollToNearestDate(elements.evYearDayList);
  } else {
    const scroller = document.querySelector('#ev-week-wrap .ev-timegrid-scroll');
    if (scroller) {
      const now = new Date();
      const hourHeight = state.calMode === 'week' ? 48 : 56;
      const nowMinutes = now.getHours() * 60 + now.getMinutes();
      scroller.scrollTop = Math.max(0, nowMinutes * hourHeight / 60 - 2 * hourHeight);
    }
    // 日 / 週 視圖下方「行程列表」
    if (state.calScope === 'full') {
      const list = document.getElementById('ev-grid-list');
      calScrollListToDate(list, list, today);
    }
  }
}

// 視圖總入口（updatePreview 的 events 分支調用）：按模式渲染列表或月曆
function renderEventsContent() {
  if (!isCalendarMd()) return;
  const scrollPositions = calCaptureScrollPositions();
  const scrollToToday = calAutoScrollToTodayPending;
  calAutoScrollToTodayPending = false;
  syncEventsModeUI();
  const content = elements.editor.value;
  const isMonth = state.calMode === 'month';
  const isWeek = state.calMode === 'week';
  const isDay = state.calMode === 'day';
  const isYear = state.calMode === 'year';
  const isGrid = isWeek || isDay;          // 日 / 週共用時間網格
  // 先解析一次供標籤條與日/週網格使用（月/列表的渲染函式內部會再解析一次，結果相同）
  // 📎 多檔聯運：主檔 + 所有 include 併成顯示用資料集（含 ro 標記）；編輯/存檔路徑仍只用主檔內容
  calRefreshAll();
  renderCalTagBar();
  calRenderHolidayLegend(); // 動態圖例：列出 calendar.md 中出現過的地區，輔助「目視差別」
  if (isMonth) renderCalMonth(content);
  else if (isYear) renderCalYear(content);
  else if (isGrid) {
    renderCalTimeGrid(isDay ? [state.calCursor] : calWeekDays(state.calCursor), false);
    if (elements.evMonthTitle) elements.evMonthTitle.textContent = calCursorTitle();
  } else renderEventsList(content);
  // 📱 啟動首次進入 events 視圖的自動滾「今天」：用 waitPane 等容器有高度再滾（桌面版 tlTriggerStartupToday 同一套路徑）
  //    單純 requestAnimationFrame × 2 不夠——restoreDraft 時 DOM 剛重建，panel.offsetHeight 可能還是 0
  if (scrollToToday) calQueueScrollActiveViewToToday();
  else calRestoreScrollPositions(scrollPositions);
}

// 保存并关闭事件表单后，先切换到事件日期，再把该事件精确滚到可视区中央。
function calScrollToEventByUid(uid) {
  if (!uid) return;
  const ev = parseCalendarEvents(elements.editor.value).find((item) => item.uid === uid);
  if (!ev || !ev.date) return;
  const date = ev.date;
  state.calCursor = new Date(date + 'T00:00:00');
  state.calSelectedDate = date;
  renderEventsContent();
  requestAnimationFrame(() => {
    const row = document.querySelector('[data-uid="' + uid + '"]');
    if (row && row.offsetParent) row.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
  });
}

// 滾到今天的延遲版本：等真正的滾動容器 + 目標元素都就位才執行（最多 120 帧 ≈ 2s）
function calQueueScrollActiveViewToToday() {
  let tries = 0;
  const wait = () => {
    const mode = state.calMode;
    let pane = null;
    let target = null;
    const today = calendarFmtDate(new Date());
    if (mode === 'list') {
      pane = elements.eventsList;
      // 今天無行程時也要能滾：只要有任何「有行程的日期」就放行，由 calScrollActiveViewToToday
      // → scrollToNearestDate 選「離今天最近」的那一天（過去或未來皆可），不再因 target 為 null 而整個略過
      target = pane && pane.querySelector('.ev-date[data-ev-date]');
    } else if (mode === 'month') {
      pane = document.querySelector('#ev-month-wrap .ev-month-scroll');
      target = elements.evMonthGrid && elements.evMonthGrid.querySelector('.ev-cell.today');
    } else if (mode === 'year') {
      pane = document.querySelector('#ev-year-wrap .ev-month-scroll');
      target = elements.evYearGrid && elements.evYearGrid.querySelector('.ev-year-month.cur-month');
    } else if (mode === 'week' || mode === 'day') {
      pane = document.querySelector('#ev-week-wrap .ev-timegrid-scroll');
      // 網格模式的目標是今天的時間列或時間網格本身（scrollTop 按當前時間算）——容器有高度即可
    }
    // 容器有高度 + 目標元素存在（網格模式只檢查容器）→ 可以滾了
    if (pane && pane.offsetHeight && (mode === 'week' || mode === 'day' || target)) {
      // 再給一帧讓瀏覽器先做一次 layout flush
      requestAnimationFrame(calScrollActiveViewToToday);
      return;
    }
    if (tries++ < 120) requestAnimationFrame(wait);
    else console.warn('[LITE] calQueueScrollActiveViewToToday 超時：mode=' + mode + ' pane=' + !!pane + ' h=' + (pane && pane.offsetHeight) + ' target=' + !!target);
  };
  requestAnimationFrame(wait);
}

function setCalMode(mode) {
  state.calMode = (mode === 'month') ? 'month' : (mode === 'week') ? 'week' : (mode === 'day') ? 'day' : (mode === 'year') ? 'year' : 'list';
  const today = new Date();
  const todayStr = calendarFmtDate(today);
  state.calCursor = today;
  state.calSelectedDate = todayStr;
  state.calListSel = todayStr;
  calAutoScrollToTodayPending = true;
  // 第十一批：年視圖下方明細默認「整年」（full）；月/週/日恢復「默認以日顯示」（day）
  state.calScope = (state.calMode === 'year') ? 'full' : 'day';
  renderEventsContent();
}

// 同步工具欄按鈕態 + 列表 / 月曆 / 時間網格容器可見性
function syncEventsModeUI() {
  const mode = state.calMode;
  const month = mode === 'month';
  const isDay = mode === 'day';
  const isWeek = mode === 'week';
  const isYear = mode === 'year';
  const isGrid = isWeek || isDay;
  if (elements.evModeList) elements.evModeList.classList.toggle('active', mode === 'list');
  if (elements.evModeDay) elements.evModeDay.classList.toggle('active', isDay);
  if (elements.evModeWeek) elements.evModeWeek.classList.toggle('active', isWeek);
  if (elements.evModeMonth) elements.evModeMonth.classList.toggle('active', month);
  if (elements.evModeYear) elements.evModeYear.classList.toggle('active', isYear);
  // 導航列：各模式都显示；列表模式标题留空（作为弹性占位，把「今天」推到右侧），‹ › 仍显示
  const isList = mode === 'list';
  if (elements.evMonthNav) elements.evMonthNav.style.display = (month || isGrid || isList || isYear) ? '' : 'none';
  if (elements.evMonthTitle && isList) elements.evMonthTitle.textContent = '';
  if (elements.evMonthWrap) elements.evMonthWrap.style.display = month ? '' : 'none';
  if (elements.evWeekWrap) elements.evWeekWrap.style.display = isGrid ? 'flex' : 'none';
  if (elements.evYearWrap) elements.evYearWrap.style.display = isYear ? '' : 'none';
  if (elements.eventsList) elements.eventsList.style.display = mode === 'list' ? '' : 'none';
  // 「跨天一筆 / 跨天多筆」切換：只在列表模式出現（月/週/日不顯示，也不受其影響）
  if (elements.evMultiDayBtn) elements.evMultiDayBtn.style.display = isList ? '' : 'none';
  if (isList) calUpdateMultiDayBtn();
}

// 月曆：6x7 網格（週一開頭），單元格顯示日號 + 最多 2 條 chip + 溢出數；下方渲染選中日的行程列表
// 月視圖：把今天日期格置於專屬滾動區中央，不觸碰頁面外層滾動
function calScrollMonthToToday() {
  const scroller = document.querySelector('#ev-month-wrap .ev-month-scroll');
  const todayCell = elements.evMonthGrid && elements.evMonthGrid.querySelector('.ev-cell.today');
  if (!todayCell || !scroller) return;
  const top = calElAbsTop(todayCell, scroller);
  scroller.scrollTop = Math.max(0, top - (scroller.clientHeight - todayCell.offsetHeight) / 2);
}

// 進入程式時（首次渲染 events 視圖）及切換行程分頁時，自動定位到今天
let calStartupAutoScrollDone = false;
let calAutoScrollToTodayPending = false;

// 年視圖：把今天所在月份卡片置於專屬滾動區中央，不觸碰頁面外層滾動
function calScrollYearToCurrentMonth() {
  const scroller = document.querySelector('#ev-year-wrap .ev-month-scroll');
  const cur = elements.evYearGrid && elements.evYearGrid.querySelector('.ev-year-month.cur-month');
  if (!cur || !scroller) return;
  const top = calElAbsTop(cur, scroller);
  scroller.scrollTop = Math.max(0, top - (scroller.clientHeight - cur.offsetHeight) / 2);
}

function renderCalMonth(content) {
  // 📎 多檔聯運：主檔 + 所有 include 併成顯示用資料集（含 ro 標記）；編輯/存檔路徑仍只用主檔內容
  calRefreshAll();
  const cur = state.calCursor;
  const y = cur.getFullYear(), m = cur.getMonth();
  // 重複展開視窗：當月 + 前 7 天（含跨月首尾週），避免 never 無限展開
  calSetRepeatWindow(calendarFmtDate(new Date(y, m, 1 - 7)), calendarFmtDate(new Date(y, m + 1, 0)));
  if (elements.evMonthTitle) elements.evMonthTitle.textContent = y + '年' + (m + 1) + '月';
  const occByDate = {};
  // 🏷 套用標籤過濾後才展開成逐日出現（跨天行程整條過濾，不做逐日拆分）
  state.calEvents.filter(calEventShown).forEach(ev => { calEventOccurrences(ev).forEach(o => { (occByDate[o.date] = occByDate[o.date] || []).push(o); }); });
  if (!state.calSelectedDate) state.calSelectedDate = calendarFmtDate(new Date());
  const todayStr = calendarFmtDate(new Date());
  const first = new Date(y, m, 1);
  const offset = (first.getDay() + 6) % 7; // 週一開頭
  const start = new Date(y, m, 1 - offset);
  const HEADS = ['一', '二', '三', '四', '五', '六', '日'];
  let html = HEADS.map(h => '<div class="ev-mc-head">' + h + '</div>').join('');
  for (let i = 0; i < 42; i++) {
    const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
    const ds = calendarFmtDate(d);
    const out = d.getMonth() !== m;
    const occ = (occByDate[ds] || []).slice().sort(calOccSort);
    const hols = calHolidaysOnDay(ds);
    let chips = '';
    // ## HOLIDAY：月格 chip（与 EVENT 视觉区隔：type 色块＋图标徽章）
    for (let k = 0; k < Math.min(2, hols.length); k++) {
      const region = calHolidayRegionMeta(hols[k].region);
      chips += '<span class="ev-holiday-chip" style="--holiday-color:' + escapeHtml(region.color) + '" title="' + escapeHtml(hols[k].title) + '">' + region.icon + escapeHtml(region.label) + calRoIcon(hols[k]) + '</span>';
    }
    if (hols.length > 2) chips += '<div class="ev-more">+' + (hols.length - 2) + '</div>';
    // 事件 chip（假日占用空间时收紧上限，避免月格溢出）
    const evCap = hols.length ? 1 : 2;
    for (let j = 0; j < Math.min(evCap, occ.length); j++) {
      chips += calSpanChipHtml(occ[j].ev, occ[j].pos, occ[j].idx, occ[j].total, occ[j].date);
    }
    if (occ.length > evCap) chips += '<div class="ev-more">+' + (occ.length - evCap) + '</div>';
    const cp = calLunarCompact(ds);
    const lunarCls = 'ev-lunar' + (cp.jieqi ? ' jieqi' : '');
    // 📕 當天有日記 → 日期數字旁掛一枚小圖標（與日期標題上的「日記按鈕」同圖標，日期一眼可辨）
    const diaryMark = calDiaryMarkHtml(ds);
    html += '<div class="ev-cell' + (out ? ' out' : '') + (ds === todayStr ? ' today' : '') + (ds === state.calSelectedDate ? ' selected' : '') + '" data-date="' + ds + '">' +
      '<span class="ev-daynum">' + d.getDate() + '</span>' + diaryMark +
      (cp.text ? '<span class="' + lunarCls + '" data-ev-almanac="' + escapeHtml(ds) + '" title="農民曆 / 老黃曆">' + escapeHtml(cp.text) + '</span>' : '') +
      chips + '</div>';
  }
  if (elements.evMonthGrid) elements.evMonthGrid.innerHTML = html;
  calBindSplit(elements.evMonthWrap, document.getElementById('ev-month-split'));
  renderCalDayList();
}

// 月視圖下方：選中日期的行程列表（含編輯/刪除 + 該日新增入口）
function renderCalDayList() {
  const list = elements.evDayList;
  if (!list) return;
  const today = calendarFmtDate(new Date());
  // 重複展開視窗：整月＝當月 + 前 7 天；單日＝選定日當天
  if (state.calScope === 'full') {
    const mo = state.calCursor.getMonth(), my = state.calCursor.getFullYear();
    calSetRepeatWindow(calendarFmtDate(new Date(my, mo, 1 - 7)), calendarFmtDate(new Date(my, mo + 1, 0)));
  } else {
    calSetRepeatWindow(state.calSelectedDate || today, state.calSelectedDate || today);
  }
  const toggle = calScopeToggleHtml();
  // 「月」範圍：渲染游標月整月（按日期分組，只含該月開始的事件/假日），頭部顯示彙總 + 切換
  if (state.calScope === 'full') {
    const mo = state.calCursor.getMonth();
    const prefix = state.calCursor.getFullYear() + '-' + String(mo + 1).padStart(2, '0');
    // 跨天行程/假日逐日展開（與「日」範圍同口徑），只收游標月內的日期
    const byDate = calEventsByDate(state.calEvents.filter(calEventShown), (ds) => typeof ds === 'string' && ds.slice(0, 7) === prefix);
    const dates = Array.from(byDate.keys()).sort();
    let total = 0;
    byDate.forEach((g) => { total += g.events.length + g.holidays.length; });
    // toggle 內聯進每個日期標題條，隨 sticky 讓「第一筆可見日期」始終帶切換控件；
    // 整月無內容時才退回獨立彙總條放 toggle，保證切換仍可達
    let html = '';
    if (!dates.length) html += '<div class="ev-date active">' + (mo + 1) + '月 <span class="ev-week">全部 ' + total + ' 條</span>' +
      '<span class="ev-toolbar-flex"></span>' + toggle + '</div><div class="ev-empty">本月沒有行程</div>';
    else {
      for (let i = 0; i < dates.length; i++) {
        const grp = byDate.get(dates[i]);
        let g = calDateHeaderHtml(dates[i], today, toggle, grp.events.length + grp.holidays.length);
        for (const h of grp.holidays) g += calHolidayHtml(h, today, dates[i]);
        for (const ev of sortedCalEvents(grp.events)) g += evItemHtml(ev, today, dates[i]);
        html += (dates[i] === state.calSelectedDate) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
      }
    }
    list.innerHTML = html;
    list.classList.add('scope-follow');
    calBindActiveDateScroll(list);
    calUpdateActiveDate(list);
    return;
  }
  // 「日」範圍（默認）：選定日單日
  const ds = state.calSelectedDate || calendarFmtDate(new Date());
  // 與「列表/整月」共用同一分組入口（逐日展開）→ 保證「日」與「整月」同一天條數一致
  const dayItems = calDayItems(ds);
  const evs = sortedCalEvents(dayItems.events);
  const hols = dayItems.holidays;
  // 與「月」範圍/列表模式共用 calDateHeaderHtml（含倒計時/農曆/日記按鈕），避免兩範圍頭部不一致
  let html = calDateHeaderHtml(ds, today, toggle, evs.length + hols.length);
  if (!evs.length && !hols.length) {
    html += '<div class="ev-empty">這一天沒有行程</div>';
  } else {
    for (const h of hols) html += calHolidayHtml(h, today, ds);
    for (const ev of evs) html += evItemHtml(ev, today, ds);
  }
  list.classList.remove('scope-follow');
  list.innerHTML = html;
}

// 條目操作（事件委派）：編輯 / 刪除 / 月視圖「此日新增」
// 🗒 清單行的便利貼徽標（data-ev-sticky）→ 開便利貼並跳到該行程的第一張
function calOpenStickyForEvent(uid) {
  if (typeof calStickyOpen !== 'function') return;
  const ev = calLoadEventsForNotes().find((x) => x.uid === uid) || null;
  if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); return; }
  if (!((parseInt(ev.sticky, 10) || 0) > 0)) { showToast('此行程沒有設定便利貼', 'error'); return; }
  calStickyOpen(ev);
}
function onEvListClick(e) {
  // 📅 點列表標題的農曆文字 → 開老黃曆詳情
  const alm = e.target.closest('[data-ev-almanac]');
  if (alm) { calShowAlmanac(alm.getAttribute('data-ev-almanac'), alm); return; }
  // 完成勾選框：切換 done → 寫回編輯緩衝（按頂欄「保存」才落盤）
  const doneChk = e.target.closest('[data-ev-done]');
  if (doneChk) { toggleEventDone(doneChk.getAttribute('data-ev-done'), doneChk.checked); return; }
  // ＋☐ 加入子事件：必須排在 data-ev-edit 之前，否則整列點選會先開編輯選單
  const acBtn = e.target.closest('[data-ev-addcheck]');
  if (acBtn) { e.preventDefault(); e.stopPropagation(); calOpenAddCheckDialog(acBtn.getAttribute('data-ev-addcheck')); return; }
  // 🗒 便利貼徽標：開便利貼並跳到該行程（同樣必須排在 data-ev-edit 之前）
  const stBtn = e.target.closest('[data-ev-sticky]');
  if (stBtn) { e.preventDefault(); e.stopPropagation(); calOpenStickyForEvent(stBtn.getAttribute('data-ev-sticky')); return; }
  // ☐ 每事件「只顯示未完成 checkbox」開關：必須排在 data-ev-edit 之前，否則整列點選會先開編輯選單
  const ufBtn = e.target.closest('[data-ev-undone-filter]');
  if (ufBtn) { e.preventDefault(); e.stopPropagation(); calToggleEventUndoneChecks(ufBtn.getAttribute('data-ev-undone-filter'), ufBtn); return; }
  const editBtn = e.target.closest('[data-ev-edit]');
  if (editBtn) {
    const uid = editBtn.getAttribute('data-ev-edit');
    // 🆕 多檔聯運：ro 事件不再拒絕，openEventForm 會開成「檢視行程（唯讀）」窗體（2026-11-04）
    // 触屏：点事件改弹小选单（编辑 / 详情），不再直接开表单；桌面保持点开表单
    if (calCanHover.matches) openEventForm(uid);
    else calShowEventMenu(editBtn, uid);
    return;
  }
  const delBtn = e.target.closest('[data-ev-del]');
  if (delBtn) {
    const uid = delBtn.getAttribute('data-ev-del');
    // 📎 多檔聯運：只讀（ro）事件不可刪除
    const ev = (state.calEvents || []).find((x) => x.uid === uid);
    if (ev && ev.ro) { showToast('此行程來自被包含的只讀檔案，不可刪除', 'error'); return; }
    deleteEventByUid(uid); return;
  }
  // 明細範圍切換（日 <-> 月/週）
  const scopeBtn = e.target.closest('[data-cal-scope]');
  if (scopeBtn) { calSetCalScope(scopeBtn.getAttribute('data-cal-scope')); return; }
  const addBtn = e.target.closest('[data-ev-add-on]');
  if (addBtn) { openEventForm(null, addBtn.getAttribute('data-ev-add-on')); return; }
  // 📓 日記按鈕：開日記編輯視窗（有日記則載入編輯，無則新增）
  const diaryBtn = e.target.closest('[data-ev-diary]');
  if (diaryBtn) { openDiaryForm(diaryBtn.getAttribute('data-ev-diary')); return; }
  // 📓「只顯示日記」清單條目的刪除按鈕（屬性名與 data-ev-diary 不同，不會被上面那行誤命中）
  const diaryDel = e.target.closest('[data-ev-diary-del]');
  if (diaryDel) { calDeleteDiaryByDate(diaryDel.getAttribute('data-ev-diary-del')); return; }
}

// 🖱 雙擊條目＝進入編輯狀態（條目本身無單擊開啟，故用 dblclick 快捷編輯；與桌面版一致）
// 目前只有「只顯示日記」清單條目帶 data-ev-diary-row；行程條目的單擊已直接開表單，不重複處理。
function onEvListDblClick(e) {
  const row = e.target.closest('.ev-item[data-ev-diary-row]');
  if (!row) return;
  // 「編輯 / 刪除」按鈕不觸發雙擊編輯，避免與單擊衝突（尤其刪除按鈕二次確認）
  if (e.target.closest('.ev-actions')) return;
  openDiaryForm(row.getAttribute('data-ev-diary-row'));
}

// 打開表單：uid 為 null = 新增（預設日期 = 月視圖選中日或今天）；uid 有值 = 編輯該條
function openEventForm(uid, defaultDate, pre) {
  calHideTip();
  if (!isCalendarMd()) return;
  // 📎 多檔聯運：先用併集定位（才能識別 ro 事件）。
  //    🆕 ro 事件不再 toast 拒絕，而是開「檢視行程（唯讀）」窗體（與桌面同口徑，2026-11-04）。
  calRefreshAll();
  let roEv = null;
  if (uid) {
    const hit = state.calEvents.find(x => x.uid === uid);
    if (hit && hit.ro) roEv = hit;
  }
  state.calEvents = parseCalendarEvents(elements.editor.value);
  renderCalTagOptions();
  state.evFormUid = null;
  // ro 事件不在主檔解析結果裡，直接用上面的併集快照帶入表單
  let ev = roEv;
  if (uid && !ev) {
    ev = state.calEvents.find(x => x.uid === uid) || null;
    if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); return; }
  }
  if (uid) state.evFormUid = uid;
  const p = pre || {}; // 🖱 雙擊空白快速新增時的預填：{ allDay, startTime, endTime }
  const today = calendarFmtDate(new Date());
  // 標題／刪除鈕顯隱統一交給 calSetEventFormReadonly（新增／編輯／唯讀 三態一次判完）
  elements.evFTitle.value = ev ? ev.title : '';
  elements.evFDate.value = ev ? ev.date : (defaultDate || (state.calMode === 'month' ? state.calSelectedDate : today) || today);
  elements.evFEndDate.value = ev ? (ev.endDate || '') : '';
  elements.evFSpanDisplay.value = ev && (ev.spanDisplay === 'first' || ev.spanDisplay === 'last' || ev.spanDisplay === 'today') ? ev.spanDisplay : 'daily';
  // ===== 重複事件 =====
  // p.repeat：由「重複事件一覽」的新增按鈕傳入 → 新增時直接進「重複」模式並帶出起始日的星期
  const rMode = ev ? (ev.repeatMode || '') : (p.repeat ? 'weekly' : '');
  elements.evFRepeatOn.checked = !!rMode;
  elements.evFRepeatFields.style.display = rMode ? '' : 'none';
  elements.evFRepeatMode.value = rMode || 'weekly';
  elements.evFRepeatInterval.value = ev && ev.repeatInterval ? (parseInt(ev.repeatInterval, 10) || 1) : 1;
  calRenderRepeatWeekDays(ev ? (ev.repeatWeekDay || []) : []);
  elements.evFMonthDay.value = ev && ev.repeatMonthDay ? (parseInt(ev.repeatMonthDay, 10) || '') : '';
  elements.evFYearMonthDay.value = ev && ev.repeatYearMonthDay ? String(ev.repeatYearMonthDay).replace(/^"|"$/g, '') : '';
  const rEnd = ev ? (ev.repeatEndType || 'never') : 'never';
  elements.evFRepeatEndType.value = rEnd;
  elements.evFRepeatEndValue.value = ev && ev.repeatEndValue != null ? String(ev.repeatEndValue) : '';
  elements.evFRepeatExclude.value = (ev && ev.repeatExcludeDates && ev.repeatExcludeDates.length) ? ev.repeatExcludeDates.join(', ') : '';
  calOnRepeatModeChange();
  calOnRepeatEndTypeChange();
  if (!uid && p.repeat) calToggleRepeat(); // 走既有入口：展開重複欄位 + 自動勾上起始日所屬星期
  calUpdateFormDow(); // 🗓 依輸入日期即時顯示星期
  elements.evFAllday.checked = ev ? ev.allDay : (p.allDay === true);
  // 完成狀態：新增預設未完成（舊檔案沒有 - done 欄位時解析也是未完成）
  elements.evFDone.checked = ev ? !!ev.done : false;
  elements.evFStart.value = ev ? ev.startTime : (p.startTime || '');
  elements.evFEnd.value = ev ? ev.endTime : (p.endTime || '');
  elements.evFStart.disabled = elements.evFAllday.checked;
  elements.evFEnd.disabled = elements.evFAllday.checked;
  elements.evFLocation.value = ev ? ev.location : '';
  // 🗒 便利貼張數（0＝不顯示）：與桌面共用同一 `- sticky` 欄位
  if (elements.evFSticky) elements.evFSticky.value = String(ev ? (Math.max(0, parseInt(ev.sticky, 10) || 0)) : 0);
  state.evFormColor = ev ? ev.color : CAL_COLORS[0];
  state.evFormTags = calNormalizeTags(ev && ev.tags ? ev.tags : []);
  elements.evFTags.value = '';
  calRenderTagPicker();
  // 🔗 關聯 Todo 卡片：帶入該行程原本的 todoIds（slice 複製，避免改到工作副本）
  state.evFormTodoIds = ev ? (ev.todoIds || []).slice() : [];
  calRenderEvTodoLinkPanel();
  if (elements.evFTodoInput) elements.evFTodoInput.value = '';
  elements.evFNotes.value = ev ? ev.notes : '';
  renderEvColorSwatches();
  // ⚠️ 唯讀態最後才套：上面 calOnRepeatModeChange / 全天 disabled / renderEvColorSwatches 會重設或重建控件。
  calSetEventFormReadonly(!!roEv, roEv ? (roEv.src || '') : '');
  elements.evFormOverlay.style.display = 'flex';
  if (!roEv) elements.evFTitle.focus();
  // 採集表單原始值快照——closeEventForm 前比對是否有改動
  calFormBaseline = calSnapshotEventForm();
  console.log('[openEventForm] baseline采了 len=' + calFormBaseline.length + ' dirtyNow=' + calIsEventFormDirty());
}

// 🆕 行程窗體「唯讀模式」單一可信來源（與桌面 tlSetEventFormReadonly 同口徑，2026-11-04）：
//    被 include 的外部檔行程（ev.ro）可開窗檢視，但所有寫入口關掉。
//    · input / select / button → disabled；textarea → readOnly（仍可選取複製、卷動）
//    · 顏色 / 標籤 / Todo 等非表單控件 → overlay 的 .is-readonly CSS 關 pointer-events
//    · 「關閉」鈕永不 disabled；寫入 / 刪除直接隱藏
function calSetEventFormReadonly(ro, src) {
  const ov = elements.evFormOverlay;
  if (!ov) return;
  const on = !!ro;
  state.evFormReadonly = on;
  ov.classList.toggle('is-readonly', on);
  ov.querySelectorAll('input, select, textarea, button').forEach((el) => {
    if (el.id === 'ev-form-cancel') { el.disabled = false; return; }
    if (el.tagName === 'TEXTAREA') { el.readOnly = on; el.disabled = false; }
    else el.disabled = on;
  });
  const title = elements.evFormTitle;
  if (title) title.textContent = on ? '檢視行程（唯讀）' : (state.evFormUid ? '編輯行程' : '新增行程');
  const banner = document.getElementById('ev-form-ro-banner');
  if (banner) {
    banner.style.display = on ? '' : 'none';
    banner.textContent = on
      ? ('🔒 唯讀 · 來自被包含的外部檔 ' + (src || 'calendar-*.md') + '（僅供檢視；如需修改請開啟該檔案）')
      : '';
  }
  const hint = document.getElementById('ev-form-hint');
  if (hint) hint.textContent = on
    ? '此窗體不寫回任何檔案；便利貼內容仍可直接在便利貼修改並寫回來源檔。'
    : '寫入後按頂欄「保存」，在分享面板選「儲存到檔案」→ 覆蓋原檔';
  if (elements.evFormDelete) elements.evFormDelete.style.display = on ? 'none' : (state.evFormUid ? '' : 'none');
  if (elements.evFormSave) elements.evFormSave.style.display = on ? 'none' : '';
  if (elements.evFormCancel) elements.evFormCancel.textContent = on ? '關閉' : '取消';
  // 恢復可編輯時重算「全天」對開始/結束時間的連帶 disabled
  if (!on) {
    elements.evFStart.disabled = elements.evFAllday.checked;
    elements.evFEnd.disabled = elements.evFAllday.checked;
  }
}

function renderEvColorSwatches() {
  if (!elements.evFColors) return;
  elements.evFColors.innerHTML = CAL_COLORS.map(c =>
    '<span class="sw' + (c === state.evFormColor ? ' selected' : '') + '" data-color="' + c + '" style="background:' + c + '"></span>'
  ).join('');
  // 色板選擇（一次性委派，openEventForm 每次重建）
  elements.evFColors.onclick = (e) => {
    if (state.evFormReadonly) return;
    const sw = e.target.closest('.sw[data-color]');
    if (!sw) return;
    state.evFormColor = sw.getAttribute('data-color');
    elements.evFColors.querySelectorAll('.sw').forEach(x => x.classList.toggle('selected', x.getAttribute('data-color') === state.evFormColor));
  };
}

// 行程表單 dirty 守門：openEventForm 時存一份原始快照，closeEventForm 前比對是否有改動。
// 只有「內容真的變了」才彈 confirm；使用者在表單裡點了幾下又改回原樣 → 不問。
let calFormBaseline = null;
function calSnapshotEventForm() {
  const f = elements;
  // repeatWeekDay 是 checkbox 陣列，分開存
  const rwd = Array.from(document.querySelectorAll('#ev-f-weekdays input[type=checkbox]'))
    .map(cb => cb.checked ? cb.value : '');
  return JSON.stringify({
    title: f.evFTitle.value,
    date: f.evFDate.value,
    endDate: f.evFEndDate.value,
    spanDisplay: f.evFSpanDisplay.value,
    repeatOn: f.evFRepeatOn.checked,
    repeatMode: f.evFRepeatMode.value,
    repeatInterval: f.evFRepeatInterval.value,
    repeatWeekDay: rwd.join(','),
    repeatMonthDay: f.evFMonthDay.value,
    repeatYearMonthDay: f.evFYearMonthDay.value,
    repeatEndType: f.evFRepeatEndType.value,
    repeatEndValue: f.evFRepeatEndValue.value,
    repeatExclude: f.evFRepeatExclude.value,
    allDay: f.evFAllday.checked,
    done: f.evFDone.checked,
    start: f.evFStart.value,
    end: f.evFEnd.value,
    location: f.evFLocation.value,
    sticky: f.evFSticky ? f.evFSticky.value : '0',
    color: state.evFormColor,
    tags: (state.evFormTags || []).join(','),
    // todoIds 是 chips 陣列，存 id
    todoIds: (state.evFormTodoIds || []).join(','),
    notes: f.evFNotes.value
  });
}
function calIsEventFormDirty() {
  if (calFormBaseline === null) return false;
  return calSnapshotEventForm() !== calFormBaseline;
}
function closeEventForm(skipDirtyGuard) {
  // 行程表單有未保存改動 → 先確認（與便利貼編輯模式同口徑）
  console.log('[closeEventForm] called skip=' + skipDirtyGuard + ' baseline=' + (calFormBaseline ? calFormBaseline.slice(0,40) : 'null') + ' dirty=' + calIsEventFormDirty());
  // 🆕 唯讀窗體不做 dirty 守門：控件全 disabled，不可能有改動；也避免誤彈「先保存」把資料寫回主檔。
  if (!skipDirtyGuard && !state.evFormReadonly && calIsEventFormDirty()) {
    const ok = window.confirm('🚨 行程內容有未保存的改動\n\n【確定】＝先保存（寫入編輯緩衝）再關閉\n【取消】＝留在表單（不丟失改動）');
    if (ok) {
      // 保存失敗（標題空、區塊位置變了等）→ 留在表單
      if (!saveEventForm(false)) return;
    } else return;
  }
  const closingUid = state.evFormUid;
  const scrollAfterSave = state.evFormScrollOnCloseUid === closingUid;
  calFormBaseline = null;
  if (elements.evFormOverlay) elements.evFormOverlay.style.display = 'none';
  state.evFormUid = null;
  state.evFormScrollOnCloseUid = null;
  state.evFormColor = null;
  state.evFormTodoIds = [];
  // 🆕 復位唯讀態：下一張窗體可能是主檔可編輯行程，不能帶著 disabled / 隱藏按鈕進去。
  calSetEventFormReadonly(false, '');
  if (scrollAfterSave) calScrollToEventByUid(closingUid);
}

// ===== ## EVENT(REPEAT) 表單控件 =====
const CAL_REPEAT_INTERVAL_UNIT = { daily: '天', weekly: '週', monthly: '月', yearly: '年' };
function calToggleRepeat() {
  const on = elements.evFRepeatOn.checked;
  elements.evFRepeatFields.style.display = on ? '' : 'none';
  if (on) {
    if (!elements.evFRepeatMode.value) elements.evFRepeatMode.value = 'weekly';
    if (!elements.evFRepeatInterval.value) elements.evFRepeatInterval.value = '1';
    const d = elements.evFDate.value;
    if (d && !calGetRepeatWeekDays().length) {
      const wd = CAL_WD[new Date(d + 'T00:00:00').getDay()];
      calSetWeekDay(wd, true);
    }
    calOnRepeatModeChange();
    calOnRepeatEndTypeChange();
  }
}
function calRenderRepeatWeekDays(selected) {
  selected = selected || [];
  const labels = { sun: '日', mon: '一', tue: '二', wed: '三', thu: '四', fri: '五', sat: '六' };
  const box = elements.evFWeekDays;
  if (!box) return;
  box.innerHTML = CAL_WD.map((w) =>
    '<label class="ev-f-wd"><input type="checkbox" data-wd="' + w + '"' + (selected.indexOf(w) >= 0 ? ' checked' : '') + ' onchange="calOnWeekDayChange()">' + labels[w] + '</label>'
  ).join('');
}
function calSetWeekDay(w, checked) {
  const el = elements.evFWeekDays ? elements.evFWeekDays.querySelector('input[data-wd="' + w + '"]') : null;
  if (el) el.checked = checked;
}
function calOnWeekDayChange() { /* 委派占位，取值走 calGetRepeatWeekDays */ }
function calGetRepeatWeekDays() {
  const els = elements.evFWeekDays ? elements.evFWeekDays.querySelectorAll('input[data-wd]:checked') : [];
  return Array.prototype.map.call(els, (e) => e.getAttribute('data-wd'));
}
function calOnRepeatModeChange() {
  const mode = elements.evFRepeatMode.value;
  elements.evFWeekDayBox.style.display = mode === 'weekly' ? '' : 'none';
  elements.evFMonthDayBox.style.display = mode === 'monthly' ? '' : 'none';
  elements.evFYearMonthDayBox.style.display = mode === 'yearly' ? '' : 'none';
  if (elements.evFRepeatIntervalUnit) elements.evFRepeatIntervalUnit.textContent = CAL_REPEAT_INTERVAL_UNIT[mode] ? '（每 ' + CAL_REPEAT_INTERVAL_UNIT[mode] + '）' : '';
}
function calOnRepeatEndTypeChange() {
  const t = elements.evFRepeatEndType.value;
  elements.evFEndValueBox.style.display = t === 'never' ? 'none' : '';
  const unit = elements.evFEndValueUnit;
  const inp = elements.evFRepeatEndValue;
  if (t === 'count') { unit.textContent = '（次）'; inp.type = 'number'; inp.placeholder = '如 20'; }
  else if (t === 'date') { unit.textContent = ''; inp.type = 'date'; inp.placeholder = ''; }
  else { unit.textContent = ''; inp.type = 'text'; inp.value = ''; }
}
// 規範化「每年月-日」：去掉可能存在的外層引號後統一加上，保證寫回文件格式與用戶一致（"MM-DD"）
function calNormalizeYmd(v) {
  v = (v || '').trim();
  if (!v) return '';
  if (v.length >= 2 && v[0] === '"' && v[v.length - 1] === '"') v = v.slice(1, -1);
  return '"' + v + '"';
}

// 表單「寫入編輯內容」：校驗 → upsert 工作副本 → 重新序列化整份 calendar.md → 寫回編輯器緩衝（isDirty = true）
// ⚠️ 不直接落盤：iOS 無法直接寫原文件，走現有「保存」流程（分享面板 → 儲存到檔案 → 覆蓋）
function saveEventForm(closeAfterSave = true) {
  // 🆕 唯讀窗體硬守衛：按鈕雖已隱藏，仍擋住 onclick 直呼 / 快捷鍵旁路，絕不寫回任何檔案。
  if (state.evFormReadonly) return false;
  const title = elements.evFTitle.value.trim();
  let date = elements.evFDate.value;
  let endDate = elements.evFEndDate.value;
  if (!title) { alert('請輸入標題'); elements.evFTitle.focus(); return; }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) { alert('請選擇日期'); elements.evFDate.focus(); return; }
  // 跨天：結束日早於起始日則互換；等於起始日視為單日（清空 endDate）
  if (endDate && endDate < date) { const tmp = date; date = endDate; endDate = tmp; }
  if (endDate === date) endDate = '';
  const allDay = elements.evFAllday.checked;
  const ev = {
    uid: state.evFormUid || genCalId(),
    title,
    date,
    endDate: endDate || '',
    spanDisplay: elements.evFSpanDisplay.value,
    allDay,
    done: elements.evFDone.checked,
    startTime: allDay ? '' : elements.evFStart.value,
    endTime: allDay ? '' : elements.evFEnd.value,
    location: elements.evFLocation.value.trim(),
    // 🗒 便利貼張數：不設上限，避免把檔案中既有的 >9 張在存檔時靜默截斷（表單 UI 仍以 9 為輸入上限）
    sticky: elements.evFSticky ? Math.max(0, parseInt(elements.evFSticky.value, 10) || 0) : 0,
    color: state.evFormColor || CAL_COLORS[0],
    tags: state.evFormTags.slice(),
    // 🔗 修復：此前漏寫 todoIds → 每次編輯存檔都會把桌面端建立的關聯卡片清空
    todoIds: state.evFormTodoIds.slice(),
    notes: elements.evFNotes.value.replace(/\r\n/g, '\n')
  };
  // ===== 重複事件：依表單寫回欄位（未勾選則清空，序列化降回 ## EVENT）=====
  if (elements.evFRepeatOn.checked) {
    const rMode = elements.evFRepeatMode.value;
    const interval = Math.max(1, parseInt(elements.evFRepeatInterval.value, 10) || 1);
    ev.repeatMode = rMode;
    ev.repeatInterval = String(interval);
    if (rMode === 'weekly') {
      ev.repeatWeekDay = calGetRepeatWeekDays();
      ev.repeatMonthDay = '';
      ev.repeatYearMonthDay = '';
    } else if (rMode === 'monthly') {
      ev.repeatWeekDay = [];
      const md = parseInt(elements.evFMonthDay.value, 10);
      ev.repeatMonthDay = (md >= 1 && md <= 31) ? String(md) : '';
      ev.repeatYearMonthDay = '';
    } else if (rMode === 'yearly') {
      ev.repeatWeekDay = [];
      ev.repeatMonthDay = '';
      ev.repeatYearMonthDay = calNormalizeYmd(elements.evFYearMonthDay.value);
    } else {
      ev.repeatWeekDay = [];
      ev.repeatMonthDay = '';
      ev.repeatYearMonthDay = '';
    }
    const endType = elements.evFRepeatEndType.value;
    ev.repeatEndType = endType;
    ev.repeatEndValue = endType === 'never' ? '' : elements.evFRepeatEndValue.value.trim();
    const exRaw = elements.evFRepeatExclude.value;
    ev.repeatExcludeDates = exRaw.split(',').map((x) => x.trim()).filter((x) => /^\d{4}-\d{2}-\d{2}$/.test(x));
  } else {
    ev.repeatMode = '';
    ev.repeatInterval = '';
    ev.repeatWeekDay = [];
    ev.repeatMonthDay = '';
    ev.repeatYearMonthDay = '';
    ev.repeatEndType = 'never';
    ev.repeatEndValue = '';
    ev.repeatExcludeDates = [];
  }
  // 以當前編輯器內容為基準重新解析（保留用戶可能手改過的其它條目），再 upsert
  state.calEvents = parseCalendarEvents(elements.editor.value);
  const i = state.calEvents.findIndex(x => x.uid === ev.uid);
  if (i >= 0) state.calEvents[i] = ev;
  else state.calEvents.push(ev);
  applyEventsToEditor();
  // 新增事件的 uid 由解析器按位置生成；保存后重新解析，确保关闭时能精确找到新事件。
  const saved = parseCalendarEvents(elements.editor.value);
  const signature = (item) => [item.title, item.date, item.endDate, item.startTime, item.endTime, item.location].join('\u0001');
  const savedEvent = saved.find((item) => item.uid === ev.uid) || saved.find((item) => signature(item) === signature(ev));
  state.evFormUid = savedEvent ? savedEvent.uid : ev.uid;
  state.evFormScrollOnCloseUid = state.evFormUid;
  if (closeAfterSave) closeEventForm(true);   // 已保存 → 跳過 dirty guard
  showToast(closeAfterSave
    ? '已寫入編輯內容，按頂欄「保存」存回文件'
    : '已寫入編輯內容，可繼續編輯（按頂欄「保存」存回文件）', 'success');
}

// 刪除：confirm → 從工作副本移除 → 寫回編輯器緩衝
function deleteEventByUid(uid) {
  state.calEvents = parseCalendarEvents(elements.editor.value);
  const ev = state.calEvents.find(x => x.uid === uid);
  if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); return; }
  if (!window.confirm('確定刪除行程「' + ev.title + '」（' + ev.date + '）嗎？\n\n寫入後按「保存」才會真正存回文件。')) return;
  state.calEvents = state.calEvents.filter(x => x.uid !== uid);
  applyEventsToEditor();
  showToast('已刪除「' + ev.title + '」，按「保存」存回文件', 'success');
}

function deleteEventFromForm() {
  if (state.evFormReadonly) return;   // 🆕 唯讀窗體：刪除鈕已隱藏，這裡再擋一次旁路呼叫
  if (!state.evFormUid) return;
  const uid = state.evFormUid;
  closeEventForm(true);   // 刪除 → 跳過 dirty guard（反正要丟棄）
  deleteEventByUid(uid);
}

// ===== ## DIARY 新增/編輯/刪除（寫回編輯緩衝，按頂欄「保存」落盤）=====
let calDiaryFormDate = null;
function openDiaryForm(date) {
  if (!DIARY_FEATURE_ENABLED) return;
  calHideTip();
  if (!isCalendarMd()) return;
  calDiaries = parseCalendarDiaries(elements.editor.value);
  const d = calDiaryOnDate(date);
  calDiaryFormDate = date;
  elements.diaryFTitle.value = d ? d.title : '';
  elements.diaryFDate.textContent = date;
  elements.diaryFMood.value = d ? (d.mood || '') : '';
  elements.diaryFTags.value = d ? (d.tags || []).map(calTagName).join(', ') : '';
  elements.diaryFWeather.value = d ? (d.weather || '') : '';
  elements.diaryFContent.value = d ? (d.content || '') : '';
  elements.diaryFRemark.value = d ? (d.remark || '') : '';
  elements.diaryFormDelete.style.display = d ? '' : 'none';
  elements.diaryFormOverlay.style.display = 'flex';
  elements.diaryFContent.focus();
}
function closeDiaryForm() {
  if (elements.diaryFormOverlay) elements.diaryFormOverlay.style.display = 'none';
  calDiaryFormDate = null;
}
function saveDiaryForm() {
  const date = calDiaryFormDate;
  if (!date) return;
  const title = elements.diaryFTitle.value.trim();
  if (!title) { alert('請輸入日記標題'); elements.diaryFTitle.focus(); return; }
  const tags = elements.diaryFTags.value.split(/[,，]/).map(t => t.trim()).filter(Boolean).map((nm) => ({ name: nm, cat: '' }));
  const diary = {
    date,
    title,
    mood: elements.diaryFMood.value.trim(),
    tags,
    weather: elements.diaryFWeather.value.trim(),
    content: elements.diaryFContent.value.replace(/\r\n/g, '\n'),
    remark: elements.diaryFRemark.value.trim()
  };
  calDiaries = parseCalendarDiaries(elements.editor.value);
  const i = calDiaries.findIndex(x => x.date === date);
  if (i >= 0) calDiaries[i] = diary; else calDiaries.push(diary);
  applyDiariesToEditor();
  closeDiaryForm();
  showToast('已寫入日記，按「保存」存回文件', 'success');
}
// 刪除日記的「唯一收口」：確認 → 從緩衝重解析 → 剔除該日 → 序列化寫回（按頂欄「保存」才落盤）。
// 表單內刪除與列表條目刪除共用；返回是否真的刪了（日記表單據此決定要不要關窗）。
function calRemoveDiary(date) {
  const d = calDiaryOnDate(date);
  if (!d) return false;
  if (!window.confirm('確定刪除 ' + date + ' 的日記「' + d.title + '」嗎？\n\n按「保存」才會真正存回文件。')) return false;
  calDiaries = parseCalendarDiaries(elements.editor.value);
  calDiaries = calDiaries.filter(x => x.date !== date);
  applyDiariesToEditor();
  showToast('已刪除日記，按「保存」存回文件', 'success');
  return true;
}
function deleteDiary() {
  const date = calDiaryFormDate;
  if (!date) return;
  if (!calDiaryOnDate(date)) { closeDiaryForm(); return; }
  if (calRemoveDiary(date)) closeDiaryForm();
}
// 「只顯示日記」列表條目上的刪除按鈕（不經日記表單，直接按日期刪）
function calDeleteDiaryByDate(date) {
  if (!date || !calDiaryOnDate(date)) return;
  calRemoveDiary(date);
}
// 序列化整份 calendar.md（events + holidays + diaries）寫回編輯器緩衝：從當前緩衝重解析 events/holidays，
// 再以最新 calDiaries 覆蓋日記段，避免保存日記時把用戶手寫的事件/假日覆蓋掉。
function applyDiariesToEditor() {
  const events = parseCalendarEvents(elements.editor.value);
  const holidays = parseCalendarHolidays(elements.editor.value);
  state.calEvents = events;
  calHolidays = holidays;
  // 📎 同 applyEventsToEditor：保留 ## TAGS / ## INCLUDE，別讓日記存檔把元區塊清掉
  elements.editor.value = calPreserveMetaBlocks(elements.editor.value, calCalendarToMarkdown(events, holidays, calDiaries));
  state.isDirty = elements.editor.value !== state.lastContent;
  updateStatus();
  updateWordCount();
  updatePreview();
}

// 清單上的「完成」勾選框：切換 done → 寫回編輯緩衝（applyEventsToEditor 內會重繪行程視圖）
function toggleEventDone(uid, done) {
  state.calEvents = parseCalendarEvents(elements.editor.value);
  const ev = state.calEvents.find(x => x.uid === uid);
  if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); return; }
  ev.done = !!done;
  applyEventsToEditor();
  showToast(ev.done ? '已標記完成，按「保存」存回文件' : '已取消完成，按「保存」存回文件', 'success');
}

// 備註 checkbox 行勾選互換 + dl/cp 標記維護（純函數，不改入參；便於單測）：newDone=true 勾選、false 取消；todayStr 為 YYYY-MM-DD
function calNoteCheckTransform(line, newDone, todayStr) {
  const m = line.match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
  if (!m) return line;
  let body = m[3] || '';
  if (newDone) {
    body = body.replace(/\[\[(\d{4}-\d{2}-\d{2})\]\]/g, '[[dl:$1]]');
    // 勾選一律補 [[cp:今天]]（無論有無 dl；已有 cp 則不重複）
    if (!/\[\[cp:\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/.test(body)) {
      body = body.replace(/\s+$/, '') + ' [[cp:' + todayStr + ']]';
    }
  } else {
    body = body.replace(/\s*\[\[cp:\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/g, '');
  }
  return m[1] + '- [' + (newDone ? 'x' : ' ') + ']' + (body ? ' ' + body : '');
}
// 備註裡的 Markdown checkbox 勾選/取消：定位 ev.notes 的對應行，互換 - [ ] ↔ - [x]，
//   主檔→序列化回編輯緩衝；include 來源檔→只改該檔的那一個區塊。
//   ⚠️ 僅限便利貼介面：行程檢視裡 include 行程為唯讀（與桌面一致），在那裡點會被告知去便利貼改。
function calToggleNoteCheck(e, uid, line) {
  if (e) { e.stopPropagation(); e.preventDefault(); } // 阻止冒泡到 .ev-block 開啟編輯表單
  // 📎 多檔聯運：從併集（主檔＋include）定位——ro 事件也要能勾自己的便利貼子事件
  const ev = calLoadEventsForNotes().find((x) => x.uid === uid);
  if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); return; }
  if (calNotesRoLocked(ev, calNotesFromSticky(e))) return;
  const lines = String(ev.notes || '').split('\n');
  if (line < 0 || line >= lines.length) return;
  const m = lines[line].match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
  if (!m) return; // 該行已被用戶改得不再是 checkbox，跳過以免破壞原文
  const wasDone = m[2] !== ' ';
  const nextDone = !wasDone;
  lines[line] = calNoteCheckTransform(lines[line], nextDone, calendarFmtDateTime(new Date()));
  ev.notes = lines.join('\n');
  // 主檔→回編輯緩衝待「保存」；include→寫回來源檔那一塊（本機快取，需匯出）
  calCommitEventNotes(ev);
  showToast(calNotesHint(ev, nextDone ? '已勾選，按「保存」存回文件' : '已取消勾選，按「保存」存回文件'), 'success');
}
function calCalCheckKey(e, uid, line) {
  if (e && e.target && e.target.closest && e.target.closest('button')) return; // 圓點按鈕的 Space/Enter 不該順帶勾選
  if (e && (e.key === ' ' || e.key === 'Spacebar' || e.key === 'Enter')) {
    e.preventDefault();
    calToggleNoteCheck(e, uid, line);
  }
}

// ===== 📝 備註「最小 MD 區塊 / 子事件」編輯對話框（手機底部彈層；桌面端同名機制的 LITE 移植）=====
//   uid 一律用「當下編輯緩衝重新解析」定位：evpN 是位置型 uid，重排後可能漂移，不能拿舊快取。
let calMdEditTarget = null;
let calMdEditBaseline = '';
// 🆕 「group 啟用（唯一小事件）」：只在「編輯內容區塊」出現，預設不啟用；原本已整組時預勾。
let calGroupWasOn = false;
let calGroupBaseline = false;
function calMdEditEl(id) { return document.getElementById(id); }
// 單一 setter：所有對話框（add / task / block）都經 calShowMdEditDialog，這裡一次收口。
function calSyncGroupUi(src, target, hide) {
  const row = calMdEditEl('calGroupRow');
  const box = calMdEditEl('calGroupEnable');
  const label = row && row.querySelector('span');
  // 三种模式都提供：block＝编辑内容区块／task＝编辑 CheckBox 子事件／add-check＝加入 checkbox 子事件
  // （add-table 是格子视图、add-text 是纯文本新增，逐行 {gp} 没意义 → off）
  const mode = (target && target.mode === 'block') ? 'block'
             : (target && target.mode === 'task') ? 'task'
             : (target && target.mode === 'add' && (target.add || 'check') === 'check') ? 'add'
             : 'off';
  const show = !hide && mode !== 'off';
  const type = mode === 'block' ? target.type : '';
  // 代碼區塊（或內含圍欄）不適用：圍欄行加標記會破壞 isFence，圍欄內標記又會原樣顯示
  // 🆕 例外：整段已是「塊級 {gpX}…{/gpX} 群」時不逐行加標記，圍欄完全安全 → 照常啟用
  const isFenceGroup = (typeof calGpFenceWrap === 'function') && !!calGpFenceWrap(src);
  const enabled = show && (isFenceGroup || (!(mode === 'block' && type === 'code') && !calHasCodeFence(src)));
  // add 是「還沒寫入的草稿」永遠不預勾；block/task 依開框原文偵測
  const detected = (mode === 'block' || mode === 'task') && enabled && calIsWholeGpBlock(src);
  calGroupWasOn = !!detected;
  if (row) {
    row.style.display = show ? '' : 'none';
    row.classList.toggle('is-disabled', !enabled);
  }
  if (label) label.textContent = enabled ? 'group 啟用（唯一小事件）' : 'group 啟用（代碼區塊不適用）';
  if (box) {
    box.disabled = !enabled;
    box.checked = !!detected;
  }
  calGroupBaseline = !!(box && box.checked && !box.disabled);
  return enabled;
}
function calMdEditIsOpen() {
  const ov = calMdEditEl('calMdEditOverlay');
  return !!ov && ov.style.display !== 'none';
}
function calMdEditDirty() {
  const inp = calMdEditEl('calMdEditInput');
  const gp = calMdEditEl('calGroupEnable');
  // 🆕 只勾了 group 也算未保存（checkbox 不改 textarea 內容，光比文字會漏掉這個改動）
  return (!!inp && inp.value !== calMdEditBaseline) ||
         (!!gp && !gp.disabled && gp.checked !== calGroupBaseline);
}
function calLoadEventsForNotes() {
  // 📎 多檔聯運：便利貼來源需含 include 進來的只讀事件 → 用併集
  calRefreshAll();
  return state.calEvents;
}
// ── 🆕 表格網格編輯器（區塊圓點 type==='table' 時啟用）──────────────────────────────
// 引擎住在 md-table-grid.js（與桌面 md-table-grid.js 同一份鏡像），這裡只接本視窗的節點；
// 網格只是 #calMdEditInput 的另一層視圖：格子改動即時序列化回 textarea，
// 保存仍走 calMdEditSave 的「按區塊 start..end 區間回寫備註」，沒有第二條存檔分支。
let calTableGrid = null;
function calTableGridInstance() {
  if (calTableGrid) return calTableGrid;
  if (!window.MdTableGrid || !calMdEditEl('calTableGrid')) return null;
  const byId = (id) => calMdEditEl(id);
  calTableGrid = window.MdTableGrid.createGrid({
    textarea: byId('calMdEditInput'),
    grid: byId('calTableGrid'),
    scroll: byId('calTableGridScroll'),
    controls: {
      rows: byId('calTableRows'), cols: byId('calTableCols'), build: byId('calTableBuild'),
      addRow: byId('calTableAddRow'), delRow: byId('calTableDelRow'),
      addCol: byId('calTableAddCol'), delCol: byId('calTableDelCol'), toggle: byId('calTableViewText')
    },
    toast: showToast,
    // 引擎預設文字是桌面端的簡體；LITE 介面一律繁體，這裡只換字不換行為
    labels: {
      toRaw: '改 Markdown 原文',
      toGrid: '回到網格',
      invalidTable: '這段 Markdown 不是合法表格（需要表頭行＋分隔行），請先修正'
    },
    onSave: calMdEditSave,
    onClose: () => { const inp = calMdEditEl('calMdEditInput'); if (inp) inp.focus(); }   // 🆕 網格內 Esc 也不關窗
  });
  return calTableGrid;
}
function calEnterTableMode(src) {
  const g = calTableGridInstance();
  if (!g) return false;
  g.bind();
  return g.enter(src);
}
function calExitTableMode() { if (calTableGrid) calTableGrid.exit(); }
function calShowMdEditDialog(title, hint, value, target) {
  const ov = calMdEditEl('calMdEditOverlay');
  const inp = calMdEditEl('calMdEditInput');
  if (!ov || !inp) return;
  calExitTableMode();   // 同一個彈層也用來做表格網格，進一般模式前一定復位
  calMdEditTarget = target;
  const titleEl = calMdEditEl('calMdEditTitle');
  const hintEl = calMdEditEl('calMdEditHint');
  const saveBtn = calMdEditEl('calMdEditSave');
  if (titleEl) titleEl.textContent = title;
  if (hintEl) hintEl.textContent = hint;
  if (saveBtn) saveBtn.textContent = target && target.mode === 'add' ? '加入' : '保存';
  inp.value = value;
  calMdEditBaseline = value;
  calSyncGroupUi(value, target);   // 🆕 只有 mode=block 才顯示 group 勾選；原本已整組時預勾
  ov.style.display = 'flex';
  setTimeout(() => inp.focus(), 0);
}
function calOpenEditBlockDialog(event, uid, start, end, type) {
  if (event) { event.preventDefault(); event.stopPropagation(); }
  const fromSticky = calNotesFromSticky(event);
  const ev = calLoadEventsForNotes().find((x) => x.uid === uid);
  if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); return; }
  // 📎 聯運：ro 行程只在便利貼裡可編輯備註；行程檢視唯讀（渲染時也已不給 ✎，這裡再兜一層）
  if (calNotesRoLocked(ev, fromSticky)) return;
  const lines = String(ev.notes || '').replace(/\r\n/g, '\n').split('\n');
  if (!Number.isInteger(start) || !Number.isInteger(end) || start < 0 || end >= lines.length || start > end) {
    showToast('該區塊內容已變化，請關閉後重新開啟', 'error');
    return;
  }
  const src = lines.slice(start, end + 1).join('\n');
  calShowMdEditDialog(
    '編輯內容區塊（' + calMdUnitTypeName(type) + '）',
    '直接編輯此區塊的 Markdown 原文。保存後寫入編輯內容，按頂欄「保存」才存回文件；清空並保存＝刪除該區塊（會先確認）。',
    src,
    { mode: 'block', uid: uid, start: start, end: end, type: type, sticky: fromSticky }
  );
  // 🆕 表格區塊 → 進網格模式；認不出合法表格（缺表頭＋分隔行）就留在原文模式，不擋路
  if (type !== 'table' || !calEnterTableMode(src)) return;
  const titleEl = calMdEditEl('calMdEditTitle');
  const hintEl = calMdEditEl('calMdEditHint');
  if (titleEl) titleEl.textContent = '編輯表格內容';
  if (hintEl) hintEl.textContent = '在格子裡填內容即可；「＋行／＋列」增刪，或填「行×列」按「建立空白表」重畫一張；需要手寫 Markdown 時按「改 Markdown 原文」。保存後寫入編輯內容，按頂欄「保存」才存回文件。';
  if (calTableGrid && !calTableGrid.focusFirstCell()) {
    const inp = calMdEditEl('calMdEditInput');
    if (inp) setTimeout(() => inp.focus(), 0);
  }
}
function calOpenEditNoteCheckDialog(event, uid, line) {
  if (event) { event.preventDefault(); event.stopPropagation(); }
  const fromSticky = calNotesFromSticky(event);
  const ev = calLoadEventsForNotes().find((x) => x.uid === uid);
  if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); return; }
  // 📎 聯運：ro 行程的子事件只在便利貼裡可編輯；行程檢視唯讀
  if (calNotesRoLocked(ev, fromSticky)) return;
  const lines = String(ev.notes || '').replace(/\r\n/g, '\n').split('\n');
  const m = (line >= 0 && line < lines.length) ? lines[line].match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/) : null;
  if (!m) { showToast('該子事件內容已變化，請關閉後重新開啟', 'error'); return; }
  calShowMdEditDialog(
    '編輯子事件（CheckBox）',
    '勾選狀態會保留。換行＝拆成多個子事件（第一行保留原勾選狀態，其餘為未完成）；清空並保存＝刪除（會先確認）。',
    m[3] || '',
    { mode: 'task', uid: uid, line: line, sticky: fromSticky }
  );
}
// ＋☐ 的三種加入模式（與桌面便利貼選單同口徑）：
//   check＝逐行包成 - [ ]／table＝空白網格從零建 MD 表格／text＝原樣追加任意文本。
// 不帶 addKind 的舊入口（行程清單行的 ＋☐）一律走 check，行為不變。
// from：動作來自哪個介面（'sticky'＝便利貼）。include(ro) 行程只在便利貼裡可加子事件，
//   行程檢視唯讀；便利貼的呼叫端要明確傳 'sticky'（那裡的按鈕沒有 event 可判斷歸屬）。
function calOpenAddCheckDialog(uid, addKind, from) {
  const kind = (addKind === 'table' || addKind === 'text') ? addKind : 'check';
  const fromSticky = from === 'sticky';
  const ev = calLoadEventsForNotes().find((x) => x.uid === uid);
  if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); return; }
  // 📎 聯運：ro 行程在行程檢視不可＋☐（渲染時按鈕已不給，這裡再兜一層）
  if (calNotesRoLocked(ev, fromSticky)) return;
  if (kind === 'table') {
    if (!calTableGridInstance()) { showToast('表格編輯器未載入', 'error'); return; }
    calShowMdEditDialog(
      '加入表格（MD）',
      '在格子裡填內容，可用「＋行／＋列」增刪；「加入」＝整張表追加到備註末尾，不關窗可連續建立。全空的表格不會寫入。',
      '',
      { mode: 'add', uid: uid, add: 'table', sticky: fromSticky }
    );
    const g = calTableGridInstance();
    const rowsEl = calMdEditEl('calTableRows');
    const colsEl = calMdEditEl('calTableCols');
    g.bind();   // ⚠️ 這是「第一次用網格」的入口：沒先 bind 的話格子 input 委托與工具列都不會生效
    g.enterBlank(parseInt(rowsEl && rowsEl.value, 10), parseInt(colsEl && colsEl.value, 10));
    calMdEditBaseline = String(calMdEditEl('calMdEditInput').value);   // 剛建的空白表＝還沒開始編輯，關窗不必被問
    g.focusFirstCell();
    return;
  }
  if (kind === 'text') {
    calShowMdEditDialog(
      '自由編輯（純文本）',
      '直接輸入任意文本／Markdown，原樣追加到備註末尾（不會包成「- [ ]」子事件）。加入後按頂欄「保存」才存回文件。',
      '',
      { mode: 'add', uid: uid, add: 'text', sticky: fromSticky }
    );
    const inp = calMdEditEl('calMdEditInput');
    if (inp) inp.placeholder = '任意輸入文本，Enter 換行（原樣保存，不會變成子事件）…';
    return;
  }
  calShowMdEditDialog(
    '加入 checkbox 子事件',
    '一行一項：每個非空行都會變成一個「- [ ]」子事件，加在備註末尾。加入後按頂欄「保存」才存回文件。',
    '',
    { mode: 'add', uid: uid, add: 'check', sticky: fromSticky }
  );
  const inp = calMdEditEl('calMdEditInput');
  if (inp) inp.placeholder = '每行一個子事件…';
}
function calMdEditRequestClose() {
  if (!calMdEditIsOpen()) return;
  if (calMdEditDirty() && !window.confirm('內容尚未保存，確定關閉嗎？')) return;
  calMdEditClose();
}
function calMdEditClose() {
  const ov = calMdEditEl('calMdEditOverlay');
  if (ov) ov.style.display = 'none';
  calMdEditTarget = null;
  calMdEditBaseline = '';
  calSyncGroupUi('', null);   // 🆕 關窗一律復位，下次開任何對話框都不會殘留上次的勾選
  calExitTableMode();   // 收掉網格模式，下次開一般對話框別殘留
}
function calMdEditSave() {
  const target = calMdEditTarget;
  const inp = calMdEditEl('calMdEditInput');
  if (!target || !inp) return;
  const text = String(inp.value).replace(/\r\n/g, '\n');
  const ev = calLoadEventsForNotes().find((x) => x.uid === target.uid);
  if (!ev) { showToast('找不到該條行程（內容可能已被修改）', 'error'); calMdEditClose(); return; }
  // 📎 聯運：ro 行程只在便利貼裡可編輯備註 → 開窗時記下的介面歸屬（target.sticky）決定放不放行
  if (calNotesRoLocked(ev, !!(target && target.sticky))) { calMdEditClose(); return; }
  const notes = String(ev.notes || '').replace(/\r\n/g, '\n');
  const lines = notes ? notes.split('\n') : [];
  if (target.mode === 'block') {
    if (!Number.isInteger(target.start) || !Number.isInteger(target.end) ||
        target.start < 0 || target.end >= lines.length || target.start > target.end) {
      showToast('該區塊內容已變化，請關閉後重新開啟', 'error'); calMdEditClose(); return;
    }
    const span = target.end - target.start + 1;
    if (!text.trim()) {
      if (!window.confirm('區塊內容為空＝刪除該區塊。\n\n確定要刪除嗎？')) return;
      lines.splice(target.start, span);
      ev.notes = lines.join('\n');
      calCommitEventNotes(ev);
      calMdEditClose();
      showToast(calNotesHint(ev, '已刪除區塊，按「保存」存回文件'), 'success');
      return;
    }
    // 🆕 group 啟用：勾選時逐行補 {gp}（整塊＝一個小事件）；原本整組卻取消勾選＝拆組；其餘原樣
    const gpBox = calMdEditEl('calGroupEnable');
    const resolved = calResolveGroupText(text, !!(gpBox && gpBox.checked && !gpBox.disabled), calGroupWasOn);
    const newLines = resolved.split('\n');
    lines.splice(target.start, span, ...newLines);
    ev.notes = lines.join('\n');
    calCommitEventNotes(ev);
    calMdEditClose();
    showToast(calNotesHint(ev, '已保存區塊，按「保存」存回文件'), 'success');
    return;
  }
  if (target.mode === 'task') {
    const line = target.line;
    const m = (Number.isInteger(line) && line >= 0 && line < lines.length)
      ? lines[line].match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/) : null;
    if (!m) { showToast('該子事件內容已變化，請關閉後重新開啟', 'error'); calMdEditClose(); return; }
    const rows = text.split('\n').map((l) => l.trim()).filter(Boolean);
    if (!rows.length) {
      if (!window.confirm('子事件內容為空＝刪除該子事件。\n\n確定要刪除嗎？')) return;
      lines.splice(line, 1);
      ev.notes = lines.join('\n');
      calCommitEventNotes(ev);
      calMdEditClose();
      showToast(calNotesHint(ev, '已刪除子事件，按「保存」存回文件'), 'success');
      return;
    }
    // 一行＝一個子事件：第一行繼承原勾選狀態（含使用者自己寫的 dl/cp 標記），其餘同縮進、未完成
    const rawMd = rows.map((l, i) => m[1] + '- [' + (i === 0 ? m[2] : ' ') + '] ' + l).join('\n');
    const newLines = calGroupMd(rawMd, () => rawMd).split('\n');
    lines.splice(line, 1, ...newLines);
    ev.notes = lines.join('\n');
    calCommitEventNotes(ev);
    calMdEditClose();
    showToast(calNotesHint(ev, rows.length > 1
      ? '已拆成 ' + rows.length + ' 項子事件，按「保存」存回文件'
      : '已保存子事件，按「保存」存回文件'), 'success');
    return;
  }
  if (target.mode === 'add') {
    // 與桌面同口徑：「加入」＝寫入緩衝但**不關窗**，清乾淨讓使用者直接繼續輸入下一批
    const kind = target.add || 'check';
    const prev = notes.replace(/\s+$/, '');
    if (kind === 'check') {
      const items = text.split('\n').map((l) => l.trim()).filter(Boolean);
      if (!items.length) { showToast('沒有可加入的內容', 'error'); return; }
      const rawMd = items.map((l) => '- [ ] ' + l).join('\n');
      const md = calGroupMd(rawMd, () => rawMd, true);
      ev.notes = (prev ? prev + '\n' : '') + md + '\n';
      calCommitEventNotes(ev);
      inp.value = '';
      calMdEditBaseline = '';
      showToast(calNotesHint(ev, '已加入 ' + items.length + ' 項子事件（可繼續輸入，按「取消」關閉）'), 'success');
      return;
    }
    const block = text.replace(/^\s*\n+/, '').replace(/\s+$/, '');
    if (!block) { showToast('沒有可加入的內容', 'error'); return; }
    if (kind === 'table') {
      const parsed = window.MdTableGrid && window.MdTableGrid.parseMd(block);
      if (!parsed) { showToast('表格內容不完整（需要表頭行＋分隔行）', 'error'); return; }
      const filled = [parsed.header].concat(parsed.rows).some((row) => row.some((cell) => String(cell).trim()));
      if (!filled) { showToast('請先在格子裡填內容', 'error'); return; }
    }
    // 空一行隔開，切塊器才會把它當成獨立的 table／para 區塊，而不是併進上一段
    ev.notes = (prev ? prev + '\n\n' : '') + block + '\n';
    calCommitEventNotes(ev);
    if (kind === 'table') {
      const g = calTableGridInstance();
      const rowsEl = calMdEditEl('calTableRows');
      const colsEl = calMdEditEl('calTableCols');
      if (g) {
        g.bind();
        g.enterBlank(parseInt(rowsEl && rowsEl.value, 10), parseInt(colsEl && colsEl.value, 10));
        calMdEditBaseline = String(inp.value);
        g.focusFirstCell();
      }
      showToast(calNotesHint(ev, '已加入表格（可繼續建立下一張，按「取消」關閉）'), 'success');
    } else {
      inp.value = '';
      calMdEditBaseline = '';
      showToast(calNotesHint(ev, '已追加文本（原樣保存，未轉成子事件；可繼續輸入，按「取消」關閉）'), 'success');
    }
  }
}
function calInitMdEditDialog() {
  const ov = calMdEditEl('calMdEditOverlay');
  if (!ov || ov.dataset.initialized === '1') return;
  ov.dataset.initialized = '1';
  // 🆕 誤觸背罩不關窗：只有「取消」／✕ 按鈕能關；點背罩只把焦點還給編輯框
  ov.addEventListener('click', (e) => {
    if (e.target !== ov) return;
    e.stopPropagation();
    const inp = calMdEditEl('calMdEditInput');
    if (inp) inp.focus();
  });
  const closeBtn = calMdEditEl('calMdEditClose');
  const cancelBtn = calMdEditEl('calMdEditCancel');
  const saveBtn = calMdEditEl('calMdEditSave');
  if (closeBtn) closeBtn.addEventListener('click', calMdEditRequestClose);
  if (cancelBtn) cancelBtn.addEventListener('click', calMdEditRequestClose);
  if (saveBtn) saveBtn.addEventListener('click', calMdEditSave);
  const autoTermBtn = calMdEditEl('calMdEditAutoTerm');
  if (autoTermBtn) autoTermBtn.addEventListener('click', calAutoMarkTermsInEditBox);
  const inp = calMdEditEl('calMdEditInput');
  if (inp) {
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); calMdEditSave(); }
    });
  }
  // 🆕 Esc 不關窗：只吃掉按鍵（擋住底層便利貼／翻頁快捷鍵），關窗請按「取消」／✕
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !calMdEditIsOpen()) return;
    e.preventDefault();
  });
}

// 🆕 重画后保留「非行程」元区块（## TAGS / ## INCLUDE）：序列化器只认识 EVENT/HOLIDAY/DIARY，
//   整份重画会把用户手写的标签父阶、Include 勾选清单清掉（与桌面 tlPreserveMetaBlocks 同一做法）
function calPreserveMetaBlocks(original, newMd) {
  const src = String(original || '');
  const kept = [];
  ['TAGS', 'INCLUDE'].forEach((name) => {
    const idx = src.search(new RegExp('^##[ \\t]*' + name + '[ \\t]*$', 'm'));
    if (idx < 0) return;
    const after = src.slice(idx);
    const next = after.search(/\n##[ \t]/m);
    const end = next >= 0 ? idx + next : src.length;
    kept.push(src.slice(idx, end).replace(/\s+$/, ''));
  });
  if (!kept.length) return newMd;
  return String(newMd).replace(/\s*$/, '') + '\n\n' + kept.join('\n\n') + '\n';
}

// 把工作副本序列化為 calendar 檔全文寫回編輯器緩衝；
// lastContent 不動 → isDirty = true → 頂欄「保存」亮起，由用戶決定何時落盤
function applyEventsToEditor() {
  // ⚠️ 從當前緩衝重新解析 holiday / diary，避免保存事件時把用戶手寫的 ## HOLIDAY / ## DIARY 整體覆蓋掉（事件序列化器會重畫整份文件）
  const holidays = parseCalendarHolidays(elements.editor.value);
  const diaries = parseCalendarDiaries(elements.editor.value);
  calHolidays = holidays;
  calDiaries = [];
  // 📎 重畫後保留 ## TAGS / ## INCLUDE（避免父階標籤、Include 勾選被清掉）
  // 📎 多檔聯運安全網：state.calEvents 在此可能是「主檔＋include 併集」，
  //    但編輯緩衝只屬於主檔——絕不可把 ro（只讀來源）事件序列化寫回主檔，
  //    故序列化前先濾掉 ro（編輯/存檔路徑都只用主檔內容，這裡是雙重保險）。
  const mainEvents = (state.calEvents || []).filter((e) => !e.ro);
  elements.editor.value = calPreserveMetaBlocks(elements.editor.value, calCalendarToMarkdown(mainEvents, holidays, diaries));
  state.isDirty = elements.editor.value !== state.lastContent;
  updateStatus();
  updateWordCount();
  updatePreview(); // 重新渲染行程列表 / 月曆
  // 便利貼彈層開著時同步重繪：勾 checkbox / 表單存檔後，張數、內容與子事件進度立即更新
  if (typeof calStickyRefreshIfOpen === 'function') calStickyRefreshIfOpen();
}
