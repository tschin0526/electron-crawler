/**
 * MD 編輯器 Lite - PWA 版本
 * 支持 iCloud 文件讀取與保存
 */

// 視圖模式：edit = 只編輯 / preview = 只預覽 / split = 分屏（邊寫邊看）
const VIEWS = ['edit', 'preview', 'split', 'events'];

// 📌 應用版本號（單一可信來源）。
// 每次改動都要 +1，方便在手機上確認跑的是不是最新版（狀態列左下角會顯示）。
const APP_VERSION = '1.10.41';

// 可處理的文字檔副檔名白名單（對齊 todo 編輯器 TEXT_EXTS，取常用子集）
const TEXT_EXTS = [
  '.txt', '.text', '.log', '.csv', '.tsv',
  '.md', '.markdown', '.mdx',
  '.html', '.htm',
  '.json', '.json5', '.jsonc',
  '.yaml', '.yml', '.toml', '.ini', '.conf', '.config', '.properties', '.cfg', '.xml',
  '.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx', '.vue', '.svelte',
  '.css', '.scss', '.less',
  '.py', '.rb', '.sh', '.bash', '.zsh', '.fish', '.ps1', '.bat', '.cmd',
  '.sql', '.graphql', '.gql',
  '.c', '.h', '.cpp', '.cc', '.cxx', '.hpp', '.java', '.kt', '.go', '.rs', '.swift',
  '.php', '.lua', '.r', '.cs', '.scala', '.dart', '.ex', '.erl',
  '.env', '.gitignore', '.editorconfig', '.tex', '.rst', '.diff', '.patch'
];
const TEXT_EXTS_SET = new Set(TEXT_EXTS);
// 無副檔名但約定為文字檔的檔名
const TEXT_NOEXT = new Set([
  'makefile', 'dockerfile', 'rakefile', 'gemfile', 'vagrantfile', 'readme', 'license',
  'changelog', 'copying', 'install', 'authors', 'contributing', 'todo', 'news', 'changes'
]);

// 副檔名 → 檔案類別（決定預覽方式與 MIME）
function classifyFileType(name) {
  const lower = (name || '').toLowerCase();
  const ext = lower.slice(lower.lastIndexOf('.'));
  if (lower.endsWith('.md') || lower.endsWith('.markdown') || lower.endsWith('.mdx')) return 'md';
  if (lower.endsWith('.html') || lower.endsWith('.htm')) return 'html';
  if (lower.endsWith('.json') || lower.endsWith('.json5') || lower.endsWith('.jsonc')) return 'json';
  return 'text';
}

// 判斷某檔名是否為可編輯的文字檔（副檔名白名單 or 無副檔名約定檔名）
function isTextFile(name) {
  const lower = (name || '').toLowerCase();
  const dot = lower.lastIndexOf('.');
  // 有副檔名（含 .gitignore/.dockerignore 這類「副檔名即全名」的點檔）→ 查白名單
  if (dot >= 0) {
    const ext = lower.slice(dot);
    return TEXT_EXTS_SET.has(ext);
  }
  // 完全無點 → 查無副檔名約定檔名（Makefile / README …）
  return TEXT_NOEXT.has(lower);
}

// 判斷文字內容是否為 todo 卡片（符合 todo 編輯器的卡片結構）。
// 條件（對齊 openExternalFile）：解析後是物件 + 有 text 字串 + 含 todo 卡片特有字段
// （completed/tags/createdAt/updatedAt/attachments/bgColor 任一即可）。
function isTodoJson(content) {
  if (!content) return false;
  let obj;
  try { obj = JSON.parse(content); } catch (_) { return false; }
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return false;
  if (typeof obj.text !== 'string') return false;
  return ('completed' in obj) || ('tags' in obj) || ('createdAt' in obj) ||
         ('updatedAt' in obj) || ('attachments' in obj) || ('bgColor' in obj);
}

// 全局狀態
const state = {
  currentFile: null,
  isDirty: false,
  view: 'edit',
  isDarkMode: true,  // 預設暗色模式（無 localStorage 記錄 / 重置後即為黑夜模式）
  lastContent: '',
  // 🆕 todo 卡片模式：開啟 todo-*.json（符合 todo 卡片結構）後進入此模式，
  //    編輯器只顯示 markdown 正文（text 字段）；存檔前把改後的 text 合回原物件
  //    再整體序列化，保留所有其它字段（tags/bgColor/attachments/createdAt/...）。
  todoMode: false,
  originalTodo: null,  // 開啟時的完整原始 todo 物件（保存時以此為基礎合併）
  // 📅 行程視圖（calendar.md 專用）
  calMode: 'year',              // 'list' | 'day' | 'week' | 'month' | 'year'（第十一批依用户截图设定默认 'year'，此前 'month'）
  calCursor: new Date(),        // 當前游標日期（月視圖＝該月；日視圖＝當天；週視圖＝該週內某天）
  calSelectedDate: null,        // 月視圖選中日期（YYYY-MM-DD）
  calListSel: null,             // 列表模式：< > / 「今天」導航到的「選中日」（金色描邊）
  calScope: 'full',             // 下方明細範圍：'day'=選定日 / 'full'=整月·整週·整年。第十一批：年視圖默認 'full'（整年＝「表身 默認 by 年」）；月/週/日仍 'day'（見 setCalMode）。因 calMode 現默認 'year'
  calEvents: [],                // 工作副本（含 uid；每次渲染/編輯前從編輯器緩衝重新解析）
  calTagFilter: [],             // 🏷 標籤過濾（空＝全部；OR 邏輯，任一標籤命中即顯示）
  calRegionFilter: [],          // 🌏 HOLIDAY 地區過濾（圖例 checkbox；第十一批依用户截图设定默认空＝不顯示任何地區假日；僅內存態）
  calShowEvents: true,          // 🗂 分類顯示：普通行程 EVENT（頂欄勾選，默認開；僅內存態）
  calShowRepeat: 'next',        // 🗂 分類顯示：重複行程 REPEAT 三態（none=隱藏 / next=只顯示未來最近一次 / some=最近前一次+未來4次≤5；第十一批依用户截图设定默认 'next'；僅內存態）
  // 📋 列表模式：「跨天行程」顯示幾筆（純 UI 偏好：記憶體 + localStorage，絕不寫回 calendar.md）
  //    'multi'（預設）＝跨幾天就顯示幾筆（每天一筆，與「日」範圍同口徑）；'one'＝整段只在起始日顯示一筆。
  //    ⚠️ 只作用於列表模式（renderEventsList）；月/週/日三種模式一律不受影響。
  calMultiDayMode: 'multi',
  // 📓 列表模式：「只顯示日記」過濾（純 UI 偏好：記憶體 + localStorage，鍵 calDiaryOnly；絕不寫回 calendar.md）
  //    勾選後列表只列有日記的日期（行程 EVENT/REPEAT 與假日 HOLIDAY 不參與）。⚠️ 只作用於列表模式。
  calDiaryOnly: false,
  // ☐ 「只顯示未完成」過濾（純 UI 偏好：記憶體 + localStorage，鍵 calUndoneOnly；絕不寫回 calendar.md）
  //    勾選後隱藏已完成（done ✓）的行程；假日無完成態不受影響。⚠️ 全模式生效（年/月/週/日/列表），收口在 calEventShown。
  //    第十一批依用户截图设定：默認「開」（新環境未設 localStorage 時即勾選）。
  calUndoneOnly: true,
  evFormUid: null,              // 編輯表單當前目標 uid（null = 新增）
  evFormColor: null,            // 編輯表單當前選中顏色
  evFormTags: [],               // 編輯表單當前已選標籤
  evFormTodoIds: [],            // 🔗 編輯表單當前關聯的 Todo 卡片 id（寫回 todoIds 字段）
  // 📎 多檔聯運：額外「加入」的 calendar*.md（只讀來源，不寫回主檔編輯緩衝）；
  //    每個元素 { name, content }；uid 在渲染時加 ro-<序> 前綴避免與主檔 evpN 撞名（對齊桌面 ro 機制）。
  //    內容快取在 localStorage（鍵 md-editor-cal-includes，按主檔名索引），重新開啟主檔可自動重併，免於 iCloud 重選。
  calIncludeFiles: []
};

// DOM 元素
const elements = {
  btnOpen: document.getElementById('btn-open'),
  btnSave: document.getElementById('btn-save'),
  btnSaveCaret: document.getElementById('btn-save-caret'),
  btnSaveMenu: document.getElementById('btn-save-menu'),
  btnSaveCombo: document.getElementById('btn-save-combo'),
  btnReset: document.getElementById('btn-reset'),
  btnTheme: document.getElementById('btn-theme'),
  fileInput: document.getElementById('file-input'),
  fileName: document.getElementById('file-name'),
  tabEvents: document.getElementById('tab-events'),
  eventsList: document.getElementById('events-list'),
  evModeList: document.getElementById('ev-mode-list'),
  evModeDay: document.getElementById('ev-mode-day'),
  evModeWeek: document.getElementById('ev-mode-week'),
  evModeMonth: document.getElementById('ev-mode-month'),
  evModeYear: document.getElementById('ev-mode-year'),
  evAddBtn: document.getElementById('ev-add-btn'),
  evStatsBtn: document.getElementById('ev-stats-btn'),
  evTagBar: document.getElementById('ev-tagbar'),
  evTagFilter: document.getElementById('ev-tag-filter'),
  evMonthNav: document.getElementById('ev-month-nav'),
  evMonthTitle: document.getElementById('ev-month-title'),
  evPrevMonth: document.getElementById('ev-prev-month'),
  evNextMonth: document.getElementById('ev-next-month'),
  evTodayBtn: document.getElementById('ev-today-btn'),
  evMultiDayBtn: document.getElementById('ev-multiday-btn'),
  evMonthWrap: document.getElementById('ev-month-wrap'),
  evMonthGrid: document.getElementById('ev-month-grid'),
  evDayList: document.getElementById('ev-day-list'),
  evWeekWrap: document.getElementById('ev-week-wrap'),
  evYearWrap: document.getElementById('ev-year-wrap'),
  evYearGrid: document.getElementById('ev-year-grid'),
  evYearDayList: document.getElementById('ev-year-day-list'),
  evFormOverlay: document.getElementById('ev-form-overlay'),
  evFormTitle: document.getElementById('ev-form-title'),
  evFormDelete: document.getElementById('ev-form-delete'),
  evFormCancel: document.getElementById('ev-form-cancel'),
  evFormSave: document.getElementById('ev-form-save'),
  evFTitle: document.getElementById('ev-f-title'),
  evFDate: document.getElementById('ev-f-date'),
  evFEndDate: document.getElementById('ev-f-enddate'),
  evFSpanDisplay: document.getElementById('ev-f-span-display'),
  evFAllday: document.getElementById('ev-f-allday'),
  evFDone: document.getElementById('ev-f-done'),
  evFStart: document.getElementById('ev-f-start'),
  evFEnd: document.getElementById('ev-f-end'),
  evFLocation: document.getElementById('ev-f-location'),
  evFSticky: document.getElementById('ev-f-sticky'),
  evFColors: document.getElementById('ev-f-colors'),
  evFTags: document.getElementById('ev-f-tags'),
  evFTodoPanel: document.getElementById('ev-f-todo-panel'),
  evFTodoInput: document.getElementById('ev-f-todo-input'),
  evFTodoAdd: document.getElementById('ev-f-todo-add'),
  evFNotes: document.getElementById('ev-f-notes'),
  evFResize: document.getElementById('ev-f-resize'),
  // 📎 多檔聯運：加入 / 移除額外 calendar*.md（只讀來源）
  calIncludeInput: document.getElementById('cal-include-input'),
  calIncludeBar: document.getElementById('cal-include-bar'),
  // 🔁 重複事件表單
  evFRepeatOn: document.getElementById('ev-f-repeat-on'),
  evFRepeatFields: document.getElementById('ev-f-repeat-fields'),
  evFRepeatMode: document.getElementById('ev-f-repeat-mode'),
  evFRepeatInterval: document.getElementById('ev-f-repeat-interval'),
  evFRepeatIntervalUnit: document.getElementById('ev-f-repeat-interval-unit'),
  evFWeekDayBox: document.getElementById('ev-f-weekday-box'),
  evFWeekDays: document.getElementById('ev-f-weekdays'),
  evFMonthDayBox: document.getElementById('ev-f-monthday-box'),
  evFMonthDay: document.getElementById('ev-f-monthday'),
  evFYearMonthDayBox: document.getElementById('ev-f-yearmonthday-box'),
  evFYearMonthDay: document.getElementById('ev-f-yearmonthday'),
  evFRepeatEndType: document.getElementById('ev-f-repeat-endtype'),
  evFEndValueBox: document.getElementById('ev-f-endvalue-box'),
  evFEndValueUnit: document.getElementById('ev-f-endvalue-unit'),
  evFRepeatEndValue: document.getElementById('ev-f-repeat-endvalue'),
  evFRepeatExclude: document.getElementById('ev-f-repeat-exclude'),
  // 📓 日記表單
  diaryFormOverlay: document.getElementById('ev-diary-overlay'),
  diaryFormTitle: document.getElementById('ev-diary-title'),
  diaryFormDelete: document.getElementById('ev-diary-delete'),
  diaryFormCancel: document.getElementById('ev-diary-cancel'),
  diaryFormSave: document.getElementById('ev-diary-save'),
  diaryFTitle: document.getElementById('ev-diary-f-title'),
  diaryFDate: document.getElementById('ev-diary-date'),
  diaryFMood: document.getElementById('ev-diary-f-mood'),
  diaryFWeather: document.getElementById('ev-diary-f-weather'),
  diaryFTags: document.getElementById('ev-diary-f-tags'),
  diaryFContent: document.getElementById('ev-diary-f-content'),
  diaryFRemark: document.getElementById('ev-diary-f-remark'),
  editor: document.getElementById('editor'),
  mdToolbar: document.getElementById('md-toolbar'),
  editorContainer: document.getElementById('editor-container'),
  preview: document.getElementById('preview'),
  tabbar: document.getElementById('tabbar'),
  statusText: document.getElementById('status-text'),
  wordCount: document.getElementById('word-count'),
  appVersion: document.getElementById('app-version'),
  toast: document.getElementById('toast'),
  toastMsg: document.getElementById('toast-msg'),
  toastClose: document.getElementById('toast-close')
};

// 狀態列版本號：v<APP_VERSION> · sw.js v<SW 版本>（SW 版本 = CACHE_NAME 尾碼）
function renderAppVersion(swVersion) {
  if (!elements.appVersion) return;
  const swPart = swVersion ? ' · sw.js v' + swVersion : '';
  elements.appVersion.textContent = 'v' + APP_VERSION + swPart;
  elements.appVersion.title = 'MD 編輯器 Lite v' + APP_VERSION +
    (swVersion ? ' ／ Service Worker v' + swVersion : '');
}

// 問目前接管頁面的 SW 要版本號（GET_VERSION → { cacheName }），拿到後補進狀態列
function loadSwVersion() {
  if (!('serviceWorker' in navigator)) {
    fetchSwVersion();
    return;
  }
  navigator.serviceWorker.ready.then((reg) => {
    const worker = reg.active;
    if (!worker) {
      fetchSwVersion();
      return;
    }
    let replied = false;
    const channel = new MessageChannel();
    channel.port1.onmessage = (event) => {
      replied = true;
      const match = /-v(\d+)$/.exec((event.data && event.data.cacheName) || '');
      if (match) renderAppVersion(match[1]);
      channel.port1.close();
    };
    worker.postMessage({ type: 'GET_VERSION' }, [channel.port1]);
    // SW 沒回話（舊版 SW 不認得 GET_VERSION）→ 退回抓 sw.js 解析
    setTimeout(() => {
      if (!replied) fetchSwVersion();
    }, 800);
  }).catch(() => fetchSwVersion());
}

// 退路：直接抓 sw.js 解析 CACHE_NAME 尾碼
function fetchSwVersion() {
  fetch(new URL('./sw.js', document.baseURI).href, { cache: 'no-store' })
    .then((res) => res.text())
    .then((text) => {
      const match = /CACHE_NAME\s*=\s*['"][^'"]*-v(\d+)['"]/.exec(text);
      if (match) renderAppVersion(match[1]);
    })
    .catch(() => {});
}

// 初始化
function init() {
  loadSettings();
  setupEventListeners();
  restoreDraft();
  setView(state.view);
  updateWordCount();
  // 顯示版本號（狀態列左下角）：先顯示應用版本，SW 版本問到後再補上
  renderAppVersion('');
  loadSwVersion();
  
  // 註冊 Service Worker（使用相對路徑，避免部署在子目錄時 404）
  if ('serviceWorker' in navigator) {
    const swPath = new URL('./sw.js', document.baseURI).href;
    navigator.serviceWorker.register(swPath)
      .then(reg => {
        console.log('SW 註冊成功', reg);
        // 🆕 檢測到新 SW 版本 → 等它接管後自動刷新一次，確保拿到最新資源
        //    （緩存優先策略下，若 SW 更新但頁面不刷新，會一直用舊快取）
        if (reg.waiting) {
          reg.waiting.postMessage({ type: 'SKIP_WAITING' });
        }
        reg.addEventListener('updatefound', () => {
          const newWorker = reg.installing;
          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                newWorker.postMessage({ type: 'SKIP_WAITING' });
              }
            });
          }
        });
      })
      .catch(err => console.warn('SW 註冊失敗（離線功能不可用）', err));

    // 🆕 新 SW 接管後自動刷新，避免停留在舊頁面/舊緩存
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      window.location.reload();
    });
  }
}

// 設置事件監聽
function setupEventListeners() {
  // 是否有真鼠标（决定 hover 提示框 / 点开表单 行为；触屏改为弹小选单）
  const mqCanHover = window.matchMedia('(hover: hover) and (pointer: fine)');

  // 開啟文件
  elements.btnOpen.addEventListener('click', () => {
    openFilePicker('');
  });

  elements.fileInput.addEventListener('change', handleFileSelect);

  // 保存文件：主按鈕＝保存全部（等同原本行為：主檔＋所有待寫回聯運檔）
  elements.btnSave.addEventListener('click', () => handleSave('all'));

  // 🆕 保存 combo：右側 ▾ 下拉徽標 → 展開「選擇要保存的檔案」選單
  if (elements.btnSaveCaret) {
    elements.btnSaveCaret.addEventListener('click', (e) => {
      e.stopPropagation();   // 避免觸發下面的 document 外部點擊關閉
      e.preventDefault();
      toggleSaveMenu();
    });
  }
  // 選單項目：點擊＝只存該檔（handleSave 會遞減角標）
  if (elements.btnSaveMenu) {
    elements.btnSaveMenu.addEventListener('click', (e) => {
      const item = e.target.closest('.btn-save-menu-item');
      if (!item) return;
      const target = item.dataset.saveTarget;
      closeSaveMenu();
      if (target) handleSave(target);
    });
  }
  // 點擊頁面其它地方關閉保存選單
  document.addEventListener('click', (e) => {
    if (e.target.closest && !e.target.closest('#btn-save-combo')) closeSaveMenu();
  });

  // 重置：清除所有緩存並重新載入整個應用
  elements.btnReset.addEventListener('click', handleReset);

  // 🆕 常駐提醒的 ✕ 關閉鈕：由使用者手動關閉訊息
  if (elements.toastClose) {
    elements.toastClose.addEventListener('click', () => {
      if (typeof hideToast === 'function') hideToast();
    });
  }

  // 📅 行程視圖（calendar.md）：模式切換 / 月曆導航 / 新增 / 條目編輯刪除（事件委派）
  if (elements.evModeList) elements.evModeList.addEventListener('click', () => setCalMode('list'));
  if (elements.evModeDay) elements.evModeDay.addEventListener('click', () => setCalMode('day'));
  if (elements.evModeWeek) elements.evModeWeek.addEventListener('click', () => setCalMode('week'));
  if (elements.evModeMonth) elements.evModeMonth.addEventListener('click', () => setCalMode('month'));
  if (elements.evModeYear) elements.evModeYear.addEventListener('click', () => setCalMode('year'));
  if (elements.evAddBtn) elements.evAddBtn.addEventListener('click', () => openEventForm(null));
  if (elements.evStatsBtn) elements.evStatsBtn.addEventListener('click', () => calOpenStats());
  if (typeof calInitCalendarToolbarCombo === 'function') calInitCalendarToolbarCombo();
  if (typeof calInitNewDialogs === 'function') calInitNewDialogs();
  if (typeof calInitMdEditDialog === 'function') calInitMdEditDialog();
  // ‹ › 依當前模式步進：月→月、週→週、日→日
  if (elements.evPrevMonth) elements.evPrevMonth.addEventListener('click', () => { if (state.calMode === 'list') calListNavDay(-1); else calStepCursor(-1); });
  if (elements.evNextMonth) elements.evNextMonth.addEventListener('click', () => { if (state.calMode === 'list') calListNavDay(1); else calStepCursor(1); });
  if (elements.evTodayBtn) elements.evTodayBtn.addEventListener('click', () => { state.calCursor = new Date(); state.calSelectedDate = calendarFmtDate(new Date()); state.calListSel = calendarFmtDate(new Date()); calAutoScrollToTodayPending = true; renderEventsContent(); });
  // 📋 列表模式：跨天一筆 / 跨天多筆（僅列表模式顯示；其餘模式不受影響）
  if (elements.evMultiDayBtn) elements.evMultiDayBtn.addEventListener('click', () => calToggleMultiDayMode());
  if (elements.evMonthGrid) elements.evMonthGrid.addEventListener('click', (e) => {
    // 📅 點農曆文字 → 開老黃曆詳情（不觸發選日 / 快速新增）
    const alm = e.target.closest('[data-ev-almanac]');
    if (alm) { calShowAlmanac(alm.getAttribute('data-ev-almanac'), alm); return; }
    // 先判斷是否點到行程 chip（帶 data-ev-edit）→ 直接開表單，不再觸發選日
    const chip = e.target.closest('.ev-chip[data-ev-edit]');
    if (chip) {
      const uid = chip.getAttribute('data-ev-edit');
      // 触屏：点事件弹小选单（编辑 / 详情）；桌面保持点开表单
      if (mqCanHover.matches) openEventForm(uid);
      else calShowEventMenu(chip, uid);
      return;
    }
    const cell = e.target.closest('.ev-cell[data-date]');
    if (!cell) return;
    const ds = cell.getAttribute('data-date');
    // 月格單擊＝選日；400ms 內連點同一天＝快速新增。
    // ⚠️ 不能用原生 dblclick：單擊會整格重繪 innerHTML，第二次點擊落在新節點上，
    //    瀏覽器視為不同目標，dblclick 事件根本不會派發（實測）——必須手動檢測。
    const now = Date.now();
    const isDbl = calLastCellClick.date === ds && (now - calLastCellClick.t) < 400;
    calLastCellClick = isDbl ? { date: null, t: 0 } : { date: ds, t: now };
    state.calSelectedDate = ds;
    if (isDbl) { openEventForm(null, ds); return; }
    renderCalMonth(elements.editor.value);
  });
  // 📅 年視圖：點日期選日（下部明細）；400ms 內連點同一天＝快速新增（與月視圖一致）
  if (elements.evYearGrid) elements.evYearGrid.addEventListener('click', (e) => {
    const cell = e.target.closest('.ev-year-day[data-date]');
    if (!cell) return;
    const ds = cell.getAttribute('data-date');
    const now = Date.now();
    const isDbl = calYearLastCellClick.date === ds && (now - calYearLastCellClick.t) < 400;
    calYearLastCellClick = isDbl ? { date: null, t: 0 } : { date: ds, t: now };
    state.calSelectedDate = ds;
    if (isDbl) { openEventForm(null, ds); return; }
    renderCalYear(elements.editor.value);
  });
  // 🏷 標籤過濾條：點選切換（OR 邏輯，可多選）
  if (elements.evTagFilter) elements.evTagFilter.addEventListener('click', (e) => {
    const chip = e.target.closest('.ev-tag-chip');
    if (!chip) return;
    const t = chip.getAttribute('data-tag');
    const i = state.calTagFilter.indexOf(t);
    if (i >= 0) state.calTagFilter.splice(i, 1);
    else state.calTagFilter.push(t);
    renderEventsContent();
  });
  const tagPicker = document.getElementById('ev-tag-picker');
  if (tagPicker && elements.evFTags) {
    tagPicker.addEventListener('click', (e) => {
      const edit = e.target.closest('[data-ev-tag-edit]');
      const editSubcat = e.target.closest('[data-ev-tag-subcat-edit]');
      if (edit) {
        calEvTagEditIndex = parseInt(edit.getAttribute('data-ev-tag-edit'), 10);
        calEvTagEditLevel = 'cat';
        calRenderTagPicker();
        return;
      }
      if (editSubcat) {
        calEvTagEditIndex = parseInt(editSubcat.getAttribute('data-ev-tag-subcat-edit'), 10);
        calEvTagEditLevel = 'subcat';
        calRenderTagPicker();
        return;
      }
      const remove = e.target.closest('[data-ev-tag-remove]');
      const option = e.target.closest('[data-ev-tag-option]');
      if (remove) calRemoveFormTag(remove.getAttribute('data-ev-tag-remove'));
      else if (option) calToggleFormTag(option.getAttribute('data-ev-tag-option'));
      else { tagPicker.classList.add('open'); calRenderTagPicker(); }
    });
    elements.evFTags.addEventListener('input', () => { tagPicker.classList.add('open'); calRenderTagPicker(); });
    elements.evFTags.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); calAddFormTag(elements.evFTags.value); }
      else if (e.key === 'Backspace' && !elements.evFTags.value) calRemoveFormTag(state.evFormTags[state.evFormTags.length - 1]);
    });
    document.addEventListener('click', (e) => { if (!tagPicker.contains(e.target)) tagPicker.classList.remove('open'); });
  }
  // 條目「編輯/刪除」按鈕：列表視圖、月視圖日列表、日/週時間網格共用一套委派
  if (elements.eventsList) elements.eventsList.addEventListener('click', onEvListClick);
  if (elements.evDayList) elements.evDayList.addEventListener('click', onEvListClick);
  if (elements.evYearDayList) elements.evYearDayList.addEventListener('click', onEvListClick);
  if (elements.evWeekWrap) elements.evWeekWrap.addEventListener('click', onEvListClick);
  // 🖱 雙擊列表條目＝進入編輯狀態（📓「只顯示日記」條目；行程條目單擊即開表單，不在此重複）
  if (elements.eventsList) elements.eventsList.addEventListener('dblclick', onEvListDblClick);
  // 週視圖：點日期標題切換「下半部明細」所顯示的那一天（與月視圖點格選日一致）；日模式只有一天，不處理。
  if (elements.evWeekWrap) elements.evWeekWrap.addEventListener('click', (e) => {
    const hc = e.target.closest('.ev-tg-head-cell[data-date]');
    if (hc && state.calMode === 'week') {
      state.calSelectedDate = hc.getAttribute('data-date');
      renderCalGridDayList();
      elements.evWeekWrap.querySelectorAll('.ev-tg-head-cell').forEach((c) => c.classList.toggle('selected', c.getAttribute('data-date') === state.calSelectedDate));
    }
  });
  // 🖱 雙擊空白處快速新增：日/週網格＝日期+時間、全天條＝日期(全天)。
  //    月模式不走原生 dblclick——單擊重繪格點會讓 dblclick 不派發，已在 evMonthGrid 的 click 裡手動檢測連點。
  if (elements.evWeekWrap) elements.evWeekWrap.addEventListener('dblclick', calGridDblClickNew);
  // 🖱 悬停行程事件 → 放大提示框（事件委托到 editorContainer；桌面浏览器看 PWA 时生效）
  // ⚠️ 触屏手机无真正 hover：点事件的第一次 tap 会被浏览器伪造 mouseover → 提示框先弹、再派 click 开表单，两者重叠。
  //    故用媒体查询「仅真鼠标设备（hover:hover + pointer:fine）」才启用；手机本就点一下弹小选单（编辑/详情），提示框冗余。
  if (elements.editorContainer) {
    const calEvSel = '.ev-chip, .ev-block, .ev-item';
    elements.editorContainer.addEventListener('mouseover', (e) => {
      if (!mqCanHover.matches) return;
      // 日记图标 hover → 显示日记 tip（仅当天有日记时）
      const dyBtn = e.target.closest('.ev-day-diary');
      if (dyBtn && dyBtn.getAttribute('data-ev-diary')) {
        const d = calDiaryOnDate(dyBtn.getAttribute('data-ev-diary'));
        if (d) { calShowDiaryTip(d.date, e.clientX, e.clientY); return; }
      }
      const el = e.target.closest(calEvSel);
      if (el && el.getAttribute('data-ev-edit')) calShowTip(el.getAttribute('data-ev-edit'), el.getAttribute('data-occ-date'), e.clientX, e.clientY);
    });
    elements.editorContainer.addEventListener('mousemove', (e) => {
      if (!mqCanHover.matches) return;
      if (!calTipEl || calTipEl.style.display === 'none') return;
      const dyBtn = e.target.closest('.ev-day-diary');
      if (dyBtn && dyBtn.getAttribute('data-ev-diary')) {
        const d = calDiaryOnDate(dyBtn.getAttribute('data-ev-diary'));
        if (d) { calShowDiaryTip(d.date, e.clientX, e.clientY); return; }
      }
      const el = e.target.closest(calEvSel);
      if (el && el.getAttribute('data-ev-edit')) calShowTip(el.getAttribute('data-ev-edit'), el.getAttribute('data-occ-date'), e.clientX, e.clientY);
      else calHideTip();
    });
    elements.editorContainer.addEventListener('mouseout', (e) => {
      const to = e.relatedTarget;
      if (to && to.closest) {
        if (to.closest(calEvSel)) return;            // 仍在事件元素间移动，不隐藏
        if (to.closest('.ev-day-diary')) return;    // 仍在日记按钮上，不隐藏
      }
      calHideTip();
    });
    elements.editorContainer.addEventListener('mouseleave', calHideTip);
  }
  // 🔗 表單內關聯 Todo 卡片面板：chip 的 ✕ 移除 / 輸入框 ＋ 新增
  if (elements.evFTodoPanel) elements.evFTodoPanel.addEventListener('click', (e) => {
    const x = e.target.closest('.ev-todo-chip-x');
    if (x) calEvRemoveTodoLink(x.getAttribute('data-id'));
  });
  if (elements.evFTodoAdd) elements.evFTodoAdd.addEventListener('click', () => {
    if (!elements.evFTodoInput) return;
    const v = (elements.evFTodoInput.value || '').trim();
    if (!v) return;
    calEvAddTodoLink(v);
    elements.evFTodoInput.value = '';
  });
  if (elements.evFTodoInput) elements.evFTodoInput.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    const v = (elements.evFTodoInput.value || '').trim();
    if (!v) return;
    calEvAddTodoLink(v);
    elements.evFTodoInput.value = '';
  });
  // 表單
  if (elements.evFormSave) elements.evFormSave.addEventListener('click', saveEventForm);
  if (elements.evFormCancel) elements.evFormCancel.addEventListener('click', closeEventForm);
  if (elements.evFormDelete) elements.evFormDelete.addEventListener('click', deleteEventFromForm);
  if (elements.evFAllday) elements.evFAllday.addEventListener('change', () => {
    elements.evFStart.disabled = elements.evFAllday.checked;
    elements.evFEnd.disabled = elements.evFAllday.checked;
  });
  // 🗓 表單日期輸入變更 → 即時更新輸入框旁的星期提示
  if (elements.evFDate) { elements.evFDate.addEventListener('change', calUpdateFormDow); elements.evFDate.addEventListener('input', calUpdateFormDow); }
  if (elements.evFEndDate) { elements.evFEndDate.addEventListener('change', calUpdateFormDow); elements.evFEndDate.addEventListener('input', calUpdateFormDow); }
  if (elements.evFormOverlay) elements.evFormOverlay.addEventListener('click', (e) => {
    if (e.target === elements.evFormOverlay) closeEventForm(); // 點遮罩 = 取消
  });
  // 📓 日記表單
  if (elements.diaryFormSave) elements.diaryFormSave.addEventListener('click', saveDiaryForm);
  if (elements.diaryFormCancel) elements.diaryFormCancel.addEventListener('click', closeDiaryForm);
  if (elements.diaryFormDelete) elements.diaryFormDelete.addEventListener('click', deleteDiary);
  if (elements.diaryFormOverlay) elements.diaryFormOverlay.addEventListener('click', (e) => {
    if (e.target === elements.diaryFormOverlay) closeDiaryForm(); // 點遮罩 = 取消
  });
  // ↕ 備註框高度拖拽手柄：iOS Safari 不支持 textarea 原生 resize，用 Pointer Events 自繪（觸屏/鼠標通用）
  if (elements.evFResize && elements.evFNotes) {
    elements.evFResize.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      const startY = e.clientY;
      const startH = elements.evFNotes.offsetHeight;
      const onMove = (ev) => {
        const h = Math.max(60, Math.min(420, startH + (ev.clientY - startY)));
        elements.evFNotes.style.height = h + 'px';
      };
      const onEnd = () => {
        document.removeEventListener('pointermove', onMove);
        document.removeEventListener('pointerup', onEnd);
        document.removeEventListener('pointercancel', onEnd);
      };
      document.addEventListener('pointermove', onMove);
      document.addEventListener('pointerup', onEnd);
      document.addEventListener('pointercancel', onEnd);
    });
  }

  // 視圖切換頁簽（事件委派，頁簽增減不用改這裡）
  elements.tabbar.addEventListener('click', (e) => {
    const tab = e.target.closest('.tab');
    if (tab) setView(tab.dataset.view);
  });

  // 聯運清單裡每個 chip 的 ✕ 移除 / 💾 匯出（事件委派，清單動態產生）
  if (elements.calIncludeBar) elements.calIncludeBar.addEventListener('click', (e) => {
    // 💾 排在 ✕ 前面判斷：兩顆按鈕都在同一個 chip 裡，先命中較少見的那個
    const save = e.target.closest('[data-ib-save]');
    if (save) {
      if (typeof calSaveIncludeFile === 'function') calSaveIncludeFile(save.getAttribute('data-ib-save'));
      return;
    }
    const x = e.target.closest('[data-ib-x]');
    if (x && typeof calRemoveIncludeFile === 'function') calRemoveIncludeFile(x.getAttribute('data-ib-x'));
  });

  // 切換主題
  elements.btnTheme.addEventListener('click', toggleTheme);

  // 編輯器輸入
  elements.editor.addEventListener('input', () => {
    state.isDirty = elements.editor.value !== state.lastContent;
    updatePreview();
    updateWordCount();
    updateStatus();   // ← 已含 calRenderIncludeBar()
  });

  // 點擊頁面其它地方關閉工具列下拉
  document.addEventListener('click', (e) => {
    if (!e.target.closest('[data-md-dropdown]')) closeAllMdDropdowns();
  });

  // 鍵盤快捷鍵
  document.addEventListener('keydown', handleKeyboard);

  // 頁面卸載前提示（桌面端有效；iOS Safari 忽略 beforeunload，改由 visibilitychange 兜底）
  window.addEventListener('beforeunload', handleBeforeUnload);

  // 🆕 iOS 移動端切後台/關閉時無法用 beforeunload，改在離開時自動保存到 localStorage 兜底
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden' && state.isDirty) {
      try {
        localStorage.setItem('md-editor-draft', elements.editor.value);
        localStorage.setItem('md-editor-draft-name', (state.currentFile && state.currentFile.name) || '');
      } catch (e) { /* 存儲滿/禁用時忽略 */ }
    }
  });
}

// ========== Markdown 工具列：一鍵插入標記 ==========

// 在編輯器光標處插入 before + 內容 + after。
// 有選中文字 → 包裹選中文字；無選中 → 插入占位符「文本」並選中，方便直接覆寫。
function insertMd(before, after) {
  const ta = elements.editor;
  const start = ta.selectionStart;
  const end = ta.selectionEnd;
  const selected = ta.value.substring(start, end);
  const body = selected || '文本';
  const replacement = before + body + after;

  ta.value = ta.value.substring(0, start) + replacement + ta.value.substring(end);

  const savedScrollTop = ta.scrollTop;
  ta.focus({ preventScroll: true });
  const newCursor = start + before.length;
  // 有選中 → 光標落在包裹後；無選中 → 選中「文本」二字方便覆寫
  ta.setSelectionRange(newCursor, newCursor + body.length);
  ta.scrollTop = savedScrollTop;

  // 程序化修改要手動觸發 input，保持 isDirty / 預覽 / 字數統計同步
  ta.dispatchEvent(new Event('input', { bubbles: true }));

  closeAllMdDropdowns();
}

// 構造 font-family 的 CSS 值：帶 fallback 鏈時按順序拼接，通用族名（serif/sans-serif/…）不加引號。
// MD 工具列共用，保證各處字體寫法一致（單一可信來源，對齊 todo 編輯器）。
function buildFontCssValue(name, fallbacks) {
  const list = [name].concat(fallbacks || []);
  return list.map(function (f) {
    const s = String(f);
    if (/^(serif|sans-serif|monospace|cursive|fantasy|system-ui|inherit)$/i.test(s)) return s;
    return "'" + s.replace(/'/g, "\\'") + "'";
  }).join(', ');
}

// 字體選擇器：把選中文字（或占位符）用 <span style="font-family:…"> 包裹。
// 用獨立函數避免 onclick 裡 font 名帶空格時的引號嵌套地獄。
function insertFont(family) {
  // 用 !important 確保覆蓋父元素繼承的 font-family（body 的 -apple-system 在 macOS 上就是 PingFang SC，
  // 不加 !important 時設苹方=設默認，看起來「沒效果」）
  const before = '<span style="font-family: ' + buildFontCssValue(family) + ' !important">';
  insertMd(before, '</span>');
}

// 字體選擇器（帶 fallback 鏈）：name 為首選字體，fallbacks 為候選回退列表。
function insertFontFamily(name, fallbacks, label) {
  const before = '<span style="font-family: ' + buildFontCssValue(name, fallbacks) + ' !important">';
  insertMd(before, '</span>');
}

// 自定義字體：讓用戶輸入任意 font-family（支持逗號分隔多個候選）
function insertCustomFont() {
  const input = window.prompt('輸入 font-family（可填多個，逗號分隔，如：Arial, sans-serif）', '');
  if (!input) return;
  const family = input.trim();
  if (!family) return;
  insertFont(family);
}

// 直接把「字面文本/字符」原樣寫到光標處（不經過 :短碼:，也不會套用「文本」占位符）。
// 供「HTML 實體」子菜單調用——這些項要插的就是空格字符或 HTML 實體文本（&nbsp; 等）本身，
// 而非把它們當作包裹選中文字的前/後綴，所以用單獨的 insertRaw 而非 insertMd。
function insertRaw(text) {
  if (!text) return;
  const ta = elements.editor;
  const start = ta.selectionStart;
  const end = ta.selectionEnd;
  ta.value = ta.value.substring(0, start) + text + ta.value.substring(end);
  const savedScrollTop = ta.scrollTop;
  ta.focus({ preventScroll: true });
  const newCursor = start + text.length;
  ta.setSelectionRange(newCursor, newCursor);
  ta.scrollTop = savedScrollTop;
  // 程序化修改要手動觸發 input，保持 isDirty / 預覽 / 字數統計同步
  ta.dispatchEvent(new Event('input', { bubbles: true }));
  closeAllMdDropdowns();
}

// 切換下拉菜單（點其它下拉或頁面空白自動關閉）
function toggleMdDropdown(btn) {
  const dropdown = btn.closest('[data-md-dropdown]');
  const wasOpen = dropdown && dropdown.classList.contains('open');
  closeAllMdDropdowns();
  if (dropdown && !wasOpen) {
    dropdown.classList.add('open');
    const menu = dropdown.querySelector('.md-dropmenu');
    if (menu) {
      const rect = btn.getBoundingClientRect();
      menu.style.top = (rect.bottom + 4) + 'px';
      menu.style.left = rect.left + 'px';
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(() => {
          const vw = window.innerWidth || document.documentElement.clientWidth;
          if (rect.left + menu.offsetWidth > vw - 8) {
            menu.style.left = Math.max(8, rect.right - menu.offsetWidth) + 'px';
          }
        });
      }
    }
  }
}

function closeAllMdDropdowns() {
  document.querySelectorAll('[data-md-dropdown].open').forEach((el) => {
    el.classList.remove('open');
    const menu = el.querySelector('.md-dropmenu');
    if (menu) { menu.style.top = ''; menu.style.left = ''; }
  });
}

// 開啟意圖：'calendar'＝便利貼路徑觸發（calStickyOpen 在沒有 calendar 檔時跳選單），
//   該輪選擇只收 calendar*.md，其餘 toast 拒絕／濾除，絕不誤開成主檔；選完成功自動開便利貼。
//   「開啟」鈕 / Cmd+O 傳 ''＝不設限（todo 卡片 JSON 等照舊可開）。
//   intent 在 handleFileSelect 開頭消費一次；使用者取消選單時 change 不觸發、intent 會殘留，
//   但所有入口都經 openFilePicker 覆寫它，殘留不會污染下一輪。
let fileOpenIntent = '';
function openFilePicker(intent) {
  fileOpenIntent = intent || '';
  elements.fileInput.click();
}

// 便利貼設定 JSON：檔名口徑與匯出檔一致（LITE 可攜檔＋桌面原生 state 檔）
function isStickySettingsJsonName(name) {
  return /^sticky-notes-(?:settings-.+|state)\.json$/i.test(String(name || ''));
}

// 開檔時一起選到的設定 JSON → 套用到剛開啟的 calendar 檔；
//   若還沒開 calendar（剛啟動先選 JSON），由 calStickyApplySettingsFile 依 JSON 自帶的
//   calendarFile 先寫入該檔的設定槽，等它被開啟時生效。
//   使用者一次選「calendar + 設定 JSON」就是明示意圖，故不再彈確認（opts.auto）。
async function applyPickedStickySettings(settingsFiles) {
  if (!settingsFiles || !settingsFiles.length) return false;
  if (typeof calStickyApplySettingsFile !== 'function') return false;
  const hasCal = (typeof isCalendarMd === 'function') && isCalendarMd();
  const current = String((state.currentFile && state.currentFile.name) || '');
  const ownName = hasCal
    ? 'sticky-notes-settings-' + current.replace(/\.md$/i, '').toLowerCase() + '.json'
    : '';
  const own = ownName ? settingsFiles.find((f) => f.name.toLowerCase() === ownName) : null;
  const file = own || settingsFiles[0];
  if (settingsFiles.length > 1) {
    showToast('已套用「' + file.name + '」，其餘 ' + (settingsFiles.length - 1) + ' 個設定檔略過', 'info');
  }
  try {
    return await calStickyApplySettingsFile(file, { auto: true });
  } catch (e) {
    console.error('[LITE] 自動套用便利貼設定失敗:', e);
    showToast('套用設定 JSON 失敗：' + ((e && e.message) || e), 'error');
    return false;
  }
}

// 處理文件選擇（「開啟」是唯一入口，可一次多選）
//   📎 多選規則（2026-10-24 使用者定稿口徑，與選擇先後無關）：
//     • 只選 1 個檔案 → 照舊開啟，並自動還原該主檔上次聯運過的檔案（本機快取）
//     • 有選 calendar.md → 以行事历判定應用類型；calendar.md 當主檔（行程本體可編輯），
//       其餘所有 calendar*.md 當只讀聯運檔（行程本體不可編輯，只有便利貼內容可改），排除所有非 calendar*.md
//     • 沒選 calendar.md 但有 calendar*.md → 同上以行事历判定；第一個 calendar*.md 當主檔，其餘聯運，排除非 calendar*.md
//     • 完全沒有 calendar*.md → 只認「第一個被選的檔案」當作業檔（二進位檔會被 isTextFile 拒絕），排除其餘所有
//   🛡️ intent='calendar'（便利貼路徑）：iOS 原生選單無法按檔名前綴過濾（accept=".md" 在本機實測
//     會把 .md 灰掉不可選），改在這裡嚴格校验——選錯檔零代價（拒絕＋說明），不會開錯主檔。
async function handleFileSelect(event) {
  const input = event.target;
  let files = Array.from(input.files || []);
  const intent = fileOpenIntent;
  fileOpenIntent = '';

  // 🛡️ 立即清空 input，允許下次重選「同一批」也能觸發 change（否則 iOS 會因 value 未變而不重發事件）。
  //    放在讀取之前（同步），避免異步讀取期間用戶再次選擇時 input 還未清空。
  input.value = '';

  if (!files.length) return;

  // 🆕 便利貼設定 JSON 可與 calendar 檔一起選（一次選「calendar.md + sticky-notes-settings-*.json」）：
  //   先分流出來，不當普通文字檔開啟，等主檔開好後自動套用。
  const settingsPicked = files.filter((f) => isStickySettingsJsonName(f.name));
  if (settingsPicked.length) files = files.filter((f) => !isStickySettingsJsonName(f.name));
  if (!files.length) {
    await applyPickedStickySettings(settingsPicked);
    return;
  }

  if (intent === 'calendar') {
    const picked = files.filter((f) => /^calendar.*\.md$/i.test(f.name));   // 與 calPlanOpenSet 同口徑
    if (!picked.length) {
      // 只選了設定 JSON → 直接套用（已有 calendar 檔就立刻生效；還沒開則等該檔開啟後生效）
      if (settingsPicked.length) {
        await applyPickedStickySettings(settingsPicked);
        if (typeof isCalendarMd === 'function' && isCalendarMd() && typeof calStickyOpen === 'function') calStickyOpen();
        return;
      }
      showToast('便利貼只開啟 calendar*.md：「' + files.map((f) => f.name).join('、') + '」這次未開啟', 'error');
      return;
    }
    if (picked.length !== files.length) {
      showToast('已濾除 ' + (files.length - picked.length) + ' 個非 calendar*.md，只開啟 calendar 檔', 'info');
    }
    files = picked;
  }

  // ① 單一檔案：完全沿用舊行為（含 todo 卡片 JSON、任何文字檔）
  if (files.length === 1) {
    const ok = await openSingleFile(files[0]);
    // 設定 JSON 跟著這批一起選 → 主檔就緒後立刻套用（不必再進便利貼選單按載入）
    let settingsApplied = false;
    if (ok && settingsPicked.length) settingsApplied = await applyPickedStickySettings(settingsPicked);
    // 🆕 開啟 calendar 後：本機設定資料不存在、且本次沒帶設定 JSON → 提醒去「開啟」載入備份
    if (ok && typeof calStickyAfterCalendarOpen === 'function') calStickyAfterCalendarOpen(settingsApplied);
    // 便利貼路徑：開啟成功就把便利貼開起來，讓「🗒 → 選檔 → 看貼」一次走完
    if (ok && intent === 'calendar' && typeof calStickyOpen === 'function') calStickyOpen();
    return;
  }

  // ② 多選：交給純函數判定主檔（calendar.md 優先，其餘 calendar*.md 當只讀聯運）
  const plan = (typeof calPlanOpenSet === 'function')
    ? calPlanOpenSet(files.map((f) => f.name))
    : { main: '', includes: [], others: [] };
  const byName = (n) => files.find((f) => f.name === n) || null;

  if (!plan.main) {
    // 完全沒有 calendar*.md（2026-10-24 使用者定的口徑）：只認「第一個被選的檔案」當作業檔，
    //   其餘全部排除（不靜默丟掉，toast 點名）。第一個若是二進位檔，openSingleFile 的 isTextFile 會拒絕。
    const first = files[0];
    const ok = await openSingleFile(first);
    if (ok) showToast('沒有 calendar*.md：只開啟第一個選擇的檔案「' + first.name + '」，其餘 ' + (files.length - 1) + ' 個已排除', 'info');
    return;
  }

  const main = byName(plan.main);
  if (!main) { showToast('找不到主檔「' + plan.main + '」', 'error'); return; }
  const includeFiles = plan.includes.map(byName).filter(Boolean);
  const others = plan.others;

  if (!(await openSingleFile(main))) return;   // 先開主檔（openSingleFile 內會從快取還原聯運清單）

  // ③ 這批還有其它 calendar*.md → 用「剛選的這一組」整組取代舊清單（不是疊加）
  if (includeFiles.length) {
    const picked = [];
    for (const f of includeFiles) {
      try { picked.push({ name: f.name, content: await readFileAsText(f) }); }
      catch (err) { console.error('讀取聯運檔失敗:', err); }
    }
    const replaced = (typeof calReplaceIncludes === 'function') ? calReplaceIncludes(picked) : true;
    if (!replaced) return;   // 使用者選擇保留既有修改（不覆蓋）
  }

  // 設定 JSON 也一起選了 → 主檔＋聯運檔都就緒後套用（樣式／關閉清單／頁次立即生效）
  let settingsApplied = false;
  if (settingsPicked.length) settingsApplied = await applyPickedStickySettings(settingsPicked);
  // 🆕 開啟 calendar 後：本機設定資料不存在、且本次沒帶設定 JSON → 提醒去「開啟」載入備份
  if (typeof calStickyAfterCalendarOpen === 'function') calStickyAfterCalendarOpen(settingsApplied);

  const bits = ['主檔：' + main.name + '（行程本體可編輯）'];
  if (includeFiles.length) bits.push('聯運 ' + includeFiles.length + ' 檔（只讀·便利貼可編輯）');
  if (settingsApplied) bits.push('便利貼設定：已套用 JSON');
  if (others.length) bits.push('略過 ' + others.length + ' 個非 calendar 檔');
  showToast(bits.join('；'), 'success');
  if (intent === 'calendar' && typeof calStickyOpen === 'function') calStickyOpen();
}

// 開啟單一檔案（handleFileSelect 的實作本體）：回傳是否成功
async function openSingleFile(file) {
  // 驗證文件類型：只收文字檔（對齊 todo 編輯器支援的類型）
  if (!isTextFile(file.name)) {
    showToast('不支援的檔案類型（僅支援文字檔：md / json / html / 程式碼 / csv …）', 'error');
    return false;
  }

  try {
    showToast('正在讀取文件...', 'success');

    const content = await readFileAsText(file);

    // 🆕 事前解析：如果是 todo 卡片結構的 JSON，編輯器只載入 text 字段；
    //    原物件另存到 state.originalTodo，存檔時再合回去。
    //    這樣所有附加字段（tags/bgColor/attachments/createdAt/completedAt…）都不會被破壞。
    let editorContent = content;
    let todoMode = false;
    let originalTodo = null;
    if (classifyFileType(file.name) === 'json' && isTodoJson(content)) {
      originalTodo = JSON.parse(content);
      editorContent = originalTodo.text || '';
      todoMode = true;
      showToast(`已開啟 todo 卡片：${file.name}（只編輯正文，原結構保存時合併）`, 'success');
    } else {
      showToast(`已開啟：${file.name}`, 'success');
    }

    // 更新狀態
    state.currentFile = {
      name: file.name,
      file: file,
      path: file.webkitRelativePath || file.name,
      type: classifyFileType(file.name)
    };
    state.lastContent = editorContent;
    state.isDirty = false;
    state.todoMode = todoMode;
    state.originalTodo = originalTodo;

    // 📎 多檔聯運：若本主檔先前已「加入」過其它 calendar*.md，從 localStorage 快取還原併入清單
    //    （避免 iCloud 文件選擇器無法一次多選/難以重選的痛點；還原後自動重併顯示，不寫回主檔）
    if (typeof calRestoreIncludes === 'function') calRestoreIncludes(file.name);

    // 更新 UI
    elements.editor.value = editorContent;
    elements.fileName.textContent = file.name;
    updateTodoModeBadge();   // 顯示「todo 卡片模式」徽章，讓用戶知道保存行為不同
    updatePreview();
    updateWordCount();
    updateStatus();

    // 🆕 開啟 .md 文件 → 自動切到「分屏」視圖，同時看到編輯與預覽。
    // 預設是 edit 視圖（純文字），用戶可能誤以為「沒預覽」；切到 split 立即展示 Markdown 渲染結果。
    // todo 卡片模式（json 但 text 是 md）也走 split，這樣能看到渲染效果；其他 json/html/程式碼 保持 edit。
    // 📅 calendar.md（行程應用數據文件）→ 自動切到「行程」視圖，只讀查看行程列表
    dispatchDataAwareEditor();
    return true;

  } catch (error) {
    console.error('讀取文件失敗:', error);
    showToast(`讀取失敗：${error.message}`, 'error');
    return false;
  }
}

// 顯示/隱藏 todo 卡片模式徽章（避免用戶存檔時不知道會合併原結構）
function updateTodoModeBadge() {
  const el = document.getElementById('todo-mode-badge');
  if (!el) return;
  el.style.display = state.todoMode ? '' : 'none';
}

// 讀取文件內容
function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => resolve(e.target.result);
    reader.onerror = (e) => reject(new Error('無法讀取文件'));
    reader.readAsText(file, 'UTF-8');
  });
}

// ⚠️ 不提供「刷新（重读当前文件）」按钮：iOS 文件选择器返回的 File 對象是內容快照，
//    重讀拿不到 iCloud 的最新內容（永遠同一份），功能無意義。要拿最新內容請重新「開啟」文件。

// 重置：清除所有本地緩存（localStorage / Service Worker 快取）並重新載入整個應用。
// 用途：當 iCloud 檔案內容看起來「沒更新」時，釋放快取後整頁重載，強制回到乾淨狀態。
// 🛡️ 防誤按：需輸入授權碼 123456 才執行。
async function handleReset() {
  // 確認閘門：要求輸入 123456，未輸入正確授權碼一律中止。
  let input = null;
  try {
    input = window.prompt('此操作會清除所有快取並重新載入。\n請輸入授權碼 123456 以繼續：', '');
  } catch (_) {
    input = null;
  }
  if (input !== '123456') {
    showToast('已取消重置（授權碼不正確）', 'error');
    return;
  }

  try {
    // 1) 清空本程式的 localStorage（主題/視圖/草稿等全部清除）
    localStorage.clear();

    // 2) 清空 Cache Storage（Service Worker 緩存，可能快取舊的 index.html/app.js）
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }

    // 3) 註銷 Service Worker（讓下次載入走全新註冊，避免舊 SW 繼續伺服舊資源）
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }

    // 4) 強制重新載入（繞過 HTTP 快取）
    showToast('已清除所有快取，正在重新載入...', 'success');
    setTimeout(() => {
      window.location.reload();
    }, 300);
  } catch (error) {
    console.error('重置失敗:', error);
    // 即使部分步驟失敗，仍嘗試重載
    showToast('重置中，重新載入...', 'info');
    setTimeout(() => {
      window.location.reload();
    }, 300);
  }
}

// 保存文件。
//   target（可選）：
//     'all'（預設）＝ 原本行為：主檔＋所有待寫回聯運檔一次存（頂欄「保存」主按鈕＝此值）；
//     'main'        ＝ 只存主檔，不動聯運檔；
//     'include:<檔名>' ＝ 只存指定聯運檔（角標會隨之遞減）。
async function handleSave(target) {
  target = target || 'all';
  const onlyInclude = (typeof target === 'string' && target.indexOf('include:') === 0)
    ? target.slice('include:'.length) : null;
  // 要匯出的聯運檔清單（依 target 縮減：只存某一個聯運檔 / 只存主檔＝空 / 全部＝所有 pending）
  const wantIncludes = onlyInclude
    ? [onlyInclude]
    : (target === 'main' ? [] : calPendingIncludes().map((f) => f.name));

  // 只存單一聯運檔：完全不碰主檔（dirty 角標由 calRenderIncludeBar 在匯出後自動遞減）
  if (onlyInclude) {
    if (typeof calSaveIncludeFile === 'function') await calSaveIncludeFile(onlyInclude);
    return;
  }

  // 只存便利貼設定 JSON（保存下拉選單的單獨項目）
  if (target === 'sticky-settings') {
    if (typeof calStickyExportSettings === 'function') await calStickyExportSettings();
    updateStatus();
    return;
  }

  const rawContent = elements.editor.value;

  // 🆕 todo 卡片模式：把改後的正文合回原始物件再整體序列化，
  //    確保 tags / bgColor / attachments / createdAt / completedAt 等附加字段一個不丟。
  //    對齊 todo 編輯器 openExternalFile / saveExternalTodo 的「Object.assign」做法。
  let content = rawContent;
  let saveAsJson = false;  // todo 模式下要走 JSON.stringify
  if (state.todoMode && state.originalTodo) {
    const merged = Object.assign({}, state.originalTodo, {
      text: rawContent,
      updatedAt: Date.now()
    });
    content = JSON.stringify(merged, null, 2);
    saveAsJson = true;
  }

  // 🆕 便利貼設定 JSON：跟主檔／聯運檔共用同一顆保存鍵。
  //    只在「全部保存」時附帶；下拉選單選「主檔」就只存主檔。
  const settingsExtra = [];
  if (target !== 'main' && typeof calStickySettingsDirty === 'function' && calStickySettingsDirty()
      && typeof calStickySettingsFile === 'function') {
    try { settingsExtra.push(calStickySettingsFile()); }
    catch (e) { console.warn('[LITE] 便利貼設定檔組裝失敗:', e); }
  }

  // 只存主檔但主檔沒改 → 無東西可存（聯運檔另有下拉清單可個別存）
  if (target === 'main' && !state.isDirty && state.currentFile) {
    showToast('主檔沒有修改，無需保存', 'info');
    return;
  }

  // 只改了聯運檔／便利貼設定（主檔緩衝沒動）：不要把主檔再存一次，直接匯出待寫回的檔案
  //   —— 否則 iOS 會為一個「沒改的主檔」也彈一次分享面板
  if (!state.isDirty && state.currentFile && (wantIncludes.length || settingsExtra.length)) {
    const res = await calExportIncludes(wantIncludes, { extra: settingsExtra });
    if (settingsExtra.length && res.saved.indexOf(settingsExtra[0].name) >= 0) calStickyMarkSettingsSaved();
    return;
  }

  // 如果是新文件（未開啟過），提示輸入檔名後存出
  if (!state.currentFile) {
    const name = promptFilename('untitled.md');
    if (name === null) return; // 用戶取消
    const how = await saveViaMobile(content, name);
    state.isDirty = false;
    state.lastContent = rawContent;  // 編輯器層面仍記 rawContent
    state.currentFile = { name, file: null, path: name, type: classifyFileType(name) };
    elements.fileName.textContent = name;
    updateStatus();
    showToast(how === 'shared'
      ? '已送出存檔：在分享面板選「儲存到檔案」選位置即可'
      : '已下載新文件', 'success');
    return;
  }

  try {
    showToast(saveAsJson ? '正在合併保存 todo 卡片...' : '正在保存...', 'success');

    // 創建 Blob（按實際副檔名給對應 MIME）
    const blob = new Blob([content], { type: mimeFor(state.currentFile.name) + ';charset=utf-8' });

    // 🛡️ showSaveFilePicker 只有桌面 Chromium（Chrome/Edge/Opera）有；
    // Safari / Firefox / 所有行動端都沒有（MDN 相容性表確認）。
    // 先探測再用，避免在 iOS 上 await 到 undefined 直接拋 TypeError。
    const canPick = ('showSaveFilePicker' in window) && (typeof window.showSaveFilePicker === 'function');
    if (canPick) {
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: state.currentFile.name,
          types: [{
            description: '文字檔',
            accept: {
              'text/markdown': ['.md', '.markdown'],
              'text/plain': ['.txt', '.log', '.csv', '.tsv'],
              'text/html': ['.html', '.htm'],
              'application/json': ['.json', '.json5', '.jsonc']
            }
          }]
        });

        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();

        state.isDirty = false;
        state.lastContent = rawContent;
        // todo 模式成功保存後，把合併後的物件當成新的 originalTodo，便於後續再次保存時 baseline 正確
        if (saveAsJson) state.originalTodo = JSON.parse(content);
        showToast(saveAsJson
          ? `已合併保存 todo 卡片：${state.currentFile.name}`
          : `已保存：${state.currentFile.name}`, 'success');
        // 📎 聯運檔／便利貼設定也待寫回時，順手逐檔存回（桌面走 picker，直接寫進所選路徑）
        if ((wantIncludes.length || settingsExtra.length) && typeof calExportIncludes === 'function') {
          const res = await calExportIncludes(wantIncludes, { extra: settingsExtra });
          if (settingsExtra.length && res.saved.indexOf(settingsExtra[0].name) >= 0) calStickyMarkSettingsSaved();
        }
      } catch (abortErr) {
        // 用戶在保存對話框點取消（AbortError）—— 靜默，不算錯誤
        if (abortErr && abortErr.name !== 'AbortError') throw abortErr;
      }
    } else {
      // 🍎 iOS / Android：沒有 showSaveFilePicker，
      // 首選系統分享面板（可選「儲存到檔案」直接覆蓋原檔），不行才退回下載。
      // 📎 若同時有聯運檔／便利貼設定待寫回：整批送出（主檔在前），
      //    iOS 每個檔案各彈一次面板，每次選同一資料夾並確認替換即可。
      if ((wantIncludes.length || settingsExtra.length) && typeof calExportIncludes === 'function') {
        const res = await calExportIncludes(wantIncludes, {
          extra: [{ name: state.currentFile.name, content }].concat(settingsExtra),
          silent: true   // 整批結果由這裡統一回報，避免兩個 toast 互相蓋掉
        });
        if (res.canceled) return;   // 使用者取消 → 主檔也不算已保存（維持未保存狀態，可再按）
        state.isDirty = false;
        state.lastContent = rawContent;
        if (saveAsJson) state.originalTodo = JSON.parse(content);
        if (settingsExtra.length && res.saved.indexOf(settingsExtra[0].name) >= 0) calStickyMarkSettingsSaved();
        showToast('已送出 ' + res.saved.length + ' 個檔案（主檔／聯運檔／便利貼設定）：在分享面板選「儲存到檔案」→ 選原資料夾 → 覆蓋', 'success');
      } else {
        const how = await saveViaMobile(content, state.currentFile.name);
        state.isDirty = false;
        state.lastContent = rawContent;
        // 行動端無法直接讀回保存後的內容，保留原 originalTodo；下次的保存仍以原結構為基礎
        if (saveAsJson) state.originalTodo = JSON.parse(content);
        showToast(saveAsJson
          ? (how === 'shared'
              ? '已送出 todo 卡片：在分享面板選「儲存到檔案」→ 選原位置 → 覆蓋'
              : '已下載 todo 卡片：點下載項 → 分享 → 儲存到檔案')
          : (how === 'shared'
              ? '已送出存檔：點「儲存到檔案」→ 選原位置 → 覆蓋'
              : '已下載文件：點下載項 → 分享 → 儲存到檔案 可存回 iCloud'), 'success');
      }
    }

    updateStatus();   // ← 已含 calRenderIncludeBar()（主檔 dirty 已清）

  } catch (error) {
    // 用戶在保存對話框/分享面板點取消 → 靜默，不算錯誤、也不標成已存檔
    if (error && error.name === 'AbortError') return;
    console.error('保存失敗:', error);
    showToast(`保存失敗：${error.message}`, 'error');
  }
}

// 🆕 保存 combo：下拉選單列出「可保存的檔案」（主檔＋各待寫回聯運檔），點選只存那一份
function renderSaveMenu() {
  const menu = elements.btnSaveMenu;
  if (!menu) return;
  menu.innerHTML = '';
  const items = [];
  if (state.isDirty && state.currentFile) {
    items.push({ label: state.currentFile.name, sub: '主檔', target: 'main' });
  }
  const inc = (typeof calPendingIncludes === 'function') ? calPendingIncludes() : [];
  inc.forEach((f) => items.push({ label: f.name, sub: '聯運檔', target: 'include:' + f.name }));
  // 🆕 便利貼設定：可只存這一份（不重存主檔／聯運檔）
  if (typeof calStickySettingsDirty === 'function' && calStickySettingsDirty()
      && typeof calStickySettingsFileName === 'function') {
    items.push({ label: calStickySettingsFileName(), sub: '便利貼設定', target: 'sticky-settings' });
  }
  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'btn-save-menu-empty';
    empty.textContent = '沒有未保存的修改';
    menu.appendChild(empty);
    return;
  }
  items.forEach((it) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'btn-save-menu-item';
    b.setAttribute('role', 'menuitem');
    b.dataset.saveTarget = it.target;
    b.innerHTML = '<span class="bmi-ic">📄</span>' +
      '<span class="bmi-name"></span><span class="bmi-sub"></span>';
    b.querySelector('.bmi-name').textContent = it.label;
    b.querySelector('.bmi-sub').textContent = it.sub;
    menu.appendChild(b);
  });
}

function toggleSaveMenu(force) {
  const combo = elements.btnSaveCombo;
  const menu = elements.btnSaveMenu;
  const caret = elements.btnSaveCaret;
  if (!combo || !menu || !caret) return;
  const open = (typeof force === 'boolean') ? force : menu.hasAttribute('hidden');
  if (open) {
    renderSaveMenu();
    menu.removeAttribute('hidden');
    caret.setAttribute('aria-expanded', 'true');
  } else {
    menu.setAttribute('hidden', '');
    caret.setAttribute('aria-expanded', 'false');
  }
}

function closeSaveMenu() { toggleSaveMenu(false); }

// 詢問檔名（新文件保存時）；取消返回 null
function promptFilename(fallback) {
  let name = null;
  try {
    // 桌面端可用 prompt；移動端 PWA 環境 prompt 常被禁用，直接退回 fallback
    const input = window.prompt('請輸入檔名：', fallback);
    name = (input && input.trim()) ? input.trim() : null;
  } catch (e) {
    name = null;
  }
  if (!name) name = fallback;
  // 補副檔名：優先沿用當前文件的副檔名，否則補 .md
  const current = state.currentFile && state.currentFile.name;
  const dot = name.lastIndexOf('.');
  if (dot <= 0) {
    const curExt = current ? current.slice(current.lastIndexOf('.')) : '';
    if (curExt && curExt.length > 1 && curExt !== '.') {
      name += curExt;
    } else {
      name += '.md';
    }
  }
  return name;
}

// 副檔名 → MIME（iOS 分享面板 / 下載靠它判斷存成什麼檔）
function mimeFor(filename) {
  const lower = (filename || '').toLowerCase();
  const ext = lower.slice(lower.lastIndexOf('.'));
  const map = {
    '.md': 'text/markdown', '.markdown': 'text/markdown', '.mdx': 'text/markdown',
    '.txt': 'text/plain', '.text': 'text/plain', '.log': 'text/plain', '.csv': 'text/csv',
    '.tsv': 'text/tab-separated-values',
    '.html': 'text/html', '.htm': 'text/html',
    '.json': 'application/json', '.json5': 'application/json', '.jsonc': 'application/json',
    '.yaml': 'text/yaml', '.yml': 'text/yaml', '.toml': 'text/plain', '.ini': 'text/plain',
    '.conf': 'text/plain', '.config': 'text/plain', '.properties': 'text/plain',
    '.cfg': 'text/plain', '.xml': 'application/xml',
    '.js': 'text/javascript', '.mjs': 'text/javascript', '.cjs': 'text/javascript',
    '.jsx': 'text/javascript', '.ts': 'text/plain', '.tsx': 'text/plain',
    '.vue': 'text/plain', '.svelte': 'text/plain',
    '.css': 'text/css', '.scss': 'text/css', '.less': 'text/css',
    '.py': 'text/x-python', '.rb': 'text/plain', '.sh': 'text/x-shellscript',
    '.bash': 'text/x-shellscript', '.zsh': 'text/x-shellscript', '.fish': 'text/x-shellscript',
    '.ps1': 'text/plain', '.bat': 'text/plain', '.cmd': 'text/plain',
    '.sql': 'application/sql', '.graphql': 'text/plain', '.gql': 'text/plain',
    '.c': 'text/x-c', '.h': 'text/x-c', '.cpp': 'text/x-c++src', '.cc': 'text/x-c++src',
    '.hpp': 'text/x-c++src', '.java': 'text/x-java', '.kt': 'text/plain', '.go': 'text/plain',
    '.rs': 'text/plain', '.swift': 'text/plain',
    '.php': 'text/plain', '.lua': 'text/plain', '.r': 'text/plain', '.cs': 'text/plain',
    '.scala': 'text/plain', '.dart': 'text/plain', '.ex': 'text/plain', '.erl': 'text/plain',
    '.env': 'text/plain', '.gitignore': 'text/plain', '.editorconfig': 'text/plain',
    '.tex': 'text/plain', '.rst': 'text/plain', '.diff': 'text/plain', '.patch': 'text/plain'
  };
  return map[ext] || 'text/plain';
}

// 副檔名 → highlight.js 語言類別（非 md 檔在預覽裡用語法高亮）
function hljsLangFor(filename) {
  const lower = (filename || '').toLowerCase();
  const ext = lower.slice(lower.lastIndexOf('.'));
  const map = {
    '.js': 'javascript', '.mjs': 'javascript', '.cjs': 'javascript', '.jsx': 'javascript',
    '.ts': 'typescript', '.tsx': 'typescript',
    '.json': 'json', '.json5': 'json', '.jsonc': 'json',
    '.html': 'xml', '.htm': 'xml', '.xml': 'xml', '.vue': 'xml', '.svelte': 'xml',
    '.css': 'css', '.scss': 'scss', '.less': 'less',
    '.py': 'python', '.rb': 'ruby',
    '.sh': 'bash', '.bash': 'bash', '.zsh': 'bash', '.fish': 'bash',
    '.sql': 'sql', '.yaml': 'yaml', '.yml': 'yaml',
    '.c': 'c', '.h': 'c', '.cpp': 'cpp', '.cc': 'cpp', '.hpp': 'cpp',
    '.java': 'java', '.go': 'go', '.rs': 'rust', '.swift': 'swift',
    '.php': 'php', '.lua': 'lua', '.kt': 'kotlin', '.cs': 'csharp',
    '.scala': 'scala', '.dart': 'dart', '.ex': 'elixir', '.erl': 'erlang',
    '.r': 'r', '.diff': 'diff', '.patch': 'diff', '.ini': 'ini', '.toml': 'ini',
    '.md': 'markdown', '.markdown': 'markdown'
  };
  return map[ext] || '';
}

// 能否用系統分享面板傳「檔案」（iOS 15+ Safari 支援，是行動端唯一像樣的存檔出口）
function canShareFiles() {
  try {
    if (typeof navigator.share !== 'function' || typeof navigator.canShare !== 'function') return false;
    const probe = new File([''], 'probe.txt', { type: 'text/plain' });
    return !!navigator.canShare({ files: [probe] });
  } catch (e) {
    return false;
  }
}

// 透過系統分享面板把內容當檔案交出去（iOS 會彈原生面板，可「儲存到檔案」存回 iCloud Drive）
// 用戶在面板點取消會丟 AbortError，由外層統一靜默
//
// ⚠️ 重要：只传 files，不传 title。
// iOS 的「儲存到檔案」擴展會把 share 物件裡**每個字段**都算成一個待存項目：
// title 也算 1 項（變成一份純文字副檔名無副檔名的 .txt），
// 所以帶 title 時面板底部會顯示「保存為 2 項」並多存一個奇怪檔案。
// 檔名由 File 物件的 .name 屬性提供，iOS 儲存時自然用它，無需 title。
async function shareFile(content, filename) {
  const file = new File([content], filename, { type: mimeFor(filename) });
  await navigator.share({ files: [file] });
}

// 行動端保存路徑：優先分享面板，不支援才退回下載。回傳 'shared' | 'downloaded'
async function saveViaMobile(content, filename) {
  if (canShareFiles()) {
    await shareFile(content, filename);
    return 'shared';
  }
  downloadFile(content, filename);
  return 'downloaded';
}

// 下載文件（最後兜底）
function downloadFile(content, filename) {
  const blob = new Blob([content], { type: mimeFor(filename) + ';charset=utf-8' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);
}

// 📅 资料感知编辑器分派：文件成为「当前」时，若有专属编辑器（calendar.md → 行程视图）优先启用；
// 否则回退默认编辑器（照旧）。集中此处，未来新增特性编辑器只需在此加一个分支。
function dispatchDataAwareEditor() {
  // 切換檔案：便利貼彈層關閉，並改用該檔的偏好命名空間（calendar.md 之間各自獨立）
  if (typeof calStickyOnFileChange === 'function') calStickyOnFileChange();
  updateEventsTabVisibility();
  if (isCalendarMd()) {
    setView('events');
  } else if (state.currentFile.type === 'md' || state.todoMode) {
    setView('split');
  }
}

// 切換視圖：edit / preview / split
function setView(view) {
  if (VIEWS.indexOf(view) === -1) view = 'edit';
  state.view = view;

  // 誰顯示完全交給 CSS（容器上的 data-view），JS 不逐個加減 class
  elements.editorContainer.dataset.view = view;

  // 行號邊条輪詢：進入含編輯區的視圖時自啟（離開後 tick 下一帧自停，不必逐處掛鉤）
  if (view === 'edit' || view === 'split') editorGutter.start();

  // MD 編輯工具列（格式/字體/段落/表格計算/鏈接跳轉…）只在「要編輯文本」的視圖顯示：
  // edit（編輯文本）/ split（分屏，含編輯區）顯示；preview（MD 預覽）與 events（行事曆）隱藏。
  if (elements.mdToolbar) elements.mdToolbar.style.display = (view === 'edit' || view === 'split') ? '' : 'none';

  elements.tabbar.querySelectorAll('.tab').forEach((tab) => {
    tab.classList.toggle('active', tab.dataset.view === view);
  });

  updatePreview();
  saveSettings();
}

// 更新預覽
function updatePreview() {
  const content = elements.editor.value;

  // 預覽不可見時不浪費渲染（純編輯模式完全看不到）
  if (state.view === 'edit') return;

  // 📅 行程視圖（calendar.md 專用）：渲染行程列表 / 月曆而非 markdown
  if (state.view === 'events') {
    // 📆 進入程式首次進入行程視圖：自動「按今天」→ 年視圖滾到當月 / 月視圖滾到今天
    //    （對齊使用者習慣：進入畫面即見當月曆；其餘切換回行程視圖不再重複滾動）
    if (!calStartupAutoScrollDone && isCalendarMd()) {
      state.calCursor = new Date();
      state.calSelectedDate = calendarFmtDate(new Date());
      state.calListSel = calendarFmtDate(new Date());
      calAutoScrollToTodayPending = true;
      calStartupAutoScrollDone = true;
    }
    renderEventsContent();
    return;
  }

  // 🛡️ 防護：hljs 是外部 CDN，加載失敗時不讓整頁崩潰（md 渲染管線自帶 marked 可用性檢查）
  const hasHljs = (typeof hljs !== 'undefined' && typeof hljs.highlightElement === 'function');

  // 非 Markdown 檔（json/html/code/csv…）：預覽直接顯示語法高亮的純文字，不跑 marked
  // 例外：todo 卡片模式（.json 但 text 字段是 Markdown）→ 仍當 Markdown 渲染
  const type = (state.currentFile && state.currentFile.type) || 'md';
  if (type !== 'md' && !state.todoMode) {
    const lang = hljsLangFor(state.currentFile ? state.currentFile.name : '');
    const langClass = lang ? ` class="language-${lang}"` : '';
    elements.preview.innerHTML = `<pre><code${langClass}>${escapeHtml(content || '')}</code></pre>`;
    if (hasHljs) {
      elements.preview.querySelectorAll('pre code').forEach((block) => {
        try { hljs.highlightElement(block); } catch (e) { /* 未註冊語言跳過 */ }
      });
    }
    return;
  }

  // Markdown / todo 卡片模式：使用移植自 todo 編輯器的完整渲染管線
  // （calc/sort/cols/katex/emoji/圖片定寬高/並排圖組/目錄… 與主程式一致）。
  // 帶 force:true 表示這是「原文 → 渲染」而非已渲染 HTML 的再處理。
  if (typeof renderMarkdown !== 'function') {
    elements.preview.innerHTML = '<p class="error">Markdown 渲染管線未載入（請檢查網絡連線後重新整理）</p>';
    return;
  }

  try {
    elements.preview.innerHTML = renderMarkdown(content || '', { force: true });
  } catch (error) {
    console.error('預覽渲染失敗:', error);
    elements.preview.innerHTML = '<p class="error">預覽渲染失敗：' + (error && error.message ? error.message : error) + '</p>';
  }
}

// HTML 跳脫（非 md 檔預覽時避免內容被當 HTML 解析）
function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}


// 切換暗色模式
function toggleTheme() {
  state.isDarkMode = !state.isDarkMode;
  document.body.classList.toggle('dark-mode', state.isDarkMode);
  saveSettings();
  // 主題切換後預覽區的程式碼高亮配色需重繪
  if (state.view !== 'edit') updatePreview();
}

// 更新字數統計
function updateWordCount() {
  const content = elements.editor.value;
  const chars = content.length;
  const words = content.trim() ? content.trim().split(/\s+/).length : 0;
  const lines = content.split('\n').length;
  
  elements.wordCount.textContent = `${chars} 字元 | ${words} 詞 | ${lines} 行`;
}

// 更新狀態
function updateStatus() {
  // 🆕 角標刷新：主檔 dirty（state.isDirty）或 include dirty 任一變化都要重算
  //    匯入 calRenderIncludeBar（calendar-editor.js）——它同時更新頂欄「保存」按鈕角標與 combo 菜單 toggle 角標
  if (typeof calRenderIncludeBar === 'function') calRenderIncludeBar();

  // 📎 多檔聯運：聯運檔（include）的修改也存在本機、也需要「保存」才寫回原檔，
  //   所以保存鍵是否可按＝主檔髒 **或** 有聯運檔待寫回；否則只改聯運檔時按鈕是灰的，
  //   使用者會以為「沒東西可存」（2026-10-23 實測回饋）。
  const incDirty = (typeof calPendingIncludes === 'function') ? calPendingIncludes().length : 0;
  // 🆕 便利貼設定也走同一顆保存鍵：改了樣式／關閉清單但還沒寫回 JSON 時要亮角標
  const stickyDirty = (typeof calStickySettingsDirty === 'function') ? calStickySettingsDirty() : false;
  const canSave = !!state.isDirty || incDirty > 0 || stickyDirty;
  const status = state.isDirty
    ? '● 未保存的更改'
    : (incDirty
        ? '● ' + incDirty + ' 個聯運檔未寫回'
        : (stickyDirty ? '● 便利貼設定未寫回 JSON' : '就緒'));
  elements.statusText.textContent = status;
  elements.btnSave.disabled = !canSave;
  elements.btnSave.style.opacity = canSave ? '1' : '0.5';
  if (elements.btnSaveCaret) {
    elements.btnSaveCaret.disabled = !canSave;
    elements.btnSaveCaret.style.opacity = canSave ? '1' : '0.5';
    if (!canSave) closeSaveMenu();
  }
  const what = [];
  if (state.isDirty) what.push('主檔');
  if (incDirty) what.push(incDirty + ' 個聯運檔');
  if (stickyDirty) what.push('便利貼設定 JSON');
  elements.btnSave.title = canSave
    ? '保存到 iCloud：' + what.join('、')
    : '保存文件到 iCloud';
}

// 處理鍵盤快捷鍵
function handleKeyboard(e) {
  // Ctrl/Cmd + S 保存
  if ((e.ctrlKey || e.metaKey) && e.key === 's') {
    e.preventDefault();
    // 行程編輯表單打開時：先寫入緩衝（不關窗，繼續編輯），再落盤保存
    if (elements.evFormOverlay && elements.evFormOverlay.style.display === 'flex' && typeof saveEventForm === 'function') {
      saveEventForm(false);
    }
    handleSave();
  }
  
  // Ctrl/Cmd + O 開啟
  if ((e.ctrlKey || e.metaKey) && e.key === 'o') {
    e.preventDefault();
    openFilePicker('');
  }
  
  // Ctrl/Cmd + P 循環切換視圖（編輯 → 預覽 → 分屏）
  if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
    e.preventDefault();
    setView(VIEWS[(VIEWS.indexOf(state.view) + 1) % VIEWS.length]);
  }
  
  // Ctrl/Cmd + B 切換主題
  if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
    e.preventDefault();
    toggleTheme();
  }

  // Esc：行程表單打開 → 走 closeEventForm（有 dirty guard）；便利貼有自己的 Esc 處理
  if (e.key === 'Escape') {
    if (elements.evFormOverlay && elements.evFormOverlay.style.display === 'flex' && typeof closeEventForm === 'function') {
      e.preventDefault();
      closeEventForm();
    }
  }
}

// 頁面卸載前提示
function handleBeforeUnload(e) {
  if (state.isDirty) {
    e.preventDefault();
    e.returnValue = '';
  }
}

// 顯示提示消息
function showToast(message, type = 'info', duration = 3000, persistent = false) {
  const t = elements.toast;
  if (elements.toastMsg) elements.toastMsg.textContent = message;
  else t.textContent = message;
  // 🆕 persistent＝常駐提醒：不自動關閉，顯示 ✕ 關閉鈕，由使用者手動關閉
  t.className = `toast ${type}` + (persistent ? ' show closable' : ' show');
  if (elements.toastClose) elements.toastClose.style.display = persistent ? '' : 'none';
  if (showToast._timer) { clearTimeout(showToast._timer); showToast._timer = null; }
  if (!persistent) {
    showToast._timer = setTimeout(() => { t.classList.remove('show'); }, duration);
  }
}
// 🆕 手動關閉訊息（常駐提醒的 ✕ 鈕呼叫）
function hideToast() {
  if (elements.toast) elements.toast.classList.remove('show');
}

// 本地存儲設置
function saveSettings() {
  try {
    localStorage.setItem('md-editor-theme', state.isDarkMode ? 'dark' : 'light');
    localStorage.setItem('md-editor-view', state.view);
  } catch (e) { /* 私密模式/存儲禁用時忽略 */ }
}

function loadSettings() {
  let theme = null;
  try {
    theme = localStorage.getItem('md-editor-theme');
    const savedView = localStorage.getItem('md-editor-view');
    if (VIEWS.indexOf(savedView) !== -1) state.view = savedView;
  } catch (e) { /* 忽略 */ }
  // 預設暗色：只有「顯式存過 light」才切白天；其餘（無記錄 or dark）一律保持暗色。
  if (theme === 'light') {
    state.isDarkMode = false;
    document.body.classList.remove('dark-mode');
  } else {
    state.isDarkMode = true;
    document.body.classList.add('dark-mode');
  }
}

// 🆕 恢復上次離開時未保存的草稿（iOS 關閉頁面時自動備份）
function restoreDraft() {
  try {
    const draft = localStorage.getItem('md-editor-draft');
    if (draft != null && draft !== '') {
      const name = localStorage.getItem('md-editor-draft-name') || '';
      elements.editor.value = draft;
      if (name) {
        state.currentFile = { name, file: null, path: name };
        elements.fileName.textContent = name;
      }
      state.lastContent = draft;
      state.isDirty = false;
      updateStatus();
      // 恢復後清除草稿，避免下次重複覆蓋
      localStorage.removeItem('md-editor-draft');
      localStorage.removeItem('md-editor-draft-name');
      // 📅 草稿若是 calendar.md → 把 state.view 直接改成 events；
      //    後面 init() 的 setView(state.view) 會走一次單渲染，calStartupAutoScrollDone
      //    守衛在 updatePreview 裡設 calAutoScrollToTodayPending=true →
      //    renderEventsContent → calQueueScrollActiveViewToToday 等容器就位後滾到今天。
      //    ⚠️ 這裡千萬別先調 dispatchDataAwareEditor()——它會在 restoreDraft 階段先 render 一次，
      //    然後 init() 又 setView 再 render 一次，第二次消費掉 pending（已是 false）→ 不滾。
      if (isCalendarMd()) state.view = 'events';
      updateEventsTabVisibility();
      showToast('已恢復上次未保存的內容', 'info');
      // 🆕 啟動恢復的是 calendar 檔、且本機設定資料不存在、也沒載入設定 JSON → 提醒去「開啟」載入備份
      if (typeof calStickyAfterCalendarOpen === 'function') calStickyAfterCalendarOpen(false);
    }
  } catch (e) { /* 忽略 */ }
}

// ── 文本編輯模式：左側「只讀」行號邊条（與桌面 #taskText、便利貼 #editArea 同源同義，算法 lockstep）──
//  · 行號只顯示、不可編輯（pointer-events:none），是編輯器的固有裝飾（空文档也算 1 行）。
//  · 離屏 mirror 常駐 DOM ＋ 鏡像行與行號節點池化：一次調用裡「寫」全在前、「讀」集中一批 →
//    每帧只強制排版一次，打字延遲隨行數線性而非平方增長。
//  · 改邊条寬 → textarea 重排後，clientWidth 是同一趟讀到的新值，mirror 立刻按新寬量測，
//    故不需要 _settling 二次 rAF 復檢（那趟復檢會讓行號滯後一帧、舊行號殘留可見）。
function createLineGutter(cfg) {
  function els() {
    return {
      ta: document.getElementById(cfg.taId),
      wrap: cfg.wrapId ? document.getElementById(cfg.wrapId) : null,
      gutter: document.getElementById(cfg.gutterId),
      inner: document.getElementById(cfg.innerId),
    };
  }
  let mirror = null;
  const mirrorLines = [];
  const mirrorTexts = [];
  const nums = [];
  let layoutKey = '';
  let raf = null;
  let lastSig = null;
  let lastScrollTop = null;

  function lineHeightPx(cs) {
    const lh = cs.lineHeight;
    const fs = parseFloat(cs.fontSize) || 13;
    // 行高可能是無量綱數值（如 1.7）或 normal，須解析成 px 才能用於邊条數字盒
    if (!lh || lh === 'normal') return fs * 1.2;
    if (lh.indexOf('px') >= 0) return parseFloat(lh);
    return parseFloat(lh) * fs;
  }
  function ensureMirror() {
    if (mirror) return mirror;
    const m = document.createElement('div');
    m.setAttribute('aria-hidden', 'true');
    // height:0 ＋ overflow:hidden → 常駐離屏量測盒，絕不把文档撐出滾動条
    m.style.cssText = 'position:absolute;left:-99999px;top:0;visibility:hidden;pointer-events:none;height:0;overflow:hidden';
    document.body.appendChild(m);
    mirror = m;
    return m;
  }
  function syncScroll(ta, inner) {
    inner.style.transform = 'translateY(' + (-ta.scrollTop) + 'px)';
  }

  function refresh() {
    const e = els();
    if (!e.ta || !e.gutter || !e.inner) return;
    if (!cfg.visible(e)) return;
    const ta = e.ta, gutter = e.gutter, inner = e.inner, m = ensureMirror();
    const cs = getComputedStyle(ta);
    const lhStr = lineHeightPx(cs) + 'px';
    const lines = ta.value.replace(/\r/g, '').split('\n');

    // 邊条寬度用 ch（按邊条自己的小字號）；textarea 的留白必須換成邊条的實際像素寬，
    // 否則同一個 'calc(Nch + Mpx)' 字符串按正文字號重新解析，兩者會錯開約 2px。
    // count：折疊時行號按原文編號（1,2,5…），寬度須按原文件總行數算，避免展開/折疊時邊条抖寬。
    const totalLines = cfg.count ? Math.max(lines.length, cfg.count()) : lines.length;
    const targetWidth = 'calc(' + (String(totalLines).length + 1) + 'ch + ' + cfg.chrome + 'px)';
    if (gutter.style.width !== targetWidth) gutter.style.width = targetWidth;
    const marginPx = gutter.offsetWidth + 'px';
    if (ta.style.marginLeft !== marginPx) ta.style.marginLeft = marginPx;

    // mirror 與 textarea 完全相同排版（含 padding），逐邏輯行包成 div，讀 offsetTop 即得各邏輯行起點；
    // 鏡像寬度取 textarea 內部寬度（clientWidth）→ 折行起點與文字逐像素對齊。
    const cw = Math.max(1, ta.clientWidth);
    const key = [cw, cs.fontFamily, cs.fontSize, cs.fontWeight, cs.letterSpacing, cs.lineHeight,
      cs.paddingTop, cs.paddingRight, cs.paddingBottom, cs.paddingLeft, cs.tabSize || '8'].join('|');
    if (key !== layoutKey) {
      layoutKey = key;
      m.style.cssText = 'position:absolute;left:-99999px;top:0;visibility:hidden;pointer-events:none;' +
        'height:0;overflow:hidden;box-sizing:border-box;margin:0;border:0;' +
        'white-space:pre-wrap;word-break:break-word;overflow-wrap:break-word;' +
        'width:' + cw + 'px;' +
        'padding-top:' + cs.paddingTop + ';padding-right:' + cs.paddingRight +
        ';padding-bottom:' + cs.paddingBottom + ';padding-left:' + cs.paddingLeft + ';' +
        'font-family:' + cs.fontFamily + ';font-size:' + cs.fontSize + ';font-weight:' + cs.fontWeight +
        ';letter-spacing:' + cs.letterSpacing + ';line-height:' + cs.lineHeight +
        ';tab-size:' + (cs.tabSize || '8');
    }

    // 寫階段①：鏡像行數增刪 ＋ 只替換內容真的變了的行
    while (mirrorLines.length > lines.length) { mirrorTexts.pop(); m.removeChild(mirrorLines.pop()); }
    while (mirrorLines.length < lines.length) {
      const d = document.createElement('div');
      m.appendChild(d);
      mirrorLines.push(d);
      mirrorTexts.push(null);
    }
    for (let i = 0; i < lines.length; i++) {
      if (mirrorTexts[i] !== lines[i]) {
        mirrorTexts[i] = lines[i];
        // 空行必須占 1 行高：完全沒有文字的行盒高度為 0，補一個換行符才有行高
        mirrorLines[i].textContent = lines[i] === '' ? '\n' : lines[i];
      }
    }

    // 讀階段：上面全是寫，第一次 offsetTop 才強制排版，之後是純讀 → 每次調用只排版一次
    const tops = new Array(lines.length);
    for (let i = 0; i < lines.length; i++) tops[i] = mirrorLines[i].offsetTop;

    // 寫階段②：行號節點池化復用（inner 若被外部重建過，池裡的引用已失效 → 連容器一起清空重來）
    if (nums.length && nums[0].parentNode !== inner) { inner.textContent = ''; nums.length = 0; }
    while (nums.length > lines.length) inner.removeChild(nums.pop());
    while (nums.length < lines.length) {
      const n = document.createElement('div');
      n.className = 'gutter-num';
      inner.appendChild(n);
      nums.push(n);
    }
    for (let i = 0; i < nums.length; i++) {
      const n = nums[i];
      const top = tops[i] + 'px';
      if (n._top !== top) { n._top = top; n.style.top = top; }
      // 逐节点守卫：池化新增的节点诞生在 lhChanged=false 的那趟，靠全局开关会漏写 inline
      // 行高 → 新行号用 CSS 回退行高（与 textarea 不同）而错位
      if (n._lh !== lhStr) { n._lh = lhStr; n.style.height = lhStr; n.style.lineHeight = lhStr; }
      const label = cfg.label ? String(cfg.label(i)) : String(i + 1);
      if (n._label !== label) { n._label = label; n.textContent = label; }
    }

    syncScroll(ta, inner);
    if (cfg.decorate) cfg.decorate({ ta: ta, gutter: gutter, inner: inner, lines: lines, tops: tops, lh: lhStr });
  }

  // 版簽＝內容 + 尺寸 + 字號/行高/內邊距：旋轉螢幕改尺寸、換主題都可能改排版，值沒變也一樣要重建
  function signature(ta) {
    const cs = getComputedStyle(ta);
    return ta.value + '\0' + ta.clientWidth + 'x' + ta.clientHeight + 'x' +
      cs.fontSize + '/' + cs.lineHeight + '/' + cs.paddingLeft + '/' + cs.paddingTop;
  }
  function tick() {
    const e = els();
    if (!e.ta || !cfg.visible(e)) { raf = null; return; }
    const sig = signature(e.ta);
    if (sig !== lastSig) {
      lastSig = sig;
      lastScrollTop = e.ta.scrollTop;
      refresh();
    } else if (e.ta.scrollTop !== lastScrollTop) {
      lastScrollTop = e.ta.scrollTop;
      syncScroll(e.ta, e.inner);
    }
    raf = requestAnimationFrame(tick);
  }

  return {
    refresh: refresh,
    start: function () {
      if (raf == null) {
        lastSig = null;
        lastScrollTop = null;
        raf = requestAnimationFrame(tick);
      }
    },
    invalidate: function () { lastSig = null; },
  };
}
const editorGutter = createLineGutter({
  taId: 'editor',
  wrapId: 'editorGutterWrap',
  gutterId: 'editorGutter',
  innerId: 'editorGutterInner',
  chrome: 12,
  // 手機版顯隱由容器 data-view 的 CSS 控制（無 inline style），用 offsetParent 判真實可見；
  // 切到 preview/events 時 tick 下一帧自停，setView 切回 edit/split 時再自啟。
  visible: function (e) { return e.ta.offsetParent !== null; },
});

// 啟動應用（兼容兩種時序：DOM 已就緒直接執行，否則等 DOMContentLoaded）
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
