/* ============================================================
 * 📅 Calendar 特性編輯器（桌面版 todo 編輯器的資料感知編輯器 #1）
 * ------------------------------------------------------------
 * 由 index.html 內嵌腳本抽離成獨立程式文件（<script src> 載入）。
 * 職責：calendar.md 的解析 / 序列化 / 列表·月·週·日渲染 / 表單 / 導航。
 * 宿主（index.html 主腳本）提供：currentFileTarget、tlEscapeHtml、showToast、
 * taskText 編輯緩衝、#calEventsPane 等掛載 DOM 與 ev-* 樣式。
 * 約定：本文件只含 calendar 邏輯；未來新增其它特性編輯器時各自一個
 * <script src="xxx-editor.js">，互不干擾。
 * ============================================================ */
    // ========== 📅 行程视图（calendar.md 专用）：列表 / 月模式 + 新增·编辑·删除 ==========
    // 与 Lite（pwa-md-editor）同一套实现：解析 ## EVENT 块；编辑写回 taskText 缓冲，按「保存」落盘。
    let calEventsView = false;
    // 默认视图：'year'（第十一批依用户截图设定改为年；此前为 'month'）
    let tlCalMode = 'year';
    let tlCalCursor = new Date();
    let tlCalSelected = null;
    let tlListSel = null;    // 列表模式：< > / 「今天」导航到的「选中日」（金色描边）
    // 列表模式滚动锚点标志：仅当用户显式导航（今天 / < >）时才为 true，渲染时据此把列表滚到锚点日；
    // 否则一律恢复到「渲染前的滚动位置」(prevScrollTop)，绝不任意自动滚动（2026-09-30 用户反馈）
    let tlListScrollAnchorPending = false;
    // 年/月「下方明细」(tlRenderYearDayList / tlRenderDayList) 滚动锚点标志：语义同上，仅覆盖 年/月 明细表身。
    // 仅当 今天按钮 / 点选日期格 时才为 true；编辑存档 / 过滤 / 搜索 / 切范围 / < > 一律恢复 prevScrollTop（2026-09-30 用户反馈）
    let tlDetailListScrollPending = false;
    // ⚠️ 加载标记（一次性）：确认本文件已生效。若硬刷新后 DevTools Console 看不到这行 → 跑的是旧缓存脚本
    if (!window.__calEditorLoaded) { window.__calEditorLoaded = true; console.log('[calendar-editor] 已加载 — 滚动策略(2026-09-30-v3)：进入程式 / 切换 列表·日·月·周·年 模式 / 按「今天」/ 点选日期格 → 表身滚到今天；编辑存档 / 过滤 / 搜索 / 切范围 / < > 不自动滚动'); }
    // 下方明细显示范围：'day'=选定日单日 / 'full'=整月（月模式）·整周（周模式）·整年（年模式）。仅内存态，不持久化。
    // 第十一批：年视图默认 'full'（整年＝「表身 默认 by 年」）；月/週/日仍默认 'day'（见 tlSetMode，尊重「默认以日显示」）。
    // 初始值取年视图默认（'full'）——因 tlCalMode 现已默认 'year'（第十一批）。
    let tlCalScope = 'full';
    let tlCalEvents = [];
    let tlIncludedEvents = [];    // 📎 include 进来的 calendar-*.md 事件（只读，ro=true）
    let tlAlarmSyncPromise = Promise.resolve();
    let tlAlarmSyncSnapshot = null;
    let tlAlarmSyncPending = null;
    let tlAlarmIncludeRevision = 0;
    let tlCalHolidays = [];    // ## HOLIDAY 解析結果（与 ## EVENT 同结构，多 holidayType 字段）；仅列表/日志视图显示，不进时间网格/月格 chip
    let tlCalDiaries = [];     // ## DIARY 解析結果（每天一条，keyed by date）；行事历日期旁显示日记按钮，有则打勾
    let tlIncludedHolidays = [];  // 📎 include 进来的只读假日
    let tlIncludedDiaries = [];   // 📎 include 进来的只读日记
    let tlIncludedFiles = [];    // 📎 include 加载的文件清单 [{ name, size }]（供「加载清单」按钮展示，含全部同目录 calendar-*.md，不只勾选的）
    let tlIncludeListBound = false; // 📎 Include 弹窗的 change 委托监听器是否已绑定（只绑一次）
    let tlCalTagFilter = [];   // 标签过滤（空＝全部；OR 逻辑：事件 tags 命中任一即显示）
    const TL_UNDONE_CHECKS_KEY = 'tlCalUndoneChecksByEvent';
    let tlUndoneChecksByEvent = {};
    try {
      const savedUndoneChecks = JSON.parse(localStorage.getItem(TL_UNDONE_CHECKS_KEY) || '{}');
      if (savedUndoneChecks && typeof savedUndoneChecks === 'object' && !Array.isArray(savedUndoneChecks)) {
        tlUndoneChecksByEvent = savedUndoneChecks;
      } else {
        console.warn('[calendar-editor] 忽略无效的每事件 checkbox 筛选设置');
      }
    } catch (error) {
      console.warn('[calendar-editor] 读取每事件 checkbox 筛选设置失败', error);
    }
    let tlCalRegionFilter = [];   // ## HOLIDAY 地区过滤（图例 checkbox 勾选；第十一批依用户截图设定：默认为空＝不显示任何地区假日；只影响显示，不改数据）
    let tlCalShowEvents = true;   // 分类显示：普通行程 EVENT（默认勾选；只影响显示，不改数据）
    let tlCalShowRepeat = 'next';   // 分类显示：重复行程 REPEAT 三态（none=隐藏 / next=只显示未来最近一次 / some=最近前一次+未来4次≤5；第十一批依用户截图设定默认 'next'；只影响显示，不改数据）
    // 📋 「跨天行程」在列表模式里显示几笔（纯 UI 偏好：内存 + localStorage，绝不写回 calendar.md）
    //    'multi'（默认）＝跨几天就显示几笔（每天一笔，与「日」范围同口径）；
    //    'one'＝整段跨天只在「起始日」显示一笔。
    //    ⚠️ 只作用于列表模式（tlRenderList）；月/週/日三种模式一律不受影响。
    let tlCalMultiDayMode = 'multi';
    let tlMultiDayLoaded = false;
    // 📓 「只显示日记」：列表模式专属的显示过滤（纯 UI 偏好：内存 + localStorage，绝不写回 calendar.md）
    //    勾选后列表只列「有日记」的日期（每篇日记渲染成一条，含内容预览）；行程 EVENT/REPEAT 与假日 HOLIDAY 一律不参与。
    //    ⚠️ 只作用于列表模式（tlRenderList）；月/週/日三种模式一律不受影响。
    let tlCalDiaryOnly = false;
    let tlDiaryOnlyLoaded = false;
    // 日记功能已停用；后续日历内容请使用 VIEW 便利贴承载。
    const TL_DIARY_FEATURE_ENABLED = false;
    // 📆 年视图自动滚动：切到年视图 / 点「今天」 / 首次打开行程视图时，若当前月份未完整显示，则滚动使其可见。
    //    由触发点设 tlYearAutoScrollPending=true，tlRenderYear 渲染后消费一次，避免选择日期等重绘时重复滚动。
    let tlYearAutoScrollPending = false;
    // 📅 月视图自动滚动：切到月视图 / 点「今天」 / 首次打开行程视图时，若「今天」日期格未完整显示，则滚动使其可见。
    let tlMonthAutoScrollPending = false;
    // 📎 程式启动首渲：面板尚未布局，滚动函数会因 rect 全 0 误判「已完整显示」而跳过；
    //    故进入行程视图后延迟到布局就绪再自动按一次「今天」按钮（只触发一次，避免与用户操作打架）。
    let tlStartupScrollDone = false;
    // ☐ 「只显示未完成」：全模式生效（年/月/周/日/列表）的显示过滤（纯 UI 偏好：内存 + localStorage，绝不写回 calendar.md）
    //    勾选后隐藏已完成（done ✓）的行程，只看未完成；假日无完成态、不受影响。⚠️ 收口于 tlEventShown（所有视图自动生效，无需每处重复过滤）。
    //    第十一批依用户截图设定：默认「开」（新环境未设 localStorage 时即勾选）。
    let tlCalUndoneOnly = true;
    let tlUndoneOnlyLoaded = false;
    let tlUndoneScrollResult = null;   // 测试 seam：undone 勾选切换后实际滚动到的日期组（null＝无列表/无锚点）
    let tlEvFormTodoIds = [];   // 表单内「关联 Todo 卡片」临时列表（仅编辑期，不污染存档对象）
    let tlEvFormUid = null;
    let tlEvFormScrollOnCloseUid = null;
    // 🆕 编辑窗体来源：true＝从桌面便利贴唤起（tlOnStickyOpenEvent 传 pre.fromNote）。
    //    关闭窗体后必须滚动回该行程；从主画面自己点「编辑」开的窗体为 false，关闭后原地不动。
    //    （用户 2026-11-04：主画面编辑关闭不要滚动画面；便利贴编辑关闭要滚到该行程）
    let tlEvFormFromNote = false;
    let tlEvFormColor = null;
    let tlEvFormSticky = 0;   // 🆕 桌面便利贴 instance 数（表单临时值，不污染存档对象）
    // 🆕 新增行程的「写入目标」：'' = calendar.md（主文件，走缓冲）；否则 = 来源 include 档文件名（直接追加落盘）。
    //    只在「新增」时有意义；编辑既有行程时恒为 ''（编辑 include 行程仍未开放，见 tlOpenEventForm 的 ev.ro 拦截）。
    let tlEvFormTarget = '';
    // 🆕 只读窗体：被 include 的外部 calendar-*.md 行程（ev.ro）可「检视」但不可写。
    //    与 tlDiaryFormReadonly 同口径；DOM 状态统一由 tlSetEventFormReadonly 控管（开窗 / 关窗都走它）。
    let tlEvFormReadOnly = false;
    let tlEvFormReadOnlySrc = '';
    let tlEvFormDirty = false;

    // 表单内「＋ CheckBox」按钮旁的便利贴小图标：sticky>0 或本会话已临时开成便利贴才显示。
    //    2026-11-06 起可点（跳到便利贴应用、翻页模式翻到该行程那一页）。**刻意维持 <span>**：
    //    tlSetEventFormReadonly 会把窗体内所有 <button> disabled，只读查看行程时也要能跳去便利贴改备注，
    //    所以不能换成 <button>（沿用「取消钮是唯一 button 例外」的铁律）。
    function tlSyncStickyFlag() {
      const flag = document.getElementById('tlEvFStickyFlag');
      if (!flag) return;
      const v = parseInt((document.getElementById('tlEvFSticky') || {}).value, 10) || 0;
      const isTemp = !!(tlEvFormUid && tlIsTempSticky(tlEvFormUid));
      flag.style.display = (v > 0 || isTemp) ? '' : 'none';
      flag.title = (isTemp ? '临时便利贴（仅本会话）· ' : '') +
        '点击跳到便利贴应用；翻页模式会翻到这笔行程对应的那一页';
      flag.setAttribute('aria-label', isTemp ? '跳到临时便利贴' : '跳到便利贴');
    }

    // 🆕 编辑行程窗体的便利贴徽标：跳到便利贴应用，并把翻页便利贴切到「这笔行程」那一页。
    //    复用既有主窗 → 便利贴链路，不新增 IPC：
    //      tlFocusStickyNote → focus-sticky-note → showStickyNoteAt
    //        → sticky-note-show-page（带主进程权威 order + pageIndex）
    //        → applyFlipOrder → renderFlipPage(target)
    //    分体模式则由 showStickyNoteAt 直接把该张窗口 show/moveTop/focus，本来就自动适配。
    //    key ＝ 事件 uid；idx ＝ 同事件第几张 instance，徽标统一跳第 1 张（idx=0）。
    async function tlFocusStickyNoteFromEvForm() {
      const toast = (msg, type) => { if (typeof showToast === 'function') showToast(msg, type || 'warning'); };
      if (!window.electronAPI || !window.electronAPI.invoke) { toast('当前环境无法跳转便利贴'); return; }
      const uid = tlEvFormUid;
      // 新增行程还没落盘，主进程清单里没有这张贴 → 先存才有得跳
      if (!uid) { toast('这是「新增行程」，请先按「写入编辑内容」保存后再跳转'); return; }
      // 临时便利贴（sticky=0、仅本会话）走专用路径，绕过 tlFocusStickyNote 的 sticky>0 守卫
      if (tlIsTempSticky(uid)) {
        await tlFocusTempSticky(uid);
        return;
      }
      const formSticky = parseInt((document.getElementById('tlEvFSticky') || {}).value, 10) || 0;
      const ev = tlCalEvents.find((e) => e && e.uid === uid);
      const savedSticky = ev ? (parseInt(ev.sticky, 10) || 0) : 0;
      // 窗体里刚把 ×N 改成 >0 但还没按保存：tlCalEvents 里仍是旧值，focus 必然找不到 → 明说
      if (!savedSticky) {
        toast(formSticky > 0
          ? '便利贴设定还没保存，请先按「写入编辑内容」再跳转'
          : '这笔行程目前不是便利贴');
        return;
      }
      if (typeof tlFocusStickyNote !== 'function') { toast('跳转便利贴功能未载入'); return; }
      await tlFocusStickyNote(uid);
    }

    // 🆕 便利贴小图标：与工具栏 #tlStickyBtn 用的同一段 SVG（淡黄折叠便签造型），保证视觉一致
    const TL_STICKY_IC_SVG = '<svg class="ev-sticky-ic" viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><rect x="2.8" y="2.8" width="18.4" height="18.4" rx="2.2" fill="#FCEFA4"/><path d="M3 18.4c0 1.5 1.2 2.8 2.8 2.8h14.4v-2.8H3Z" fill="#F7E694"/><path d="M21.2 14.8v3.6c0 1.5-1.2 2.8-2.8 2.8h-3.6l6.4-6.4Z" fill="#FDF6C8"/><path d="M21.2 14.8 14.8 21.2" stroke="#E8CE7C" stroke-width=".7" stroke-linecap="round" fill="none"/><rect x="8.6" y="6.1" width="6.8" height="1.9" rx=".95" fill="#F0C860"/><rect x="9.1" y="6.5" width="5.8" height=".8" rx=".4" fill="#FFF3C0"/><path d="M6.6 11.4h10.8M6.6 14.2h7.6" stroke="#EBD88F" stroke-width=".9" stroke-linecap="round" fill="none"/></svg>';
    let tlEvFormTags = [];
    let tlEvTagEditIndex = -1;   // 正在内联编辑分类的选中标签下标（-1＝无）
    let tlEvTagEditLevel = 'cat';
    const TL_CAL_COLORS = ['#FF3B30', '#FF9500', '#FFCC00', '#34C759', '#5AC8FA', '#007AFF', '#5856D6', '#AF52DE', '#FF2D55', '#A2845E', '#8E8E93'];

    // 当前编辑器打开的文件是不是 calendar*.md（行程应用数据文件；calendar.md 正式档或 calendar-<后缀>.md 档案）
    function isCalendarMdDoc() {
      const t = currentFileTarget();
      if (!t) return false;
      const name = String(t.name || '').toLowerCase();
      // 🆕 放开为 calendar*.md 前缀匹配：让「建立 calendar 档案」生成的 calendar-<后缀>.md 也能独立作为行事历打开，
      //    与 LITE 版（/^calendar.*\.md$/）对齐；其余判定（md / 外部 .md）不变。
      if (!/^calendar.*\.md$/.test(name)) return false;
      return t.kind === 'md' || (t.kind === 'ext' && /\.md$/i.test(name));
    }

    // 显示/隐藏「📅 行程」开关；文件不是 calendar.md 时若停在行程视图则退回编辑模式
    function updateCalEventsBtnVisibility() {
      const btn = document.getElementById('calEventsBtn');
      const show = isCalendarMdDoc();
      if (btn) {
        btn.style.display = show ? '' : 'none';
        btn.classList.toggle('active', show && calEventsView);
      }
      if (!show && calEventsView) setCalEventsView(false);
    }

    // 资料感知编辑器分派：文件成为「当前」时，若有专属编辑器（calendar.md → 行程视图）优先启用；
    // 否则回退默认编辑器（照旧）。
    // ⚠️ 只在「打开/切换文件」入口（openEditMdModal / openExternalFile）调用；这些入口都由用户动作触发
    //    （点文件列表项、点底部 Sheet 页签、edit: 链接），所以「用户每次打开 calendar.md 都应重新进入行程视图」。
    //    绝不能用「上次已分派的文件 key」去跳过——否则用户手动退出行程视图后再次选中 calendar.md，
    //    会因 key 相同被跳过而退化成文本编辑器（实测 bug）。而用户手动关闭行程视图不会再次触发这些入口，
    //    因此无需任何守卫来「保留其关闭状态」。
    function tlPrioritizeDedicatedEditor() {
      if (isCalendarMdDoc()) {
        // ⚠️ 必须「无条件」重新进入行程视图，不能写成 `if (!calEventsView) setCalEventsView(true)`：
        //    openExternalFile 的 md 分支在派发前会把 #taskText 重新显示出来（textarea.style.display=''，见 L12707），
        //    若此刻 calEventsView 已为 true 而跳过 → showCalEventsPaneOnly() 不执行 → 文字编辑器与行程面板
        //    「同时」占据 flex 版面（textarea flex:1 抢走绝大部分高度，行程只剩底部一条）。
        //    用户实测：进入系统后第二次打开 calendar.md 就会这样；切走再切回（会把 calEventsView 置 false）反而正常。
        //    setCalEventsView(true) 幂等：重跑 showCalEventsPaneOnly()（重新隐藏文字编辑器）+ 重渲染行程内容；
        //    内容来自 #taskText 实时缓冲，不会丢编辑。
        setCalEventsView(true);
        tlKickIncludeRefresh(); // 📎 打开/切入 calendar.md 时，加载同目录 calendar-*.md（只读合并；加载完自动重绘）
        tlSyncAlarms(); // 打开另一份 Calendar 时立即切换提醒来源，不等待定时轮询
      } else if (calEventsView) {
        setCalEventsView(false);
      }
    }

    // 📎 合并 include 进来的只读事件（渲染统一走 tlCalEvents，只读约束靠 ro 标记 + 写回过滤）
    function tlAllEvents(md) { return (tlParseEvents(md) || []).concat(tlIncludedEvents || []); }

    function tlAlertDateTime(value) {
      const m = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2})(\d{2})$/);
      if (!m) return null;
      const date = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], 0, 0);
      if (date.getFullYear() !== +m[1] || date.getMonth() !== +m[2] - 1 ||
          date.getDate() !== +m[3] || date.getHours() !== +m[4] || date.getMinutes() !== +m[5]) return null;
      return date.getTime();
    }

    function tlAlertInterval(value) {
      const m = String(value || '').match(/^([1-9]\d*)(m|h|d)$/);
      if (!m) return 0;
      const scale = { m: 60000, h: 3600000, d: 86400000 }[m[2]];
      const result = Number(m[1]) * scale;
      return Number.isSafeInteger(result) ? result : 0;
    }

    function tlAlertTableCells(line) {
      if (window.MdTableGrid && typeof window.MdTableGrid.splitCells === 'function') {
        return window.MdTableGrid.splitCells(line);
      }
      return String(line || '').trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((cell) => cell.trim());
    }

    function tlAlertTableInfo(lines, markerLineIndex, fenceEnd) {
      const headerIndex = markerLineIndex + 1;
      if (headerIndex + 1 >= fenceEnd) return null;
      const headerLine = String(lines[headerIndex] || '').trim();
      const dividerLine = String(lines[headerIndex + 1] || '').trim();
      if (headerLine.indexOf('|') < 0 || !/^[\s|:-]+$/.test(dividerLine) ||
          dividerLine.indexOf('|') < 0 || dividerLine.indexOf('-') < 0) return null;
      const header = tlAlertTableCells(headerLine);
      if (header.length !== 2 || header[0] !== '完成日期与时间' || header[1] !== '备注') return null;

      let endLine = headerIndex + 1;
      while (endLine + 1 < fenceEnd && String(lines[endLine + 1] || '').trim().indexOf('|') >= 0) endLine++;
      const dates = new Set();
      for (let i = headerIndex + 2; i <= endLine; i++) {
        const cells = tlAlertTableCells(lines[i]);
        if (cells.length < 2) continue;
        const match = cells[0].match(/^(\d{4}-\d{2}-\d{2})(?:\s+\d{2}:\d{2})?$/);
        if (match && tlAlertDateTime(match[1] + ' 0000') !== null) dates.add(match[1]);
      }
      return { headerIndex, endLine, dates };
    }

    function tlAlertFenceContent(lines, markerLineIndex, range, table) {
      if (!range) return '';
      const contentStart = table ? table.endLine + 1 : markerLineIndex + 1;
      return lines.slice(contentStart, range.end).join('\n').replace(/\r/g, '').trim();
    }

    function tlAlertFenceContentHtml(content) {
      if (!content) return '';
      const prepared = tlSeparateGpHorizontalRules(tlNotesWithChecks(tlStripGpMarkers(content), null));
      return renderMarkdown(tlRenderTermDefs(tlRenderNoteMarkersLines(prepared)));
    }

    function tlAlertRecurringDue(schedule, completedDates, now) {
      const normalized = String(schedule || '').trim().replace(/\s+/g, ' ').toLowerCase();
      const anniversary = normalized.match(/^anniversary (\d{4}-\d{2}-\d{2}) (\d{4})$/);
      const daily = normalized.match(/^everyday (\d{4})$/);
      const weekdays = normalized.match(/^w([1-7])\s*-\s*w([1-7])\s+(\d{4})$/);
      const weekdayList = normalized.match(/^(w[1-7](?:\s*,\s*w[1-7])+) (\d{4})$/);
      if (!anniversary && !daily && !weekdays && !weekdayList) return null;
      const time = anniversary ? anniversary[2] : (daily ? daily[1] : (weekdayList ? weekdayList[2] : weekdays[3]));
      const hour = Number(time.slice(0, 2)), minute = Number(time.slice(2, 4));
      if (hour > 23 || minute > 59) return null;
      if (anniversary) {
        if (tlAlertDateTime(anniversary[1] + ' 0000') === null) return null;
        const current = new Date(now);
        const completedYears = new Set(Array.from(completedDates)
          .map((date) => String(date).match(/^(\d{4})-/))
          .filter(Boolean)
          .map((match) => match[1]));
        // A catch-up completion is logged on today's date, not the anniversary date.
        for (let year = current.getFullYear(); year <= current.getFullYear() + 8; year++) {
          const yearKey = String(year).padStart(4, '0');
          const dateKey = yearKey + anniversary[1].slice(4);
          const dueAt = tlAlertDateTime(dateKey + ' ' + time);
          if (dueAt === null || completedYears.has(yearKey)) continue;
          return dueAt;
        }
        return null;
      }
      const startDay = weekdays ? Number(weekdays[1]) : 1;
      const endDay = weekdays ? Number(weekdays[2]) : 7;
      const selectedDays = weekdayList
        ? new Set(weekdayList[1].match(/w[1-7]/g).map((token) => Number(token.slice(1))))
        : null;
      const current = new Date(now);
      for (let offset = 0; offset <= 7; offset++) {
        const date = new Date(current.getFullYear(), current.getMonth(), current.getDate() + offset);
        const weekday = date.getDay() || 7;
        const matchesWeekday = weekdayList ? selectedDays.has(weekday) : (!weekdays || (startDay <= endDay
          ? weekday >= startDay && weekday <= endDay
          : weekday >= startDay || weekday <= endDay));
        if (!matchesWeekday) continue;
        const dateKey = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') +
          '-' + String(date.getDate()).padStart(2, '0');
        if (completedDates.has(dateKey)) continue;
        const dueAt = tlAlertDateTime(dateKey + ' ' + time);
        if (dueAt !== null) return dueAt;
      }
      return null;
    }

    function tlAlertMarkers(notes) {
      const text = String(notes || '');
      const markers = [];
      const lines = text.split('\n');
      const fences = (typeof tlGpFenceScan === 'function') ? tlGpFenceScan(lines).ranges : [];
      let offset = 0, fenceChar = '', fenceLength = 0;
      lines.forEach((line, lineIndex) => {
        const sourceLine = line;
        line = line.replace(/\r$/, '');
        const fence = line.match(/^[ \t]{0,3}(`{3,}|~{3,})/);
        if (fence) {
          const chars = fence[1][0], length = fence[1].length;
          if (!fenceChar) { fenceChar = chars; fenceLength = length; }
          else if (chars === fenceChar && length >= fenceLength) { fenceChar = ''; fenceLength = 0; }
        } else if (!fenceChar) {
          const re = /\[\[alert:([\s\S]*?):((?:\d{4}-\d{2}-\d{2} \d{4})|(?:anniversary\s+\d{4}-\d{2}-\d{2}\s+\d{4})|(?:everyday\s+\d{4})|(?:w[1-7]\s*-\s*w[1-7]\s+\d{4})|(?:w[1-7](?:\s*,\s*w[1-7])+\s+\d{4}))\s*:\s*([1-9]\d*)\s*(m|h|d)(?:\s*:\s*([^\]]*))?\]\]/gi;
          let match;
          while ((match = re.exec(line))) {
            const intervalMs = tlAlertInterval(match[3] + match[4]);
            if (!intervalMs) continue;
            const markerOffset = offset + match.index;
            const fixedDueAt = tlAlertDateTime(match[2]);
            if (fixedDueAt !== null) {
              const range = fences.find((item) => item.alert && item.start + 1 === lineIndex);
              const table = range ? tlAlertTableInfo(lines, lineIndex, range.end) : null;
              const content = tlAlertFenceContent(lines, lineIndex, range, table);
              markers.push({
                marker: match[0],
                markerOffset,
                message: match[1].trim(),
                contentHtml: tlAlertFenceContentHtml(content),
                dueAt: fixedDueAt,
                intervalMs,
                completed: String(match[5] || '').trim() === '是',
                recurring: false
              });
              continue;
            }

            if (match[5] !== undefined || sourceLine.trim() !== match[0]) continue;
            const range = fences.find((item) => item.alert && item.start + 1 === lineIndex);
            if (!range) continue;
            const table = tlAlertTableInfo(lines, lineIndex, range.end);
            if (!table) continue;
            const dueAt = tlAlertRecurringDue(match[2], table.dates, Date.now());
            if (dueAt === null) continue;
            // 循环模式：tlAlertRecurringDue 已经跳过了表格里已完成的日期，
            // 返回的是「下一个未触发」的时间，所以 completed 一定是 false
            const content = tlAlertFenceContent(lines, lineIndex, range, table);
            markers.push({
              marker: match[0],
              markerOffset,
              message: match[1].trim(),
              contentHtml: tlAlertFenceContentHtml(content),
              dueAt,
              intervalMs,
              completed: false,
              recurring: true
            });
          }
        }
        offset += sourceLine.length + 1;
      });
      return markers;
    }

    async function tlSyncAlarms() {
      const api = window.electronAPI || {};
      if (!api.syncAlarms || !isCalendarMdDoc()) return;
      const textArea = document.getElementById('taskText');
      if (!textArea) return;
      const target = currentFileTarget();
      const source = textArea.value;
      const targetKey = target && (target.key || target.path || target.id || target.name);
      const snapshot = { targetKey, source, includeRevision: tlAlarmIncludeRevision };
      const matchesSnapshot = (candidate) => candidate && candidate.targetKey === targetKey &&
        candidate.source === source && candidate.includeRevision === tlAlarmIncludeRevision;
      if (matchesSnapshot(tlAlarmSyncSnapshot)) return;
      if (tlAlarmSyncPending && matchesSnapshot(tlAlarmSyncPending.snapshot)) {
        await tlAlarmSyncPending.promise;
        return;
      }
      const alarms = tlAllEvents(textArea.value).flatMap((ev) =>
        tlAlertMarkers(ev.notes).filter((alert) => !alert.completed).map((alert) => ({
          ...alert,
          id: String(ev.uid) + ':' + alert.markerOffset,
          title: ev.title,
          eventUid: ev.uid,
          src: ev.src || '',
          ro: ev.ro === true,
          date: ev.date
        }))
      );
      const sync = tlAlarmSyncPromise.then(async () => {
        const result = await api.syncAlarms(alarms);
        if (!result || !result.ok) {
          console.error('[calendar-editor] 闹铃清单同步失败:', result && result.error);
          return;
        }
        tlAlarmSyncSnapshot = snapshot;
      });
      tlAlarmSyncPromise = sync.catch((error) => {
        console.error('[calendar-editor] 闹铃清单同步失败:', error);
      });
      const pending = { snapshot, promise: tlAlarmSyncPromise };
      tlAlarmSyncPending = pending;
      await pending.promise;
      if (tlAlarmSyncPending === pending) tlAlarmSyncPending = null;
    }

    function tlAlarmLocalDateTime(timestamp) {
      const date = new Date(timestamp);
      const pad = (value) => String(value).padStart(2, '0');
      return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate()) +
        ' ' + pad(date.getHours()) + pad(date.getMinutes());
    }

    function tlAlertLocalDisplayDateTime(timestamp) {
      const date = new Date(timestamp);
      const pad = (value) => String(value).padStart(2, '0');
      return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate()) +
        ' ' + pad(date.getHours()) + ':' + pad(date.getMinutes());
    }

    function tlAppendAlertHistory(notes, markerOffset, note) {
      const text = String(notes || '');
      const lines = text.split('\n');
      const markerLineIndex = text.slice(0, markerOffset).split('\n').length - 1;
      const range = tlGpFenceScan(lines).ranges.find((item) => item.alert && item.start + 1 === markerLineIndex);
      if (!range) return null;
      const table = tlAlertTableInfo(lines, markerLineIndex, range.end);
      if (!table) return null;

      let lineStart = 0;
      for (let i = 0; i < table.endLine; i++) lineStart += lines[i].length + 1;
      const lineEnd = lineStart + lines[table.endLine].length;
      const hasLineEnding = text.charAt(lineEnd) === '\n';
      const insertAt = lineEnd + (hasLineEnding ? 1 : 0);
      const lineEnding = text.indexOf('\r\n') >= 0 ? '\r\n' : '\n';
      const safeNote = String(note || '完成').replace(/[\r\n]+/g, ' ').replace(/\|/g, '\\|').trim() || '完成';
      const row = '| ' + tlAlertLocalDisplayDateTime(Date.now()) + ' | ' + safeNote + ' |';
      return {
        notes: text.slice(0, insertAt) + (hasLineEnding ? row + lineEnding : lineEnding + row) + text.slice(insertAt),
        row
      };
    }

    function tlInsertAlertHistoryRowIntoDraft(draft, marker, row) {
      const text = String(draft || '');
      const lines = text.split('\n');
      const markerLineIndex = lines.findIndex((line) => line.trim() === marker);
      if (markerLineIndex < 1) return null;
      const range = tlGpFenceScan(lines).ranges.find((item) =>
        item.alert && item.start + 1 === markerLineIndex);
      if (!range) return null;
      const table = tlAlertTableInfo(lines, markerLineIndex, range.end);
      if (!table) return null;
      if (lines.slice(table.headerIndex + 2, table.endLine + 1).includes(row)) return text;
      lines.splice(table.endLine + 1, 0, row);
      return lines.join('\n');
    }

    function tlRefreshOpenBlockAfterAlarm(uid, oldMarker, newMarker, historyRow) {
      const target = tlEditBlockTarget;
      const overlay = document.getElementById('tlAddCheckOverlay');
      const input = document.getElementById('tlAddCheckInput');
      if (!target || target.uid !== uid || !overlay || overlay.style.display === 'none' || !input) return;

      const oldValue = String(input.value || '');
      const markerAt = oldValue.indexOf(oldMarker);
      if (newMarker !== oldMarker && markerAt >= 0 &&
          oldValue.indexOf(oldMarker, markerAt + oldMarker.length) < 0) {
        input.value = oldValue.slice(0, markerAt) + newMarker + oldValue.slice(markerAt + oldMarker.length);
        tlSyncGroupUi(input.value);
        return;
      }

      if (historyRow && newMarker === oldMarker) {
        const merged = tlInsertAlertHistoryRowIntoDraft(oldValue, oldMarker, historyRow);
        if (merged !== null) {
          input.value = merged;
          tlSyncGroupUi(input.value);
          return;
        }
      }

      if (tlAddCheckDirty) {
        showToast('提醒记录已写入，但当前区块草稿有未保存修改；请核对后再保存，避免覆盖最新记录', 'danger');
        return;
      }

      const textArea = document.getElementById('taskText');
      const latest = textArea ? tlAllEvents(textArea.value).find((event) => event.uid === uid) : null;
      if (!latest) return;
      const lines = String(latest.notes || '').split('\n');
      if (!(target.start >= 0 && target.end < lines.length)) return;
      input.value = lines.slice(target.start, target.end + 1).join('\n');
      tlSyncGroupUi(input.value);
    }

    async function tlSaveAlarmAction(request) {
      const alarm = request && request.alarm;
      const action = request && request.action;
      if (!alarm || !alarm.eventUid || !alarm.marker || !['snooze', 'complete'].includes(action)) {
        return { ok: false, error: '闹铃资料无效，未修改行程' };
      }
      const textArea = document.getElementById('taskText');
      if (!textArea) return { ok: false, error: '找不到行程编辑器，未修改行程' };
      const latestEvents = tlAllEvents(textArea.value);
      tlCalEvents = latestEvents;
      const ev = latestEvents.find((item) => item.uid === alarm.eventUid);
      if (!ev) return { ok: false, error: '找不到对应行程（可能已删除或切换档案）' };

      const notes = String(ev.notes || '');
      let markerOffset = Number.isInteger(alarm.markerOffset) ? alarm.markerOffset : -1;
      if (notes.slice(markerOffset, markerOffset + alarm.marker.length) !== alarm.marker) {
        const foundAt = notes.indexOf(alarm.marker);
        if (foundAt < 0 || notes.indexOf(alarm.marker, foundAt + alarm.marker.length) >= 0) {
          return { ok: false, error: '提醒标记已被修改或重复，未写入以避免改错内容' };
        }
        markerOffset = foundAt;
      }
      const parsed = alarm.marker.match(/^\[\[alert:([\s\S]*?):((?:\d{4}-\d{2}-\d{2} \d{4})|(?:anniversary\s+\d{4}-\d{2}-\d{2}\s+\d{4})|(?:everyday\s+\d{4})|(?:w[1-7]\s*-\s*w[1-7]\s+\d{4})|(?:w[1-7](?:\s*,\s*w[1-7])+\s+\d{4}))\s*:\s*([1-9]\d*)\s*(m|h|d)(?:\s*:\s*([^\]]*))?\]\]$/i);
      if (!parsed) return { ok: false, error: '提醒标记格式无效，未修改行程' };
      let nextMarker;
      let newNotes;
      let historyRow = '';
      const isRecurring = tlAlertDateTime(parsed[2]) === null;
      if (isRecurring) {
        const currentMarker = tlAlertMarkers(notes).find((item) =>
          item.markerOffset === markerOffset && item.marker === alarm.marker && item.recurring);
        if (!currentMarker) return { ok: false, error: '循环提醒围栏或记录表格已失效，未修改行程' };
        if (action === 'snooze') return { ok: true };
        const history = tlAppendAlertHistory(notes, markerOffset, request.note);
        if (history === null) return { ok: false, error: '找不到循环提醒的记录表格，未修改行程' };
        nextMarker = alarm.marker;
        newNotes = history.notes;
        historyRow = history.row;
      } else if (action === 'complete') {
        nextMarker = '[[alert:' + parsed[1] + ':' + parsed[2] + ':' + parsed[3] + parsed[4] + ':是]]';
      } else {
        const intervalMs = tlAlertInterval(parsed[3] + parsed[4]);
        const nextAt = Math.ceil((Date.now() + intervalMs) / 60000) * 60000;
        nextMarker = '[[alert:' + parsed[1] + ':' + tlAlarmLocalDateTime(nextAt) + ':' +
          parsed[3] + parsed[4] + ':否]]';
      }
      if (!isRecurring) {
        newNotes = notes.slice(0, markerOffset) + nextMarker + notes.slice(markerOffset + alarm.marker.length);
      }

      if (ev.ro) {
        const result = await tlSaveIncludedEventNotes(ev.uid, newNotes, ev.src);
        if (!result || !result.ok) return { ok: false, error: result && result.error ? result.error : '写入来源文件失败' };
      } else {
        const content = String(textArea.value || '');
        const starts = [];
        const header = /^##[ \t]*EVENT(?:\([^)]*\))?[ \t]*$/gm;
        let match;
        while ((match = header.exec(content))) starts.push({ start: match.index, endHeader: header.lastIndex });
        const eventIndexMatch = String(ev.uid).match(/^evp(\d+)$/);
        const eventIndex = eventIndexMatch ? Number(eventIndexMatch[1]) : -1;
        const matchingStart = starts.findIndex((item, index) => {
          if (index + 1 !== eventIndex) return false;
          const end = index + 1 < starts.length ? starts[index + 1].start : content.length;
          const nextHeading = content.slice(item.endHeader, end).search(/^##[ \t]/m);
          const blockEnd = nextHeading >= 0 ? item.endHeader + nextHeading : end;
          const block = tlParseBlock(content.slice(item.endHeader, blockEnd), eventIndex);
          return block && block.title === ev.title && block.date === ev.date;
        });
        if (matchingStart < 0) return { ok: false, error: '无法安全定位行程区块，未写入' };
        const item = starts[matchingStart];
        let end = matchingStart + 1 < starts.length ? starts[matchingStart + 1].start : content.length;
        const nextHeading = content.slice(item.endHeader, end).search(/^##[ \t]/m);
        if (nextHeading >= 0) end = item.endHeader + nextHeading;
        const updatedBlock = tlReplaceRemarkInBlock(content.slice(item.endHeader, end), newNotes);
        textArea.value = content.slice(0, item.endHeader) + updatedBlock + content.slice(end);
        try {
          const saved = typeof saveTask === 'function' ? await saveTask(false, true, true) : false;
          if (!saved) throw new Error('保存行程失败');
        } catch (error) {
          textArea.value = content;
          return { ok: false, error: error.message || String(error) };
        }
        if (typeof autoGrowTextarea === 'function') autoGrowTextarea(textArea);
        if (typeof tlRenderEventsContent === 'function') tlRenderEventsContent();
      }

      tlRefreshOpenBlockAfterAlarm(ev.uid, alarm.marker, nextMarker, historyRow);
      if (typeof tlPushStickyRefreshes === 'function') tlPushStickyRefreshes(true);
      await tlSyncAlarms();
      return { ok: true };
    }

    if (window.electronAPI && window.electronAPI.onAlarmActionRequest) {
      window.electronAPI.onAlarmActionRequest(async (request) => {
        let result;
        try { result = await tlSaveAlarmAction(request); }
        catch (error) {
          console.error('[calendar-editor] 处理闹铃操作失败:', error);
          result = { ok: false, error: error.message || String(error) };
        }
        if (request && request.requestId && window.electronAPI.respondToAlarmAction) {
          try {
            const response = await window.electronAPI.respondToAlarmAction(request.requestId, result);
            if (!response || !response.ok) console.error('[calendar-editor] 回传闹铃操作结果失败:', response && response.error);
          } catch (error) {
            console.error('[calendar-editor] 回传闹铃操作结果失败:', error);
          }
        }
      });
    }
    if (window.electronAPI && window.electronAPI.syncAlarms) {
      setTimeout(tlSyncAlarms, 1000);
    }

    function tlAllHolidays(md) { return (tlParseHolidays(md) || []).concat(tlIncludedHolidays || []); }
    function tlAllDiaries(md) {
      if (!TL_DIARY_FEATURE_ENABLED) return [];
      return (tlParseDiaries(md) || []).concat(tlIncludedDiaries || []);
    }
    // 📎 加载同目录 calendar-*.md（结构与 calendar.md 相同：EVENT / HOLIDAY / DIARY）并解析为只读数据：
    //   - 外部文件模式：目录 = externalFilePath 所在目录，读取走 readFileByPath
    //   - 内部 md 模式：目录 = TODO_DATA_DIR（getTodoDataDir），读取走 readMdFile
    // 📎 include 载入的「可等待句柄」：tlRefreshIncludedEvents 本身是异步且原本是「发射后不管」，
    //    于是开便利贴时草稿档（calendar-event-draft.md）里的行程还没合并进来 →
    //    便利贴页次少算（实测：9 张 vs 实际 12 张，差的正是草稿档那 3 张）。
    //    现在所有调用点走 tlKickIncludeRefresh()，需要「拿到完整清单」的地方先 await tlEnsureIncludesLoaded()。
    let tlIncludeReady = Promise.resolve();
    function tlKickIncludeRefresh() {
      tlIncludeReady = tlRefreshIncludedEvents().catch(() => {});
      return tlIncludeReady;
    }
    async function tlEnsureIncludesLoaded() {
      try { await tlIncludeReady; } catch (e) {}
      return tlIncludeReady;
    }
    async function tlRefreshIncludedEvents() {
      if (!isCalendarMdDoc()) { tlIncludedEvents = []; tlIncludedHolidays = []; tlIncludedDiaries = []; tlIncludedFiles = []; return; }
      const api = window.electronAPI || {};
      try {
        let dir = null, isExt = false;
        const t = currentFileTarget();
        if (t && t.kind === 'ext' && t.path) {
          dir = String(t.path).replace(/[\\/][^\\/]*$/, '');
          isExt = true;
        } else if (api.getTodoDataDir) {
          const r = await api.getTodoDataDir();
          dir = (r && r.data) ? String(r.data) : null;
        }
        if (!dir || !api.listAllFilesInDir) {
          tlIncludedEvents = []; tlIncludedHolidays = []; tlIncludedDiaries = []; tlIncludedFiles = [];
          tlAlarmIncludeRevision++;
          await tlSyncAlarms();
          return;
        }
        const ls = await api.listAllFilesInDir(dir);
        const items = (((ls && ls.data) || []).map((it) => ({ name: it && it.name, size: (it && it.size) || 0 })))
          .filter((it) => it.name && /^calendar-.+\.md$/i.test(it.name) && it.name.toLowerCase() !== 'calendar.md')
          .sort((a, b) => String(a.name).localeCompare(String(b.name)));
        const names = items.map((it) => it.name);
        // 📎 勾选过滤：只加载 INCLUDE 区块里标记为 '+' 的文件；区块缺失则默认全部加载
        const sel = tlParseIncludeSel(document.getElementById('taskText').value, names);
        tlIncludedFiles = items.slice(); // 📎 弹窗展示用「全部」文件（含未勾选），不只是已加载的
        const merged = [], mergedHolidays = [], mergedDiaries = [];
        for (let i = 0; i < names.length; i++) {
          const name = names[i];
          if (!sel.has(name)) continue; // 📎 未勾选 → 跳过（动态释放）
          let content = '';
          if (isExt) {
            if (api.readFileByPath) {
              const rr = await api.readFileByPath(dir + '/' + name);
              content = (rr && rr.success) ? (rr.content || '') : '';
            }
          } else if (api.readMdFile) {
            const rr = await api.readMdFile(name.replace(/\.md$/i, ''));
            content = (rr && rr.success) ? (rr.content || '') : '';
          }
          tlParseEvents(content).forEach((ev, j) => {
            ev.ro = true;
            ev.src = name;
            ev.uid = 'ro-' + i + '-' + j + '-' + ev.uid;   // 全局唯一，避免与 calendar.md 的 evpN 冲突
            merged.push(ev);
          });
          tlParseHolidays(content).forEach((h, j) => { h.ro = true; h.src = name; h.uid = 'ro-' + i + '-' + j + '-h-' + h.uid; mergedHolidays.push(h); });
          if (TL_DIARY_FEATURE_ENABLED) {
            tlParseDiaries(content).forEach((d) => { d.ro = true; d.src = name; mergedDiaries.push(d); });
          }
        }
        tlIncludedEvents = merged;
        tlIncludedHolidays = mergedHolidays;
        tlIncludedDiaries = mergedDiaries;
      } catch (e) {
        tlIncludedEvents = []; tlIncludedHolidays = []; tlIncludedDiaries = []; tlIncludedFiles = [];
      }
      tlAlarmIncludeRevision++;
      await tlSyncAlarms();
      if (calEventsView) {
        tlRenderEventsContent();
        // 📎 include 加载是启动最后一步：其重渲（无「今天」pending）会把提前滚好的位置还原；
        //    故在此「最后一次启动渲染」之后再自动按一次「今天」按钮，确保滚动真正生效并留下。
        tlTriggerStartupToday();
      }
      // 🆕 include 合并完 → 便利贴集合可能变大（草稿档的行程也带便利贴）：必须重算并推给主进程，
      //    否则翻页窗/翻页清单停在「开窗那一刻」的张数（实测少 3 张，正是草稿档那 3 张）
      if (typeof tlUpdateStickyBadge === 'function') tlUpdateStickyBadge();
      if (typeof tlPushStickyRefreshes === 'function') tlPushStickyRefreshes();
    }

    // ===== 📎 INCLUDE 外部文件「就地回写」（草稿便利贴等只读包含行程的编辑落盘）=====
    //   设计原则：
    //     ① 目录规则与 tlRefreshIncludedEvents 完全一致（外部文件模式＝所在目录；内部 md 模式＝TODO_DATA_DIR），
    //        不新增第二套路径推导；
    //     ② 只替换目标区块的 Remark 内容，其余字段（含本程式不认识的字段）原样保留 → 不会因为
    //        「整块重新序列化」把用户手写的东西冲掉；
    //     ③ 永远写「来源文件」（ev.src），绝不写 calendar.md；
    //     ④ 写完立刻重载 INCLUDE 并重绘，便利贴 / 日历一起刷新。
    async function tlIncludeFileTarget(name) {
      const api = window.electronAPI || {};
      const fileName = String(name || '').trim();
      if (!fileName) return null;
      let dir = null, isExt = false;
      const t = currentFileTarget();
      if (t && t.kind === 'ext' && t.path) {
        dir = String(t.path).replace(/[\\/][^\\/]*$/, '');
        isExt = true;
      } else if (api.getTodoDataDir) {
        const r = await api.getTodoDataDir();
        dir = (r && r.data) ? String(r.data) : null;
      }
      if (!dir) return null;
      const abs = dir + '/' + fileName;
      const mdId = fileName.replace(/\.md$/i, '');
      return {
        abs,
        async read() {
          if (isExt) {
            const rr = api.readFileByPath ? await api.readFileByPath(abs) : null;
            return (rr && rr.success) ? (rr.content || '') : null;
          }
          const rr = api.readMdFile ? await api.readMdFile(mdId) : null;
          return (rr && rr.success) ? (rr.content || '') : null;
        },
        async write(content) {
          if (isExt) {
            if (!api.saveFileByPath) throw new Error('缺少写入外部文件的接口');
            const r = await api.saveFileByPath(abs, content);
            if (r && r.success === false) throw new Error(r.error || '写入失败');
            return;
          }
          if (!api.saveMdFile) throw new Error('缺少写入 MD 文件的接口');
          const r = await api.saveMdFile(mdId, content);
          if (r && r.success === false) throw new Error(r.error || '写入失败');
        }
      };
    }
    // 只替换 blockText 里的 `- Remark:` 围栏正文；没有 Remark 字段时在原位补一个
    function tlReplaceRemarkInBlock(blockText, notes) {
      const nl = '\n';
      const lines = String(blockText == null ? '' : blockText).replace(/\r\n/g, nl).split(nl);
      const newNotes = String(notes == null ? '' : notes);
      const fence = tlRemarkFence(newNotes);
      const repl = [fence].concat(newNotes === '' ? [''] : newNotes.split(nl)).concat([fence]);
      const ri = lines.findIndex((l) => /^-[ \t]*Remark:/.test(l));
      if (ri < 0) {
        // 没有 Remark 字段：插到区块末尾（保持块尾空行不变）
        let at = lines.length;
        while (at > 0 && lines[at - 1].trim() === '') at--;
        return lines.slice(0, at).concat(['- Remark:'], repl, lines.slice(at)).join(nl);
      }
      // 找围栏正文范围：`- Remark:` 下一行起是开启围栏
      let end = ri + 1;
      const open = (lines[ri + 1] || '').match(/^(`{3,})[ \t]*$/);
      if (open) {
        const closeRe = new RegExp('^`{' + open[1].length + ',}[ \\t]*$');
        let k = ri + 2;
        while (k < lines.length && !closeRe.test(lines[k])) k++;
        end = Math.min(k + 1, lines.length);
      }
      return lines.slice(0, ri + 1).concat(repl, lines.slice(end)).join(nl);
    }
    // 便利贴「编辑回写」：把 notes 写入该行程的来源 include 文件（不碰 calendar.md）
    //   定位顺序：key 里的区块序号（ro-<文件序号>-<区块序号>-evp<N>）→ 标题+日期唯一匹配
    async function tlSaveIncludedEventNotes(key, notes, srcName) {
      const target = (tlCalEvents || []).find((e) => e.uid === key);
      const name = String(srcName || (target && target.src) || '').trim();
      if (!name) return { ok: false, error: '找不到该行程的来源文件' };
      const io = await tlIncludeFileTarget(name);
      if (!io) return { ok: false, error: '无法定位所在目录（请确认 Calendar 已打开）' };
      let content = null;
      try { content = await io.read(); } catch (e) { return { ok: false, error: '读取 ' + name + ' 失败：' + (e.message || e) }; }
      if (content == null) return { ok: false, error: '读取 ' + name + ' 失败' };
      const events = tlParseEvents(content);
      const same = (ev) => !!(ev && target && String(ev.title || '') === String(target.title || '') &&
        String(ev.date || '') === String(target.date || ''));
      const idxFromKey = (String(key || '').match(/^ro-\d+-(\d+)-/) || [])[1];
      let index = (idxFromKey === undefined) ? -1 : (+idxFromKey);
      // 有当前事件就核对「标题+日期」防止文件变动后错位；拿不到当前事件时退回 key 里的区块序号
      if (target) {
        if (!(index >= 0 && same(events[index]))) index = events.findIndex(same);
      } else if (!(index >= 0 && index < events.length)) {
        index = -1;
      }
      if (!(index >= 0 && events[index])) {
        return { ok: false, error: '在 ' + name + ' 中找不到该行程（文件可能已被外部修改，请刷新后重试）' };
      }
      // 取出该区块原文：先列出所有 ## EVENT 标题位置，但只保留「有标题」的块来对齐 parsed index
      //   —— tlParseEvents 会跳过无标题块（如新建档案骨架遗留的空 ## EVENT 占位），
      //      因此 parsed index 与「原始标题 index」在有空占位块时会错位；按标题块对齐才安全。
      const re = /^##[ \t]*EVENT(?:\([^)]*\))?[ \t]*$/gm;
      const allStarts = [];
      let m;
      while ((m = re.exec(content))) allStarts.push(m.index);
      const blockEndAt = (s) => {
        const nr = content.slice(s + 1).search(/^##[ \t]/m);
        return nr >= 0 ? s + 1 + nr : content.length;
      };
      // 与 tlParseEvents/tlParseBlock 同一口径判定「有标题」：- title: `非空`
      const titledStarts = allStarts.filter((s) => {
        const tm = content.slice(s, blockEndAt(s)).match(/- title: `([^`]*)`/);
        return !!tm && tm[1].length > 0;
      });
      // 安全阀：有标题的区块数必须与解析出的条目数一致（解析口径若变动 → 序号可能错位 → 宁可拒写）
      if (titledStarts.length !== events.length) {
        return { ok: false, error: name + ' 中 EVENT 区块无法安全定位，已取消写入' };
      }
      const s = titledStarts[index];
      const e = blockEndAt(s);
      const blockText = content.slice(s, e);
      const newBlock = tlReplaceRemarkInBlock(blockText, notes);
      // 就地替换 [s, e)（不走 tlSpliceEventBlockText：它按原始标题 index 取块，遇空占位块会写错位置）
      const body = String(newBlock || '').replace(/\n+$/, '') + '\n';
      const tail = content.slice(e);
      const next = content.slice(0, s) + body + (tail ? (tail.startsWith('\n') ? tail : '\n' + tail) : '');
      if (next === content) return { ok: true, file: name, unchanged: true };
      try { await io.write(next); } catch (err) { return { ok: false, error: '写入 ' + name + ' 失败：' + (err.message || err) }; }
      // 只同步内存里的这一条（不重跑 tlRefreshIncludedEvents：那是启动/切换文件用的，
      // 收尾会按一次「今天」而把用户正在看的滚动位置拉走）
      const mem = (tlCalEvents || []).find((e) => e.uid === key);
      if (mem) mem.notes = String(notes == null ? '' : notes);
      tlAlarmIncludeRevision++;
      await tlSyncAlarms();
      if (typeof tlRenderEventsContent === 'function') tlRenderEventsContent();
      if (typeof tlPushStickyRefreshes === 'function') tlPushStickyRefreshes();
      return { ok: true, file: name };
    }

    // ===== 🆕 在 INCLUDE 来源档中「新建行程」=====
    //   与上面的 Remark 回写同一套路径（tlIncludeFileTarget），差别只在**只追加、不重写**：
    //     ① 追加不需要「按块序号定位」，因此不受「缺 title 的 EVENT 块」影响（那类安全阀只服务于整块替换）；
    //     ② 绝不重画整份文件 → 用户手写的未知字段、段落顺序、缩进全部原样保留；
    //     ③ 插入点＝最后一个 EVENT 块的结尾（＝下一个 ## 级标题之前），没有 EVENT 块时插在 ## TAGS / ## INCLUDE /
    //        ## HOLIDAY / ## DIARY 这些 meta 块之前——直接 append 到文件末尾会掉进 meta 区块里。
    function tlInsertEventBlockText(content, blockText) {
      const text = String(content == null ? '' : content).replace(/\r\n/g, '\n');
      const block = String(blockText || '').replace(/\n+$/, '') + '\n';
      const re = /^##[ \t]*EVENT(?:\([^)]*\))?[ \t]*$/gm;
      let last = -1, m;
      while ((m = re.exec(text))) last = m.index;
      // 统一收口：head 保留原文（去掉尾部空白）＋ 空行 ＋ block ＋ tail（保持与原文件之间的分隔）
      const join = (head, tail) => {
        const h = head.replace(/\s*$/, '');
        const t = tail.replace(/^\s*/, '');
        return (h ? h + '\n\n' : '') + block + (t ? '\n' + t : '');
      };
      if (last < 0) {
        // 没有任何 EVENT 块：插到 meta 块之前；连 meta 块都没有 → 追加到文件末尾
        const cut = text.search(/^##[ \t]*(TAGS|INCLUDE|HOLIDAY|DIARY)[ \t]*$/m);
        if (cut < 0) return join(text, '');
        return join(text.slice(0, cut), text.slice(cut));
      }
      const nextRel = text.slice(last + 1).search(/^##[ \t]/m);
      const end = nextRel >= 0 ? last + 1 + nextRel : text.length;
      return join(text.slice(0, end), text.slice(end));
    }
    // 把一个行程块追加进指定 include 档（立即落盘）。返回 { ok, error?, file? }
    async function tlAppendEventToIncludeFile(name, ev) {
      const fileName = String(name || '').trim();
      if (!fileName) return { ok: false, error: '未指定写入文件' };
      const io = await tlIncludeFileTarget(fileName);
      if (!io) return { ok: false, error: '无法定位所在目录（请确认 Calendar 已打开）' };
      let content = null;
      try { content = await io.read(); } catch (e) { return { ok: false, error: '读取 ' + fileName + ' 失败：' + (e.message || e) }; }
      // 读不到（文件不存在／刚被外部删除）→ 当成空档新建，但不覆写任何已存在的内容
      if (content == null) content = '';
      const next = tlInsertEventBlockText(content, tlEventToMarkdown(ev));
      if (next === content) return { ok: true, file: fileName, unchanged: true };
      try { await io.write(next); } catch (err) { return { ok: false, error: '写入 ' + fileName + ' 失败：' + (err.message || err) }; }
      return { ok: true, file: fileName };
    }
    // ===== 🗑 从 md 内容里「外科手术式」删除一个行程块（新建的逆操作）=====
    //   设计原则与 tlInsertEventBlockText 一致：只摘掉目标块，其余内容（含未知字段、
    //   段落顺序、缩进）逐字节保留；绝不用「整份重新序列化」的方式删。
    //   块定位＝与解析器同一真相：对每个 ## EVENT 块跑 tlParseEvents，比 title+date。
    //   多条同名同日 → 删最后一个（与「新建追加在末尾」互为镜像）。
    //   返回删除后的全文；找不到匹配块返回 null（调用方据此报错，不静默）。
    function tlRemoveEventBlockText(content, ev) {
      const text = String(content == null ? '' : content).replace(/\r\n/g, '\n');
      const title = String((ev && ev.title) || '');
      const date = String((ev && ev.date) || '');
      // 收集所有 EVENT 块头位置（含 EVENT(REPEAT)），块尾＝下一个 ## 级标题
      const heads = [];
      const re = /^##[ \t]*EVENT(?:\([^)]*\))?[ \t]*$/gm;
      let m;
      while ((m = re.exec(text))) heads.push(m.index);
      let hitStart = -1, hitEnd = -1;
      for (let i = heads.length - 1; i >= 0; i--) {
        const start = heads[i];
        const nextRel = text.slice(start + 1).search(/^##[ \t]/m);
        const end = nextRel >= 0 ? start + 1 + nextRel : text.length;
        const parsed = tlParseEvents(text.slice(start, end)) || [];
        const strict = parsed.filter((p) => String(p.title || '') === title && String(p.date || '') === date);
        const loose = parsed.filter((p) => String(p.title || '') === title);
        if ((strict.length ? strict : loose).length) { hitStart = start; hitEnd = end; break; }
      }
      if (hitStart < 0) return null;
      const head = text.slice(0, hitStart).replace(/\s*$/, '');
      const tail = text.slice(hitEnd).replace(/^\s*/, '');
      // 拼接规则与 tlInsertEventBlockText 的 join 镜像：head／tail 之间恰好一个空行；
      // 块是最后一块时收掉多余空行（非空结果保留恰好一个结尾换行）
      const out = (head ? head + '\n\n' : '') + tail;
      return out ? out.replace(/\s*$/, '\n') : out;
    }
    // 从指定 include 档删除一个行程块（立即落盘）。返回 { ok, error?, file? }
    async function tlRemoveEventFromIncludeFile(name, ev) {
      const fileName = String(name || '').trim();
      if (!fileName) return { ok: false, error: '未指定要删除的来源文件' };
      const io = await tlIncludeFileTarget(fileName);
      if (!io) return { ok: false, error: '无法定位所在目录（请确认 Calendar 已打开）' };
      let content = null;
      try { content = await io.read(); } catch (e) { return { ok: false, error: '读取 ' + fileName + ' 失败：' + (e.message || e) }; }
      if (content == null) return { ok: false, error: '读取 ' + fileName + ' 失败：文件不存在' };
      const next = tlRemoveEventBlockText(content, ev);
      if (next === null) return { ok: false, error: '在 ' + fileName + ' 中没有找到可删除的行程块' };
      try { await io.write(next); } catch (err) { return { ok: false, error: '写入 ' + fileName + ' 失败：' + (err.message || err) }; }
      return { ok: true, file: fileName };
    }
    // 刷新后 uid 由文件位置重建（ro-<文件序>-<块序>-evpN），只能按 来源档+标题+日期 反查刚写入的那条。
    //   多个同名同日 → 取最后一个（刚追加在文件末尾，序号最大）
    //   ⚠️ 两级匹配：先「来源档＋标题＋日期」（同名同日取最后一条 ＝ 刚追加的那条），
    //      匹配不到再退「来源档＋标题」——序列化/解析对日期的规范化一旦不一致（空日期、补零差异），
    //      严格匹配会返回 '' → 便利贴建出来了但翻页跳不到（症状：新建没反应、页面不动）。
    function tlFindIncludedEventKey(src, title, date) {
      const bySrc = (tlIncludedEvents || []).filter((e) => e.src === src &&
        String(e.title || '') === String(title || ''));
      const strict = bySrc.filter((e) => String(e.date || '') === String(date || ''));
      const hit = (strict.length ? strict : bySrc).pop();
      return hit ? hit.uid : '';
    }
    // 写入后把刚落盘的那条「定位一下」。
    // 与 tlJumpToEventCore 的区别：当前视图没显示这条时**静默跳过**（不是错误，不要弹 toast 打断）。
    function tlFlashIncludedEvent(target, ev) {
      try {
        const uid = tlFindIncludedEventKey(target, ev.title, ev.date);
        if (!uid) return;
        const el = document.querySelector('[data-uid="' + uid + '"]');
        if (!el || !el.offsetParent) return;
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.remove('tl-jump-flash');
        void el.offsetWidth;
        el.classList.add('tl-jump-flash');
        setTimeout(() => el.classList.remove('tl-jump-flash'), 2000);
      } catch (e) { /* 定位失败不影响写入结果 */ }
    }

    // 写入目标下拉：'' = 主文件；其余 = 同目录 calendar-*.md（含未勾选的：写进去后勾选即可见）
    function tlEvTargetOptions() {
      const names = (tlIncludedFiles || []).map((f) => f.name).filter(Boolean);
      return [''].concat(names);
    }
    // 某个 include 档是否已进入清单（宿主 index.html 用它决定「先补一次刷新」；避免外部直接读 tlIncludedFiles 的 TDZ 风险）
    function tlHasIncludeFile(name) {
      const n = String(name || '');
      return !!n && (tlIncludedFiles || []).some((f) => f.name === n);
    }
    function tlRenderEvTargetSelect(selected) {
      const sel = document.getElementById('tlEvFTarget');
      if (!sel) return;
      const names = tlEvTargetOptions();
      // 目标是 include 档时，即使它本次不在目录清单里（文件刚被外部删/改名）也要保留这一项，避免选项消失后静默改写到主文件
      const cur = String(selected || '');
      if (cur && names.indexOf(cur) < 0) names.push(cur);
      sel.innerHTML = names.map((n) =>
        '<option value="' + tlEscapeHtml(n) + '">' + (n ? tlEscapeHtml(n) : 'calendar.md（主文件）') + '</option>'
      ).join('');
      sel.value = cur;
      tlSyncEvTargetHint();
    }
    function tlSyncEvTargetHint() {
      const sel = document.getElementById('tlEvFTarget');
      const hint = document.getElementById('tlEvFTargetHint');
      if (!sel || !hint) return;
      const v = String(sel.value || '');
      // 变量与下拉保持同步（保存路径以变量为准；编辑既有行程时行已隐藏、恒为 ''）
      tlEvFormTarget = tlEvFormUid ? '' : v;
      const titleEl = document.getElementById('tlEvFormTitle');
      if (titleEl && !tlEvFormUid) titleEl.textContent = v ? ('新增行程 → ' + v) : '新增行程';
      if (!v) {
        hint.textContent = '写入主文件 calendar.md：点「写入编辑内容」先进编辑器缓冲，再按编辑器「保存」才落盘';
        return;
      }
      const loaded = (tlIncludedFiles || []).some((f) => f.name === v);
      const selNames = [];
      try {
        const list = (tlIncludedFiles || []).map((f) => f.name);
        tlParseIncludeSel(document.getElementById('taskText').value, list).forEach((n) => selNames.push(n));
      } catch (e) { /* 解析失败就不提示勾选状态 */ }
      const checked = selNames.indexOf(v) >= 0;
      hint.textContent = '直接追加写入 ' + v + '（点「写入编辑内容」即刻落盘，不经过编辑器缓冲、无需再按「保存」）'
        + (loaded && !checked ? '；该档当前未勾选，勾选后才会显示在行程列表里' : '');
    }
    // 从「📄 Include 清单」某一行发起新建：以该档预填打开新增表单（未勾选则顺手勾上，否则写进去也看不见）
    function tlNewEventInInclude(name) {
      const fileName = String(name || '').trim();
      if (!fileName) return;
      let checked = false;
      try {
        const list = (tlIncludedFiles || []).map((f) => f.name);
        checked = tlParseIncludeSel(document.getElementById('taskText').value, list).has(fileName);
      } catch (e) { checked = false; }
      if (!checked) tlSetInclude(fileName, true);
      const ov = document.getElementById('tlIncludeListOverlay');
      if (ov) ov.style.display = 'none';
      tlOpenEventForm(null, null, { target: fileName });
    }

    // 📂 Include 加载清单：列出同目录被 include 的 calendar-*.md 及其大小
    function tlFormatSize(bytes) {
      const n = Number(bytes) || 0;
      if (n < 1024) return n + ' B';
      if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
      return (n / (1024 * 1024)).toFixed(1) + ' MB';
    }
    function tlOpenIncludeList() {
      const body = document.getElementById('tlIncludeListBody');
      const fileEl = document.getElementById('tlIncludeListFile');
      const list = tlIncludedFiles || [];
      const sel = tlParseIncludeSel(document.getElementById('taskText').value, list.map((f) => f.name));
      if (fileEl) fileEl.textContent = '已加载 ' + list.filter((f) => sel.has(f.name)).length + ' / 共 ' + list.length + ' 个文件';
      if (!body) return;
      if (!list.length) {
        body.innerHTML = '<div class="tl-include-empty">同目录下没有其他 calendar-*.md 文件</div>';
      } else {
        body.innerHTML = list.map((f) => {
          const on = sel.has(f.name);
          // 🆕 行尾「＋」：直接在该档新建行程（写入位置＝该档，追加落盘）。
          //    结构：div 行 → label（勾选框＋文件名，点名字即切换）＋ 大小 ＋ 独立 button，
          //    避免把 <button> 塞进 <label>（HTML 规范不允许 label 内含其它交互控件，实测虽能跑但键盘/朗读会串）。
          return '<div class="tl-include-item">' +
            '<label class="tl-include-main">' +
            '<input type="checkbox" class="tl-include-check" data-name="' + tlEscapeHtml(f.name) + '"' + (on ? ' checked' : '') + '>' +
            '<span class="fname">' + tlEscapeHtml(f.name) + '</span></label>' +
            '<span class="fsize">' + tlFormatSize(f.size) + '</span>' +
            '<button type="button" class="tl-include-add" data-name="' + tlEscapeHtml(f.name) + '" title="在此文件中新建行程（新建便利贴）">＋</button>' +
            '</div>';
        }).join('');
      }
      // 📎 绑定一次：行内 checkbox 勾选变化 → 立即写入 calendar.md 并动态重新加载
      if (!tlIncludeListBound && body) {
        body.addEventListener('change', (e) => {
          const cb = e.target.closest('.tl-include-check');
          if (!cb) return;
          tlSetInclude(cb.getAttribute('data-name'), cb.checked);
        });
        body.addEventListener('click', (e) => {
          const btn = e.target.closest('.tl-include-add');
          if (!btn) return;
          e.preventDefault();
          e.stopPropagation();
          tlNewEventInInclude(btn.getAttribute('data-name'));
        });
        tlIncludeListBound = true;
      }
      const ov = document.getElementById('tlIncludeListOverlay');
      if (ov) ov.style.display = 'flex';
    }
    // 📎 勾选/取消勾选某个 include 文件：写回 ## INCLUDE 区块 → 立即持久化 → 立即动态重载（加载/释放）
    function tlSetInclude(name, on) {
      const names = (tlIncludedFiles || []).map((f) => f.name);
      if (!names.includes(name)) return;
      const sel = tlParseIncludeSel(document.getElementById('taskText').value, names);
      if (on) sel.add(name); else sel.delete(name);
      const list = names.map((n) => ({ name: n, on: sel.has(n) }));
      tlWriteIncludeBlock(list);
      // 立即落盘（含外部文件模式）：写回 calendar.md，供下次启动按勾选加载 + 跨设备同步
      if (typeof saveTask === 'function') { try { saveTask(false, true); } catch (e) {} }
      // 立即动态重载：勾选→出现，取消→释放，无需重开文件
      tlKickIncludeRefresh();
      // 刷新弹窗计数（列表本身状态已由 checkbox 反映）
      const fileEl = document.getElementById('tlIncludeListFile');
      if (fileEl) fileEl.textContent = '已加载 ' + list.filter((it) => it.on).length + ' / 共 ' + list.length + ' 个文件';
    }

    // ========== 📖 Glossary 术语表：收集全部行程（标题＋备注）中的 [[term]]，排序去重展示 ==========
    // 同名 term 只保留「最完整」的一条：4 段 > 3 段 > 2 段 > 1 段；完整度并列时以先出现者为准。
    // 跳过代码围栏（与渲染约定一致）；解析规则共用 tlParseTermToken（dl/cp/cr/裸日期排除）。
    function tlTermCompleteness(t) {
      return (t.release ? 4 : 0) + (t.domain ? 2 : 0) + (t.def ? 1 : 0);
    }
    function tlCollectTerms() {
      const map = new Map();   // 小写 term 为 key（大小写不同视为同一 term）→ { term, def, domain, release, count, srcs }
      const add = (text, ev) => {
        if (!text) return;
        let inFence = false;
        String(text).split('\n').forEach((line) => {
          if (/^\s*```/.test(line)) { inFence = !inFence; return; }
          if (inFence) return;
          String(line).replace(/\[\[([^\]\n]+)\]\]/g, (m, inner) => {
            const t = tlParseTermToken(inner);
            if (t) {
              const key = t.term.toLowerCase();   // 🆕 大小写不同 → 同一 term
              let rec = map.get(key);
              if (!rec) {
                rec = { term: t.term, def: t.def, domain: t.domain, release: t.release || '', count: 0, srcs: [] };
                map.set(key, rec);
              }
              rec.count += 1;   // 出现次数＝标题＋备注命中之和（同一事件标题与备注都命中也各计 1）
              if (tlTermCompleteness(t) > tlTermCompleteness(rec)) { rec.def = t.def; rec.domain = t.domain; rec.release = t.release || ''; }
              // 标签沿用「先出现者」的大小写（稳定可预测），仅合并释义/领域/发行/计数
              // 🆕 收集使用该 term 的「来源日程事件」（按 uid 去重），供术语表逐一跳转
              if (ev && ev.uid && !rec.srcs.some((s) => s.uid === ev.uid)) {
                rec.srcs.push({ uid: ev.uid, title: ev.title || '', date: ev.date || '' });
              }
            }
            return m;
          });
        });
      };
      (tlCalEvents || []).forEach((ev) => { add(ev.title, ev); add(ev.notes, ev); });
      // 🆕 2026-11-14：额外扫 gp 围栏的 TERM=xxx，把围栏内容当作该 term 的额外说明
      // 格式：{gpX|attrs段|TERM=便利贴} → 围栏内容就是"便利贴"的说明
      (tlCalEvents || []).forEach((ev) => {
        if (!ev || !ev.notes) return;
        const lines = String(ev.notes).split('\n');
        const scan = (typeof tlGpFenceScan === 'function') ? tlGpFenceScan(lines) : { ranges: [] };
        (scan.ranges || []).forEach((r) => {
          if (!r.termName) return;  // 没有 TERM=xxx 的围栏跳过
          const key = r.termName.toLowerCase();
          let rec = map.get(key);
          if (!rec) {
            rec = { term: r.termName, def: '', domain: '', release: '', count: 0, srcs: [], fenceDesc: '', fenceEvUids: [], fenceRange: null };
            map.set(key, rec);
          }
          // 围栏内容：start+1 到 end-1（去掉 open/close 行）
          const fenceContent = lines.slice(r.start + 1, r.end).join('\n').trim();
          if (fenceContent) {
            // 取最完整的（更长的优先）
            if (!rec.fenceDesc || fenceContent.length > rec.fenceDesc.length) {
              rec.fenceDesc = fenceContent;
              rec.fenceEvUids = [ev.uid || ''];
              rec.fenceRange = { ev: ev, start: r.start, end: r.end };
            }
          }
          // 来源事件
          if (ev && ev.uid && !rec.srcs.some((s) => s.uid === ev.uid)) {
            rec.srcs.push({ uid: ev.uid, title: ev.title || '', date: ev.date || '' });
          }
        });
      });
      // 排序：英文/数字开头的术语在前（en 排序），其余按中文拼音（zh-Hans-CN）；ICU 默认会把拉丁字母排在汉字之后，显式分桶修正
      const isAscii = (s) => /^[0-9A-Za-z]/.test(s);
      return Array.from(map.values()).sort((a, b) => {
        const ab = isAscii(a.term), bb = isAscii(b.term);
        if (ab !== bb) return ab ? -1 : 1;
        return a.term.localeCompare(b.term, ab ? 'en' : 'zh-Hans-CN');
      });
    }
    // ===== 🆕 术语表文本搜索：只过滤「本次开窗收集到的」清单，不重算、不写档 =====
    let tlGlossTerms = [];
    function tlGlossQueryTokens() {
      const el = document.getElementById('tlGlossarySearch');
      return String((el && el.value) || '').trim().toLowerCase().split(/\s+/).filter(Boolean);
    }
    function tlGlossHaystack(t) {
      return [t.term, t.def, t.domain, t.release]
        .concat((t.srcs || []).map((s) => (s.title || '') + ' ' + (s.date || '')))
        .filter(Boolean).join(' ').toLowerCase();
    }
    // 纯文字命中包 <mark>：先切原始字串再逐段 escape，绝不破坏 HTML 实体／属性
    function tlGlossHl(text, tokens) {
      const s = String(text == null ? '' : text);
      if (!s || !tokens.length) return tlEscapeHtml(s);
      const low = s.toLowerCase();
      const hits = [];
      tokens.forEach((tok) => {
        let from = 0;
        for (;;) {
          const at = low.indexOf(tok, from);
          if (at < 0) break;
          hits.push([at, at + tok.length]);
          from = at + tok.length;
        }
      });
      if (!hits.length) return tlEscapeHtml(s);
      hits.sort((a, b) => a[0] - b[0]);
      const merged = [];
      hits.forEach((h) => {
        const last = merged[merged.length - 1];
        if (last && h[0] <= last[1]) last[1] = Math.max(last[1], h[1]);
        else merged.push(h.slice());
      });
      let out = '', pos = 0;
      merged.forEach((h) => {
        out += tlEscapeHtml(s.slice(pos, h[0])) + '<mark class="tl-gloss-hl">' + tlEscapeHtml(s.slice(h[0], h[1])) + '</mark>';
        pos = h[1];
      });
      return out + tlEscapeHtml(s.slice(pos));
    }
    // 胶囊 HTML（与事件渲染同款标记：.tl-term-cap 金胶囊＋内嵌 .tl-term-domain／.tl-term-release 小胶囊＋釋義 tooltip）
    // tokens 只供搜索高亮，缺省＝原样输出（其它调用点零影响）
    function tlGlossCapHtml(t, tokens) {
      const defMap = tlGetTermDefMap();
      const allDefs = [];
      if (t.def) allDefs.push(t.def);
      const globalDefs = defMap.get(t.term.toLowerCase());
      if (globalDefs) globalDefs.forEach((d) => { if (!allDefs.includes(d)) allDefs.push(d); });
      const tooltip = allDefs.join(' --- ');
      const hl = tokens || [];
      return '<span class="tl-term"><span class="tl-term-cap"' +
        (tooltip ? ' title="' + tlEscapeHtml(tooltip) + '"' : '') + '>' +
        tlGlossHl(t.term, hl) +
        (t.domain ? '<span class="tl-term-domain">' + tlGlossHl(t.domain, hl) + '</span>' : '') +
        (t.release ? '<span class="tl-term-release">' + tlGlossHl(t.release, hl) + '</span>' : '') +
        '</span></span>';
    }
    function tlRenderGlossary() {
      const body = document.getElementById('tlGlossaryBody');
      if (!body) return;
      const input = document.getElementById('tlGlossarySearch');
      const tokens = tlGlossQueryTokens();
      const all = tlGlossTerms;
      const shown = tokens.length
        ? all.filter((t) => { const hay = tlGlossHaystack(t); return tokens.every((tok) => hay.includes(tok)); })
        : all;
      const countEl = document.getElementById('tlGlossarySearchCount');
      if (countEl) countEl.textContent = tokens.length ? (shown.length + ' / ' + all.length) : '';
      const clearEl = document.getElementById('tlGlossarySearchClear');
      if (clearEl) clearEl.hidden = !(input && input.value);
      if (!all.length) {
        body.innerHTML = '<div class="tl-gloss-empty">目前没有任何 [[term]] 术语。<br>语法：<code>[[term:釋義:領域:發行]]</code>（釋義／領域／發行皆可省略，發行可记「首发」等创作节点）</div>';
      } else if (!shown.length) {
        body.innerHTML = '<div class="tl-gloss-noresult">没有符合「' + tlEscapeHtml(String((input && input.value) || '').trim()) + '」的术语。<br>可试试术语名、释义、领域、发行或来源行程的关键词。</div>';
      } else {
        body.innerHTML = shown.map((t) => {
          // 来源事件 chips：关弹层 → scrollIntoView 居中 → 金色描边闪 2s；标题走 MD 行内渲染，故不注入 <mark>
          const srcHtml = (t.srcs && t.srcs.length)
            ? '<div class="tl-gloss-srcs"><span class="tl-gloss-srcs-label">来源事件：</span>' + t.srcs.map((s) => {
                const srcText = ((s.title || '') + ' ' + (s.date || '')).toLowerCase();
                const hit = tokens.length > 0 && tokens.every((tok) => srcText.includes(tok));
                return '<button type="button" class="tl-gloss-src' + (hit ? ' tl-gloss-src-hit' : '') + '" title="跳转：' + tlEscapeHtml(s.title || '') + (s.date ? '（' + tlEscapeHtml(s.date) + '）' : '') + '" onclick="tlGlossJumpToEvent(\'' + tlEscapeHtml(s.uid) + '\')">' +
                  tlRenderInlineMarkdown(s.title || '(无标题)') +
                  (s.date ? ' <span class="tl-gloss-src-date">' + tlEscapeHtml(s.date) + '</span>' : '') +
                  '</button>';
              }).join('') + '</div>'
            : '';
          // 🆕 gp 围栏额外说明区域
          const fenceHtml = t.fenceDesc
            ? '<div class="tl-gloss-fence" style="margin-top:8px;padding:8px 10px;background:var(--ev-bg-soft,#1f2b3d);border-left:3px solid var(--ev-primary,#3b82f6);border-radius:4px">' +
                '<div class="tl-gloss-fence-head" style="display:flex;align-items:center;gap:6px;margin-bottom:6px">' +
                  '<span style="font-size:11px;color:var(--ev-muted);font-weight:600">📌 围栏说明</span>' +
                  (t.fenceRange && t.fenceRange.ev && t.fenceRange.ev.uid
                    ? '<button type="button" onclick="tlGlossJumpToFence(\'' + tlEscapeHtml(t.fenceRange.ev.uid) + '\',' + t.fenceRange.start + ',' + t.fenceRange.end + ')" style="font-size:11px;background:var(--ev-primary);color:#fff;border:none;border-radius:3px;padding:2px 8px;cursor:pointer">定位到围栏</button>'
                    : '') +
                '</div>' +
                '<div class="tl-gloss-fence-body" style="font-size:12px;color:var(--ev-text);white-space:pre-wrap;max-height:160px;overflow:auto">' + tlGlossHl(t.fenceDesc, tokens) + '</div>' +
              '</div>'
            : '';
          return '<div class="tl-gloss-row">' +
            '<div class="tl-gloss-row-head">' + tlGlossCapHtml(t, tokens) +
            '<span class="tl-gloss-def">' + (t.def ? tlGlossHl(t.def, tokens) : '<span class="tl-gloss-nodef">（无释义）</span>') + '</span>' +
            '<span class="tl-gloss-count" title="出现次数">×' + t.count + '</span>' +
            '</div>' + srcHtml + fenceHtml + '</div>';
        }).join('');
      }
      body.scrollTop = 0;   // 新结果集从第一条看（与明细滚动收口同口径）
    }
    function tlGlossSearchClear() {
      const input = document.getElementById('tlGlossarySearch');
      if (!input) return;
      input.value = '';
      tlRenderGlossary();
      input.focus();
    }
    function tlGlossSearchKeydown(e) {
      if (e.isComposing || e.keyCode === 229) return;   // IME 组字中不拦
      if (e.key !== 'Escape') return;
      e.preventDefault(); e.stopPropagation();
      // Esc 只清空查询、不关弹层（关闭仍走右上角 ✕ / 点背罩），也不让全局快捷键接手
      const input = document.getElementById('tlGlossarySearch');
      if (input && input.value) { input.value = ''; tlRenderGlossary(); }
    }
    function tlOpenGlossary() {
      const body = document.getElementById('tlGlossaryBody');
      if (!body) return;
      const fileEl = document.getElementById('tlGlossaryFile');
      tlGlossTerms = tlCollectTerms();
      if (fileEl) fileEl.textContent = '共 ' + tlGlossTerms.length + ' 个术语';
      const input = document.getElementById('tlGlossarySearch');
      if (input) input.value = '';   // 每次开窗从干净状态开始
      tlRenderGlossary();
      const ov = document.getElementById('tlGlossaryOverlay');
      if (ov) ov.style.display = 'flex';
      if (input) { try { input.focus(); } catch (e) {} }
    }
    function tlCloseGlossary() {
      const ov = document.getElementById('tlGlossaryOverlay');
      if (ov) ov.style.display = 'none';
    }
    function tlCloseIncludeList() {
      const ov = document.getElementById('tlIncludeListOverlay');
      if (ov) ov.style.display = 'none';
    }

    // ⏰ 闹铃提醒查询：两个页签「待执行」「已结案」
    let tlAlarmFocusUnitsPending = [];  // 待执行的 focusUnit 索引
    let tlAlarmFocusUnitsDone = [];     // 已结案的 focusUnit 索引
    let tlAlarmCurrentTab = 'pending';  // 当前页签
    function tlOpenAlarmPreview() {
      const ov = document.getElementById('tlAlarmPreviewOverlay');
      if (!ov) return;
      tlAlarmCurrentTab = 'pending';  // 默认打开待执行
      // 重置 tab 按钮样式（pending active）
      const pBtn = document.getElementById('tlAlarmTabPending');
      const dBtn = document.getElementById('tlAlarmTabDone');
      if (pBtn) { pBtn.style.background = 'var(--ev-primary, #3b82f6)'; pBtn.style.color = '#fff'; pBtn.style.fontWeight = '700'; }
      if (dBtn) { dBtn.style.background = 'transparent'; dBtn.style.color = 'var(--ev-muted)'; dBtn.style.fontWeight = '400'; }
      tlRenderAlarmPreview();
      ov.style.display = 'flex';
    }
    function tlCloseAlarmPreview() {
      const ov = document.getElementById('tlAlarmPreviewOverlay');
      if (ov) ov.style.display = 'none';
    }
    // 🆕 切换页签
    function tlAlarmSwitchTab(tab) {
      tlAlarmCurrentTab = (tab === 'done') ? 'done' : 'pending';
      // 更新 tab 按钮样式（active 状态：深色背景 + 白字 + 圆角，非常明显）
      const pBtn = document.getElementById('tlAlarmTabPending');
      const dBtn = document.getElementById('tlAlarmTabDone');
      const isPending = tlAlarmCurrentTab === 'pending';
      if (pBtn) {
        pBtn.style.background = isPending ? 'var(--ev-primary, #3b82f6)' : 'transparent';
        pBtn.style.color = isPending ? '#fff' : 'var(--ev-muted)';
        pBtn.style.fontWeight = isPending ? '700' : '400';
        pBtn.style.borderRadius = '6px';
        pBtn.style.borderBottom = 'none';
      }
      if (dBtn) {
        dBtn.style.background = !isPending ? 'var(--ev-primary, #3b82f6)' : 'transparent';
        dBtn.style.color = !isPending ? '#fff' : 'var(--ev-muted)';
        dBtn.style.fontWeight = !isPending ? '700' : '400';
        dBtn.style.borderRadius = '6px';
        dBtn.style.borderBottom = 'none';
      }
      tlRenderAlarmPreview();  // 重渲染当前 tab
    }
    // 🆕 给定事件 notes 和 alert message，算出 alert 所在区块的 focusUnit
    // 与右键小圆点 tlCtxUnitOf 返回值完全同口径：{ kind, start, end, type, text }
    function tlBuildAlarmFocusUnit(notes, message) {
      if (!notes) return null;
      const lines = notes.replace(/\r\n/g, '\n').split('\n');
      const needle = '[[alert:' + String(message || '').trim();
      // ① 先找 alert 标记在 notes 内部第几行
      let alertLine = -1;
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].indexOf(needle) >= 0) { alertLine = i; break; }
      }
      if (alertLine < 0) {
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].indexOf('[[alert:') >= 0) { alertLine = i; break; }
        }
      }
      if (alertLine < 0) return null;
      // ② 用 tlSplitMdBlocks 找包含 alertLine 的区块（gp 围栏优先）
      let blocks = [];
      if (typeof tlSplitMdBlocks === 'function') blocks = tlSplitMdBlocks(notes);
      // 优先 type='gp' 的围栏
      let hit = null;
      for (let i = 0; i < blocks.length; i++) {
        const b = blocks[i];
        if (b.start <= alertLine && alertLine <= b.end && b.type === 'gp') { hit = b; break; }
      }
      // 兜底：任意 type
      if (!hit) {
        for (let i = 0; i < blocks.length; i++) {
          const b = blocks[i];
          if (b.start <= alertLine && alertLine <= b.end) { hit = b; break; }
        }
      }
      if (hit) {
        const blockText = lines.slice(hit.start, hit.end + 1).join('\n');
        return { kind: 'block', start: hit.start, end: hit.end, type: hit.type, text: blockText };
      }
      // 极端兜底：单行 block
      return { kind: 'block', start: alertLine, end: alertLine, type: '', text: lines[alertLine] || '' };
    }
    // 跳转到指定 tab + idx 的闹铃对应的 alert 围栏
    async function tlJumpToAlarmItem(tab, idx) {
      const arr = (tab === 'done') ? tlAlarmFocusUnitsDone : tlAlarmFocusUnitsPending;
      const item = arr[idx];
      if (!item) return;
      tlCloseAlarmPreview();
      const ev = item.ev;
      const uid = item.uid;
      const focusUnit = item.focusUnit;
      if (!ev || !uid || !focusUnit) return;

      // ① ⭐ 优先便利贴（用户要求）：若事件有 sticky，先把便利贴唤起并闪到 alert 围栏
      const stickyCount = parseInt(ev.sticky, 10) || 0;
      if (stickyCount > 0 && typeof tlFocusStickyNote === 'function') {
        try { await tlFocusStickyNote(uid, 0, focusUnit); }
        catch (e) { console.warn('[AlarmPreview] 便利贴跳转失败:', e); }
      }

      // ② 主画面：用 focusUnit 的 start/end 找小圆点 → 找到那个 md-unit → 滚动 + 闪烁
      const cardEl = document.querySelector('[data-uid="' + uid + '"]');
      let targetUnit = null;
      if (cardEl && cardEl.offsetParent) {
        // 事件卡内找 .md-unit-edit[data-start=focusUnit.start][data-end=focusUnit.end]
        const exactBtn = cardEl.querySelector(
          '.md-unit-edit[data-start="' + focusUnit.start + '"][data-end="' + focusUnit.end + '"]'
        );
        if (exactBtn) targetUnit = exactBtn.closest('.md-unit');
        // 兜底：范围匹配
        if (!targetUnit) {
          const btns = cardEl.querySelectorAll('.md-unit-edit[data-start][data-end]');
          for (let i = 0; i < btns.length; i++) {
            const s = parseInt(btns[i].getAttribute('data-start'), 10);
            const e = parseInt(btns[i].getAttribute('data-end'), 10);
            if (s === focusUnit.start && e === focusUnit.end) {
              targetUnit = btns[i].closest('.md-unit'); break;
            }
          }
        }
        // 闪事件卡本身（金色描边）
        cardEl.classList.remove('tl-jump-flash');
        void cardEl.offsetWidth;
        cardEl.classList.add('tl-jump-flash');
      }

      // ③ 精准闪烁目标 md-unit（和右键小圆点点击后闪烁的是同一个元素！）
      if (targetUnit) {
        targetUnit.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        tlBlinkFound(targetUnit);
      }
    }
    // 让元素闪烁：复用便利贴的 .fs-found-blink class（blinkFoundLineTwice 同口径）
    function tlBlinkFound(el) {
      if (!el) return;
      el.classList.remove('fs-found-blink');
      void el.offsetWidth;
      el.classList.add('fs-found-blink');
      setTimeout(() => { el.classList.remove('fs-found-blink'); }, 4200);
    }
    // 🆕 重写：分 pending / done 两个 tab，两个都支持定位+闪烁
    function tlRenderAlarmPreview() {
      const body = document.getElementById('tlAlarmPreviewBody');
      if (!body) return;
      const textArea = document.getElementById('taskText');
      if (!textArea) { body.innerHTML = '<div class="tl-ev-stats-empty">找不到编辑器</div>'; return; }
      const events = tlAllEvents(textArea.value);
      const now = Date.now();
      // 扫描全部闹铃
      let pending = [], done = [];
      events.forEach((ev) => {
        if (!ev || !ev.notes) return;
        const hasSticky = parseInt(ev.sticky, 10) > 0;
        const markers = tlAlertMarkers(ev.notes);
        markers.forEach((a) => {
          const focusUnit = tlBuildAlarmFocusUnit(ev.notes, a.message);
          const row = {
            ...a,
            title: ev.title || '(无标题)',
            date: ev.date || '',
            ro: ev.ro === true,
            src: ev.src || '',
            hasSticky,
            overdue: a.dueAt !== null && a.dueAt <= now,
            eventUid: ev.uid || '',
            ev: ev,
            focusUnit: focusUnit
          };
          if (a.completed) done.push(row); else pending.push(row);
        });
        // 🆕 循环闹铃的历史完成记录：从表格 dates 展开到 done tab
        // 找该事件 notes 里的所有循环 alert（通过 marker 正则扫）
        const text = String(ev.notes || '');
        const lines = text.split('\n');
        const fences = (typeof tlGpFenceScan === 'function') ? tlGpFenceScan(lines).ranges : [];
        lines.forEach((line, lineIndex) => {
          const re = /\[\[alert:([\s\S]*?):((?:anniversary\s+\d{4}-\d{2}-\d{2}\s+\d{4})|(?:everyday\s+\d{4})|(?:w[1-7]\s*-\s*w[1-7]\s+\d{4})|(?:w[1-7](?:\s*,\s*w[1-7])+\s+\d{4}))\s*:\s*([1-9]\d*)\s*(m|h|d)\]\]/gi;
          let m2;
          while ((m2 = re.exec(line))) {
            const range = fences.find((item) => item.alert && item.start + 1 === lineIndex);
            if (!range) continue;
            const table = tlAlertTableInfo(lines, lineIndex, range.end);
            if (!table || !table.dates || !table.dates.length) continue;
            // 跳过 dueAt 对应的那一条（已经在 pending 里了）
            const dueAt = tlAlertRecurringDue(m2[2], table.dates, Date.now());
            const dueYmd = dueAt ? (() => { const d = new Date(dueAt); return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0'); })() : '';
            // 表格里每条完成日期都生成一个 done 项
            table.dates.forEach((d) => {
              const ds = String(d || '').trim();
              if (!ds) return;
              // 如果就是 pending 里那条 dueAt → 跳过
              if (dueYmd && ds.indexOf(dueYmd) === 0) return;
              // 解析日期时间
              let ts = null;
              const dm = ds.match(/(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/);
              if (dm) {
                const dt = new Date(+dm[1], +dm[2]-1, +dm[3], dm[4]?+dm[4]:0, dm[5]?+dm[5]:0);
                ts = dt.getTime();
              }
              done.push({
                message: m2[1].trim(),
                dueAt: ts,
                intervalMs: tlAlertInterval(m2[3] + m2[4]),
                completed: true,
                recurring: true,
                title: ev.title || '(无标题)',
                date: ev.date || '',
                ro: ev.ro === true,
                src: ev.src || '',
                hasSticky,
                overdue: false,
                eventUid: ev.uid || '',
                ev: ev,
                focusUnit: null,  // 历史记录不支持定位（不是精确到某一行）
                isHistory: true   // 🆕 标记是展开的历史
              });
            });
          }
        });
      });
      // 排序
      pending.sort((a, b) => (a.dueAt ?? Infinity) - (b.dueAt ?? Infinity));
      done.sort((a, b) => (b.dueAt ?? -Infinity) - (a.dueAt ?? -Infinity));  // 已结案按完成时间倒序
      // 同步全局索引
      tlAlarmFocusUnitsPending = pending.map((x) => ({ ev: x.ev, uid: x.eventUid, focusUnit: x.focusUnit }));
      tlAlarmFocusUnitsDone = done.map((x) => ({ ev: x.ev, uid: x.eventUid, focusUnit: x.focusUnit }));
      // 更新计数角标
      const cP = document.getElementById('tlAlarmCountPending');
      const cD = document.getElementById('tlAlarmCountDone');
      if (cP) cP.textContent = pending.length ? '(' + pending.length + ')' : '';
      if (cD) cD.textContent = done.length ? '(' + done.length + ')' : '';
      // 格式化辅助
      const fmtDate = (ts) => {
        if (ts == null || !Number.isFinite(ts)) return '(时间未知)';
        const d = new Date(ts);
        const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0');
        const h = String(d.getHours()).padStart(2, '0'), mi = String(d.getMinutes()).padStart(2, '0');
        const today = new Date(); today.setHours(0, 0, 0, 0);
        const dayDiff = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - today) / 86400000);
        const dayLabel = dayDiff === 0 ? '今天' : dayDiff === 1 ? '明天' : dayDiff === -1 ? '昨天' : dayDiff > 1 ? dayDiff + ' 天后' : (-dayDiff) + ' 天前';
        return `${y}-${m}-${dd} ${h}:${mi}（${dayLabel}）`;
      };
      const fmtInterval = (ms) => {
        if (!ms) return '';
        if (ms < 3600000) return (ms / 60000) + ' 分钟';
        if (ms < 86400000) return (ms / 3600000) + ' 小时';
        return (ms / 86400000) + ' 天';
      };
      // 渲染当前 tab
      const isPending = tlAlarmCurrentTab !== 'done';
      const items = isPending ? pending : done;
      if (!items.length) {
        body.innerHTML = '<div class="tl-ev-stats-empty">' + (isPending ? '当前没有待执行的闹铃提醒' : '当前没有已结案的闹铃提醒') + '</div>';
        return;
      }
      // 表格渲染（thead 固定，tbody 滚动）
      const dueColLabel = isPending ? '下次触发' : '设定时间';
      const html = `
        <div style="max-height:420px;overflow:auto;border-top:1px solid var(--ev-border)">
        <table style="width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed">
          <thead style="position:sticky;top:0;z-index:1;background:var(--ev-bg, #1a2332)">
            <tr style="border-bottom:2px solid var(--ev-border)">
              <th style="padding:8px 10px;text-align:left;width:140px;color:var(--ev-muted);font-weight:600">类型</th>
              <th style="padding:8px 10px;text-align:left;color:var(--ev-muted);font-weight:600">闹铃讯息</th>
              <th style="padding:8px 10px;text-align:left;width:120px;color:var(--ev-muted);font-weight:600">来源行程</th>
              <th style="padding:8px 10px;text-align:left;width:160px;color:var(--ev-muted);font-weight:600">${dueColLabel}</th>
              <th style="padding:8px 10px;text-align:center;width:60px;color:var(--ev-muted);font-weight:600">操作</th>
            </tr>
          </thead>
          <tbody>
          ${items.map((a, idx) => {
            let typeCell = a.recurring
              ? '<span style="background:#7c3aed;color:#fff;border-radius:10px;padding:1px 8px;font-size:11px">🔄 循环</span>'
              : '<span style="background:#2563eb;color:#fff;border-radius:10px;padding:1px 8px;font-size:11px">⏰ 一次性</span>';
            if (isPending && a.overdue) typeCell += '<br><span style="background:#dc2626;color:#fff;border-radius:10px;padding:1px 8px;font-size:11px;margin-top:2px;display:inline-block">⚠️ 已过期</span>';
            if (!isPending) typeCell += '<br><span style="background:#16a34a;color:#fff;border-radius:10px;padding:1px 8px;font-size:11px;margin-top:2px;display:inline-block">✅ 已完成</span>';
            const roTag = a.ro ? '<span style="color:#f59e0b;margin-left:4px" title="只读 include 文件">⛔</span>' : '';
            const stickyTag = a.hasSticky ? '<span style="color:#f0c860;margin-left:4px" title="该事件有便利贴">📌</span>' : '';
            const histTag = a.isHistory ? '<span style="color:#64748b;margin-left:4px" title="循环闹铃历史完成记录">📜</span>' : '';
            const canJump = a.focusUnit != null;
            const jumpBtn = canJump
              ? `<button type="button" data-tl-alarm-jump data-tab="${isPending ? 'pending' : 'done'}" data-idx="${idx}" style="background:var(--ev-primary);color:#fff;border:none;border-radius:4px;padding:3px 8px;font-size:11px;cursor:pointer">定位</button>`
              : `<button type="button" disabled style="background:#475569;color:#94a3b8;border:none;border-radius:4px;padding:3px 8px;font-size:11px;cursor:not-allowed" title="历史记录不支持定位">—</button>`;
            const timeStyle = isPending
              ? (a.overdue ? 'color:#dc2626;font-weight:600' : a.dueAt != null && (a.dueAt - now) < 3600000 ? 'color:#f59e0b;font-weight:600' : '')
              : 'color:#64748b';
            const msg = tlEscapeHtml(a.message);
            // 压缩长讯息
            const msgShort = msg.length > 60 ? msg.slice(0, 60) + '…' : msg;
            const title = tlEscapeHtml(a.title || '(无标题)');
            const titleShort = title.length > 20 ? title.slice(0, 20) + '…' : title;
            return `<tr style="border-bottom:1px solid var(--ev-border);height:40px">
              <td style="padding:6px 10px;vertical-align:middle">${typeCell}</td>
              <td style="padding:6px 10px;vertical-align:middle;color:var(--ev-text);font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${msg}">${msgShort}${stickyTag}${roTag}${histTag}</td>
              <td style="padding:6px 10px;vertical-align:middle;color:var(--ev-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${title}${a.date ? '｜' + tlEscapeHtml(a.date) : ''}">${titleShort}</td>
              <td style="padding:6px 10px;vertical-align:middle;${timeStyle}">${fmtDate(a.dueAt)}</td>
              <td style="padding:6px 10px;vertical-align:middle;text-align:center">
                ${jumpBtn}
              </td>
            </tr>`;
          }).join('')}
          </tbody>
        </table>
        </div>`;
      body.innerHTML = html;
    }

    function toggleCalEventsView() {
      setCalEventsView(!calEventsView);
    }

    function setCalEventsView(on) {
      if (on && !isCalendarMdDoc()) return;
      calEventsView = !!on;
      const btn = document.getElementById('calEventsBtn');
      if (btn) btn.classList.toggle('active', calEventsView);
      // 🔎 搜索框占位符随视图切换：行程视图搜的是「画面上渲染出来的内容」，不是 calendar.md 源码
      const si = document.getElementById('editSearchInput');
      if (si) si.placeholder = calEventsView ? '搜索当前视图...' : '搜索内容...';
      if (calEventsView) {
        showCalEventsPaneOnly();
        // 首次/重新进入行程视图：网格滚动到当前月份/今天；表身明细（年/月/周/日）或列表滚到今天
        if (tlCalMode === 'year') tlYearAutoScrollPending = true;
        if (tlCalMode === 'month') tlMonthAutoScrollPending = true;
        if (tlCalMode === 'list') tlListScrollAnchorPending = true;
        else tlDetailListScrollPending = true;
        tlRenderEventsContent();
        tlApplyCalLayout();
      } else {
        // 交还给原模式：这里先收掉面板，再由 toggleMdPreview 按 previewMode 重新显示
        // （toggleMdPreview 内部会一并清掉 #mdPreview 上的内联 display:none）
        const pane = document.getElementById('calEventsPane');
        if (pane) pane.style.display = 'none';
        toggleMdPreview(previewMode);
      }
    }

    // 行程视图下：隐藏三个输入框 + 预览 + 三套工具栏，只显示行程面板

    // 📎 程式启动自动滚到今天：在「include 加载完成后的最后一次渲染」之后调用（见 tlRefreshIncludedEvents）。
    //    仅触发一次：等行程面板真正可见（有高度）后按一次「今天」按钮；按钮逻辑里的滚动函数
    //    若遇容器未布局会自延后重试（见 tlScrollYearToCurrentMonth / tlScrollMonthToToday / tlScrollElToTop），直到真正滚到今天。
    function tlTriggerStartupToday() {
      if (tlStartupScrollDone) return;
      tlStartupScrollDone = true;
      let tries = 0;
      const waitPane = () => {
        const pane = document.getElementById('calEventsPane');
        if (!pane || !pane.offsetHeight) { // 面板还没开/动画中 → 下帧再试（上限 120 帧 ≈ 2s）
          if (tries++ < 120) requestAnimationFrame(waitPane);
          return;
        }
        const tb = document.getElementById('tlEvTodayBtn');
        if (tb) tb.click(); // 面板可见后按一次「今天」：重设游标/选中日 + 设 pending + 重渲并滚动
      };
      requestAnimationFrame(waitPane);
    }    function showCalEventsPaneOnly() {
      const ids = ['taskText', 'htmlText', 'jsonText', 'mdPreview'];
      ids.forEach((id) => { const el = document.getElementById(id); if (el) el.style.display = 'none'; });
      // 撤销/重做钮是 #editorToolbar 的直接子元素（位于 #mdTools 分组之外），隐藏行程视图时一并收起，
      // 否则它们会遗留在行程面板工具栏、却只改动隐藏的 taskText 缓冲（行程面板不重绘，且会被自动保存静默写回）
      ['mdTools', 'htmlTools', 'jsonTools', 'undoBtn', 'redoBtn'].forEach((id) => { const el = document.getElementById(id); if (el) el.style.display = 'none'; });
      const pane = document.getElementById('calEventsPane');
      if (pane) pane.style.display = '';
    }

    // ===== 解析（与桌面 calendar 插件 parseMarkdownEvents 对齐） =====
    function tlParseArr(s) {
      s = (s || '').trim();
      if (!s) return [];
      try { const a = JSON.parse(s); return Array.isArray(a) ? a : []; } catch (e) { return []; }
    }
    // ===== 標籤結構：{name, cat?, subcat?}；舊資料純字串自動升級 =====
    function tlTagName(t) { return (t && typeof t === 'object') ? (t.name || '') : (t || ''); }
    function tlTagCat(t) { return (t && typeof t === 'object') ? (t.cat || '') : ''; }
    function tlTagSubcat(t) { return (t && typeof t === 'object') ? (t.subcat || '') : ''; }
    function tlTagLabel(t) { const n = tlTagName(t), c = tlTagCat(t), s = tlTagSubcat(t); return n + (c ? '·' + c : '') + (s ? '·' + s : ''); }
    function tlNormalizeTags(arr) {
      return (Array.isArray(arr) ? arr : []).map((t) => (t && typeof t === 'object')
        ? { name: t.name || '', cat: t.cat || '', subcat: t.subcat || '' }
        : { name: String(t || ''), cat: '', subcat: '' });
    }
    // ===== 標籤父階（樹形結構）：標籤名 → 父標籤名，集中存於 calendar.md 的 ## TAGS 區塊 =====
    // ⚠️ 與事件/日記不同：標籤父階是全文件級元數據（一棵標籤名組成的樹），不依附於單一事件，
    //    故單獨收口在 ## TAGS（JSON map：標籤名 → 父標籤名；缺省或空字串＝根）。
    //    右键标签 → 编辑 → 画面显示「子标签列表」（child tag names）＋ 可设定「父阶标签」。
    function tlParseTagsMeta(md) {
      const map = {};
      const blocks = String(md || '').split(/^##[ \t]*TAGS[ \t]*$/m);
      if (blocks.length < 2) return map;
      let chunk = blocks[1];
      const cut = chunk.search(/^##[ \t]/m);
      if (cut >= 0) chunk = chunk.slice(0, cut);
      const m = chunk.match(/\{[\s\S]*\}/);
      if (m) { try { const o = JSON.parse(m[0]); if (o && typeof o === 'object') { for (const k in o) if (typeof o[k] === 'string') map[k] = o[k]; } } catch (e) {} }
      return map;
    }
    function tlSerializeTagsMeta(map) {
      const clean = {};
      for (const k in map) if (k) clean[k] = (map[k] || '');
      return '## TAGS\n' + JSON.stringify(clean);
    }
    // 把最新父階表寫回 calendar.md 緩衝（taskText）；已存在 ## TAGS 區塊則替換其內容，否則追加
    function tlWriteTagsMeta(map) {
      let md = document.getElementById('taskText').value;
      const body = tlSerializeTagsMeta(map);
      const idx = md.search(/^##[ \t]*TAGS[ \t]*$/m);
      if (idx >= 0) {
        const after = md.slice(idx);
        const next = after.search(/\n##[ \t]/m);
        const end = next >= 0 ? idx + next : md.length;
        md = md.slice(0, idx) + body + md.slice(end);
      } else {
        md = md.replace(/\s*$/, '') + '\n\n' + body + '\n';
      }
      document.getElementById('taskText').value = md;
    }
    function tlTagMeta() { return tlParseTagsMeta(document.getElementById('taskText').value); }
    // ===== Include 加载清单：勾选状态存于 calendar.md 的 ## INCLUDE 区块 =====
    // 每行一个同目录 calendar-*.md 文件，前缀 '+' = 加载 / '-' = 不加载（与 LITE 共用此格式）。
    // 区块不存在（老文件）或区块无有效行时，默认「全部加载」（与改前行为一致；默认 A）。
    // allNames：当前目录枚举到的全部 calendar-*.md 文件名（不含 calendar.md），用于「缺省全选」回退。
    function tlParseIncludeSel(md, allNames) {
      const set = new Set();
      const blocks = String(md || '').split(/^##[ \t]*INCLUDE[ \t]*$/m);
      if (blocks.length < 2) { (allNames || []).forEach((n) => set.add(n)); return set; }
      let chunk = blocks[1];
      const cut = chunk.search(/^##[ \t]/m);
      if (cut >= 0) chunk = chunk.slice(0, cut);
      let hasLine = false;
      chunk.split(/\r?\n/).forEach((ln) => {
        const m = ln.match(/^\s*([+\-])\s+(.+?)\s*$/);
        if (m) { hasLine = true; if (m[1] === '+') set.add(m[2]); }
      });
      if (!hasLine) (allNames || []).forEach((n) => set.add(n));
      return set;
    }
    // 把勾选列表序列化：list = [{ name, on }]；on=true → '+ name'，否则 '- name'
    function tlSerializeInclude(list) {
      let body = '## INCLUDE\n';
      (list || []).forEach((it) => { body += (it.on ? '+ ' : '- ') + it.name + '\n'; });
      return body.replace(/\n$/, '');
    }
    // 把最新勾选列表写回 calendar.md 缓冲（taskText）；已存在 ## INCLUDE 区块则替换其内容，否则追加
    function tlWriteIncludeBlock(list) {
      let md = document.getElementById('taskText').value;
      const body = tlSerializeInclude(list);
      const idx = md.search(/^##[ \t]*INCLUDE[ \t]*$/m);
      if (idx >= 0) {
        const after = md.slice(idx);
        const next = after.search(/\n##[ \t]/m);
        const end = next >= 0 ? idx + next : md.length;
        md = md.slice(0, idx) + body + md.slice(end);
      } else {
        md = md.replace(/\s*$/, '') + '\n\n' + body + '\n';
      }
      document.getElementById('taskText').value = md;
    }
    function tlTagParent(name) { return (tlTagMeta()[name] || ''); }
    function tlTagChildren(name) { const m = tlTagMeta(); return Object.keys(m).filter((k) => m[k] === name); }
    function tlAllTagNames() {
      const set = new Set();
      tlCalEvents.forEach((ev) => (ev.tags || []).forEach((t) => { const n = tlTagName(t); if (n) set.add(n); }));
      const m = tlTagMeta();
      Object.keys(m).forEach((k) => { if (k) set.add(k); });
      Object.keys(m).forEach((k) => { if (m[k]) set.add(m[k]); });
      return Array.from(set).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
    }
    // 防止成環：start 是否為 root 的（間接）後代（沿父階向上走，若撞到 root 即為後代）
    function tlIsDescendant(start, root, m) {
      m = m || tlTagMeta();
      let cur = start, guard = 0;
      while (cur && guard++ < 1000) { if (cur === root) return true; cur = m[cur]; }
      return false;
    }
    // 設定/解除父階（parent==='' 或不存在 → 根）。返回 false 表示會成環被拒絕
    function tlSetTagParent(name, parent) {
      parent = (parent || '').trim();
      if (!name || parent === name) return false;
      const m = tlTagMeta();
      if (parent && tlIsDescendant(parent, name, m)) return false;
      if (parent) m[name] = parent; else delete m[name];
      tlWriteTagsMeta(m);
      return true;
    }
    // ===== Remark 围栏：备注正文可能本身含 ``` 代码围栏 → 按 CommonMark 规则处理 =====
    // 写入：围栏长度取 max(3, 备注内最长反引号串+1)，保证正文的 ``` 不可能闭合外层围栏
    function tlRemarkFence(notes) {
      const runs = String(notes || '').match(/`+/g) || [];
      const longest = runs.reduce((m, r) => Math.max(m, r.length), 0);
      return '`'.repeat(Math.max(3, longest + 1));
    }
    // 读取：开启围栏＝首个仅由 3+ 反引号组成的行；闭合围栏＝其后首个长度 ≥ 开启长度的反引号行（CommonMark：闭合围栏须 ≥ 开启长度）
    // 回传 { found, body, endAbs }：endAbs＝闭合围栏末端在 rest 内的索引（找不到闭合为 -1）
    function tlExtractFenced(rest) {
      const text = String(rest || '');
      const re = /^(`{3,})[ \t]*\r?$/gm;
      let open = null;
      let m;
      while ((m = re.exec(text))) {
        if (!open) {
          open = { len: m[1].length, bodyStart: re.lastIndex };
          continue;
        }
        if (m[1].length >= open.len) {
          const body = text.slice(open.bodyStart, m.index).replace(/^\r?\n/, '').replace(/\r?\n$/, '');
          return { found: true, body: body.trim() === '' ? '' : body, endAbs: re.lastIndex };
        }
      }
      if (!open) return { found: false, body: '', endAbs: -1 };
      const body = text.slice(open.bodyStart).replace(/^\r?\n/, '');
      return { found: true, body: body.trim() === '' ? '' : body, endAbs: -1 };
    }
    function tlExtractRemark(rest) {
      return tlExtractFenced(rest).body;
    }
    function tlParseBlock(block, idx) {
      let remark = '';
      let head = block;
      const ri = block.indexOf('- Remark:');
      if (ri >= 0) {
        head = block.slice(0, ri);
        // ⚠️ 不能用非贪婪 /```([\s\S]*?)```/：备注正文含 ``` 时会在正文首个 ``` 处提前闭合，吞掉其后内容（2026-09-30 用户反馈）
        remark = tlExtractRemark(block.slice(ri + '- Remark:'.length));
      }
      const get = (name) => {
        const m = head.match(new RegExp('- ' + name + ': `([^`]*)`'));
        return m ? m[1] : '';
      };
      const title = get('title');
      if (!title) return null;
      let color = get('color').trim();
      if (color.length >= 2 && color[0] === '"' && color[color.length - 1] === '"') color = color.slice(1, -1);
      return {
        idx, uid: 'evp' + idx, title,
        date: get('date'),
        endDate: get('endDate'),
        spanDisplay: get('spanDisplay') || 'daily',
        allDay: get('allDay') === 'true',
        // 完成状态：旧文件没有 - done 栏位 → 视为未设定 = 未完成
        done: get('done') === 'true',
        startTime: get('startTime'),
        endTime: get('endTime'),
        location: get('location'),
        color: color || TL_CAL_COLORS[0],
        tags: tlNormalizeTags(tlParseArr(get('tags'))),
        // 修复：此前缺读 todoIds，往返保存会把 calendar 插件写入的关联卡片清空
        todoIds: tlParseArr(get('todoIds')),
        // ## HOLIDAY 比 ## EVENT 多一个 holidayType 字段（workday/holiday/festival），事件解析为空字符串即可
        holidayType: get('holidayType') || '',
        // 地区：cn 中国大陆 / hk 香港 / tw 台湾（可扩展）；缺省 '' 渲染时回退 cn（向后兼容旧数据）
        region: get('region') || '',
        notes: remark,
        // ===== ## EVENT(REPEAT) 重複事件字段（空＝不重複）=====
        repeatMode: get('repeatMode') || '',
        repeatInterval: get('repeatInterval') || '',
        repeatWeekDay: tlParseArr(get('repeatWeekDay')),
        repeatMonthDay: get('repeatMonthDay') || '',
        repeatYearMonthDay: get('repeatYearMonthDay') || '',
        repeatEndType: get('repeatEndType') || '',
        repeatEndValue: get('repeatEndValue') || '',
        repeatExcludeDates: tlParseArr(get('repeatExcludeDates')),
        // 🆕 桌面便利贴：instance 数（缺省 0 = 不显示为便利贴）；同事件可同时显示多张
        sticky: parseInt(get('sticky'), 10) || 0
      };
    }
    function tlParseEvents(md) {
      if (!md) return [];
      const out = [];
      const blocks = String(md).split(/^##[ \t]*EVENT(?:\([^)]*\))?[ \t]*$/m);
      for (let i = 0; i < blocks.length; i++) {
        // ⚠️ 切块只按 ## EVENT → 本块尾巴会粘着紧随其后的 ## HOLIDAY / ## DIARY 块。
        //    必须先在该标记处截断，否则 remark / holidayType / region 等会被后面的块污染；
        //    更重要的是：## DIARY 含 - title / - date，会被 tlParseBlock 误当成行程事件（带勾选框）参与渲染（2026-10-17 修复）
        const cut = blocks[i].search(/^##[ \t]*(HOLIDAY|DIARY)[ \t]*$/m);
        const ev = tlParseBlock(cut >= 0 ? blocks[i].slice(0, cut) : blocks[i], i);
        if (ev) out.push(ev);
      }
      return out;
    }
    // ## HOLIDAY：与 ## EVENT 同一套字段（多 holidayType），仅分割符不同；复用 tlParseBlock 解析（无 title 的块会被跳过）
    // ⚠️ 必须从 i=1 开始：split 后 blocks[0] 是「第一个 ## HOLIDAY 之前的所有内容」（通常含 ## EVENT 块），
    //    那段里的 - title 会被误当成 holiday；holiday 必然跟在它自己的 ## HOLIDAY 标记之后，故跳过 blocks[0] 即正确。
    function tlParseHolidays(md) {
      if (!md) return [];
      const out = [];
      const blocks = String(md).split(/^##[ \t]*HOLIDAY[ \t]*$/m);
      for (let i = 1; i < blocks.length; i++) {
        // 同理：假日块尾巴可能粘着后面的 ## EVENT（含 (REPEAT)）/ ## DIARY 块 → 先在该标记处截断
        //    （## DIARY 含 - title / - date，不截断会被误当成假日渲染）
        const cut = blocks[i].search(/^##[ \t]*(EVENT(?:\([^)]*\))?|DIARY)[ \t]*$/m);
        const h = tlParseBlock(cut >= 0 ? blocks[i].slice(0, cut) : blocks[i], i);
        if (h) out.push(h);
      }
      return out;
    }

    // ===== ## DIARY 解析 / 序列化（每天一条，keyed by date；行事历日期旁按钮打勾）=====
    // 块格式（桌面 + LITE 共用）：
    // ## DIARY
    // - date: `2026-09-20`
    // - title: `今日交易复盘`
    // - mood: `平稳`
    // - tags: `["投资","自我总结"]`
    // - weather: `多云`
    // - content:        ← 多行正文走代码块（与 Remark 同约定：非贪婪截取，避免吞掉后续 ## 块）
    // ```
    // 今天大盘震荡，持仓观察。
    // ```
    // - remark: `晚间复盘再核对数据`
    function tlParseDiaryBlock(block, idx) {
      let content = '';
      let head = block;
      const ci = block.indexOf('- content:');
      if (ci >= 0) {
        const base = ci + '- content:'.length;
        // 与 Remark 同一个坑：正文含 ``` 时不能在首个 ``` 处提前闭合
        const f = tlExtractFenced(block.slice(base));
        if (f.found) {
          content = f.body;
          // ⚠️ 只摘掉整段 content 區（含 - content: 與首尾圍欄），讓 remark 等「位於 content 之後」的欄位不被它隔斷而丟失
          if (f.endAbs >= 0) head = block.slice(0, ci) + block.slice(base + f.endAbs);
        }
      }
      const get = (name) => {
        const m = head.match(new RegExp('- ' + name + ': `([^`]*)`'));
        return m ? m[1] : '';
      };
      const date = get('date');
      if (!date) return null;       // 无日期的块无效（日记必须挂在某个日期上）
      let tags = [];
      try { const a = JSON.parse(get('tags') || '[]'); if (Array.isArray(a)) tags = tlNormalizeTags(a); } catch (e) {}
      return {
        idx,
        date,
        title: get('title'),
        mood: get('mood'),
        tags,
        weather: get('weather'),
        content,
        remark: get('remark')
      };
    }
    function tlParseDiaries(md) {
      if (!md) return [];
      const out = [];
      const blocks = String(md).split(/^##[ \t]*DIARY[ \t]*$/m);
      for (let i = 1; i < blocks.length; i++) {
        // ⚠️ 块尾可能黏着紧随其后的 ## EVENT / ## HOLIDAY / ## DIARY → 在最靠前的标记处截断
        const cut = blocks[i].search(/^##[ \t]*(EVENT(?:\([^)]*\))?|HOLIDAY|DIARY)[ \t]*$/m);
        const d = tlParseDiaryBlock(cut >= 0 ? blocks[i].slice(0, cut) : blocks[i], i);
        if (d) out.push(d);
      }
      return out;
    }
    function tlDiaryToMarkdown(d) {
      const tagsJson = JSON.stringify(Array.isArray(d.tags) ? d.tags : []);
      let s = '## DIARY \n';
      s += '- date: `' + tlMdEscape(d.date) + '`\n';
      s += '- title: `' + tlMdEscape(d.title || '') + '`\n';
      s += '- mood: `' + tlMdEscape(d.mood || '') + '`\n';
      s += '- tags: `' + tagsJson + '`\n';
      s += '- weather: `' + tlMdEscape(d.weather || '') + '`\n';
      const contentFence = tlRemarkFence(d.content);
      s += '- content:\n' + contentFence + '\n' + String(d.content || '') + '\n' + contentFence + '\n';
      s += '- remark: `' + tlMdEscape(d.remark || '') + '`\n';
      return s;
    }
    function tlDiaryOnDate(dateStr) {
      if (!TL_DIARY_FEATURE_ENABLED) return null;
      if (!tlCalDiaries || !tlCalDiaries.length) return null;
      return tlCalDiaries.find((d) => d.date === dateStr) || null;
    }
    // 📕「当天有日记」标记（月格日期数字旁、周/日视图列头日期旁**共用**，一个入口一处样式）。
    // ⚠️ 纯显示、故意不挂 onclick：这些格子单击＝选日，在 ~12px 的小图标上再开一个点击热区只会造成误点；
    //    要看/改日记 → 点格子选日，下方明细的日期标题上有可点的日记按钮 .ev-day-diary。
    function tlDiaryMarkHtml(date) {
      const dy = tlDiaryOnDate(date);
      if (!dy) return '';
      return '<span class="ev-diary-mark' + (dy.ro ? ' ro' : '') + '" title="' + tlEscapeHtml('日记：' + (dy.title || '（无标题）')) + '">\ud83d\udcd5</span>';
    }

    // ===== 序列化（与桌面 calendar 插件 eventsToMarkdown 逐字节对齐） =====
    function tlMdEscape(s) { return String(s == null ? '' : s).replace(/`/g, "'"); }
    function tlEventToMarkdown(ev) {
      const tagsJson = JSON.stringify(Array.isArray(ev.tags) ? ev.tags : []);
      const todoJson = JSON.stringify(Array.isArray(ev.todoIds) ? ev.todoIds : []);
      const color = '"' + String(ev.color || '').replace(/^"|"$/g, '') + '"';
      const rep = !!(ev.repeatMode && ev.repeatMode !== '');
      let s = (rep ? '## EVENT(REPEAT) ' : '## EVENT ') + '\n';
      s += '- title: `' + tlMdEscape(ev.title) + '`\n';
      s += '- date: `' + tlMdEscape(ev.date) + '`\n';
      if (ev.endDate && ev.endDate !== ev.date) s += '- endDate: `' + tlMdEscape(ev.endDate) + '`\n';
      if (ev.spanDisplay === 'first' || ev.spanDisplay === 'last' || ev.spanDisplay === 'today') s += '- spanDisplay: `' + ev.spanDisplay + '`\n';
      s += '- allDay: `' + (ev.allDay ? 'true' : 'false') + '`\n';
      // 完成状态：永远显式写出（与桌面 calendar 插件同一栏位、同一顺序）
      s += '- done: `' + (ev.done ? 'true' : 'false') + '`\n';
      s += '- startTime: `' + tlMdEscape(ev.startTime) + '`\n';
      s += '- endTime: `' + tlMdEscape(ev.endTime) + '`\n';
      s += '- location: `' + tlMdEscape(ev.location) + '`\n';
      s += '- color: `' + color + '`\n';
      s += '- tags: `' + tagsJson + '`\n';
      s += '- todoIds: `' + todoJson + '`\n';
      // 🆕 桌面便利贴 instance 数（>0 才写出，缺省 0 不写）
      if (ev.sticky > 0) s += '- sticky: `' + (ev.sticky | 0) + '`\n';
      if (rep) {
        s += '- repeatMode: `' + String(ev.repeatMode || '') + '`\n';
        s += '- repeatInterval: `' + String(ev.repeatInterval || '1') + '`\n';
        s += '- repeatWeekDay: `' + JSON.stringify(Array.isArray(ev.repeatWeekDay) ? ev.repeatWeekDay : []) + '`\n';
        s += '- repeatMonthDay: `' + String(ev.repeatMonthDay || '') + '`\n';
        s += '- repeatYearMonthDay: `' + String(ev.repeatYearMonthDay || '') + '`\n';
        s += '- repeatEndType: `' + String(ev.repeatEndType || 'never') + '`\n';
        s += '- repeatEndValue: `' + String(ev.repeatEndValue || '') + '`\n';
        s += '- repeatExcludeDates: `' + JSON.stringify(Array.isArray(ev.repeatExcludeDates) ? ev.repeatExcludeDates : []) + '`\n';
      }
      // Remark 围栏长度按备注内容动态加长（CommonMark：闭合围栏 ≥ 开启围栏），备注正文里的 ``` 不会再提前闭合
      s += '- Remark:\n' + tlRemarkFence(ev.notes) + '\n' + String(ev.notes || '') + '\n' + tlRemarkFence(ev.notes) + '\n';
      return s;
    }
    // ## HOLIDAY 序列化：字段顺序与用户实际写法对齐（在 todoIds 后多 holidayType，再 Remark），保证保存后 diff 干净
    function tlHolidayToMarkdown(h) {
      const tagsJson = JSON.stringify(Array.isArray(h.tags) ? h.tags : []);
      const todoJson = JSON.stringify(Array.isArray(h.todoIds) ? h.todoIds : []);
      const color = '"' + String(h.color || '').replace(/^"|"$/g, '') + '"';
      let s = '## HOLIDAY \n';
      s += '- title: `' + tlMdEscape(h.title) + '`\n';
      s += '- date: `' + tlMdEscape(h.date) + '`\n';
      if (h.endDate && h.endDate !== h.date) s += '- endDate: `' + tlMdEscape(h.endDate) + '`\n';
      s += '- allDay: `' + (h.allDay ? 'true' : 'false') + '`\n';
      s += '- done: `' + (h.done ? 'true' : 'false') + '`\n';
      s += '- startTime: `' + tlMdEscape(h.startTime) + '`\n';
      s += '- endTime: `' + tlMdEscape(h.endTime) + '`\n';
      s += '- location: `' + tlMdEscape(h.location) + '`\n';
      s += '- color: `' + color + '`\n';
      s += '- tags: `' + tagsJson + '`\n';
      s += '- todoIds: `' + todoJson + '`\n';
      s += '- holidayType: `' + tlMdEscape(h.holidayType || '') + '`\n';
      s += '- region: `' + tlMdEscape(h.region || 'cn') + '`\n';
      s += '- Remark:\n' + tlRemarkFence(h.notes) + '\n' + String(h.notes || '') + '\n' + tlRemarkFence(h.notes) + '\n';
      return s;
    }
    // 整份 calendar.md 序列化：events + holidays + diaries 都保留（保存任一类时若只写该类会把用户手写的其它类整体覆盖掉）
    function tlCalendarToMarkdown(events, holidays, diaries) {
      const head = '# 日历行程\n\n> 每条行程以 `## EVENT` 分隔，字段值写在反引号内，Remark 用代码块保存多行备注。\n\n';
      // 📎 保存时按 date 排序：EVENT（用现有 tlSorted：日期→全天→时间）与 DIARY（按日期）都排序，HOLIDAY 保持原序
      const evSorted = (events && events.length) ? tlSorted(events.slice()) : [];
      const diSorted = (diaries && diaries.length) ? diaries.slice().sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0)) : [];
      let body = evSorted.length ? evSorted.map(tlEventToMarkdown).join('\n') : '';
      if (holidays && holidays.length) {
        body += (body ? '\n' : '') + holidays.map(tlHolidayToMarkdown).join('\n');
      }
      if (diSorted.length) {
        body += (body ? '\n' : '') + diSorted.map(tlDiaryToMarkdown).join('\n');
      }
      return head + (body || '');
    }

    function tlFmtDate(d) {
      return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    }
    // 🆕 2026-11-08：cr/cp 存檔用「本機 date + 本機 HH:mm」（24H、無秒）；
    //   只給寫入 cr/cp 的呼叫點用，⛔ 月曆格／表單／事件 date 仍一律用 tlFmtDate 純日期。
    function tlFmtDateTime(d) {
      return tlFmtDate(d) + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
    }
    function tlTimeToMin(t) {
      const m = String(t || '').match(/^(\d{1,2}):(\d{2})/);
      return m ? (+m[1]) * 60 + (+m[2]) : 0;
    }
    function tlSorted(events) {
      return events.slice().sort((a, b) => {
        if (a.date !== b.date) return a.date < b.date ? -1 : 1;
        if (a.allDay !== b.allDay) return a.allDay ? -1 : 1;
        return tlTimeToMin(a.startTime) - tlTimeToMin(b.startTime);
      });
    }
    function tlGenId() { return 'ev-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7); }
    function tlEscapeHtml(s) {
      return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
    }
    function tlViewStickyRef(events) {
      if (!window.ViewStickyRules || typeof window.ViewStickyRules.buildRef !== 'function') return null;
      // 🆕 用「存盘里被自定义过的内置提醒规则」来生成这张贴（tlBuiltinViewRule，由 tlApplyCustomViewRules 捕获），
      //   没有存盘版才回退引擎默认的 BUILTIN_REMIND_RULE——这样维护窗里对「提醒」的标题／条件／通知等自定义才会落地。
      const rule = tlBuiltinViewRule || (window.ViewStickyRules.builtinRules ? window.ViewStickyRules.builtinRules()[0] : null);
      if (!rule) return null;
      return window.ViewStickyRules.buildRef(rule, events, tlCustomViewDeps());
    }
    // ===== 跨天行程辅助 =====
    // 🆕 自定义 VIEW 便利贴：使用者自己定「抓哪些行」的条件，做几张跟「🔔 提醒」同类的投影贴。
    //   条件＝关键词（任一／全部）＋ 标记（[[remind:]]／[[dl:]]／[[cp:]]）＋ 行型态，三个条件之间是 AND。
    //   引擎在 view-sticky-rules.js（独立插件档），规则存在主进程 data/view-sticky-rules.json；
    //   入口目前挂在便利贴窗的菜单「🧩 自定义 VIEW 便利贴设定维护作业」，以后也可以挂别处。
    //   ⚠️ 三条例外口径与 🔔 完全相同（key 前缀 __view__ → 内容不落盘／不可异动；窗体只读；外观照一般便利贴存盘）。
    let tlCustomViewRules = [];   // 规则档案的本会话复本：refs 是同步算出来的，不能就地 invoke
    let tlBuiltinViewRule = null; // 🆕 内置「提醒」规则的本会话复本（存盘版优先，否则引擎默认）；tlViewStickyRef 用它生成提醒贴
    function tlCustomViewDeps() {
      return {
        tlEscapeHtml: tlEscapeHtml, tlRenderInlineMarkdown: tlRenderInlineMarkdown,
        tlRenderNoteMarkers: tlRenderNoteMarkers, tlRenderTermDefs: tlRenderTermDefs,
        renderMarkdown: renderMarkdown, tlMdShort: tlMdShort
      };
    }
    function tlApplyCustomViewRules(rules) {
      const all = (window.ViewStickyRules && window.ViewStickyRules.normalizeList(rules)) || [];
      // 🆕 自定义规则：排除内置提醒（它单独走 tlViewStickyRef，不在这里重复生成）
      tlCustomViewRules = all.filter((rule) => !rule.builtin && rule.id !== '__builtin_remind__');
      // 🆕 捕获内置提醒规则（存盘版优先，否则引擎默认）——供 tlViewStickyRef 生成「提醒」贴，让自定义生效
      const b = all.filter((rule) => rule.id === '__builtin_remind__' || rule.builtin)[0];
      tlBuiltinViewRule = b || (window.ViewStickyRules ? window.ViewStickyRules.builtinRules()[0] : null);
    }
    // 启动时拉一次；维护窗存档后主进程会推 view-sticky-rules-changed 过来（不必轮询）。
    //   第一次拉到规则时集合可能多了一张 → 必须整份 sync（force），否则翻页清单看不到新贴。
    function tlLoadCustomViewRules() {
      if (!window.electronAPI || typeof window.electronAPI.invoke !== 'function') return;
      Promise.resolve(window.electronAPI.invoke('vsr-list')).then((r) => {
        console.log('[tlLoadCustomViewRules] vsr-list raw:', r);
        const rules = r && Array.isArray(r.rules) ? r.rules : [];
        console.log('[tlLoadCustomViewRules] rules count:', rules.length, 'ids:', rules.map(x => x.id));
        const before = tlCustomViewRules.map((x) => x.id + '|' + x.enabled).join(',');
        tlApplyCustomViewRules(rules);
        console.log('[tlLoadCustomViewRules] tlCustomViewRules after filter:', tlCustomViewRules.map(x => ({id: x.id, title: x.title, enabled: x.enabled})));
        if (tlCustomViewRules.map((x) => x.id + '|' + x.enabled).join(',') !== before) {
          console.log('[tlLoadCustomViewRules] calling tlPushStickyRefreshes(true)');
          tlPushStickyRefreshes(true);
        }
      }).catch((e) => { console.error('[tlLoadCustomViewRules] error:', e); });
    }
    if (window.electronAPI && typeof window.electronAPI.onViewStickyRulesChanged === 'function') {
      window.electronAPI.onViewStickyRulesChanged((rules) => {
        tlApplyCustomViewRules(rules);
        tlPushStickyRefreshes(true);
      });
    }
    function tlCustomViewStickyRefs(events) {
      if (!window.ViewStickyRules || !tlCustomViewRules.length) {
        console.log('[tlCustomViewStickyRefs] SKIP ViewStickyRules?', !!window.ViewStickyRules, 'rules.length:', tlCustomViewRules.length);
        return [];
      }
      const refs = window.ViewStickyRules.buildRefs(tlCustomViewRules, events, tlCustomViewDeps());
      console.log('[tlCustomViewStickyRefs] rules:', tlCustomViewRules.length, 'events:', events.length, '→ refs:', refs.length, refs.map(r => ({key: r.key, title: r.title})));
      return refs;
    }
    tlLoadCustomViewRules();
    // 🆕 桌面便利贴清单：把 sticky>0 的事件展开成 [{key,idx,html}]（key = 事件 uid，供桌面便利贴窗口定位）
    //    evpN 是当前 Markdown 分块位置生成的临时 key，重排事件后可能变化；刷新时由标题/日期回退定位旧便利贴。
    //    html 复用主程式 tlRenderNotes/renderMarkdown 管线（含 [[cp:]]→✅、[[dl:]]→📅、checkbox），
    //    渲染好的 HTML 交给便利贴窗口显示 → 单一可信来源，两处渲染永不漂移。
    function tlStickyNoteRefs(events) {
      // ⚠️ 无参时务必走「实时」事件全集（tlLiveCalEvents），而非 tlCalEvents 快照：
      //    tlCalEvents 只有在「事件视图重绘」时才会把 include 进来的 calendar-*.md 事件并入
      //    （见 tlRenderEventsContent 的 `if(!calEventsView) return` 门控）；一旦重绘没跑或滞后，
      //    tlCalEvents 就是「include 未合并」的旧快照 → 外部档（如 calendar-我的iphone.md）的事件
      //    会在便利贴里整批消失。tlLiveCalEvents() 直接重读 textarea 并 .concat(tlIncludedEvents)，
      //    与 tlPushStickyRefreshes 同一数据源，保证 include 事件不漏。tlPushStickyRefreshes 已用它，这里补齐。
      const list = Array.isArray(events) ? events : tlLiveCalEvents();
      const out = [];
      // 🆕 VIEW 便利贴永远第一张（有内容才出现）：清单、翻页、分体开窗都从这里拿
      const viewRef = tlViewStickyRef(list);
      if (viewRef) out.push(viewRef);
      // 🆕 自订投影贴紧跟在 🔔 之后，再才是使用者自己设的便利贴。
      //    与 🔔 的差别（2026-10-27 使用者要求）：自订规则「有条件但 0 命中」也照建一张，
      //    贴面写明「这个条件没抓到任何行」——静默消失会让人分不清是规则没生效还是行程里真的没有。
      const customRefs = tlCustomViewStickyRefs(list).map((ref) => {
        // 🆕 标题同样经 tlRenderInlineMarkdown 渲染后再取纯文字，与下方「使用者自己设的便利贴」（第 1259-1262 行）
        //    同一管线：避免 VIEW 投影贴清单里出现原始 # ／ <BIG> 等 Markdown 样式符号
        //    （一般便利贴清单不会显示 MD 样式，VIEW 贴应与之保持一致；贴面标题仍用 titleHtml 渲染，不受影响）。
        const tNode = document.createElement('div');
        tNode.innerHTML = ref.titleHtml || '';
        const plain = (tNode.textContent || tNode.innerText || ref.title || '').replace(/\s+/g, ' ').trim();
        return Object.assign({}, ref, { title: plain });
      });
      console.log('[tlStickyNoteRefs] builtin:', viewRef ? 1 : 0, 'custom:', customRefs.length, '→ total before user:', out.length + customRefs.length);
      customRefs.forEach((ref) => out.push(ref));
      list.forEach((ev) => {
        const n = parseInt(ev && ev.sticky, 10) || 0;
        if (n > 0) {
          const key = ev.uid || ((ev.title || '') + '|' + (ev.date || ''));
          // 🆕 便利贴层：include(ro) 行程也全開编辑（落回來源檔），故传 forceEditable=true；
          //    并把 ev 一并传入（evOverride），确保这里必定走 canEdit 分支 → 正文有 .md-unit 区块，
          //    「找出相同 → 切换」才能定位并闪烁非 checkbox 行（否则只有 checkbox 行有元素可定位）。
          const html = (typeof tlRenderNotes === 'function') ? tlRenderNotes(ev.notes, ev.uid || key, true, ev) : '';
          // 🆕 标题同样由主窗口渲染（与列表行同一 tlRenderInlineMarkdown 管线），避免便利贴里显示原始 <BIG> 等标签
          const titleHtml = (typeof tlRenderInlineMarkdown === 'function') ? tlRenderInlineMarkdown(ev.title || '') : '';
          const titleNode = document.createElement('div');
          titleNode.innerHTML = titleHtml;
          const title = (titleNode.textContent || titleNode.innerText || ev.title || '').replace(/\s+/g, ' ').trim();
          for (let i = 0; i < n; i++) out.push({
            key, idx: i, html, titleHtml, title, date: ev.date || '', endDate: ev.endDate || '',
            color: ev.color || '', done: !!ev.done, tags: Array.isArray(ev.tags) ? ev.tags : [],
            notes: ev.notes || '',
            // 🆕 显示方式：便利贴据此判断「显示在今天」→ meta 行改显示固定字样，不显示真实日期区间
            spanDisplay: ev.spanDisplay || '',
            // 🆕 来源文件名（仅 INCLUDE 外部文件的事件有值）：便利贴据此显示文档名徽标、
            //    并把编辑结果写回该文件（而不是 calendar.md）
            src: ev.ro ? String(ev.src || '') : ''
          });
        }
      });
      // 🆕 临时便利贴：仅本会话、不落盘；右键「临时开启为便利贴」加入的普通行程（sticky=0）
      tlTempStickyUids.forEach(function (uid) {
        const ev = list.find(function (e) { return e && e.uid === uid; });
        if (!ev) return;
        if ((parseInt(ev.sticky, 10) || 0) > 0) return; // 已正式设为便利贴 → 交给上面那段
        const key = ev.uid || ((ev.title || '') + '|' + (ev.date || ''));
        const html = (typeof tlRenderNotes === 'function') ? tlRenderNotes(ev.notes, ev.uid || key, true, ev) : '';
        const titleHtml = (typeof tlRenderInlineMarkdown === 'function') ? tlRenderInlineMarkdown(ev.title || '') : '';
        const titleNode = document.createElement('div');
        titleNode.innerHTML = titleHtml;
        const title = (titleNode.textContent || titleNode.innerText || ev.title || '').replace(/\s+/g, ' ').trim();
        out.push({
          key: key, idx: 0, html: html, titleHtml: titleHtml, title: title,
          date: ev.date || '', endDate: ev.endDate || '',
          color: ev.color || '', done: !!ev.done, tags: Array.isArray(ev.tags) ? ev.tags : [],
          notes: ev.notes || '',
          spanDisplay: ev.spanDisplay || '',
          src: ev.ro ? String(ev.src || '') : '',
          temp: true
        });
      });
      return out;
    }
    // 🆕 主程式事件变更后，把便利贴最新状态推给主进程（再由主进程中转给便利贴窗）
    //   ⚠️ 关键：集合（key#idx 清单）变了时必须整份 sticky-note-sync。
    //      以前一律只发逐张 sticky-note-refresh → 主进程的 stickyNoteOrder 停在开窗那一刻，
    //      事后新增／减少的便利贴永远进不了翻页清单（症状：翻页窗「第 9 / 9 张」，
    //      而 ☰ 清单现场查询已经 12 张；点清单第 12 项才把整份重开、数字才对上）。
    let tlLastStickySet = '';   // 上次推过的便利贴集合指纹（有序 key#idx）
    let tlTempStickyUids = new Set();   // 🆕 临时便利贴：本会话内存持有、未写入 calendar.md 的普通行程 uid 集合
    // 便利贴清单要用「实时」事件全集：行程视图没重绘过时 tlCalEvents 可能是旧快照
    //   （例如刚在 include 档里新建完，calEventsView 已关 → tlRenderEventsContent 没跑），
    //   那样 refs 里就没有新贴、指纹不变 → 主进程收不到 sync → 翻页清单永远少一张。
    //   ⚠️ 只有当前文件确实是 calendar.md 才重新解析：否则 taskText 装的是别的文件，会把清单洗成空。
    function tlLiveCalEvents() {
      try {
        if (typeof isCalendarMdDoc === 'function' && isCalendarMdDoc()) {
          const ta = document.getElementById('taskText');
          if (ta && typeof ta.value === 'string') return tlAllEvents(ta.value);
        }
      } catch (e) { /* 解析失败就用现有快照 */ }
      return tlCalEvents;
    }
    // 🆕 把「全部行程（含未设便利贴的普通行程）」压成比对/显示所需的精简结构，随 sticky-note-sync
    //    一并交给主进程，供便利贴窗「找出相同的项目」搜到 VIEW 投影贴的「来源行程」（普通行程没上便利贴
    //    清单，原本只在便利贴目录里找不到）与「其它普通行程」里的相同内容。
    //    只挑「有备注内容」且「有 uid」的行程：① 无备注不可能命中；② 没 uid 无法定位/打开。
    function tlCompactStickyEvents(events) {
      const list = Array.isArray(events) ? events : (Array.isArray(tlCalEvents) ? tlCalEvents : []);
      return list
        .filter((ev) => ev && String(ev.notes || '').trim() && (ev.uid || ''))
        .map((ev) => ({
          uid: ev.uid || '',
          title: ev.title || '',
          date: ev.date || '',
          endDate: ev.endDate || '',
          // ⚠️ 只有 INCLUDE(ro) 行程才带 src（与主进程目录一致：普通档 src 恒空＝主档）
          src: ev.ro ? String(ev.src || '') : '',
          notes: ev.notes || ''
        }));
    }
    function tlPushStickyRefreshes(force) {
      // 🆕 force=true 时不被 tlStickyNotesOpen 守卫拦截（规则刚加载时便利贴可能还没开）：
      //    先算好 refs、记好指纹，等下一次 open-sticky-notes 会重新调用 tlStickyNoteRefs() 拿最新集合。
      if (!force && typeof tlStickyNotesOpen !== 'undefined' && !tlStickyNotesOpen) return;
      if (!window.electronAPI || !window.electronAPI.send) return;
      const liveEvents = tlLiveCalEvents();
      const refs = tlStickyNoteRefs(liveEvents);
      console.log('[tlPushStickyRefreshes] force=', force, 'refs count:', refs.length, 'keys:', refs.map(r => r.key));
      const setSig = refs.map((ref) => ref.key + '#' + (+ref.idx || 0)).join(',');
      const prevSig = tlLastStickySet;
      tlLastStickySet = setSig;
      // 本会话第一次推：主进程刚由 open-sticky-notes 播种，只记指纹、不重复整份同步
      // force：调用方刚确定集合变了（新建便利贴）→ 无论指纹都要整份同步一次
      if (force || (prevSig && setSig !== prevSig)) {
        // 集合变了（张数增减 / 换行程）→ 整份同步，主进程才知道翻页清单多了或少了哪几张；
        // sync 本身会按分量刷新已存在的窗并补建新窗，不必再逐张发 refresh
        // 🆕 events：全部行程（含普通行程），供便利贴窗 find-same 找回 VIEW 来源行程与跨行程相同内容
        try { window.electronAPI.send('sticky-note-sync', { notes: refs, events: tlCompactStickyEvents(liveEvents) }); } catch (err) {}
        return;
      }
      refs.forEach((ref) => { window.electronAPI.send('sticky-note-refresh', ref); });
    }

    // ========== 🆕 临时便利贴：把普通行程（sticky=0）临时开成桌面便利贴，不写入 calendar.md ==========
    function tlInjectTempStickyStyle() {
      if (document.getElementById('tlTempStickyStyle')) return;
      const s = document.createElement('style');
      s.id = 'tlTempStickyStyle';
      s.textContent =
        // 只描「卡片容器」，不描备注子行的小圆点（.md-unit-edit / .ev-cb 等也都带 data-uid）
        '.ev-item.tl-temp-sticky,.ev-chip.tl-temp-sticky,.ev-block.tl-temp-sticky,.tl-repeat-ov-item.tl-temp-sticky{outline:2px dashed #f5c518;outline-offset:-2px}' +
        // 列表行标题上的「📌 临时便利贴」按钮：与既有 ev-sticky-flag 并列，虚线框＝临时
        '.ev-item .ev-title .ev-temp-sticky-btn{display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;min-width:22px;min-height:22px;padding:2px 4px;border:1px dashed #f5c518;border-radius:999px;background:transparent;color:inherit;font-size:11px;line-height:1;cursor:pointer;opacity:.72;margin-left:2px}' +
        '.ev-item .ev-title .ev-temp-sticky-btn:hover{opacity:1;background:rgba(245,197,24,.14)}' +
        '.ev-item .ev-title .ev-temp-sticky-btn.active{opacity:1;background:rgba(245,197,24,.22);border-style:solid}' +
        '.tl-event-ctx-menu{position:fixed;z-index:9999;min-width:170px;background:var(--ev-card,#1e293b);color:var(--ev-text,#e2e8f0);border:1px solid var(--ev-border,#334155);border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.35);padding:6px;font-size:13px}' +
        '.tl-event-ctx-menu button{display:block;width:100%;text-align:left;background:transparent;border:0;color:inherit;padding:7px 10px;border-radius:6px;cursor:pointer;font-size:13px}' +
        '.tl-event-ctx-menu button:hover{background:var(--ev-hover,#334155)}';
      document.head.appendChild(s);
    }
    // 卡片容器选择器（避开同样带 data-uid 的备注子行元素）
    function tlTempStickyCardQuery(uid) {
      const q = String(uid).replace(/"/g, '\\"');
      return ['.ev-item[data-uid="' + q + '"]', '.ev-chip[data-uid="' + q + '"]',
              '.ev-block[data-uid="' + q + '"]', '.tl-repeat-ov-item[data-uid="' + q + '"]'].join(',');
    }
    // 同步「临时便利贴」的视觉状态：卡片描边 + 列表行按钮文字/高亮（重绘后由 tlAfterCalRender 重刷）
    function tlRefreshTempStickyMarks() {
      tlInjectTempStickyStyle();
      document.querySelectorAll('.tl-temp-sticky').forEach(function (el) { el.classList.remove('tl-temp-sticky'); });
      document.querySelectorAll('.ev-temp-sticky-btn').forEach(function (btn) {
        const on = tlIsTempSticky(btn.getAttribute('data-uid'));
        btn.classList.toggle('active', on);
        btn.title = on ? '已临时开启为便利贴 · 点击关闭（仅本会话，未写入 calendar.md）'
                       : '临时开启为便利贴（仅本会话，未写入 calendar.md）';
        btn.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      tlTempStickyUids.forEach(function (uid) {
        document.querySelectorAll(tlTempStickyCardQuery(uid)).forEach(function (el) {
          if (el.classList) el.classList.add('tl-temp-sticky');
        });
      });
    }
    function tlIsTempSticky(uid) { return !!uid && tlTempStickyUids.has(uid); }
    // 列表行 📌 按钮：已临时开启则关闭，否则开启
    async function tlToggleTempSticky(uid) {
      if (tlIsTempSticky(uid)) await tlCloseTempSticky(uid);
      else await tlOpenEventAsTempSticky(uid);
    }
    // 临时开启为便利贴（仅本会话，不落盘）
    async function tlOpenEventAsTempSticky(uid) {
      if (!uid) return;
      const ev = (typeof tlCalEvents !== 'undefined' && Array.isArray(tlCalEvents)) ? tlCalEvents.find(function (e) { return e && e.uid === uid; }) : null;
      if (!ev) { if (typeof showToast === 'function') showToast('找不到该行程（内容可能已被修改）', 'danger'); return; }
      if ((parseInt(ev.sticky, 10) || 0) > 0) { await tlFocusStickyNote(uid); return; } // 已是正式便利贴 → 直接跳转
      tlTempStickyUids.add(uid);
      if (typeof tlUpdateStickyBadge === 'function') tlUpdateStickyBadge();
      tlRefreshTempStickyMarks();
      let opened = (typeof tlStickyNotesOpen !== 'undefined') && tlStickyNotesOpen;
      if (!opened) {
        if (typeof tlOpenStickyNotes === 'function') await tlOpenStickyNotes();
        opened = (typeof tlStickyNotesOpen !== 'undefined') && tlStickyNotesOpen;
      } else {
        if (typeof tlPushStickyRefreshes === 'function') tlPushStickyRefreshes(true);
      }
      if (opened && window.electronAPI && window.electronAPI.invoke) {
        try { await window.electronAPI.invoke('focus-sticky-note', { key: ev.uid || uid, idx: 0 }); } catch (e) {}
      }
      if (typeof showToast === 'function') showToast('已临时开启为便利贴（仅本会话，未写入文件）', 'success');
    }
    // 关闭临时便利贴：从内存移除；翻页模式同步移除，分体模式额外发 close 关窗
    async function tlCloseTempSticky(uid) {
      if (!uid || !tlTempStickyUids.has(uid)) return;
      tlTempStickyUids.delete(uid);
      if (typeof tlUpdateStickyBadge === 'function') tlUpdateStickyBadge();
      tlRefreshTempStickyMarks();
      if ((typeof tlStickyNotesOpen !== 'undefined') && tlStickyNotesOpen && typeof tlPushStickyRefreshes === 'function') {
        tlPushStickyRefreshes(true);
      }
      if (window.electronAPI && window.electronAPI.invoke) {
        try { await window.electronAPI.invoke('sticky-note-close', { key: uid, idx: 0 }); } catch (e) {}
      }
    }
    // 跳转到已临时开启的便利贴（不走 tlFocusStickyNote 的 sticky>0 守卫）
    async function tlFocusTempSticky(uid, unit) {
      if (!window.electronAPI || !window.electronAPI.invoke) return;
      if (!((typeof tlStickyNotesOpen !== 'undefined') && tlStickyNotesOpen)) {
        if (typeof tlOpenStickyNotes === 'function') await tlOpenStickyNotes();
      }
      try { await window.electronAPI.invoke('focus-sticky-note', { key: uid, idx: 0, focusUnit: unit || undefined }); } catch (e) {}
    }
    // 🆕 从右击目标反推「被右击的那笔小事件(群)」定位描述（坐标优先，文本兜底）。
    //   与主窗卡片、便利贴正文共用同一套 tlRenderNotes → data-line / data-start+data-end 完全一致，
    //   故可直接作为便利贴窗匹配的权威键；text 作为只读区块（无编辑按钮）的兜底匹配。
    function tlCtxUnitOf(target) {
      if (!target || !target.closest) return null;
      const norm = (s) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
      // ① 编辑小圆点：坐标最精确
      const editBtn = target.closest('.ev-md-edit, .md-unit-edit');
      if (editBtn) {
        if (editBtn.classList.contains('ev-md-edit')) {
          const line = editBtn.getAttribute('data-line');
          if (line != null) {
            const c = editBtn.closest('.ev-md-check') || editBtn;
            return { kind: 'check', line: parseInt(line, 10), text: norm(c.textContent) };
          }
        } else {
          const s = editBtn.getAttribute('data-start'), e = editBtn.getAttribute('data-end'), t = editBtn.getAttribute('data-type');
          if (s != null && e != null) {
            const c = editBtn.closest('.md-unit') || editBtn;
            return { kind: 'block', start: parseInt(s, 10), end: parseInt(e, 10), type: t || '', text: norm(c.textContent) };
          }
        }
      }
      // ② checkbox 行：命中文字也认得到（.ev-cb 带 data-line）
      const checkWrap = target.closest('.ev-md-check');
      if (checkWrap) {
        const cb = checkWrap.querySelector('.ev-cb[data-line]');
        if (cb) { const line = cb.getAttribute('data-line'); if (line != null) return { kind: 'check', line: parseInt(line, 10), text: norm(checkWrap.textContent) }; }
      }
      // ③ 区块：命中文字（.md-unit 容器，含只读 gp 外框）
      const unitDiv = target.closest('.md-unit');
      if (unitDiv) {
        const btn = unitDiv.querySelector('.md-unit-edit[data-start]');
        if (btn) {
          const s = btn.getAttribute('data-start'), e = btn.getAttribute('data-end'), t = btn.getAttribute('data-type');
          if (s != null && e != null) return { kind: 'block', start: parseInt(s, 10), end: parseInt(e, 10), type: t || '', text: norm(unitDiv.textContent) };
        }
        // 只读区块（无编辑按钮）：纯文本兜底
        return { kind: 'block', start: -1, end: -1, type: '', text: norm(unitDiv.textContent) };
      }
      return null;
    }
    // 🆕 唯讀行程「編輯小圓點」左鍵：不進編輯，直接開同一套事件右鍵選單
    //    （右鍵由全域 contextmenu 監聽處理；兩條路都帶 tlCtxUnitOf 反推的 unit → 跳轉可精確定位該筆小事件）
    function tlOpenRoDotMenu(e) {
      if (!e) return;
      e.preventDefault(); e.stopPropagation();
      const dot = e.currentTarget;
      const uid = dot && dot.getAttribute('data-uid');
      if (!uid) return;
      const ev = (typeof tlCalEvents !== 'undefined' && Array.isArray(tlCalEvents))
        ? tlCalEvents.find(function (x) { return x && x.uid === uid; }) : null;
      if (!ev) return;
      tlShowEventCtxMenu(ev, e.clientX || 0, e.clientY || 0, tlCtxUnitOf(dot));
    }
    // 行程卡片右键菜单
    function tlShowEventCtxMenu(ev, x, y, unit) {
      let menu = document.getElementById('tlEventCtxMenu');
      if (!menu) {
        menu = document.createElement('div');
        menu.id = 'tlEventCtxMenu';
        menu.className = 'tl-event-ctx-menu';
        menu.style.display = 'none';
        menu.innerHTML =
          '<button type="button" data-tl-ev-act="open-temp">📌 临时开启为便利贴</button>' +
          '<button type="button" data-tl-ev-act="close-temp">✕ 关闭临时便利贴</button>' +
          '<button type="button" data-tl-ev-act="focus">🔍 跳转到便利贴</button>' +
          '<button type="button" data-tl-ev-act="edit">✎ 编辑事件</button>';
        document.body.appendChild(menu);
        menu.addEventListener('click', function (ce) {
          const act = ce.target.getAttribute && ce.target.getAttribute('data-tl-ev-act');
          if (!act) return;
          menu.style.display = 'none';
          const uid = menu.__uid;
          if (act === 'open-temp') tlOpenEventAsTempSticky(uid);
          else if (act === 'close-temp') tlCloseTempSticky(uid);
          else if (act === 'focus') { if (tlIsTempSticky(uid)) tlFocusTempSticky(uid, menu.__unit); else tlFocusStickyNote(uid, 0, menu.__unit); }
          else if (act === 'edit') { if (typeof tlOpenEventForm === 'function') tlOpenEventForm(uid); }
        });
        document.addEventListener('click', function () { menu.style.display = 'none'; }, true);
      }
      const isSticky = (parseInt(ev.sticky, 10) || 0) > 0;
      const temp = tlIsTempSticky(ev.uid);
      const openItem = menu.querySelector('[data-tl-ev-act="open-temp"]');
      const closeItem = menu.querySelector('[data-tl-ev-act="close-temp"]');
      const focusItem = menu.querySelector('[data-tl-ev-act="focus"]');
      const editItem = menu.querySelector('[data-tl-ev-act="edit"]');
      if (openItem) openItem.style.display = (isSticky || temp) ? 'none' : '';
      if (closeItem) closeItem.style.display = temp ? '' : 'none';
      if (focusItem) focusItem.style.display = (isSticky || temp) ? '' : 'none';
      // 🆕 唯讀（include 外部檔）行程：只顯示非編輯功能（臨時開啟／關閉便利貼、跳轉到便利貼定位）；
      //    「✎ 編輯事件」對唯讀事件無意義（表單會被 tlSetEventFormReadonly 全數 disabled），故收起。
      if (editItem) editItem.style.display = ev.ro ? 'none' : '';
      menu.__uid = ev.uid;
      menu.__unit = unit || null;
      menu.style.display = 'block';
      const pw = menu.offsetWidth || 180, ph = menu.offsetHeight || 120;
      let left = x, top = y;
      if (left + pw > window.innerWidth - 8) left = window.innerWidth - pw - 8;
      if (top + ph > window.innerHeight - 8) top = window.innerHeight - ph - 8;
      menu.style.left = Math.max(4, left) + 'px';
      menu.style.top = Math.max(4, top) + 'px';
    }
    // 行程卡片右键 → 弹出菜单（标签菜单优先；命中标签则由标签处理器处理）
    //  ⚠️ 千萬別用 .modal 當排除條件：主視窗本身就是 <div class="modal editor-layout">，
    //     日曆視圖整個都在它裡面 → 一排等於把所有行程行的右鍵全部擋掉（2026-11-04 實測「右鍵沒反應」根因）。
    //     只排除「真正的表單浮層」.tl-ev-form-overlay（新增行程/編輯/統計等 overlay）。
    document.addEventListener('contextmenu', function (e) {
      // 每次右鍵先收掉上一次的事件選單：右鍵不觸發 click，下方 document 的 click 捕獲監聽收不到它
      const prev = document.getElementById('tlEventCtxMenu');
      if (prev) prev.style.display = 'none';
      if (e.target.closest && e.target.closest('[data-tag]')) return; // 标签有独立菜单
      if (e.target.closest && e.target.closest('.tl-ev-form-overlay')) return; // 表單浮層內不觸發
      const evEl = e.target.closest ? e.target.closest('[data-uid]') : null;
      if (!evEl) return;
      const uid = evEl.getAttribute('data-uid');
      if (!uid) return;
      const ev = (typeof tlCalEvents !== 'undefined' && Array.isArray(tlCalEvents)) ? tlCalEvents.find(function (x) { return x && x.uid === uid; }) : null;
      if (!ev) return;
      e.preventDefault();
      tlShowEventCtxMenu(ev, e.clientX, e.clientY, tlCtxUnitOf(e.target));
    });
    // 依据便利贴 key（= 事件 uid）找事件 uid（供桌面便利贴「在主程式打开 / 编辑回写」定位事件）
    function tlFindEventUidByKey(key) {
      const ev = tlCalEvents.find((x) => (x.uid || '') === key);
      return ev ? ev.uid : null;
    }

    function tlIsMultiDay(ev) { return !!(ev && ev.endDate && ev.endDate !== ev.date); }
    // 🆕 显示方式＝「显示在今天」：真实 date/endDate 区间已被锚定到今天，不要再显示
    //    「开始日期 – 结束日期 · 共N天」，改显示固定字样（便利贴 / LITE 三端同口径）。
    const TL_SPAN_TODAY_TEXT = '显示在今天';
    function tlIsSpanToday(ev) { return !!(ev && ev.spanDisplay === 'today'); }
    // ⚠️ 必须含「日」：曾漏掉 (+m[3]) → 跨天行程/假日区间显示成「2026/9 – 2026/9」（看不出是哪天）。与 LITE calMdShort 对齐。
    function tlMdShort(d) { const m = String(d || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/); return m ? (+m[1]) + '/' + (+m[2]) + '/' + (+m[3]) : (d || ''); }
    function tlSpanDays(a, b) {
      const d1 = new Date(a + 'T00:00:00'), d2 = new Date(b + 'T00:00:00');
      if (isNaN(d1) || isNaN(d2)) return 1;
      return Math.round((d2 - d1) / 86400000) + 1;
    }
    function tlRangeLabel(a, b, st, et) {
      if (st || et) return tlMdShort(a) + ' ' + (st || '') + ' \u2013 ' + tlMdShort(b) + ' ' + (et || '');
      return tlMdShort(a) + ' \u2013 ' + tlMdShort(b);
    }
    function tlEventOccurrences(ev) {
      // 🆕 显示方式＝「显示在今天」：无论真实 date/endDate 为何，都只在「今天」出现一笔
      //   （与 首末天/每天 同列于「显示方式」下拉；覆盖跨天、单日、重复所有类型；真实日期原样保留在编辑器里）。
      if (ev && ev.spanDisplay === 'today') {
        const today = tlFmtDate(new Date());
        return [{ date: today, ev, pos: 'single', idx: 1, total: 1 }];
      }
      const out = [];
      if (tlIsMultiDay(ev)) {
        let cur = new Date(ev.date + 'T00:00:00');
        const end = new Date(ev.endDate + 'T00:00:00');
        if (!isNaN(cur) && !isNaN(end)) {
          const total = Math.round((end - cur) / 86400000) + 1;
          let idx = 0;
          while (cur <= end) {
            idx++;
            const ds = tlFmtDate(cur);
            const pos = ds === ev.date ? 'start' : (ds === ev.endDate ? 'end' : 'middle');
            out.push({ date: ds, ev, pos, idx, total });
            cur.setDate(cur.getDate() + 1);
          }
          return tlFilterSpanDisplay(ev, out);
        }
      }
      // ===== ## EVENT(REPEAT) 重複事件：展開為可見範圍內的發生日 =====
      // REPEAT 三態：none=隱藏全部；next=只顯示「今天及之後最近的一次」；some=最近的前一次+未來4次（最多5次）
      if (ev.repeatMode && ev.repeatMode !== '') {
        // ⚠️ some 需要「未來 4 次」但當前視圖窗口（tlRepeatFrom/To）可能只覆蓋未來 1~3 次，
        //    故 some 分支改用「寬窗口」重新展開，拿到完整序列再截取，不受視圖窗口裁剪。
        const savedFrom = tlRepeatFrom, savedTo = tlRepeatTo;
        tlSetRepeatWindow('2000-01-01', '2100-01-01');
        const occ = tlExpandRepeats(ev);
        tlSetRepeatWindow(savedFrom, savedTo);
        if (tlCalShowRepeat === 'none') return [];
        const today = tlFmtDate(new Date());
        if (tlCalShowRepeat === 'next') {
          let best = null;
          for (let i = 0; i < occ.length; i++) { if (occ[i].date >= today && (!best || occ[i].date < best.date)) best = occ[i]; }
          return best ? [best] : [];
        }
        // some：最近的前一次（date < today）+ 未來 4 次（date >= today），最多 5 次
        const past = [], future = [];
        for (let i = 0; i < occ.length; i++) { if (occ[i].date < today) past.push(occ[i]); else future.push(occ[i]); }
        return (past.length ? [past[past.length - 1]] : []).concat(future.slice(0, 4));
      }
      out.push({ date: ev.date, ev, pos: 'single', idx: 1, total: 1 });
      return tlFilterSpanDisplay(ev, out);
    }
    function tlFilterSpanDisplay(ev, occurrences) {
      if (!tlIsMultiDay(ev)) return occurrences;
      const mode = ev && (ev.spanDisplay === 'first' || ev.spanDisplay === 'last') ? ev.spanDisplay : 'daily';
      if (mode === 'first') return occurrences.filter((o) => o.pos === 'start');
      if (mode === 'last') return occurrences.filter((o) => o.pos === 'end');
      return occurrences;
    }
    // 取事件在当前 span 显示模式下的「代表显示日」：daily/first → start date；last → end date
    //   用于便利贴「滚动」等需要「跳到事件实际被渲染的那一天」的场景
    function tlEventDisplayDate(ev) {
      if (!ev) return '';
      if (ev.spanDisplay === 'today') return tlFmtDate(new Date());   // 🆕 显示在今天 → 锚定今天
      if (!tlIsMultiDay(ev)) return ev.date || '';
      const mode = (ev.spanDisplay === 'first' || ev.spanDisplay === 'last') ? ev.spanDisplay : 'daily';
      if (mode === 'last' && ev.endDate) return ev.endDate;
      return ev.date || '';
    }
    // 重複展開視窗：各視圖渲染前用 tlSetRepeatWindow 設定，避免 never 模式無限展開
    let tlRepeatFrom = '2000-01-01', tlRepeatTo = '2100-01-01';
    function tlSetRepeatWindow(from, to) { tlRepeatFrom = from || '2000-01-01'; tlRepeatTo = to || '2100-01-01'; }
    const TL_WD = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
    function tlWdKey(d) { return TL_WD[d.getDay()]; }
    function tlAddDaysStr(ds, n) { const d = new Date(ds + 'T00:00:00'); d.setDate(d.getDate() + n); return tlFmtDate(d); }
    // 把 ''/'1'/'01' 統一成 'DD'（日）
    function tlPad2(n) { n = parseInt(n, 10); return isNaN(n) ? '' : (n < 10 ? '0' + n : '' + n); }
    // 由重複定義生成發生日陣列（受 [tlRepeatFrom, tlRepeatTo] 約束）；idx＝實際收錄序號，total＝count 模式總次數
    function tlExpandRepeats(ev) {
      // 去掉用户手写时可能带的最外层双引号（如 repeatYearMonthDay: `"05-26"`），保证比较正确且不改写文件
      const strip = (s) => { s = String(s == null ? '' : s); return (s.length >= 2 && s[0] === '"' && s[s.length - 1] === '"') ? s.slice(1, -1) : s; };
      const mode = strip(ev.repeatMode);
      if (!mode) return [];
      const interval = Math.max(1, parseInt(strip(ev.repeatInterval), 10) || 1);
      let exclude = ev.repeatExcludeDates;
      if (typeof exclude === 'string') { try { exclude = JSON.parse(exclude); } catch (e) { exclude = []; } }
      if (!Array.isArray(exclude)) exclude = [];
      const endType = strip(ev.repeatEndType) || 'never';
      const endVal = strip(ev.repeatEndValue);
      const from = tlRepeatFrom, to = tlRepeatTo;
      const out = [];
      const cur = new Date(ev.date + 'T00:00:00');
      if (isNaN(cur)) return out;
      const bD = cur.getDate(), bM = cur.getMonth(), bY = cur.getFullYear();
      const wds = (ev.repeatWeekDay && ev.repeatWeekDay.length) ? ev.repeatWeekDay : [tlWdKey(cur)];
      const mDay = ev.repeatMonthDay ? parseInt(strip(ev.repeatMonthDay), 10) : bD;
      const ymd = ev.repeatYearMonthDay ? strip(ev.repeatYearMonthDay) : (tlPad2(bM + 1) + '-' + tlPad2(bD));
      let idx = 0, guard = 0;
      while (guard++ < 8000) {
        const ds = tlFmtDate(cur);
        if (ds > to) break;
        if (ds >= from) {
          let hit = false;
          if (mode === 'daily') hit = true;
          else if (mode === 'weekly') hit = wds.indexOf(tlWdKey(cur)) >= 0;
          else if (mode === 'monthly') {
            const months = (cur.getFullYear() - bY) * 12 + (cur.getMonth() - bM);
            hit = cur.getDate() === mDay && months % interval === 0;
          } else if (mode === 'yearly') {
            const curMd = tlPad2(cur.getMonth() + 1) + '-' + tlPad2(cur.getDate());
            hit = curMd === ymd && (cur.getFullYear() - bY) % interval === 0;
          }
          if (hit && exclude.indexOf(ds) < 0) {
            idx++;
            if (endType === 'count' && idx > (parseInt(endVal, 10) || 0)) break;
            if (endType === 'date' && ds > endVal) break;
            out.push({ date: ds, ev, pos: 'single', idx, total: endType === 'count' ? (parseInt(endVal, 10) || 0) : 0 });
          }
        }
        cur.setDate(cur.getDate() + 1);
      }
      return out;
    }
    function tlOccSort(a, b) {
      const aSpan = a.pos === 'single' ? 1 : 0, bSpan = b.pos === 'single' ? 1 : 0;
      if (aSpan !== bSpan) return aSpan - bSpan;
      if (a.ev.date !== b.ev.date) return a.ev.date < b.ev.date ? -1 : 1;
      if (a.ev.allDay !== b.ev.allDay) return a.ev.allDay ? -1 : 1;
      return tlTimeToMin(a.ev.startTime) - tlTimeToMin(b.ev.startTime);
    }
    // 跨天行程的「第幾天」後綴（單一來源）：total>1 時回傳「 (idx/total)」（如 回上海 (1/7)），單日行程不加
    // 使用點：月格色條、時間網格（全天條／定時塊／假期條）、列表行、假日列
    function tlSpanSuffix(idx, total) { return (total > 1 && idx > 0) ? ' (' + idx + '/' + total + ')' : ''; }
    // 由「出現日」直接算跨天序號——呼叫方不必手上握有 occurrence 的 idx/total（列表行/假日列走的是
    // 「按日期分組」入口，那份資料只有 ev + 日期，沒有產生 seq）。
    // ⚠️ 只認「跨天」（date ≠ endDate）：重複事件的 idx/total 是「第幾次」而非「第幾天」，兩者不可混用。
    function tlSpanDaySuffix(item, occDate) {
      // 🆕 显示方式＝「显示在今天」：真实区间已锚定成「今天一笔」，不再显示 (第几天/共几天)
      if (tlIsSpanToday(item)) return '';
      if (!tlIsMultiDay(item)) return '';
      const total = tlSpanDays(item.date, item.endDate);
      if (total <= 1) return '';
      const idx = Math.min(Math.max(tlSpanDays(item.date, occDate || item.date), 1), total);
      return tlSpanSuffix(idx, total);
    }
    // 📝 備註裡的 Markdown checkbox（- [ ] / - [x]）渲染成 ☐/☑ 樣式，且可點擊勾選/取消（寫回 notes 原文）。
    //    入參必須是「已 escape」的文本；支援任意縮進的 `- [ ]` / `- [x]` / `- [X]`。
    //    uid 為所屬行程（點擊時定位用）；fenced code block 內的行不當成 checkbox，避免誤判代碼。
    // 基礎 Markdown 渲染（標題/備註共用）。
    // 標題行內使用：若 marked 只產出單個 <p>，去掉 <p> 包裝，避免在 .ev-title 裡產生多餘段間距。
    function tlRenderInlineMarkdown(text) {
      if (!text) return '';
      // 🆕 標題也支援術語渲染：[[term:釋義]]／[[term]] → 膠囊＋虛線底線（dl/cp/裸日期排除，見 tlRenderTermDefs）
      const html = renderMarkdown(tlRenderTermDefs(String(text).trim()));
      const trimmed = html.trim();
      if (/^<p>/i.test(trimmed) && /<\/p>$/i.test(trimmed)) {
        const inner = trimmed.slice(3, -4);
        if (!/<p>/i.test(inner)) return inner;
      }
      return html;
    }
    // ── 顏色名解析 v2（2026-11-09 擴展：+n/-n 數字級別 + 漸變） ──
    //   語法：
    //     紅 / 藍 / 綠 ...       → 基礎色（16 種）
    //     紅+1 ~ 紅+10           → 加深 1~10 級（每級 ≈ 7.5%，最多 75%）
    //     紅-1 ~ 紅-10           → 淡化 1~10 級（向白色靠近）
    //     深紅 / 淺紅 / 淡紅      → 文字級別（保留兼容）
    //     漸變(白→淡藍)           → linear-gradient(135deg, #ecf0f1, #aed6f1)
    //     #hex / rgb() / hsl()   → 原樣透傳
    //   解析優先級：漸變 → 數字級別 → 文字級別 → 預定義全名 → hex/rgb/hsl → 原樣
    const tlCN_COLORS = {
      '红': '#e74c3c', '橙': '#e67e22', '黄': '#f1c40f', '金': '#d4af37',
      '粉': '#ff6b9d', '紫': '#8e44ad', '蓝': '#3498db',
      '绿': '#27ae60', '青': '#1abc9c', '灰': '#95a5a6', '黑': '#2c3e50', '白': '#ecf0f1',
      '卡其': '#bdb76b', '棕': '#8b5a2b', '酒红': '#722f37', '米': '#f5f0dc'
    };
    function tlHexToHsl(hex) {
      const h = hex.replace('#', '');
      const r = parseInt(h.slice(0, 2), 16) / 255;
      const g = parseInt(h.slice(2, 4), 16) / 255;
      const b = parseInt(h.slice(4, 6), 16) / 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b);
      const l = (max + min) / 2;
      let hh, s = 0;
      if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) { case r: hh = (g - b) / d + (g < b ? 6 : 0); break; case g: hh = (b - r) / d + 2; break; default: hh = (r - g) / d + 4; }
        hh /= 6;
      } else hh = 0;
      return { h: hh * 360, s: s * 100, l: l * 100 };
    }
    function tlHslToHex(hsl) {
      const h = hsl.h / 360, s = hsl.s / 100, l = hsl.l / 100;
      function hue2rgb(p, q, t) {
        if (t < 0) t += 1; if (t > 1) t -= 1;
        if (t < 1/6) return p + (q - p) * 6 * t;
        if (t < 1/2) return q;
        if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
        return p;
      }
      let r, g, b;
      if (s === 0) { r = g = b = l; }
      else {
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = hue2rgb(p, q, h + 1/3); g = hue2rgb(p, q, h); b = hue2rgb(p, q, h - 1/3);
      }
      const toHex = (v) => Math.round(v * 255).toString(16).padStart(2, '0');
      return '#' + toHex(r) + toHex(g) + toHex(b);
    }
    // 通用亮度調整：baseHex + 參數
    //   op: '+' 加深 / '-' 淡化 / '深'/'浅'/'淡' 文字級別
    //   n:  數字級別（1~10，僅 op 為 '+'/'-' 時生效）
    function tlShiftBrightness(baseHex, op, n) {
      const hsl = tlHexToHsl(baseHex);
      let newL = hsl.l;
      if (op === '+') newL = hsl.l * (1 - Math.min(10, n) / 10 * 0.75);
      else if (op === '-') newL = hsl.l + (100 - hsl.l) * Math.min(10, n) / 10 * 0.75;
      else if (op === '深') newL = hsl.l * 0.65;
      else if (op === '浅') newL = hsl.l + (100 - hsl.l) * 0.28;
      else if (op === '淡') newL = hsl.l + (100 - hsl.l) * 0.48;
      newL = Math.max(3, Math.min(97, newL));
      return tlHslToHex({ h: hsl.h, s: hsl.s, l: newL });
    }
    function tlResolveColorName(input) {
      if (!input) return '';
      const s = String(input).trim();
      if (!s) return '';
      // ① 漸變：漸變(白→淡藍) 或 漸變(#fff→#3498db)
      const gm = s.match(/^渐变\s*\(\s*([^→)]+)\s*→\s*([^)]+)\s*\)$/);
      if (gm) {
        const a = tlResolveColorName(gm[1]);
        const b = tlResolveColorName(gm[2]);
        if (a && b) return 'linear-gradient(135deg, ' + a + ', ' + b + ')';
      }
      // ② 數字級別：紅+3 / 藍-2
      const nm = s.match(/^(.+?)\s*([+\-])\s*(\d+)$/);
      if (nm) {
        const base = nm[1].trim(), op = nm[2], n = parseInt(nm[3], 10);
        const baseHex = tlCN_COLORS[base];
        if (baseHex && n >= 1 && n <= 10) return tlShiftBrightness(baseHex, op, n);
      }
      // ③ 文字級別：深紅 / 淺藍 / 淡綠（保留兼容）
      const tm = s.match(/^(深|浅|淡)(.+)$/);
      if (tm) {
        const op = tm[1], base = tm[2].trim();
        const baseHex = tlCN_COLORS[base];
        if (baseHex) return tlShiftBrightness(baseHex, op);
      }
      // ④ 預定義全名
      if (tlCN_COLORS[s]) return tlCN_COLORS[s];
      // ⑤ hex / rgb / hsl 原樣透傳
      if (/^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(s)) return s;
      if (/^(rgb|rgba|hsl|hsla)\s*\(/i.test(s)) return s;
      // ⑥ 原樣交 CSS
      return s;
    }
    // 🆕 2026-11-14 升级为多 pipe 版本（与 desktop-note.js noteExtractGpAttrs 对齐）
    // 格式：{gpX|attrs段|term段}
    //   attrs 段用 , 分隔 fg=红,bg=黄,anim=pulse
    //   term 段用 | 分隔 alert|TERM=便利贴
    function tlParseGpAttrs(raw) {
      const s = String(raw == null ? '' : raw).trim();
      if (!s) return { key: '', fg: '', bg: '', anim: '', alert: false, extra: [], term: '', termName: '', railStyle: '', railA: '', railB: '' };
      const pipe1 = s.indexOf('|');
      if (pipe1 < 0) return { key: s, fg: '', bg: '', anim: '', alert: false, extra: [], term: '', termName: '', railStyle: '', railA: '', railB: '' };
      const key = s.slice(0, pipe1).trim();
      const rest = s.slice(pipe1 + 1);
      const pipe2 = rest.indexOf('|');
      const attrsPart = pipe2 >= 0 ? rest.slice(0, pipe2) : rest;
      const termPart = pipe2 >= 0 ? rest.slice(pipe2 + 1) : '';
      // 解析 attrs 段
      const extra = [];
      let fg = '', bg = '', anim = '', alert = false, termName = '', railStyle = '', railA = '', railB = '';
      attrsPart.split(',').forEach((pair) => {
        const p = pair.trim();
        if (!p) return;
        const eq = p.indexOf('=');
        if (eq < 0) { extra.push(p); return; }
        const k = p.slice(0, eq).trim().toLowerCase();
        const v = p.slice(eq + 1).trim();
        if (k === 'fg') fg = tlResolveColorName(v);
        else if (k === 'bg') bg = tlResolveColorName(v);
        else if (k === 'anim' && /^(pulse|scan|data|aurora|orbit|arc|holo|signal|glitch)$/.test(v)) anim = v;
        else if (k === 'rail') {
          const rp = v.split('#');
          if (rp.length >= 3 && ['斜栏', '直栏', '>形栏', '圆弧栏'].indexOf(rp[0].trim()) >= 0) {
            railStyle = rp[0].trim();
            railA = tlResolveColorName(rp[1].trim());
            railB = tlResolveColorName(rp[2].trim());
          }
        }
        else extra.push(p);
      });
      // 兜底：attrs 段里可能有 TERM=xxx（没有第二个 pipe 的情况），移到 termName
      const termInAttrs = extra.find((x) => /^TERM\s*=/i.test(x));
      if (termInAttrs) {
        termName = termInAttrs.replace(/^TERM\s*=\s*/i, '').trim();
        const idx = extra.indexOf(termInAttrs);
        if (idx >= 0) extra.splice(idx, 1);
      }
      // 解析 term 段
      if (termPart) {
        // 先按 | 拆分多段，每段内部再按 , 拆分（支持 TERM=xxx,rail=xxx 混写）
        termPart.split('|').forEach((seg) => {
          seg.split(',').forEach((item) => {
            const segTrim = item.trim();
            if (!segTrim) return;
            const eq = segTrim.indexOf('=');
            if (eq < 0) {
              if (/^(dl|cp|cr|alert|remind|bookmark)$/i.test(segTrim)) alert = true;
              return;
            }
            const k = segTrim.slice(0, eq).trim().toUpperCase();
            const v = segTrim.slice(eq + 1).trim();
            if (k === 'TERM' && v) termName = v;
            else if (k === 'ALERT') alert = v.toLowerCase() === 'true';
            // 🆕 2026-11-14：term 段兜底解析 rail（rail=斜栏#白#黑）
            else if (k === 'RAIL') {
              const rp = v.split('#');
              if (rp.length >= 3 && ['斜栏', '直栏', '>形栏', '圆弧栏'].indexOf(rp[0].trim()) >= 0) {
                railStyle = rp[0].trim();
                railA = tlResolveColorName(rp[1].trim());
                railB = tlResolveColorName(rp[2].trim());
              }
            }
          });
        });
      }
      return { key: key, fg: fg, bg: bg, anim: anim, alert: alert, extra: extra, term: termPart, termName: termName, railStyle: railStyle, railA: railA, railB: railB };
    }
    function tlExtractGpAttrsFromLine(line) {
      const s = String(line == null ? '' : line);
      let m = s.trim().match(/^\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}]*)\}[ \t]*$/i);
      if (m) return tlParseGpAttrs(m[1]);
      m = s.match(/\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}]*)\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
      if (m) return tlParseGpAttrs(m[1]);
      return { key: '', fg: '', bg: '', anim: '', alert: false };
    }
    // ── group 標記語法（2026-11-06 寬放）：花括號內「開頭」是 gp 或 group 即算；大小寫不拘、冒號可省略 ──
    //   {gp} ＝ {GP} ＝ {GroUP} ＝ {group}               → 無名組（key ''）
    //   {gp:ABC} ＝ {gpABC} ＝ {GROUP:ABC} ＝ {GROUPABC}  → key 'ABC'
    //   {gp1} ＝ {gp:1} ＝ {Group:1}                     → key '1'
    //   ⚠️ 前綴 group 必須優先於 gp，否則 {groupABC} 會被誤讀成 key 'roupABC'；
    //      組名本身仍區分大小寫，且只比較「連續且同 key」的行（組是連續區段，不是全域合併）。
    //   ⚠️ 位置（2026-11-06 二次定規）：標記必須在「行尾」或「行尾 [[...]] 標記序列之前」才算結構標記；
    //      行中的 {gp} 一律是普通文字，必須原樣顯示、也不參與分組。三式正則共用 lookahead 錨定行尾，
    //      且 lookahead 不消費 [[...]]，剝離時才不會把 cr/dl/cp 一併吃掉。
    //   ⚠️ 三式正則（取 key / 剝離 / cr 定位）四端字面量必須完全一致，見 /tmp/gp-syntax-test.cjs。
    //      勾選「group 啟用」寫入底稿時一律正規化成標準 {gp}（見 tlApplyGroupMarkers）。
    // 🆕 {gp} / {gp:名稱} 分組標記：連續且「名稱相同」的行視為一個小事件（一顆編輯小圓點）。
    //   · 回傳 null＝這行沒有標記；''＝{gp} 無名組；名稱＝{gp:名稱}。
    //   · 名稱不同的相鄰行各自成組；同名但不連續也各自成組（組是「連續區段」，不是全域合併）。
    //   · 標記只存在於原始 notes，顯示層由 tlStripGpMarkers 剝掉；寫入底稿一律保留原文
    //     （tlOpenEditBlockDialog / tlSaveAddCheckDialog 直接讀寫 ev.notes 的 start..end 原文）。
    function tlGpKeyOfLine(line) {
      const m = String(line == null ? '' : line).match(/\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}|]*)(?:\|[^{}]*)?\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
      if (!m) return null;
      return String(m[1] || '').trim();
    }
    // ── 🆕 塊級（圍欄式）小事件群（2026-11-08）：單獨一行 {gpX} 開啟、
    //    單獨一行 {/gpX} 結束，兩行之間的 Markdown 整體算「一個」[[小事件群]]。 ──
    //  · 與「行尾 {gpX}」並存：行尾寫法靠連續同 key，塊級寫法靠成對標記行，是**硬邊界**，
    //    絕不與前後群合併；塊內各行也不必再加行尾標記。
    //  · 標記行是結構控制行：顯示層剝成空行（行數不變 → start/end/baseLine/勾選回寫全部照舊），底稿保留原文。
    //  · 只認「整行就是一個花括號標記」；行中的 {gpX} 仍是普通文字（沿用 11-06 位置規則）。
    //  · 代碼圍欄內不解析；未配對／孤立標記行不形成群（容錯，完全退回既有行尾語義，零回歸）。
    //  · 不支援巢狀：遇到第一個同名結束行即閉合。
    function tlGpFenceOfLine(line) {
      const s = String(line == null ? '' : line).trim();
      let m = s.match(/^\{[ \t]*\/[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}|]*)(?:\|[^{}]*)?\}[ \t]*$/i);
      if (m) return { kind: 'close', key: String(m[1] || '').trim() };
      m = s.match(/^\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}|]*)(?:\|[^{}]*)?\}[ \t]*$/i);
      if (m) return { kind: 'open', key: String(m[1] || '').trim() };
      return null;
    }
    // 掃出所有「已配對」區間與其標記行行號；回傳 {ranges:[{start,end,key,fg,bg}], markers:[行號]}。
    function tlGpFenceScan(lines) {
      const ranges = [], markers = [];
      let inFence = false, open = null;
      for (let i = 0; i < lines.length; i++) {
        const line = String(lines[i] == null ? '' : lines[i]);
        if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; continue; }
        if (inFence) continue;
        const f = tlGpFenceOfLine(line);
        if (!f) continue;
        if (f.kind === 'open') {
          if (!open) {
            // 🆕 從 open 行提取 fg/bg/anim/rail attrs + termName（TERM=xxx），存進 open 供關閉時寫入 range
            const a = (typeof tlExtractGpAttrsFromLine === 'function') ? tlExtractGpAttrsFromLine(line) : { fg: '', bg: '', alert: false };
            open = { i: i, key: f.key, fg: a.fg || '', bg: a.bg || '', anim: a.anim || '', alert: a.alert === true, term: a.term || '', termName: a.termName || '', railStyle: a.railStyle || '', railA: a.railA || '', railB: a.railB || '' };
          }
          continue;
        }
        if (open && open.key === f.key) {
          ranges.push({ start: open.i, end: i, key: f.key, fg: open.fg, bg: open.bg, anim: open.anim, alert: open.alert, term: open.term || '', termName: open.termName || '', railStyle: open.railStyle || '', railA: open.railA || '', railB: open.railB || '' });
          markers.push(open.i, i);
          open = null;
        }
      }
      return { ranges: ranges, markers: markers };
    }
    // 整段（去掉首尾純空白行後）恰好就是一個塊級群 → 回傳其資料，供 group 啟用預勾／拆組使用。
    function tlGpFenceWrap(text) {
      const lines = String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
      let s = 0, e = lines.length - 1;
      while (s <= e && !lines[s].trim()) s++;
      while (e >= s && !lines[e].trim()) e--;
      if (s > e) return null;
      const scan = tlGpFenceScan(lines);
      const hit = scan.ranges.find((r) => r.start === s && r.end === e);
      // 🆕 2026-11-09：把 hit.fg / hit.bg 也帶出來，供 tlWrapGpFence 重寫時保留 attrs
      return hit ? { lines: lines, start: s, end: e, key: hit.key, fg: hit.fg || '', bg: hit.bg || '', anim: hit.anim || '', alert: hit.alert === true, term: hit.term || '', termName: hit.termName || '', railStyle: hit.railStyle || '', railA: hit.railA || '', railB: hit.railB || '', scan: scan } : null;
    }
    // ── 🆕 2026-11-08：勾選「group 啟用」按保存時一律改寫成「塊級」{gpX}…{/gpX}，不再逐行補行尾標記 ──
    //  · 已是塊級群且沒給新標記 → 原樣保留（不無謂改名）；給了 mark → 整段改名（兩行一起改）。
    //  · 舊的「行尾式」群 → 先剝掉每行行尾標記，再用原本的群名（沿用第一個標記字面量）包成塊級。
    //  · mark 為空時沿用原文第一個行尾標記的字面量，避免主窗／LITE 沒有「群標記」輸入框就把 {gpA} 降成 {gp}。
    //  · 🆕 2026-11-09：attrs（fg/bg）從原文 open 行或行尾式第一行提取，保存時永不丟失。
    function tlWrapGpFence(text, mark) {
      const lines = String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
      const wrap = (typeof tlGpFenceWrap === 'function') ? tlGpFenceWrap(text) : null;
      if (wrap) {
        // 🆕 沒給 mark（null/空/undefined）→ 原樣保留
        if (!mark) return lines.join('\n');
        // 🆕 mark 是預設無名組 '{gp}' 且 fence 已有具名 key → 不誤改群名
        if (mark === '{gp}' && wrap.key) return lines.join('\n');
        // 🆕 給了新 mark → 組裝新 open 行：key 用新 mark，attrs 沿用原文
        const newOpen = tlBuildGpOpenLine(mark, wrap.fg, wrap.bg, wrap.anim, wrap.alert, wrap.railStyle || '', wrap.railA || '', wrap.railB || '');
        const out = lines.slice();
        out[wrap.start] = newOpen;
        out[wrap.end] = tlBuildGpCloseLine(wrap.key);  // 🆕 close 只寫 key，不帶 attrs！
        return out.join('\n');
      }
      // 🆕 行尾式 → 塊級：從第一個行尾標記提取「完整字面量」（key + attrs 全都要）
      let open = '';
      for (const line of lines) {
        const m = line.match(/(\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\})(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
        if (m) { open = m[1]; break; }
      }
      // 🆕 用 mark（只有 key）組裝：attrs 已在 open 裡；若 mark 存在但無 attrs，保留原 attrs
      if (mark) {
        const origAttrs = (typeof tlExtractGpAttrsFromLine === 'function')
          ? tlExtractGpAttrsFromLine(open || '') : { fg: '', bg: '', anim: '', alert: false };
        open = tlBuildGpOpenLine(mark, origAttrs.fg, origAttrs.bg, origAttrs.anim, origAttrs.alert, origAttrs.railStyle, origAttrs.railA, origAttrs.railB);
      }
      open = open || '{gp}';
      const close = tlBuildGpCloseLine(tlKeyFromGpMarker(open));  // 🆕 close 只寫 key，不帶 attrs！
      const stripped = (typeof tlStripGpMarkers === 'function') ? tlStripGpMarkers(lines.join('\n')) : lines.join('\n');
      const body = stripped.split('\n');
      while (body.length && !body[0].trim()) body.shift();
      while (body.length && !body[body.length - 1].trim()) body.pop();
      if (!body.length) return '';
      return [open].concat(body, [close]).join('\n');
    }
    // 🆕 2026-11-09：用 key + attrs 組裝 open 行（兩端共用）
    function tlBuildGpOpenLine(keyName, fg, bg, anim, alert, railStyle, railA, railB) {
      let s = String(keyName == null ? '' : keyName).trim();
      // mark 可能是完整 '{gpX}'（从编辑视窗输入）或只是 'gpX'
      if (!s.startsWith('{')) s = '{' + s;
      if (!s.endsWith('}')) s = s + '}';
      // 若 keyName 已自带 attrs（含 |），就直接返回
      if (s.indexOf('|') >= 0) return s;
      const parts = [];
      if (fg) parts.push('fg=' + fg);
      if (bg) parts.push('bg=' + bg);
      if (anim) parts.push('anim=' + anim);
      if (alert) parts.push('alert');
      if (railStyle && railA && railB) parts.push('rail=' + railStyle + '#' + railA + '#' + railB);
      if (!parts.length) return s;
      // 在 key 字符串的 '}' 之前插入 attrs
      return s.replace(/\}$/, '|' + parts.join(',') + '}');
    }
    // 🆕 2026-11-09：純 key 提取（從 `{gpE|bg=白}` 或 `gpE` 或 `E` 提取 `E`），供 close 行構造
    function tlKeyFromGpMarker(marker) {
      const s = String(marker == null ? '' : marker).trim();
      if (!s) return '';
      // 已經是純 key（不含花括號、豎線、group/gp 前綴）→ 直接返回
      if (!s.includes('{') && !s.includes('}') && !s.includes('|')) return s;
      // 完整 marker → 用正則提取 key
      const m = s.match(/\{?\s*\/?\s*(?:group|gp)\s*:?\s*([^{}|]*)/i);
      return m ? String(m[1] || '').trim() : s;
    }
    // 🆕 2026-11-09：close 行構造 — 帶 gp/group 前綴 + key，永不帶 attrs！
    function tlBuildGpCloseLine(markerOrKey) {
      let s = String(markerOrKey == null ? '' : markerOrKey).trim();
      if (!s) return '{/gp}';
      if (s.includes('{')) {
        const m = s.match(/\{[ \t]*(\/?)\s*(group|gp)\s*:?\s*([^{}|]*)/i);
        if (m) return '{/' + m[2].toLowerCase() + String(m[3] || '').trim() + '}';
      }
      const prefixM = s.match(/^(gp|group)\s*:?/i);
      if (prefixM) {
        const prefix = prefixM[1].toLowerCase();
        const key = s.slice(prefixM[0].length).trim();
        return '{/' + prefix + key + '}';
      }
      return '{/gp' + s + '}';
    }
    // ── 從 block.fg / block.bg 生成 .md-unit.is-gp 的 inline style（2026-11-09） ──
    //   未設定的屬性 → 回傳空字串，CSS 靠 var 兜底。
    function tlGpInlineStyle(b) {
      const parts = [];
      if (b.fg) parts.push('--gp-fg:' + b.fg);
      if (b.bg) {
        parts.push('--gp-bg:' + b.bg);
        if (b.fg) parts.push('--gp-border:' + b.fg);  // 有字色時邊框跟著字色
      }
      // 🆕 rail 轨道：--gp-rail-style 控制 background-image pattern，--gp-rail-a/b 是双色
      if (b.railStyle) {
        parts.push('--gp-rail-style:' + b.railStyle);
        if (b.railA) parts.push('--gp-rail-a:' + b.railA);
        if (b.railB) parts.push('--gp-rail-b:' + b.railB);
      }
      return parts.length ? ' style="' + parts.join(';') + '"' : '';
    }
    // 🆕 2026-11-14：gp 围栏属性徽标 HTML — TERM（📌 金色）+ ALERT（🔔 红色）
    // 位置：右上角边框线（CSS position:absolute 定位），多个徽标横向堆叠
    function tlGpBadgesHtml(b) {
      const badges = [];
      if (b && b.termName) {
        badges.push('<span class="gp-badge gp-badge-term" title="TERM=' + tlEscapeHtml(b.termName) + '">\u{1F4CC}</span>');
      }
      if (b && b.alert) {
        badges.push('<span class="gp-badge gp-badge-alert" title="ALERT 闹铃">\u{1F514}</span>');
      }
      if (!badges.length) return '';
      return '<span class="gp-badges">' + badges.join('') + '</span>';
    }
    // 顯示層剝掉 {gp} 標記（代碼圍欄內原樣保留，避免吃掉程式碼裡的字面花括號）。
    //   只有真的剝掉標記的那一行才順手清尾隨空白，其餘行完全不動 → 不破壞 Markdown 行尾兩空格換行語義。
    function tlStripGpMarkers(text) {
      let inFence = false;
      return String(text == null ? '' : text).split('\n').map(function (line) {
        if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; return line; }
        if (inFence) return line;
        // 🆕 塊級標記行整行剝成空行（行數不變，底稿原文由對話框讀寫）。
        //    與 tlGpFenceOfLine 同口徑但刻意內聯：顯示層純函式常被單獨抽出載入，不能依賴外部定義。
        if (/^\{[ \t]*\/?[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\}[ \t]*$/i.test(line.trim())) return '';
        const stripped = line.replace(/[ \t]*\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/gi, '');
        return stripped === line ? line : stripped.replace(/[ \t]+$/, '');
      }).join('\n');
    }
    // ── 🆕 group 启用（唯一小事件）：保存时把编辑框里「每一行」行尾标成同一个群标记，
    //    使 tlSplitMdBlocks / view-sticky-rules 的「连续同 key 段」把整块认成一个小事件。
    //  · 与 tlStripGpMarkers 完全对称：代码围栏行与围栏内文原样保留。
    //  · 2026-11-07：既有具名组（{gp:名稱}／{gpABC}）是使用者自訂的分組邊界，**绝不改写**。
    //    旧版一律归一成 {gp}，会让当前群与前后同为 {gp} 的群连成一片（3 群融合成 1 群）。
    //    新口径：已有行尾标记的行原样保留；没有标记的新行补上「本块第一个标记的字面量」；
    //    整块都没有标记才补 {gp}（保留「主动把一般文字改成唯一小事件」的既有行为）。
    //  · 行数不变 → 保存后 tlEditBlockTarget 的 start/end 区间仍然有效。
    //  · 三端同口径：便利贴窗 noteApplyGroupMarkers／LITE calApplyGroupMarkers。
    function tlHasCodeFence(text) {
      return /^\s*(```|~~~)/m.test(String(text == null ? '' : text));
    }
    //  · **纯空白行保持空白**：空白行在 {gp} 规则里是「上一行的延续」，不能被写成内容行，
    //    否则 group 启用保存后空行会变成 '{gp}'，段落间隔就被破坏了（2026-11-06 空白行规则）。
    function tlApplyGroupMarkers(text, on) {
      const lines = String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
      // 🆕 塊級群：邊界本身已經是硬分組，勾選時絕不逐行補行尾標記（會造成雙重分組／破壞原文）；
      //    取消勾選才把兩行標記「置空」（不是刪除 → 行數不變），內容行自然散回各自的小事件。
      const fenceScan = (typeof tlGpFenceScan === 'function') ? tlGpFenceScan(lines) : { ranges: [] };
      if (fenceScan.ranges.length) {
        if (on) return lines.join('\n');
        const out = lines.slice();
        fenceScan.ranges.forEach((r) => { out[r.start] = ''; out[r.end] = ''; });
        return out.join('\n');
      }
      // 本块基准标记：只扫围栏外的行，避免把程式码里的字串当成设定
      let baseMark = '', fence = false;
      for (const line of lines) {
        if (/^\s*(```|~~~)/.test(line)) { fence = !fence; continue; }
        if (fence) continue;
        const m = line.match(/[ \t]*(\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\})(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
        if (m) { baseMark = m[1]; break; }
      }
      let inFence = false;
      return lines.map(function (line) {
        if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; return line; }
        if (inFence) return line;
        if (!line.trim()) return line;
        const stripped = line.replace(/[ \t]*\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/gi, '');
        // 没标记的行原样回传（尤其 on=false）：行尾两空格是 Markdown 换行语义，不能顺手清掉
        const clean = stripped === line ? line : stripped.replace(/[ \t]+$/, '');
        if (!on) return clean;                  // 拆组：沿用既有行为
        if (stripped !== line) return line;     // 已有标记：原样保留（含具名组，绝不归一）
        return clean + (baseMark || '{gp}');    // 新行补齐成同一组
      }).join('\n');
    }
    function tlIsWholeGpBlock(text) {
      const raw = String(text == null ? '' : text).replace(/\r\n/g, '\n');
      // 🆕 塊級群本身已是「唯一小事件」：即使內容含代碼圍欄也照樣預勾（塊級語法不逐行加標記，圍欄安全）
      if (typeof tlGpFenceWrap === 'function' && tlGpFenceWrap(raw)) return true;
      if (tlHasCodeFence(raw)) return false;
      const lines = raw.split('\n');
      let key = null, seen = false;
      for (let i = 0; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const m = lines[i].match(/\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}]*)\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
        if (!m) return false;
        const k = String(m[1] || '').trim();
        if (!seen) { key = k; seen = true; }
        else if (k !== key) return false;
      }
      return seen;
    }
    function tlResolveGroupText(raw, checked, wasOn) {
      // 🆕 2026-11-08：编辑「内容区块」勾选 group 启用 → 一律改写成块级 {gpX}…{/gpX}
      //    （旧的行尾式群会就地升级：剥掉每行行尾标记、沿用原群名包成块级）。
      if (checked) return (typeof tlWrapGpFence === 'function') ? tlWrapGpFence(raw, '') : tlApplyGroupMarkers(raw, true);
      if (wasOn) return tlApplyGroupMarkers(raw, false);   // 原本整组、使用者主动取消 → 拆回多个小事件
      return raw;                                          // 原本不是整组：手写的 {gp} 原样保留
    }
    function tlGroupChecked() {
      const box = document.getElementById('tlGroupEnable');
      return !!(box && box.checked && !box.disabled);
    }
    // ＋☐ 加入 / 编辑 CheckBox 子事件共用：勾选 → 整批逐行补 {gp} + 每个 checkbox 行各补 1 个 cr；
    //   原本整组却取消 → 拆组 + 逐行补 cr；其余走 fallback（完全沿用原本逐行 cr 的写法）。
    function tlGroupMd(rawMd, todayStr, fallback, fenceWrap) {
      const on = tlGroupChecked();
      if (!on && !tlGroupWasOn) return fallback();
      let resolved;
      if (fenceWrap) {
        // 🆕 新增「＋☐ 加入子事件」：整批包成一个块级小事件群
        resolved = (typeof tlWrapGpFence === 'function')
          ? (on ? tlWrapGpFence(rawMd, '') : (tlGroupWasOn ? tlApplyGroupMarkers(rawMd, false) : rawMd))
          : tlResolveGroupText(rawMd, on, tlGroupWasOn);
      } else {
        // 编辑「单个 CheckBox 子事件」：target 只是群内局部行，包块会嵌套 → 沿用旧行尾式
        resolved = on ? tlApplyGroupMarkers(rawMd, true)
          : (tlGroupWasOn ? tlApplyGroupMarkers(rawMd, false) : rawMd);
      }
      if (on) return tlEnsureCrMarkersForCheckboxLines(resolved, todayStr);
      return resolved.split('\n').map(function (l) { return tlEnsureCrMarker(l, todayStr); }).join('\n');
    }
    // 備註渲染：uid 可編輯時依「最小 MD 表達單元」分塊，每塊非 checkbox 類型注入編輯小圓點；
    //   唯讀事件 / uid 為 null（節日 / tooltip）→ 不掛編輯小圓點，但 gp 區塊仍包 .md-unit.is-gp 外框。
    //   🆕 forceEditable：便利贴层对 include(ro) 行程全開（编辑落回來源檔，见 tlSaveIncludedEventNotes），
    //      故便利贴渲染须传 true；行程視圖 / 事件表單維持 ro 唯讀（不顯示編輯小圓點）。
    function tlSeparateGpHorizontalRules(text) {
      let inFence = false;
      const lines = [];
      String(text == null ? '' : text).split('\n').forEach((line) => {
        if (/^\s*(```|~~~)/.test(line)) {
          inFence = !inFence;
          lines.push(line);
          return;
        }
        if (!inFence && /^\s{0,3}-{3,}\s*$/.test(line)) {
          if (lines.length && lines[lines.length - 1].trim()) lines.push('');
          lines.push(line);
          lines.push('');
          return;
        }
        lines.push(line);
      });
      return lines.join('\n');
    }
    function tlRenderNotes(notes, uid, forceEditable, evOverride) {
      if (!notes) return '';
      const raw = String(notes);
      // 🆕 evOverride：调用方手上已有 event 对象时直接传进来，不再回查 tlCalEvents。
      //    ⚠️ 便利贴窗正文走 tlStickyNoteRefs（下方 line ~1255），那时 tlCalEvents 可能尚未刷新/不含该 uid，
      //    回查失败 → event=null → canEdit=false → 整段渲染（没有 .md-unit 区块），
      //    于是「找出相同 → 切换」定位不到非 checkbox 行（2026-10-30 用户回报：只有 checkbox 行会闪）。
      const event = evOverride || (uid ? tlCalEvents.find((x) => x.uid === uid) : null);
      const canEdit = !!(uid && event && (!event.ro || forceEditable));
      if (!canEdit) {
        // 🆕 2026-11-07：唯讀（include / ro）行程也要顯示小事件群外框。
        //   舊版這裡「整段渲染」直接 return，沒走 tlSplitMdBlocks，永遠不會產生 .md-unit.is-gp；
        //   便利貼層傳 forceEditable=true 走分塊，所以同一份內容在便利貼有框、行程視圖沒框。
        //   做法：用「原始底稿」的 gp 區間去切「顯示副本」（已剝 {gp}、已轉 checkbox，行數不變），
        //   只把 type==='gp' 那段包上 .md-unit.is-gp（**不掛編輯小圓點**，維持唯讀），
        //   其餘連續行仍照舊整段渲染；完全沒有 gp 區塊時沿用原本單次 renderMarkdown，零回歸。
        const rawN = raw.replace(/\r\n/g, '\n');
        // 🆕 roDot：唯讀（include 外部檔）行程仍顯示「編輯小圓點」當右鍵入口 →
        //    「跳轉到便利貼」等非編輯功能不會因唯讀而連入口一起消失（2026-11-08 使用者回報）。
        //    只有「有 uid、找得到事件、且 event.ro」才加；節日／tooltip（uid=null 或 event=null）維持無圓點。
        const roDot = !!(uid && event && event.ro && !forceEditable);
        const roOpts = roDot ? { roDot: true } : undefined;
        const display = tlNotesWithChecks(tlStripGpMarkers(rawN), uid, roOpts);
        const renderChunk = (s) => renderMarkdown(tlRenderTermDefs(tlRenderNoteMarkersLines(s)));
        const gpBlocks = tlSplitMdBlocks(rawN).filter((b) => b.type === 'gp');
        if (!gpBlocks.length) return renderChunk(display);
        const dLines = display.replace(/\r\n/g, '\n').split('\n');
        let out = '', cursor = 0;
        gpBlocks.forEach((b) => {
          if (cursor < b.start) out += renderChunk(dLines.slice(cursor, b.start).join('\n'));
          const roBtn = roDot
            ? '<button type="button" class="md-unit-edit" data-ro="1" title="只读 · 右键可用「跳转到便利贴」等定位功能"' +
              ' data-uid="' + tlEscapeHtml(uid) + '" data-start="' + b.start + '" data-end="' + b.end + '" data-type="' + b.type + '"' +
              ' onclick="tlOpenRoDotMenu(event)">\u270e</button>'
            : '';
          out += '<div class="md-unit is-gp"' + (b.anim ? ' data-gp-anim="' + b.anim + '"' : '') + tlGpInlineStyle(b) + '>' + tlGpBadgesHtml(b) + roBtn +
            renderChunk(tlSeparateGpHorizontalRules(dLines.slice(b.start, b.end + 1).join('\n'))) + '</div>';
          cursor = b.end + 1;
        });
        if (cursor < dLines.length) out += renderChunk(dLines.slice(cursor).join('\n'));
        return out;
      }
      const lines = raw.replace(/\r\n/g, '\n').split('\n');
      const blocks = tlSplitMdBlocks(raw);
      const uidAttr = tlEscapeHtml(uid);
      let out = '';
      blocks.forEach((b) => {
        if (b.type === 'task') {
          // checkbox 行：保留既有「行內編輯小圓點」（編輯子事件），不加外層區塊圓點
          out += tlRenderTermDefs(tlTaskLineHtml(lines[b.start], uid, b.start, forceEditable)) + '\n';
          return;
        }
        // 🆕 只剝「顯示副本」的 {gp}；編輯對話框讀的是 ev.notes 原文，標記必須留著才能維持分組
        const chunk = tlStripGpMarkers(lines.slice(b.start, b.end + 1).join('\n'));
        // 🆕 gp 组内的 - [ ] 行必须先转成与一般 checkbox 相同的 .ev-md-check/.ev-cb HTML。
        //    否则 renderMarkdown 会把它们当 GFM 任务清单 → <ul><li> → .body ul li{list-style:disc}
        //    多出一个「.」项目符号，方框也变成浏览器原生灰框（2026-11-06 使用者回报）。
        //    整组只挂外层这一颗圆点 → 组内 plain：不挂行内圆点，但 checkbox 仍可勾选；
        //    baseLine＝b.start 把区块内索引补成整份 notes 的全域行号，供 tlToggleNoteCheck 回写。
        const prepared = (b.type === 'gp')
          ? tlNotesWithChecks(chunk, uid, { plain: true, baseLine: b.start })
          : chunk;
        const gpPrepared = b.type === 'gp' ? tlSeparateGpHorizontalRules(prepared) : prepared;
        const inner = renderMarkdown(tlRenderTermDefs(tlRenderNoteMarkersLines(gpPrepared)));
        // 🆕 小事件群（连续同组 {gp} 行＝一个编辑小圆点区块）：只给 gp 区块挂 is-gp，
        //    由 CSS 画 1px currentColor 外框；task / code / table / para 等其它单元不受影响。
        //    🆕 2026-11-09：gp 区块若有 fg/bg attrs，追加 inline style 覆盖便利贴默认色
        const gpCls = b.type === 'gp' ? ' is-gp' : '';
        const gpStyle = b.type === 'gp' ? tlGpInlineStyle(b) : '';
        // 🆕 2026-11-14：gp 围栏属性徽标（右上角边框线）— TERM + ALERT
        const gpBadges = (b.type === 'gp') ? tlGpBadgesHtml(b) : '';
        // 🆕 2026-11-11：「整行就是一个 [[…]] 标示」的单行单元（闹铃／提醒／收藏／术语／日期标记）
        //   语义上＝一个小事件项目（闹铃还自带排程与完成状态），故便利贴右键菜单给它「📤 搬移项目」。
        //   判定放在渲染期——这里手上有原文；便利贴窗体那颗圆点只读属性，不必为开菜单去回读底稿。
        //   行首允许一个列表／引用符号（`- [[alert:…]]` 这种）；带 {gp} 的行已被上面剥掉标记、
        //   且 tlSplitMdBlocks 会把它们归到 gp 区块，走既有的整群搬移，两者不会重叠。
        const mkOne = (b.start === b.end && /^\s*(?:[-*>]\s+)?\[\[[^\]\n]+\]\]\s*$/.test(chunk)) ? ' data-mk="1"' : '';
        out += '<div class="md-unit' + gpCls + '"' +
          (b.type === 'gp' && b.anim ? ' data-gp-anim="' + b.anim + '"' : '') +
          (b.type === 'gp' && b.railStyle ? ' data-gp-rail="' + b.railStyle + '"' : '') +
          gpStyle + '>' + gpBadges + '<button type="button" class="md-unit-edit" title="' + tlEditUnitTip(b.type) + '"' +
          ' data-uid="' + uidAttr + '" data-start="' + b.start + '" data-end="' + b.end + '" data-type="' + b.type + '"' + mkOne +
          ' onclick="tlOpenEditBlockDialog(event,\'' + uidAttr + '\',' + b.start + ',' + b.end + ',\'' + b.type + '\')">\u270e</button>' +
          inner + '</div>';
      });
      return out;
    }
    // 🆕「最小的 MD 表達單元」切分：回傳 [{start,end,type}]（行索引含頭尾）。
    //   type：gp 分組（連續同名 {gp} 標記行，整段原子，覆蓋其內的 task/list/para 等型態）/ code 代碼圍欄（整塊原子）/
    //   table 表格 / heading 標題 / hr 分隔線 / quote 引用 / task 勾選行（逐行獨立）/ list 列表 / para 段落。
    //   空行僅作分隔，不屬於任何區塊；**例外**：夾在「前後相同 {gp} 行」之間的連續空行，
    //   視為上一行 {gp} 的延續，併入同一個 gp 區塊（不拆成兩個小事件群）。
    //   ⚠️ {gp} 是硬邊界：所有「向前掃描」的 while 遇到帶標記的行就必須停，
    //      否則 para/list/quote/table 會把下一組 {gp} 行吞進來，圓點數就錯了。
    //      代碼圍欄是例外（整塊原子，圍欄內的 {gp} 不解析），故 gp 分支排在 isFence 之後。
    function tlSplitMdBlocks(text) {
      const lines = String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
      const gpKey = (l) => tlGpKeyOfLine(l);
      const isGp = (l) => gpKey(l) !== null;
      const isBlank = (l) => /^\s*$/.test(l);
      const isFence = (l) => /^\s*(```|~~~)/.test(l);
      const isHeading = (l) => /^#{1,6}(\s|$)/.test(l);
      const isHrText = (l) => /^[ \t]{0,3}(-{3,}|\*{3,}|_{3,})[ \t]+(.+?)[ \t]+\1[ \t]*$/.test(l); // 「--- 文字 ---」＝带文字的分割线
      const isHr = (l) => /^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(l) || isHrText(l);
      const isQuote = (l) => /^\s{0,3}>/.test(l);
      const isTask = (l) => /^\s*[-*+]\s+\[[ xX]\]/.test(l);
      const isBullet = (l) => /^\s*[-*+]\s+\S/.test(l); // 必须有非空白内容
      const isOrdered = (l) => /^\s*\d{1,9}[.)]\s+\S/.test(l); // 必须有非空白内容
      const isList = (l) => !isTask(l) && !isFence(l) && (isBullet(l) || isOrdered(l));
      // 空列表项（- / * / + / 1. 后面只有空白）→ 视作分隔符，不归属任何区块
      const isEmptyListItem = (l) => /^\s*[-*+]\s*$/.test(l) || /^\s*\d{1,9}[.)]\s*$/.test(l);
      const isTableRow = (l) => !isBlank(l) && l.includes('|');
      const isTableDelim = (l) => /^[\s|:-]+$/.test(l) && l.includes('-') && l.includes('|');
      const isTableStart = (j) => j + 1 < lines.length && isTableRow(lines[j]) && isTableDelim(lines[j + 1]);
      const blocks = [];
      // 🆕 塊級 {gpX}…{/gpX} 區間索引：開啟行 → { end, fg, bg }（含 attrs，供渲染時透傳）
      const fenceStart = new Map();
      const fenceInfo = (typeof tlGpFenceScan === 'function') ? tlGpFenceScan(lines) : { ranges: [], markers: [] };
      const fenceMarkers = new Set(fenceInfo.markers);
      fenceInfo.ranges.forEach((r) => fenceStart.set(r.start, r));
      let i = 0;
      while (i < lines.length) {
        const line = lines[i];
        if (isBlank(line) || isEmptyListItem(line)) { i++; continue; }
        if (isFence(line)) {
          const marker = line.trim().slice(0, 3);
          let j = i + 1;
          while (j < lines.length && !(isFence(lines[j]) && lines[j].trim().slice(0, 3) === marker)) j++;
          blocks.push({ start: i, end: Math.min(j, lines.length - 1), type: 'code' });
          i = j + 1; continue;
        }
        // 🆕 塊級小事件群：優先於 isGp / task / list / table 等所有分支，整段（含兩行標記）原子化。
        //    標記行在顯示副本裡已被剝成空行，行數不變 → ro 外框與 baseLine 全部照舊。
        if (fenceStart.has(i)) {
          const fe = fenceStart.get(i);
          blocks.push({ start: i, end: fe.end, type: 'gp', fg: fe.fg || '', bg: fe.bg || '', anim: fe.anim || '', alert: fe.alert === true, termName: fe.termName || '', railStyle: fe.railStyle || '', railA: fe.railA || '', railB: fe.railB || '' });
          i = fe.end + 1; continue;
        }
        // 🆕 連續且「group 名相同」的 {gp} 行＝一個小事件（一顆編輯小圓點）；
        //    名稱不同或中間夾了無標記行就斷開，同名但不連續也各自成組。
        //    **例外（2026-11-06）**：純空白行（可多行連續）視為「上一行 {gp} 的延續」——
        //    只有當空白行之後的第一行仍是同 key 的 {gp} 行，才把空白行連同後段併進同一群。
        if (isGp(line)) {
          const key = gpKey(line);
          let j = i + 1;
          // 🆕 塊級標記行是硬邊界：前一個同 key 的行尾群絕對不能把它吞進來，
          //    否則「前群{gpA} / {gpA} … {/gpA} / 後群{gpA}」會整片融合成一個群（2026-11-08）。
          while (j < lines.length && gpKey(lines[j]) === key && !fenceMarkers.has(j)) j++;
          // 反覆延伸，支援「gp 段 / 空行 / gp 段 / 空行 / gp 段」；
          // 空白行納入 [start,end]，baseLine 索引才連續、勾選回寫才不會改錯行。
          while (j < lines.length && isBlank(lines[j])) {
            let k = j;
            while (k < lines.length && isBlank(lines[k])) k++;
            if (k < lines.length && !fenceMarkers.has(k) && gpKey(lines[k]) === key) {
              j = k;
              while (j < lines.length && gpKey(lines[j]) === key && !fenceMarkers.has(j)) j++;
            } else break;
          }
          // 🆕 從行尾式 gp 第一行提取 fg/bg attrs（連續同名行之間 attrs 應一致；若不同，以第一行為準）
          const headAttrs = (typeof tlExtractGpAttrsFromLine === 'function')
            ? tlExtractGpAttrsFromLine(line) : { fg: '', bg: '' };
          blocks.push({ start: i, end: j - 1, type: 'gp', fg: headAttrs.fg || '', bg: headAttrs.bg || '', anim: headAttrs.anim || '', alert: headAttrs.alert === true, railStyle: headAttrs.railStyle || '', railA: headAttrs.railA || '', railB: headAttrs.railB || '' });
          i = j; continue;
        }
        if (isHeading(line)) { blocks.push({ start: i, end: i, type: 'heading' }); i++; continue; }
        if (isHr(line)) { blocks.push({ start: i, end: i, type: 'hr' }); i++; continue; }
        if (isQuote(line)) { let j = i; while (j < lines.length && isQuote(lines[j]) && !isGp(lines[j])) j++; blocks.push({ start: i, end: j - 1, type: 'quote' }); i = j; continue; }
        if (isTableStart(i)) { let j = i + 2; while (j < lines.length && isTableRow(lines[j]) && !isBlank(lines[j]) && !isGp(lines[j])) j++; blocks.push({ start: i, end: j - 1, type: 'table' }); i = j; continue; }
        if (isTask(line)) { blocks.push({ start: i, end: i, type: 'task' }); i++; continue; }
        if (isList(line)) {
          // 普通列表块：允许中间有空行或空列表项（- / * / + / 1. 后无内容），直到遇到非列表、非空行、非空列表项才断开
          let j = i + 1;
          while (j < lines.length) {
            if (isBlank(lines[j]) || isEmptyListItem(lines[j])) {
              // 空行或空列表项：往后看是否有更多列表项，有则继续，无则断开
              let k = j + 1;
              while (k < lines.length && (isBlank(lines[k]) || isEmptyListItem(lines[k]))) k++;
              if (k < lines.length && isList(lines[k]) && !isGp(lines[k])) { j = k; continue; }
              break;
            }
            if (isList(lines[j]) && !isGp(lines[j])) { j++; continue; }
            break;
          }
          blocks.push({ start: i, end: j - 1, type: 'list' });
          i = j; continue;
        }
        { let j = i;
          while (j < lines.length && !isBlank(lines[j]) && !isFence(lines[j]) && !isHeading(lines[j]) && !isHr(lines[j]) &&
                 !isQuote(lines[j]) && !isTask(lines[j]) && !isList(lines[j]) && !isTableStart(j) && !isGp(lines[j])) j++;
          if (j === i) j = i + 1;
          blocks.push({ start: i, end: j - 1, type: 'para' }); i = j; continue;
        }
      }
      return blocks;
    }
    // 備註 checkbox 行內的 建立日 / deadline / completed 標記（顯示層轉換，不改寫源）：
    //   [[cr:...]] → 🆕（建立日）、裸日期與 [[dl:...]] → 📅、[[cp:...]] → ✅（cr 須排在最前，先轉才不會被 dl 規則吃掉）
    // 🆕 2026-11-08：cr / dl / cp（含裸日期）統一渲染成「一顆長徽標」＝圖示＋月-日（小字），
    //   完整的「日期+時間」放在 title（hover tooltip）與 data-date（給 VIEW 排序讀取）。
    //   ⚠️ 只動顯示層，底稿 [[...]] 原文完全不改；畫面不顯示年／時間，排序仍拿得到 date+time。
    function tlDateMarkHtml(kind, full) {
      const meta = { cr: ['\u{1F195}', '建立日'], dl: ['\u{1F4C5}', '预计完成'], cp: ['\u2705', '完成日'] }[kind];
      return '<span class="ev-date-mark ev-date-' + kind + '" title="' + tlEscapeHtml(meta[1] + ' ' + full) +
        '" data-date="' + tlEscapeHtml(full) + '">' + meta[0] + ' <span class="ev-date-mark-md">' +
        tlEscapeHtml(full.slice(5, 10)) + '</span></span>';
    }
    function tlRenderNoteMarkers(text) {
      return String(text)
        .replace(/\[\[cr:(\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?)\]\]/g, (m, d) => tlDateMarkHtml('cr', d))
        .replace(/\[\[(?:dl:)?(\d{4}-\d{2}-\d{2})\]\]/g, (m, d) => tlDateMarkHtml('dl', d))
        .replace(/\[\[cp:(\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?)\]\]/g, (m, d) => tlDateMarkHtml('cp', d));
    }
    // 逐行套用 cr/dl/cp 顯示轉換（跳過代碼圍欄，避免圍欄內 [[]] 被誤轉）；
    //   讓「非 checkbox 行」也能正確渲染 [[cr:…]]→🆕、[[dl:…]]→📅、[[cp:…]]→✅（原只對 checkbox 行生效）
    function tlRenderNoteMarkersLines(text) {
      let inFence = false;
      return String(text).split('\n').map(function (line) {
        if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; return line; }
        if (inFence) return line;
        return tlRenderNoteMarkers(line);
      }).join('\n');
    }
    // 逐「編輯小圓點單元」補 1 個 [[cr:建立日]]（不是每個自然行都加！）；與 checkbox 行 tlEnsureCrMarker 同口徑，
    //   一個單元（tlSplitMdBlocks 的一個 block＝一個編輯小圓點）只補 1 個 cr，已含則不動、dl/cp 前插入。
    function tlEnsureCrMarkerForBlock(blockText, todayStr) {
      if (/\[\[cr:\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/.test(blockText)) return blockText;  // 單元已含 cr：保留原值、不重複補
      const lines = String(blockText).replace(/\r\n/g, '\n').split('\n');
      let last = lines.length - 1;
      while (last >= 0 && !lines[last].trim()) last--;
      if (last < 0) return '[[cr:' + todayStr + ']]';  // 全空單元：直接給建立日標記
      const cr = '[[cr:' + todayStr + ']]';
      const whole = lines[last];
      // 🆕 {gp} 組的最後一行帶分組標記：cr 要插在標記「之前」，讓標記繼續留在行尾、
      //    顯示剝離後也不會留下孤立空格。無標記時 cut＝行尾，行為與原邏輯完全一致。
      const gp = whole.match(/\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
      const cut = (gp && typeof gp.index === 'number') ? gp.index : whole.length;
      const head = whole.slice(0, cut), tail = whole.slice(cut);
      const m = head.match(/\[\[(dl|cp):\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/);
      if (m && typeof m.index === 'number') {
        lines[last] = head.slice(0, m.index).replace(/\s+$/, '') + ' ' + cr + ' ' + head.slice(m.index) + tail;
      } else {
        lines[last] = head.replace(/\s+$/, '') + ' ' + cr + tail;
      }
      return lines.join('\n');
    }
    // 🆕 2026-11-07：只有「可點選完成」的 checkbox 行才需要建立日 —— 逐行各補 1 個 [[cr:…]]，
    //   非 checkbox 行（純文字／標題／表格／程式碼）一律原樣保留；與便利貼窗 ensureCrMarkersForCheckboxLines 同口徑。
    //   單行格式仍交給 tlEnsureCrMarkerForBlock（cr 插在 {gp} 之前、dl/cp 之前、已有 cr 不動）。
    function tlEnsureCrMarkersForCheckboxLines(blockText, todayStr) {
      let inFence = false;
      return String(blockText == null ? '' : blockText).replace(/\r\n/g, '\n').split('\n').map(function (line) {
        if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; return line; }
        if (inFence) return line;
        if (!/^\s*-\s+\[[ xX]\]\s?/.test(line)) return line;   // 非 checkbox：不注入 cr
        return tlEnsureCrMarkerForBlock(line, todayStr);         // 單行＝一個單元，已有 cr 自行短路
      }).join('\n');
    }
    // 整段 notes：按「編輯小圓點單元」逐塊各補 1 個 cr（代碼圍欄 / 表格不注入，避免破壞結構）；供整份事件表單保存時使用
    function tlEnsureCrMarkersForUnits(text, todayStr) {
      const raw = String(text == null ? '' : text).replace(/\r\n/g, '\n');
      const lines = raw.split('\n');
      const blocks = tlSplitMdBlocks(raw);
      if (!blocks.length) return raw;
      let out = '';
      let cursor = 0;
      blocks.forEach((b) => {
        while (cursor < b.start) { out += lines[cursor] + '\n'; cursor++; }
        const blockText = lines.slice(b.start, b.end + 1).join('\n');
        out += ((b.type === 'code' || b.type === 'table') ? blockText : tlEnsureCrMarkersForCheckboxLines(blockText, todayStr)) + '\n';
        cursor = b.end + 1;
      });
      while (cursor < lines.length) { out += lines[cursor] + '\n'; cursor++; }
      return out.replace(/\s+$/, '');
    }
    // 🆕 術語記號解析（單一可信來源：渲染 tlRenderTermDefs 與 Glossary 術語表 tlCollectTerms 共用）：
    //   [[term]] / [[term:釋義]] / [[term:釋義:領域]] / [[term:釋義:領域:發行]]
    //     → { term, def, domain } 或 { term, def, domain, release }（僅有發行時才掛第 4 欄位）
    //   4 段以上：末段＝發行、倒數第二段＝領域、其餘（可含冒號）併回釋義。
    //   1~3 段沿用舊口徑：末段＝領域、之前全為釋義（釋義可含冒號）→ 既有資料零回歸。
    //   ⚠️ 舊「3 段且釋義含冒號」可用末尾空段 [[term:釋義:領域:]] 明確標成 4 段語法。
    //   dl / cp / cr 前綴（日期標記）與裸日期 [[YYYY-MM-DD]] 不屬於術語 → 返回 null（留給 📅/✅ 機制）。
    function tlParseTermToken(inner) {
      const full = String(inner == null ? '' : inner).trim();
      if (!full) return null;
      const firstColon = full.indexOf(':');
      let term, rest;
      if (firstColon === -1) {
        term = full; rest = '';
        if (term === 'dl' || term === 'cp' || term === 'cr') return null;                     // 日期標記名稱
        if (/^\d{4}-\d{2}-\d{2}$/.test(term)) return null;                   // 裸日期 → dl 機制
      } else {
        term = full.slice(0, firstColon).trim();
        rest = full.slice(firstColon + 1);
        if (term === 'dl' || term === 'cp' || term === 'cr') return null;                     // 日期標記（dl:/cp: 後接日期）
      }
      if (!term) return null;
      if (/^remind$/i.test(term)) return null;                               // 提醒標記（remind:Title:Rule），不屬術語
      if (/^bookmark$/i.test(term)) return null;                             // 收藏標記（bookmark:Title:Note），不屬術語
      if (/^alert$/i.test(term)) return null;                                // 鬧鈴標記（alert:內容:下次提醒:間隔:是/否），不屬術語
      // 4 段以上（rest 有 ≥2 個冒號）→ [[term:釋義:領域:發行]]；其餘沿用舊 1~3 段口徑。
      const parts = rest.split(':');
      let def, domain, release = '';
      if (parts.length >= 3) {
        release = parts[parts.length - 1].trim();
        domain = parts[parts.length - 2].trim();
        def = parts.slice(0, -2).join(':').trim();   // 釋義可含冒號 → 原樣併回
      } else {
        const lastColon = rest.lastIndexOf(':');
        def = lastColon === -1 ? rest.trim() : rest.slice(0, lastColon).trim();
        domain = lastColon === -1 ? '' : rest.slice(lastColon + 1).trim();
      }
      const out = { term: term, def: def, domain: domain };
      // ⛔ 無發行時不掛第 4 欄位：既有 tlParseTermToken('Apple:苹果:水果') 深比較斷言零回歸。
      if (release) out.release = release;
      return out;
    }
    // 🆕 全局術語釋義映射（緩存，tlCalEvents 引用變更時自動失效）：
    //   掃描所有事件 title + notes 中的 [[term:釋義]] 記號，彙整每個 term 的全部釋義。
    //   渲染膠囊時查此表，讓未寫釋義的 [[term]] 也能 tooltip 顯示同名術語的釋義。
    let _tlTermDefMap = null;
    let _tlTermDefMapSource = null;
    function tlGetTermDefMap() {
      if (_tlTermDefMap && _tlTermDefMapSource === tlCalEvents) return _tlTermDefMap;
      const map = new Map();
      const scan = (text) => {
        if (!text) return;
        let inFence = false;
        String(text).split('\n').forEach((line) => {
          if (/^\s*```/.test(line)) { inFence = !inFence; return; }
          if (inFence) return;
          String(line).replace(/\[\[([^\]\n]+)\]\]/g, (m, inner) => {
            const t = tlParseTermToken(inner);
            if (t && t.def) {
              const key = t.term.toLowerCase();
              if (!map.has(key)) map.set(key, []);
              const arr = map.get(key);
              if (!arr.includes(t.def)) arr.push(t.def);
            }
            return m;
          });
        });
      };
      (tlCalEvents || []).forEach((ev) => { scan(ev.title); scan(ev.notes); });
      _tlTermDefMap = map;
      _tlTermDefMapSource = tlCalEvents;
      return map;
    }
    // 🆕 鬧鈴徽標：固定模式顯示時間與狀態，循環模式顯示每日／週期／周年時間；間隔放 hover tooltip。
    //   「alert」只是記號名稱、沒有資訊量，不顯示；非標準格式仍以原文顯示。
    //   非標準格式（如 [[alert:買東西]]）仍走 ⏰ 徽標，內容照原樣顯示、不掛時間與狀態膠囊。
    function tlAlertBadgeHtml(inner) {
      const body = String(inner);
      const parsed = body.match(/^alert:([\s\S]*?):((?:\d{4}-\d{2}-\d{2} \d{4})|(?:anniversary\s+\d{4}-\d{2}-\d{2}\s+\d{4})|(?:everyday\s+\d{4})|(?:w[1-7]\s*-\s*w[1-7]\s+\d{4})|(?:w[1-7](?:\s*,\s*w[1-7])+\s+\d{4}))\s*:\s*([1-9]\d*)\s*(m|h|d)(?:\s*:\s*([^\]]*))?$/i);
      const message = (parsed ? parsed[1] : body.slice(body.indexOf(':') + 1)).trim();
      const head = '<span class="tl-alert-ic">⏰</span>' + tlEscapeHtml(message);
      if (!parsed) return '<span class="tl-alert">' + head + '</span>';
      if (!/^\d{4}-\d{2}-\d{2} \d{4}$/.test(parsed[2])) {
        const anniversary = parsed[2].match(/^anniversary\s+\d{4}-(\d{2})-(\d{2})\s+(\d{4})$/i);
        const daily = parsed[2].match(/^everyday\s+(\d{4})$/i);
        const weekdays = parsed[2].match(/^w([1-7])\s*-\s*w([1-7])\s+(\d{4})$/i);
        const weekdayList = parsed[2].match(/^(w[1-7](?:\s*,\s*w[1-7])+) (\d{4})$/i);
        if (!anniversary && !daily && !weekdays && !weekdayList) return '<span class="tl-alert">' + head + '</span>';
        const weekdayNames = '一二三四五六日';
        const time = anniversary ? anniversary[3] : (daily ? daily[1] : (weekdayList ? weekdayList[2] : weekdays[3]));
        const weekdayDisplay = weekdayList
          ? '每周' + weekdayList[1].match(/w[1-7]/gi).map((token) => weekdayNames[Number(token.slice(1)) - 1]).join('、')
          : (weekdays ? '周' + weekdayNames[Number(weekdays[1]) - 1] +
            '至周' + weekdayNames[Number(weekdays[2]) - 1] : '');
        const displayWhen = (anniversary ? '每年 ' + anniversary[1] + '月' + anniversary[2] + '日'
          : (daily ? '每日' : weekdayDisplay)) + ' ' + time.slice(0, 2) + ':' + time.slice(2);
        const tooltip = ['循環提醒 ' + displayWhen,
          '間隔 ' + parsed[3] + ({ m: '分鐘', h: '小時', d: '天' })[parsed[4]]].join(' · ');
        return '<span class="tl-alert" title="' + tlEscapeHtml(tooltip) + '">' + head +
          '<span class="tl-alert-when">' + tlEscapeHtml(displayWhen) + '</span></span>';
      }
      const displayWhen = parsed[2].replace(/^(\d{4}-\d{2}-\d{2} )(\d{2})(\d{2})$/, '$1$2:$3');
      const done = parsed[5] === '是';
      const tooltip = ['下次提醒 ' + displayWhen,
        '間隔 ' + parsed[3] + ({ m: '分鐘', h: '小時', d: '天' })[parsed[4]],
        done ? '已完成' : '未結束'].join(' · ');
      return '<span class="tl-alert' + (done ? ' done' : '') + '" title="' + tlEscapeHtml(tooltip) + '">' + head +
        '<span class="tl-alert-when">' + tlEscapeHtml(displayWhen.slice(5)) + '</span>' +
        '<span class="tl-alert-state">' + (done ? '☑ 已完成' : '☐ 未完成') + '</span></span>';
    }
    // 🆕 術語（term）渲染（立體膠囊＋tooltip 顯示釋義）：
    //   [[term]]                → 立體膠囊（term）＋ 若全局 Glossary 有釋義則 tooltip 顯示
    //   [[term:釋義]]            → 立體膠囊(term) ＋ 釋義以 tooltip 呈現（hover）
    //   [[term:釋義:領域]]       → 立體膠囊(term) ＋ 領域為內嵌小膠囊 ＋ 釋義 tooltip
    //   [[term:釋義:領域:發行]]  → 再加一顆「發行」小膠囊（首發／發布等創作節點）
    //   同名術語的多個釋義以 --- 分隔全部顯示。
    //   逐行處理並跳過代碼圍欄，避免代碼塊內 [[…]] 被誤轉。解析規則見 tlParseTermToken。
    function tlRenderTermDefs(text) {
      const defMap = tlGetTermDefMap();
      let inFence = false;
      return String(text).split('\n').map(function (line) {
        if (/^\s*```/.test(line)) { inFence = !inFence; return line; }
        if (inFence) return line;
        return line.replace(/\[\[([^\]\n]+)\]\]/g, function (m, inner) {
          // 🆕 提醒標記：[[remind:Title:Rule]] → 紅框膠囊（獨立於 term 的金色立體膠囊，便於區分）
          if (/^remind:/i.test(inner)) {
            const body = inner.slice(inner.indexOf(':') + 1).trim();
            const c2 = body.indexOf(':');
            const rTitle = c2 === -1 ? body : body.slice(0, c2).trim();
            const rRule = c2 === -1 ? '' : body.slice(c2 + 1).trim();
            return '<span class="tl-remind"' + (rRule ? ' title="' + tlEscapeHtml(rRule) + '"' : '') + '>' +
              '<span class="tl-remind-ic">🔔</span>' + tlEscapeHtml(rTitle) + '</span>';
          }
          // 🆕 收藏標記：[[bookmark:Title:Note]] → 藍框膠囊（獨立於 term，便於標記收藏項目）
          if (/^bookmark:/i.test(inner)) {
            const body = inner.slice(inner.indexOf(':') + 1).trim();
            const c2 = body.indexOf(':');
            const bTitle = c2 === -1 ? body : body.slice(0, c2).trim();
            const bNote = c2 === -1 ? '' : body.slice(c2 + 1).trim();
            return '<span class="tl-bookmark"' + (bNote ? ' title="' + tlEscapeHtml(bNote) + '"' : '') + '>' +
              '<span class="tl-bookmark-ic"><svg viewBox="0 0 24 24" width="1em" height="1em" focusable="false" aria-hidden="true"><path fill="currentColor" d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg></span>' + tlEscapeHtml(bTitle) + '</span>';
          }
          // 🆕 鬧鈴標記：[[alert:內容:下次提醒:間隔:是/否]] → ⏰ 徽標＋內容原文（排程細節放 title，不顯示「alert」字樣）
          if (/^alert:/i.test(inner)) return tlAlertBadgeHtml(inner);
          const t = tlParseTermToken(inner);
          if (!t) return m;
          const allDefs = [];
          if (t.def) allDefs.push(t.def);
          const globalDefs = defMap.get(t.term.toLowerCase());
          if (globalDefs) globalDefs.forEach((d) => { if (!allDefs.includes(d)) allDefs.push(d); });
          const tooltip = allDefs.join(' --- ');
          const termHtml = '<span class="tl-term-cap"' +
            (tooltip ? ' title="' + tlEscapeHtml(tooltip) + '"' : '') + '>' +
            tlEscapeHtml(t.term) +
            (t.domain ? '<span class="tl-term-domain">' + tlEscapeHtml(t.domain) + '</span>' : '') +
            (t.release ? '<span class="tl-term-release">' + tlEscapeHtml(t.release) + '</span>' : '') +
            '</span>';
          return '<span class="tl-term">' + termHtml + '</span>';
        });
      }).join('\n');
    }
    // 單行 checkbox → 帶編輯小圓點 + 可交互勾選框的 HTML；非 task 行原樣回傳。
    //   i 為「整段 notes 的全域行索引」（保存回寫以此為準）。
    function tlTaskLineHtml(line, uid, i, forceEditable, opts) {
      const m = line.match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
      if (!m) return line;
      const done = m[2] !== ' ';
      const event = uid && tlCalEvents.find((item) => item.uid === uid);
      // 🆕 plain＝gp 组内的 checkbox：整组只有外层一颗编辑圆点，故「不挂行内 ✎」，
      //    但 checkbox 本身与一般 checkbox 完全一样可勾选（2026-11-06 使用者要求 Group 与否同作用）。
      //    外观共用 .ev-md-check/.ev-cb，避免被 renderMarkdown 当成 <ul><li> 多出项目符号。
      //    勾选后 [[cp:今天]] 落在 {gp} 之后；依新位置规则（行尾 [[]] 序列前仍算结构标记）分组不受影响。
      const plain = !!(opts && opts.plain);
      // 🆕 gp 区块传 baseLine＝该区块在整份 notes 的起始行号；勾选回写必须用「全域行号」定位，
      //    否则 tlToggleNoteCheck 会改到别的行。
      const baseLine = (opts && Number.isInteger(opts.baseLine)) ? opts.baseLine : 0;
      const lineNo = baseLine + i;
      // 🆕 roDot：唯讀（include 外部檔）行程也要有「編輯小圓點」當右鍵入口，
      //    讓「跳轉到便利貼／臨時開啟」等非編輯功能仍可用，且 data-line 供 tlCtxUnitOf 精確反推該筆小事件。
      //    ⛔ 左鍵不進編輯（唯讀），改開同一套事件右鍵選單；節日／tooltip（uid=null）不走這條。
      const roDot = !!(opts && opts.roDot);
      const editButton = roDot
        ? '<button type="button" class="ev-md-edit" data-ro="1" title="只读 · 右键可用「跳转到便利贴」等定位功能" data-uid="' + tlEscapeHtml(uid) + '" data-line="' + i + '" onclick="tlOpenRoDotMenu(event)">\u270e</button>'
        : (!plain && uid && event && (!event.ro || forceEditable)
          ? '<button type="button" class="ev-md-edit" title="编辑 checkbox 子事件" data-uid="' + tlEscapeHtml(uid) + '" data-line="' + i + '" onclick="tlOpenEditNoteCheckDialog(event,\'' +
            tlEscapeHtml(uid) + '\',' + i + ')">\u270e</button>'
          : '');
      // 🆕 plain 只代表「共用外层圆点、不挂行内 ✎」；勾选互动与一般 checkbox 完全相同，
      //    data-line／onclick 一律用全域行号 lineNo（gp 区块由 baseLine 补上偏移）。
      const cbAttr = uid
        ? ' class="ev-cb interactive" data-uid="' + tlEscapeHtml(uid) + '" data-line="' + lineNo + '"' +
          ' onclick="tlToggleNoteCheck(event,\'' + tlEscapeHtml(uid) + '\',' + lineNo + ')"' +
          ' onkeydown="tlCalCheckKey(event,\'' + tlEscapeHtml(uid) + '\',' + lineNo + ')"' +
          ' role="checkbox" aria-checked="' + (done ? 'true' : 'false') + '" tabindex="0"'
        : ' class="ev-cb"';
      return m[1] + '<span class="ev-md-check' + (done ? ' done' : '') + '">' +
        editButton +
        '<span' + cbAttr + '>' + (done ? '\u2713' : '') + '</span>' +
        '<span class="ev-md-check-text">' + tlRenderInlineMarkdown(tlRenderNoteMarkers(m[3])) + '</span></span>';
    }
    function tlNotesWithChecks(text, uid, opts) {
      let inFence = false;
      return text.split('\n').map((line, i) => {
        if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; return line; }
        if (inFence) return line;
        // plain 模式靠 opts.baseLine 把局部 i 补成全域行号（勾选回写要定位原文行）；非 plain 时 baseLine=0
        return tlTaskLineHtml(line, uid, i, opts && opts.forceEditable, opts);
      }).join('\n');
    }
    // 🔁 重复事件小图标（## EVENT(REPEAT)）：双箭头环形，随文色（灰），用于月格 chip / 时间网格 / 列表行 / 悬停提示
    function tlRepeatIcon(ev) {
      if (!ev || !ev.repeatMode) return '';
      return '<svg class="ev-repeat-ic" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="\u91cd\u590d"><title>\u91cd\u590d\u4e8b\u4ef6</title><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>';
    }
    function tlSpanChipHtml(ev, pos, idx, total, occDate) {
      // 单日 → 普通 chip（圆点+标题）；跨天 start/middle/end → 连续色条
      const links = tlEventTodoLinks(ev);
      if (pos === 'single') {
        return '<div class="ev-chip' + (ev.done ? ' done' : '') + '" data-uid="' + tlEscapeHtml(ev.uid) + '" data-occ-date="' + tlEscapeHtml(occDate || ev.date) + '" onclick="tlOpenEventFromChip(event,\'' + tlEscapeHtml(ev.uid) + '\')"><span class="dot" style="background:' + tlEscapeHtml(ev.color) + '"></span>' + (ev.done ? '\u2713 ' : '') + tlRepeatIcon(ev) + tlRenderInlineMarkdown(ev.title) + links + '</div>';
      }
      const cls = 'ev-chip span ' + pos + (ev.done ? ' done' : '');
      const dot = '<span class="dot" style="background:' + tlEscapeHtml(ev.color) + '"></span>';
      const titlePart = (ev.done ? '\u2713 ' : '') + tlRepeatIcon(ev) + tlRenderInlineMarkdown(ev.title) + tlSpanSuffix(idx, total) + links;
      // 每一段（start/middle/end）都顯示「標題 k/N」——空色條看不出是哪條行程的延續
      const inner = (pos === 'start' ? dot : '') + titlePart;
      return '<div class="' + cls + '" data-uid="' + tlEscapeHtml(ev.uid) + '" data-occ-date="' + tlEscapeHtml(occDate || ev.date) + '" style="--ev-color:' + tlEscapeHtml(ev.color) + '" onclick="tlOpenEventFromChip(event,\'' + tlEscapeHtml(ev.uid) + '\')">' + inner + '</div>';
    }

    // ===== 标签过滤 / 跨天展开 / 时间网格 辅助 =====
    // 事件是否满足当前标签过滤（空＝全部；OR 逻辑）
    // 🆕 父阶标签 BOM 展开：选中某标签＝匹配「自身＋全部子阶＋孙阶…」的事件（沿 ## TAGS 树向下收集）
    function tlTagDescendants(name) {
      const m = tlTagMeta();
      const out = [name];
      const queue = [name];
      const seen = new Set(queue);
      let guard = 0;
      while (queue.length && guard++ < 1000) {
        const cur = queue.shift();
        Object.keys(m).forEach((k) => { if (m[k] === cur && !seen.has(k)) { seen.add(k); out.push(k); queue.push(k); } });
      }
      return out;
    }
    function tlEventMatchesTag(ev) {
      if (!tlCalTagFilter.length) return true;
      const tags = ev.tags || [];
      return tlCalTagFilter.some((f) => {
        const fam = tlTagDescendants(f);
        return tags.some((tg) => fam.indexOf(tlTagName(tg)) >= 0);
      });
    }
    // 分类显示过滤（顶栏 EVENT / REPEAT 三态勾选）：
    //   EVENT 勾选＝显示普通行程；REPEAT 三态＝none 隐藏全部 / next 只显示未来最近一次 / some 最近前一次+未来4次（最多5次）。
    // ⚠️ 重复行程是否「可见」由 tlEventVisible 决定（none 才隐藏），「显示几次」由 tlEventOccurrences 决定。
    function tlEventVisible(ev) {
      if (ev && ev.repeatMode) return tlCalShowRepeat !== 'none';
      return tlCalShowEvents;
    }
    // 事件是否应显示＝标签过滤 ∩ 分类过滤（所有「按日期分组」入口统一走这里）
    // ⚠️ 「只显示未完成」全模式生效（年/月/周/日/列表）：勾选后隐藏已完成（done ✓）的行程；假日无完成态不受影响
    function tlEventShown(ev) { if (tlCalUndoneOnly && ev && ev.done) return false; return tlEventMatchesTag(ev) && tlEventVisible(ev); }
    // 取某天出现的所有事件（含跨天展开），并套用标签过滤
    function tlEventsOnDay(dateStr) {
      const out = [];
      tlCalEvents.forEach((ev) => {
        if (!tlEventShown(ev)) return;
        tlEventOccurrences(ev).forEach((o) => { if (o.date === dateStr) out.push({ ev: o.ev, pos: o.pos, idx: o.idx, total: o.total }); });
      });
      return out;
    }
    function tlAddDays(d, n) { const r = new Date(d.getFullYear(), d.getMonth(), d.getDate()); r.setDate(r.getDate() + n); return r; }
    function tlWeekDays(d) {
      const cur = new Date(d.getFullYear(), d.getMonth(), d.getDate());
      const dow = (cur.getDay() + 6) % 7; // 周一=0
      cur.setDate(cur.getDate() - dow);
      const out = [];
      for (let i = 0; i < 7; i++) out.push(new Date(cur.getFullYear(), cur.getMonth(), cur.getDate() + i));
      return out;
    }
    // 重叠布局：把时间冲突的事件分配到并排列（移植自 calendar 插件的 layoutDay）
    function tlLayoutDay(evs) {
      const items = evs.map((e) => ({
        e,
        start: tlTimeToMin(e.startTime),
        end: Math.max(tlTimeToMin(e.endTime), tlTimeToMin(e.startTime) + 15),
      })).sort((a, b) => a.start - b.start || a.end - b.end);
      const result = [];
      let cluster = [], clusterEnd = -1;
      const flush = () => {
        if (!cluster.length) return;
        const cols = [];
        cluster.forEach((it) => {
          let placed = false;
          for (let ci = 0; ci < cols.length; ci++) {
            if (cols[ci] <= it.start) { cols[ci] = it.end; it.col = ci; placed = true; break; }
          }
          if (!placed) { it.col = cols.length; cols.push(it.end); }
        });
        cluster.forEach((it) => { it.cols = cols.length; result.push(it); });
        cluster = [];
        clusterEnd = -1;
      };
      items.forEach((it) => {
        if (it.start >= clusterEnd) flush();
        cluster.push(it);
        clusterEnd = Math.max(clusterEnd, it.end);
      });
      flush();
      return result;
    }
    // 事件条上的 🔗 关联标记
    function tlEventTodoLinks(ev) {
      const ids = ev.todoIds || [];
      if (!ids.length) return '';
      return ids.map((id) => {
        const t = (typeof todos !== 'undefined') ? todos.find((x) => x.id === id) : null;
        const name = t ? tlTodoTitle(t) : id;
        return '<span class="ev-link" data-card-id="' + tlEscapeHtml(id) + '" title="\ud83d\udd17 ' + tlEscapeHtml(name) + '" onclick="event.stopPropagation(); if (typeof openCardWindow === \'function\') openCardWindow(this.getAttribute(\'data-card-id\'));">\ud83d\udd17</span>';
      }).join('');
    }
    function tlTodoTitle(t) {
      if (!t) return '';
      const title = t.title || (typeof t.text === 'string' ? t.text.split('\n')[0] : '') || '';
      return (title.trim()) || '(未命名卡片)';
    }
    // 标签过滤条
    function tlRenderTagBar() {
      const bar = document.getElementById('tlEvTagBar');
      const filter = document.getElementById('tlEvTagFilter');
      if (!bar || !filter) return;
      const tags = new Set();
      tlCalEvents.forEach((ev) => (ev.tags || []).forEach((t) => { if (tlTagName(t)) tags.add(tlTagName(t)); }));
      // 🆕 父阶标签（无事件直接挂靠，但是其他标签的父/祖阶）也要显示：并入 ## TAGS 树登记的全部标签
      tlAllTagNames().forEach((t) => tags.add(t));
      const options = document.getElementById('tl-ev-tag-options');
      if (options) options.innerHTML = Array.from(tags).sort().map((t) => '<option value="' + tlEscapeHtml(t) + '"></option>').join('');
      if (!tags.size) { bar.style.display = 'none'; filter.innerHTML = ''; return; }
      bar.style.display = '';
      const tlIsTagInherited = (t) => {
        if (tlCalTagFilter.indexOf(t) >= 0) return false;
        return tlCalTagFilter.some((f) => tlTagDescendants(f).indexOf(t) >= 0);
      };
      filter.innerHTML = Array.from(tags).map((t) => {
        const active = tlCalTagFilter.indexOf(t) >= 0;
        const desc = !active && tlIsTagInherited(t);
        const cls = active ? ' active' : (desc ? ' active-desc' : '');
        return '<span class="ev-tag-chip' + cls + '" data-tag="' + tlEscapeHtml(t) + '">' + tlEscapeHtml(t) + '</span>';
      }).join('');
    }
    function tlFormTagNames() {
      const tags = new Set();
      tlCalEvents.forEach((ev) => (ev.tags || []).forEach((t) => { if (tlTagName(t)) tags.add(tlTagName(t)); }));
      return Array.from(tags).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
    }
    // 子标签（分类）历史：只从「该标签」所属事件的 cat 收集，供内联输入的 datalist 下拉选择
    // （标签与子标签有从属关系：某标签的子分类候选只来自挂了同名标签的事件；tagName 为空 → 空列表）
    function tlFormCatNames(tagName) {
      const cats = new Set();
      if (!tagName) return [];
      tlCalEvents.forEach((ev) => (ev.tags || []).forEach((t) => { if (tlTagName(t) === tagName) { const c = tlTagCat(t); if (c) cats.add(c); } }));
      return Array.from(cats).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
    }
    function tlFormSubcatNames(tagName, cat) {
      const subcats = new Set();
      if (!tagName || !cat) return [];
      tlCalEvents.forEach((ev) => (ev.tags || []).forEach((t) => {
        if (tlTagName(t) === tagName && tlTagCat(t) === cat) {
          const subcat = tlTagSubcat(t);
          if (subcat) subcats.add(subcat);
        }
      }));
      return Array.from(subcats).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
    }
    function tlRenderTagPicker() {
      const picker = document.getElementById('tl-ev-tag-picker');
      const selected = document.getElementById('tl-ev-tag-selected');
      const menu = document.getElementById('tl-ev-tag-menu');
      const input = document.getElementById('tlEvFTags');
      if (!picker || !selected || !menu || !input) return;
      selected.innerHTML = tlEvFormTags.map((t, i) => {
        if (i === tlEvTagEditIndex) {
          const isSubcat = tlEvTagEditLevel === 'subcat';
          const value = isSubcat ? tlTagSubcat(t) : tlTagCat(t);
          const listId = isSubcat ? 'tl-ev-subcat-options' : 'tl-ev-cat-options';
          return '<span class="tl-ev-tag-selected-chip"><input type="text" class="tl-ev-tag-cat-input" data-tl-ev-tag-cat="' + i + '" maxlength="40" value="' + tlEscapeHtml(value) + '" placeholder="' + (isSubcat ? '第3段标签' : '次标签') + '" list="' + listId + '"></span>';
        }
        const name = tlEscapeHtml(tlTagName(t));
        const cat = tlTagCat(t);
        const subcat = tlTagSubcat(t);
        const catHtml = cat ? '<span class="ev-tag-cat" data-tl-ev-tag-subcat-edit="' + i + '" title="点击输入第3段标签">·' + tlEscapeHtml(cat) + '</span>' : '';
        const subcatHtml = subcat ? '<span class="ev-tag-cat" data-tl-ev-tag-subcat-edit="' + i + '" title="点击编辑第3段标签">·' + tlEscapeHtml(subcat) + '</span>' : '';
        return '<span class="tl-ev-tag-selected-chip">' + '<span class="tl-ev-tag-name" data-tl-ev-tag-edit="' + i + '" title="点击输入次标签">' + name + '</span>' + catHtml + subcatHtml + '<button type="button" data-tl-ev-tag-remove="' + tlEscapeHtml(tlTagName(t)) + '" aria-label="删除标签">×</button></span>';
      }).join('');
      // 子标签（分类）历史下拉：原生 datalist，与标签菜单同源（calendar.md 已有事件）
      // ⚠️ 只列当前编辑标签所属的子分类，不混入其他标签的子分类（从属关系）
      let catList = picker.querySelector('#tl-ev-cat-options');
      if (!catList) { catList = document.createElement('datalist'); catList.id = 'tl-ev-cat-options'; picker.appendChild(catList); }
      const editingTag = tlEvTagEditIndex >= 0 ? tlEvFormTags[tlEvTagEditIndex] : null;
      const catNames = tlFormCatNames(editingTag ? tlTagName(editingTag) : null);
      catList.innerHTML = catNames.map((c) => '<option value="' + tlEscapeHtml(c) + '"></option>').join('');
      let subcatList = picker.querySelector('#tl-ev-subcat-options');
      if (!subcatList) { subcatList = document.createElement('datalist'); subcatList.id = 'tl-ev-subcat-options'; picker.appendChild(subcatList); }
      const subcatNames = editingTag ? tlFormSubcatNames(tlTagName(editingTag), tlTagCat(editingTag)) : [];
      subcatList.innerHTML = subcatNames.map((c) => '<option value="' + tlEscapeHtml(c) + '"></option>').join('');
      const query = input.value.trim().toLowerCase();
      const names = tlFormTagNames().filter((t) => !query || t.toLowerCase().includes(query));
      menu.innerHTML = names.length ? names.map((t) => '<button type="button" class="tl-ev-tag-option' + (tlEvFormTags.some((x) => tlTagName(x) === t) ? ' selected' : '') + '" data-tl-ev-tag-option="' + tlEscapeHtml(t) + '">' + (tlEvFormTags.some((x) => tlTagName(x) === t) ? '✓ ' : '') + tlEscapeHtml(t) + '</button>').join('') : '<div class="tl-ev-tag-option">暂无可选标签</div>';
      if (tlEvTagEditIndex >= 0) {
        const ci = selected.querySelector('.tl-ev-tag-cat-input[data-tl-ev-tag-cat="' + tlEvTagEditIndex + '"]');
        if (ci) {
          ci.focus(); ci.select();
          // 有历史分类时自动弹下拉（showPicker 需用户手势；此处由点击标签名触发，正处手势链路内）
          const suggestions = tlEvTagEditLevel === 'subcat' ? subcatNames : catNames;
          try { if (suggestions.length && typeof ci.showPicker === 'function') ci.showPicker(); } catch (err) { /* 无手势等场景忽略，仍可手动点箭头 */ }
          const editIndex = tlEvTagEditIndex;
          const editLevel = tlEvTagEditLevel;
          ci.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); tlCommitTagCat(editIndex, ci.value, editLevel); }
            else if (e.key === 'Escape') { e.preventDefault(); tlEvTagEditIndex = -1; tlRenderTagPicker(); }
          });
          // datalist 选中历史分类后立即提交（change 在 blur 前触发；重复提交无副作用）
          ci.addEventListener('change', () => tlCommitTagCat(editIndex, ci.value, editLevel));
          ci.addEventListener('blur', () => tlCommitTagCat(editIndex, ci.value, editLevel));
        }
      }
    }
    function tlCommitTagCat(i, val, level) {
      if (tlEvFormTags[i]) {
        const value = (val || '').trim();
        if (level === 'subcat') tlEvFormTags[i].subcat = value;
        else {
          if (tlEvFormTags[i].cat !== value) tlEvFormTags[i].subcat = '';
          tlEvFormTags[i].cat = value;
        }
      }
      tlEvTagEditIndex = -1;
      tlRenderTagPicker();
    }
    function tlAddFormTag(value) {
      String(value || '').split(/[,，]/).map((t) => t.trim()).filter(Boolean).forEach((t) => { if (!tlEvFormTags.some((x) => tlTagName(x) === t)) tlEvFormTags.push({ name: t, cat: '', subcat: '' }); });
      document.getElementById('tlEvFTags').value = '';
      tlRenderTagPicker();
    }
    function tlRemoveFormTag(tag) {
      tlEvFormTags = tlEvFormTags.filter((t) => tlTagName(t) !== tag);
      tlRenderTagPicker();
    }
    function tlToggleFormTag(tag) {
      if (tlEvFormTags.some((t) => tlTagName(t) === tag)) tlRemoveFormTag(tag); else tlAddFormTag(tag);
    }
    function tlRenderTagOptions() {
      const options = document.getElementById('tl-ev-tag-options');
      if (!options) return;
      const tags = new Set();
      tlCalEvents.forEach((ev) => (ev.tags || []).forEach((t) => { if (tlTagName(t)) tags.add(tlTagName(t)); }));
      options.innerHTML = Array.from(tags).sort().map((t) => '<option value="' + tlEscapeHtml(t) + '"></option>').join('');
    }
    // ===== 标签右键菜单 + 编辑标签画面（树形父阶）=====
    function tlInjectTagTreeStyle() {
      if (document.getElementById('tl-tag-tree-style')) return;
      const s = document.createElement('style');
      s.id = 'tl-tag-tree-style';
      s.textContent = [
        '.tl-tag-ctx-menu{position:fixed;z-index:9999;min-width:150px;background:var(--ev-card,#1e293b);color:var(--ev-text,#e2e8f0);border:1px solid var(--ev-border,#334155);border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.35);padding:6px;font-size:13px}',
        '.tl-tag-ctx-menu button{display:block;width:100%;text-align:left;background:none;border:0;color:inherit;padding:8px 10px;border-radius:6px;cursor:pointer;font-size:13px}',
        '.tl-tag-ctx-menu button:hover{background:var(--ev-hover,#334155)}',
        '#tlTagEditOverlay{position:fixed;inset:0;z-index:9000;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.45)}',
        '#tlTagEditOverlay .tl-tag-edit-box{background:var(--ev-card,#1e293b);color:var(--ev-text,#e2e8f0);border:1px solid var(--ev-border,#334155);border-radius:14px;box-shadow:0 10px 40px rgba(0,0,0,.45);width:min(440px,92vw);max-height:86vh;overflow:auto;padding:18px 20px}',
        '#tlTagEditOverlay h3{margin:0 0 4px;font-size:16px}',
        '.tl-tag-edit-sec{margin-top:16px}',
        '.tl-tag-edit-sec .lbl{font-size:12px;opacity:.7;margin-bottom:8px}',
        '.tl-tag-children{display:flex;flex-wrap:wrap;gap:8px}',
        '.tl-tag-child{display:inline-flex;align-items:center;gap:6px;background:var(--ev-hover,#334155);border-radius:999px;padding:5px 12px;cursor:pointer;font-size:13px}',
        '.tl-tag-child:hover{outline:1px solid var(--primary,#3b82f6)}',
        '.tl-tag-cat-item{display:inline-flex;align-items:center;background:var(--ev-hover,#334155);border-radius:999px;padding:5px 12px;font-size:13px}',
        '.tl-tag-edit-actions{margin-top:20px;display:flex;justify-content:flex-end;gap:10px}',
        '.tl-tag-edit-actions button{padding:8px 16px;border-radius:8px;border:1px solid var(--ev-border,#334155);background:var(--ev-hover,#334155);color:inherit;cursor:pointer;font-size:13px}',
        '.tl-tag-edit-actions button.primary{background:var(--primary,#3b82f6);color:#fff;border-color:transparent}',
      ].join('');
      document.head.appendChild(s);
    }
    function tlEnsureTagCtxMenu() {
      let menu = document.getElementById('tlTagCtxMenu');
      if (menu) return menu;
      tlInjectTagTreeStyle();
      menu = document.createElement('div');
      menu.id = 'tlTagCtxMenu';
      menu.className = 'tl-tag-ctx-menu';
      menu.style.display = 'none';
      menu.innerHTML = '<button type="button" data-tl-tag-edit="1">✎ 编辑标签属性</button>';
      document.body.appendChild(menu);
      menu.addEventListener('click', (ev) => {
        if (ev.target.getAttribute && ev.target.getAttribute('data-tl-tag-edit')) { menu.style.display = 'none'; tlOpenTagEdit(menu.__tag); }
      });
      document.addEventListener('click', () => { menu.style.display = 'none'; }, true);
      return menu;
    }
    function tlShowTagCtxMenu(name, x, y) {
      const menu = tlEnsureTagCtxMenu();
      menu.__tag = name;
      menu.style.display = 'block';
      const pw = menu.offsetWidth || 160, ph = menu.offsetHeight || 40;
      let left = x, top = y;
      if (left + pw > window.innerWidth - 8) left = window.innerWidth - pw - 8;
      if (top + ph > window.innerHeight - 8) top = window.innerHeight - ph - 8;
      menu.style.left = Math.max(4, left) + 'px';
      menu.style.top = Math.max(4, top) + 'px';
    }
    function tlEnsureTagEditOverlay() {
      let ov = document.getElementById('tlTagEditOverlay');
      if (ov) return ov;
      tlInjectTagTreeStyle();
      ov = document.createElement('div');
      ov.id = 'tlTagEditOverlay';
      document.body.appendChild(ov);
      ov.addEventListener('click', (e) => { if (e.target === ov) ov.style.display = 'none'; });
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && ov.style.display !== 'none') ov.style.display = 'none'; });
      return ov;
    }
    // 编辑标签画面：显示「子标签列表」（以其为父的标签名）＋「分类」（该标签事件的 cat，与表单下拉同源）＋ 可设定「父阶标签」（select，排除自身与后代防成环）
    function tlOpenTagEdit(name) {
      if (!name) return;
      const ov = tlEnsureTagEditOverlay();
      const parent = tlTagParent(name);
      const children = tlTagChildren(name);
      const cats = tlFormCatNames(name);
      const m = tlTagMeta();
      const candidates = tlAllTagNames().filter((t) => t !== name && !tlIsDescendant(t, name, m));
      const opts = ['<option value="">（无／根标签）</option>'].concat(
        candidates.map((t) => '<option value="' + tlEscapeHtml(t) + '"' + (t === parent ? ' selected' : '') + '>' + tlEscapeHtml(t) + '</option>')
      ).join('');
      const childHtml = children.length
        ? '<div class="tl-tag-children">' + children.map((c) => '<span class="tl-tag-child" data-tl-tag-child="' + tlEscapeHtml(c) + '">' + tlEscapeHtml(c) + '</span>').join('') + '</div>'
        : '<div class="lbl">（暂无子标签）</div>';
      // 分类 chip：只读展示（勿用 .tl-tag-child，避免命中「点子标签递归打开」的委托）
      const catHtml = cats.length
        ? '<div class="tl-tag-children">' + cats.map((c) => '<span class="tl-tag-cat-item">' + tlEscapeHtml(c) + '</span>').join('') + '</div>'
        : '<div class="lbl">（暂无分类）</div>';
      ov.innerHTML =
        '<div class="tl-tag-edit-box">' +
          '<h3>编辑标签「' + tlEscapeHtml(name) + '」</h3>' +
          '<div class="tl-tag-edit-sec"><div class="lbl">子标签列表（以其为父的标签）</div>' + childHtml + '</div>' +
          '<div class="tl-tag-edit-sec"><div class="lbl">分类（该标签的子分类）</div>' + catHtml + '</div>' +
          '<div class="tl-tag-edit-sec"><div class="lbl">父阶标签（上级）</div>' +
            '<select id="tlTagParentSel" style="width:100%;padding:8px;border-radius:8px;background:var(--ev-hover,#334155);color:inherit;border:1px solid var(--ev-border,#334155);font-size:13px">' + opts + '</select>' +
          '</div>' +
          '<div class="tl-tag-edit-actions"><button type="button" id="tlTagEditClose">关闭</button></div>' +
        '</div>';
      ov.style.display = 'flex';
      ov.querySelector('#tlTagEditClose').addEventListener('click', () => { ov.style.display = 'none'; });
      ov.querySelector('#tlTagParentSel').addEventListener('change', (e) => {
        const ok = tlSetTagParent(name, e.target.value);
        if (!ok) { showToast('不能将上级设为自身的下级（会造成循环）', 'danger'); e.target.value = parent; return; }
        if (typeof saveTask === 'function') saveTask(false); // 落盤到 calendar.md
        tlRenderTagBar();
        showToast('已更新「' + name + '」的父阶标签', 'success');
      });
      ov.querySelectorAll('.tl-tag-child').forEach((c) => c.addEventListener('click', () => tlOpenTagEdit(c.getAttribute('data-tl-tag-child'))));
    }
    // 标签（过滤条 chip 或 事件/日志卡片上的内联标签 .ev-tag-view）右键 → 弹出菜单（委托监听，覆盖重绘后的新节点）
    document.addEventListener('contextmenu', (e) => {
      const tagEl = e.target.closest('[data-tag]');
      if (!tagEl) return;
      e.preventDefault();
      tlShowTagCtxMenu(tagEl.getAttribute('data-tag'), e.clientX, e.clientY);
    });
    // ========== 📊 事件统计：主事件 × 备注子事件（- [ ]），按标签·完成状态分类 ==========
    // 解析备注中的 Markdown checkbox 行 → 子事件数组 [{text, done}]
    function tlParseNoteChecks(text) {
      const out = [];
      if (!text) return out;
      let inFence = false;
      text.split('\n').forEach((line) => {
        if (/^\s*```/.test(line)) { inFence = !inFence; return; }
        if (inFence) return;
        const m = line.match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
        if (!m) return;
        // 捕获 dl/cp 日期（裸日期视同 dl，与渲染约定一致），供统计明细显示 📅/✅
        const raw = m[3] || '';
        const dlM = raw.match(/\[\[(?:dl:)?(\d{4}-\d{2}-\d{2})\]\]/);
        const cpM = raw.match(/\[\[cp:(\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?)\]\]/);
        const txt = raw
          .replace(/\[\[(?:dl:)?\d{4}-\d{2}-\d{2}\]\]/g, '')
          .replace(/\[\[cp:\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/g, '')
          .replace(/\s{2,}/g, ' ').trim();
        out.push({ text: txt, done: m[2] !== ' ', dl: dlM ? dlM[1] : '', cp: cpM ? cpM[1] : '' });
      });
      return out;
    }
    // 收集统计数据：仅统计 EVENT（tlCalEvents），REPEAT 系列按 1 条主事件计；子事件继承主事件标签
    // filter: { tags: Set<string>|null, status: 'all'|'done'|'undone' }；tags 非空集合才生效（空=不过滤）；status 缺省 'all'
    function tlBuildStats(filter) {
      const fTags = (filter && filter.tags && filter.tags.size) ? filter.tags : null;
      const fStatus = (filter && filter.status) || 'all';
      // 「只显示事件主体」（2026-10-10）：无子事件的事件本身＝主体；有子事件的事件不算主体（由其子事件代表）
      const fMainOnly = !!(filter && filter.mainOnly);
      // 🆕 父阶标签 BOM 展开（2026-10-13）：勾选父阶标签＝匹配「自身＋全部子阶/孙阶…」，
      //    与主程式标签过滤 tlEventMatchesTag()/tlTagDescendants() 完全同逻辑（沿 ## TAGS 树向下收集）
      const fam = new Set();
      if (fTags) fTags.forEach((t) => tlTagDescendants(t).forEach((d) => fam.add(d)));
      const tagMap = new Map();   // tagName -> { mainTotal, mainDone, mainUndone, subTotal, subDone, subUndone, mains:[], subs:[] }
      const ensure = (k) => { if (!tagMap.has(k)) tagMap.set(k, { mainTotal: 0, mainDone: 0, mainUndone: 0, subTotal: 0, subDone: 0, subUndone: 0, mains: [], subs: [] }); return tagMap.get(k); };
      let mainT = 0, mainD = 0, mainU = 0, subT = 0, subD = 0, subU = 0;
      tlCalEvents.forEach((ev) => {
        const tagNames = (ev.tags || []).map((t) => tlTagName(t)).filter(Boolean);
        // 标签过滤：事件须命中至少一个所选标签的 BOM 家族（OR，含子孙标签）；无标签事件仅在选中「(无标签)」时计入
        if (fTags) {
          const hit = tagNames.some((t) => fam.has(t));
          const noTagHit = (tagNames.length === 0 && fTags.has('(无标签)'));
          if (!hit && !noTagHit) return;
        }
        const allSubs = tlParseNoteChecks(ev.notes);
        const matchesMainStatus = fStatus === 'all' || (fStatus === 'done' ? ev.done : !ev.done);
        // mainOnly：有子事件的事件本身不算主体 → 主事件栏（计数＋明细）不计，其子事件照常计入子事件栏
        const countMain = matchesMainStatus && !(fMainOnly && allSubs.length > 0);
        // 完成状态过滤同样作用于子事件（按每条子事件自身 done 过滤，与主事件一致）
        const subs = fStatus === 'all' ? allSubs : allSubs.filter((s) => (fStatus === 'done' ? s.done : !s.done));
        if (!countMain && subs.length === 0) return;
        if (countMain) { mainT++; if (ev.done) mainD++; else mainU++; }
        const subDoneCount = subs.filter((s) => s.done).length;
        subT += subs.length; subD += subDoneCount; subU += (subs.length - subDoneCount);
        // 标签分组（含「无标签」），仅保留所选标签（或其 BOM 子孙标签）分组
        const groups = tagNames.length ? tagNames : ['(无标签)'];
        groups.forEach((g) => {
          if (fTags && !fam.has(g)) return;
          const r = ensure(g);
          if (countMain) { r.mainTotal++; if (ev.done) r.mainDone++; else r.mainUndone++; }
          r.subTotal += subs.length; r.subDone += subDoneCount; r.subUndone += (subs.length - subDoneCount);
          if (countMain) r.mains.push({ title: ev.title, done: !!ev.done, uid: ev.uid, date: ev.date });
          subs.forEach((s) => r.subs.push({ text: s.text, done: s.done, date: ev.date, dl: s.dl, cp: s.cp, uid: ev.uid, ptitle: ev.title }));
        });
      });
      // 合计行：主/子 全局合计已在 mainT/subT；标签行在 tlStatsTableHtml 内排序
      const pct = (d, t) => (t ? Math.round((d / t) * 100) : 0);
      return {
        mainT, mainD, mainU, subT, subD, subU,
        mainRate: pct(mainD, mainT), subRate: pct(subD, subT),
        mainOnly: fMainOnly,
        rows: tagMap, pct, fam,
      };
    }
    function tlStatsSummaryHtml(s) {
      const card = (title, t, d, u, rate) =>
        '<div class="tl-stats-card"><h4>' + title + '</h4>' +
        '<div class="row"><span>总计</span><b>' + t + '</b></div>' +
        '<div class="row"><span>已完成 ✓</span><b>' + d + '</b></div>' +
        '<div class="row"><span>未完成 ☐</span><b>' + u + '</b></div>' +
        '<div class="rate">完成率 ' + rate + '%<div class="bar"><i style="width:' + rate + '%"></i></div></div>' +
        '</div>';
      return '<div class="tl-stats-summary">' +
        card(s.mainOnly ? '主事件（无子事件＝主体）' : '主事件', s.mainT, s.mainD, s.mainU, s.mainRate) +
        card('子事件（备注 - [ ]）', s.subT, s.subD, s.subU, s.subRate) +
        '</div>';
    }
    function tlStatsDetailHtml(group) {
      // 主/子事件同色显示（链接 color:inherit），用「主/子事件」栏位值区分；状态直接显示文字；
      // 首栏「项次」序号；末栏「跳转」＝关闭弹层并滚动到主画面该事件位置（子事件跳到其所属主事件）；
      // 子事件内容悬停 → tooltip 显示所属主事件标题（原生 title）
      let no = 0;
      const row = (kind, date, contentHtml, done, uid, tip, extraCls) => {
        no++;
        // 状态列在内容列之前（2026-10-10 用户要求）；○＝完成、✕＝未完成，悬停 title 保留文字说明
        return '<tr class="' + (done ? 'done ' : '') + (extraCls || '') + '">' +
          '<td class="d-no">' + no + '</td>' +
          '<td class="d-date">' + tlEscapeHtml(date || '') + '</td>' +
          '<td class="d-kind">' + kind + '</td>' +
          '<td class="d-status" title="' + (done ? '完成' : '未完成') + '"><span class="st-ic ' + (done ? 'st-done' : 'st-undone') + '">' + (done ? '\u25CB' : '\u2715') + '</span></td>' +
          '<td class="d-content"' + (tip ? ' data-tip="' + tip + '"' : '') + '>' + contentHtml + '</td>' +
          '<td class="d-jump"><button class="tl-stats-jump" onclick="tlJumpToEvent(\'' + tlEscapeHtml(uid) + '\')">跳转</button></td>' +
        '</tr>';
      };
      const mainRows = group.mains.map((m) => row('主事件', m.date,
        '<a href="javascript:void(0)" onclick="tlOpenEventForm(\'' + tlEscapeHtml(m.uid) + '\')">' + tlRenderInlineMarkdown(m.title) + '</a>',
        m.done, m.uid)).join('');
      // 同一主事件的子事件行打同一「色带」class，切换主事件即交替换色（build 层按事件顺序 push，同 uid 必连续）
      let prevUid = null, band = false;
      const subRows = group.subs.map((x) => {
        if (x.uid !== prevUid) { prevUid = x.uid; band = !band; }
        return row('子事件', x.date,
        tlEscapeHtml(x.text) +
        (x.dl ? ' <span class="d-dl">📅 ' + tlEscapeHtml(x.dl) + '</span>' : '') +
        (x.cp ? ' <span class="d-cp">✅ ' + tlEscapeHtml(x.cp) + '</span>' : ''),
        x.done, x.uid, '主事件：' + tlEscapeHtml(x.ptitle || ''), band ? 'band-a' : 'band-b');
      }).join('');
      return '<table class="tl-stats-detail-table">' +
        '<thead><tr><th>项次</th><th>日期</th><th>主/子事件</th><th>状态</th><th>事件 / 子事件</th><th>跳转</th></tr></thead><tbody>' +
        (mainRows + subRows || '<tr><td colspan="6" class="muted">—</td></tr>') +
        '</tbody></table>';
    }
    // 关闭统计弹层并滚动定位到事件在主画面的渲染位置（子事件＝跳到其所属主事件）
    function tlJumpToEvent(uid) {
      tlCloseStats();
      tlJumpToEventCore(uid);
    }
    // 🆕 Glossary 术语表跳转：与事件统计同款（关弹层 → scrollIntoView 居中 → 金色描边闪 2s）
    function tlGlossJumpToEvent(uid) {
      tlCloseGlossary();
      tlJumpToEventCore(uid);
    }
    // 🆕 2026-11-14：Glossary 跳转到 gp 围栏
    //   · 便利贴路径（ev.sticky > 0）→ focus-sticky-note IPC + focusUnit → 便利贴 webview 内部滚动+闪烁（追加，不 return）
    //   · 主窗口路径 → 事件卡居中 → 精定位 .md-unit-edit[data-start,data-end] → 闪烁（两者都执行）
    async function tlGlossJumpToFence(uid, startLine, endLine) {
      tlCloseGlossary();
      // ① 便利贴路径：sticky>0 的事件 → 唤起便利贴 + 内部定位闪烁
      const ev = (tlCalEvents || []).find((e) => e && e.uid === uid);
      const stickyCount = parseInt(ev && ev.sticky, 10) || 0;
      if (stickyCount > 0) {
        try {
          await window.electronAPI.invoke('focus-sticky-note', {
            key: uid,
            idx: 0,
            focusUnit: { kind: 'block', start: startLine, end: endLine }
          });
        } catch (err) {
          // 便利贴唤起失败不影响主窗口路径继续执行
          console.warn('[Glossary] 便利贴唤起失败：', err && err.message);
        }
      }
      // ② 主窗口路径（始终执行）：事件卡居中 + 金色描边闪 2s
      const cardEl = document.querySelector('[data-uid="' + uid + '"]');
      if (!cardEl || !cardEl.offsetParent) {
        if (stickyCount > 0) { showToast('已切换到便利贴；主窗口当前视图未显示该事件', 'info'); }
        else { showToast('当前视图未显示该事件，请切换到包含它的视图后再试', 'danger'); }
        return;
      }
      cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      cardEl.classList.remove('tl-jump-flash');
      void cardEl.offsetWidth;
      cardEl.classList.add('tl-jump-flash');
      setTimeout(() => cardEl.classList.remove('tl-jump-flash'), 2000);
      // ③ 精定位围栏对应的 .md-unit-edit[data-start,data-end]
      setTimeout(() => {
        const exactBtn = cardEl.querySelector('.md-unit-edit[data-start="' + startLine + '"][data-end="' + endLine + '"]');
        let targetUnit = null;
        if (exactBtn) targetUnit = exactBtn.closest('.md-unit');
        if (!targetUnit) {
          const btns = cardEl.querySelectorAll('.md-unit-edit[data-start][data-end]');
          for (let i = 0; i < btns.length; i++) {
            const s = parseInt(btns[i].getAttribute('data-start'), 10);
            const e = parseInt(btns[i].getAttribute('data-end'), 10);
            if (s <= startLine && e >= endLine) { targetUnit = btns[i].closest('.md-unit'); break; }
          }
        }
        if (targetUnit) {
          targetUnit.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          if (typeof tlBlinkFound === 'function') tlBlinkFound(targetUnit);
          else {
            targetUnit.classList.add('fs-found-blink');
            setTimeout(() => targetUnit.classList.remove('fs-found-blink'), 4200);
          }
        }
      }, 300);
    }
    // 暴露到 window（HTML onclick 用）
    if (typeof window !== 'undefined') {
      window.tlGlossJumpToFence = tlGlossJumpToFence;
    }
    // 跳转核心：定位主画面 [data-uid] 元素 → 平滑滚动居中 → .tl-jump-flash 金色描边闪 2s
    function tlJumpToEventCore(uid) {
      const el = document.querySelector('[data-uid="' + uid + '"]');
      if (!el || !el.offsetParent) { showToast('当前视图未显示该事件，请切换到包含它的视图后再试', 'danger'); return; }
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.remove('tl-jump-flash');
      void el.offsetWidth;  // 强制 reflow 重启动画
      el.classList.add('tl-jump-flash');
      setTimeout(() => el.classList.remove('tl-jump-flash'), 2000);
    }
    // 🆕 滚动定位到某行程的「单一可信来源」：便利贴菜单「滚动」、便利贴编辑窗体关闭后回到该行程共用。
    //    两段式：① 游标／选中日／列表锚点设到该行程日期 → 各模式渲染后自动滚到该日期；
    //            ② 渲染落地后精定位 [data-uid] 事件行（列表／明细）＋金色闪烁；年/月网格无行时退而闪日期格。
    //    返回 true＝已发起滚动；false＝找不到行程或日期（调用方可自行提示，不产生任何卷动副作用）。
    function tlScrollToEventByUid(uid) {
      if (!uid) return false;
      const txt = document.getElementById('taskText');
      let list = [];
      // 以「当前编辑缓冲」重新解析为准：写入编辑内容后 uid 会重新指向已落盘事件，tlCalEvents 可能还是旧快照。
      try { list = (typeof tlAllEvents === 'function' && txt) ? tlAllEvents(txt.value) : []; }
      catch (e) { list = []; }
      if (!Array.isArray(list)) list = [];
      let ev = list.find((x) => x && (x.uid || '') === uid);
      if (!ev && Array.isArray(tlCalEvents)) ev = tlCalEvents.find((x) => x && (x.uid || '') === uid);
      if (!ev) return false;
      const date = (typeof tlEventDisplayDate === 'function') ? tlEventDisplayDate(ev) : (ev.date || '');
      if (!date) return false;
      const d = new Date(date + 'T00:00:00');
      if (!isNaN(d.getTime())) tlCalCursor = d;
      tlCalSelected = date;
      tlListSel = date;
      if (tlCalMode === 'year') tlYearAutoScrollPending = true;
      if (tlCalMode === 'month') tlMonthAutoScrollPending = true;
      if (tlCalMode === 'list') tlListScrollAnchorPending = true;
      else tlDetailListScrollPending = true;
      tlRenderEventsContent();
      setTimeout(function () {
        const row = document.querySelector('[data-uid="' + uid + '"]');
        if (row && row.offsetParent) {
          try { if (typeof tlJumpToEventCore === 'function') tlJumpToEventCore(uid); } catch (e) { /* 高亮失败不影响滚动 */ }
          return;
        }
        const cell = document.querySelector('#tlEvYearGrid .ev-year-day[data-date="' + date + '"], #tlEvMonthGrid .ev-cell[data-date="' + date + '"]');
        if (cell && cell.offsetParent) {
          cell.classList.remove('tl-jump-flash');
          void cell.offsetWidth;  // 强制 reflow 重启动画
          cell.classList.add('tl-jump-flash');
          setTimeout(function () { cell.classList.remove('tl-jump-flash'); }, 2000);
        }
      }, 400);
      return true;
    }
    function tlStatsTableHtml(s) {
      const head = '<thead><tr><th>标签</th><th>主事件<br>总计</th><th>主·完成</th><th>主·未完成</th><th>子事件<br>总计</th><th>子·完成</th><th>子·未完成</th></tr></thead>';
      const fam = s.fam || new Set();
      const tagCell = (name) => {
        if (name === '(无标签)') return '<span class="muted">(无标签)</span>';
        // 🆕 未勾选、但被已勾选父阶标签 BOM 带入的子孙标签：标「↳」并注明继承来源（与主程式标签条 active-desc 同义）
        if (!tlStatsFilter.tags.has(name) && fam.has(name)) {
          const src = tlStatsTagInheritSource(name);
          return '<span class="tl-stats-tag-inherit" title="BOM 继承自父阶标签「' + tlEscapeHtml(src) + '」">↳ ' + tlEscapeHtml(name) + '</span>';
        }
        return tlEscapeHtml(name);
      };
      const body = Array.from(s.rows.entries()).sort((a, b) => a[0].localeCompare(b[0], 'zh-Hans')).map(([name, r]) => {
        const detail = '<tr class="tl-stats-detail"><td class="tl-stats-detail" colspan="7"><details><summary>展开明细</summary>' + tlStatsDetailHtml(r) + '</details></td></tr>';
        return '<tr><td class="tl-stats-tag">' + tagCell(name) + '</td>' +
          '<td>' + r.mainTotal + '</td><td>' + r.mainDone + '</td><td>' + r.mainUndone + '</td>' +
          '<td>' + r.subTotal + '</td><td>' + r.subDone + '</td><td>' + r.subUndone + '</td></tr>' + detail;
      }).join('');
      const total = '<tr class="tl-stats-total"><td class="tl-stats-tag">总计</td>' +
        '<td>' + s.mainT + '</td><td>' + s.mainD + '</td><td>' + s.mainU + '</td>' +
        '<td>' + s.subT + '</td><td>' + s.subD + '</td><td>' + s.subU + '</td></tr>';
      return '<table class="tl-stats-table">' + head + '<tbody>' + body + total + '</tbody></table>';
    }
    let tlStatsFilter = { tags: new Set(), status: 'all', mainOnly: false };  // 默认：全部（mainOnly＝只显示事件主体）
    // 统计可选标签＝事件上用过的标签 ∪ ## TAGS 树登记的全部标签
    // 🆕 父阶标签（无事件直接挂靠，如「工作」）也要显示：与主程式标签过滤条 tlRenderTagBar() 同源合并
    function tlStatsTagOptions() {
      const set = new Set();
      tlCalEvents.forEach((ev) => (ev.tags || []).forEach((t) => { const n = tlTagName(t); if (n) set.add(n); }));
      tlAllTagNames().forEach((t) => set.add(t));
      const arr = Array.from(set).sort((a, b) => a.localeCompare(b, 'zh-Hans'));
      arr.push('(无标签)');
      return arr;
    }
    // 该子孙标签是被哪个「已勾选的（祖）父阶标签」BOM 带入：沿父阶向上找最近的已勾选祖先
    function tlStatsTagInheritSource(name) {
      let cur = tlTagParent(name), guard = 0;
      while (cur && guard++ < 100) {
        if (tlStatsFilter.tags.has(cur)) return cur;
        cur = tlTagParent(cur);
      }
      return '';
    }
    let tlStatsTagBoxBound = false;  // 标签胶囊点击委托是否已绑定（只绑一次：容器 #tlEvStatsFilters 稳定，chips 每次重绘）
    function tlRenderStatsFilters() {
      const box = document.getElementById('tlEvStatsFilters');
      if (!box) return;
      const tags = tlStatsTagOptions();
      // 🆕 勾选父阶标签 → BOM 展开出全部子孙标签；未勾选的子孙标签以「继承」态显示（与主程式标签条 active-desc 一致）
      const fam = new Set();
      tlStatsFilter.tags.forEach((t) => tlTagDescendants(t).forEach((d) => fam.add(d)));
      // 胶囊渲染（2026-10-13 由 checkbox 改为胶囊）：与主程式标签过滤条 .ev-tag-chip 完全同一套类名与三态——
      //   .active＝主动勾选（实心蓝白）／.active-desc＝选父阶后被动带入的子孙（ghost 蓝）／无类＝未选
      const tagChips = tags.map((t) => {
        const checked = tlStatsFilter.tags.has(t);
        const inherit = !checked && fam.has(t);
        const cls = 'ev-tag-chip' + (checked ? ' active' : (inherit ? ' active-desc' : ''));
        if (!inherit) {
          return '<span class="' + cls + '" data-tl-stats-tag="' + tlEscapeHtml(t) + '">' + tlEscapeHtml(t) + '</span>';
        }
        const src = tlStatsTagInheritSource(t);
        return '<span class="' + cls + '" data-tl-stats-tag="' + tlEscapeHtml(t) + '" title="BOM 继承自父阶标签「' + tlEscapeHtml(src) + '」（点选可主动勾选）">' + tlEscapeHtml(t) + '</span>';
      }).join('');
      const st = tlStatsFilter.status;
      const radio = (v, label) => '<label class="tl-stats-status"><input type="radio" name="tlStatsStatus" value="' + v + '"' + (st === v ? ' checked' : '') + '> ' + label + '</label>';
      box.innerHTML =
        '<div class="tl-stats-filter-row"><span class="lbl" title="点选胶囊过滤；点选父阶标签＝自动展开 BOM，纳入其全部子孙标签（与主程式标签过滤条同逻辑）">标签：</span><div class="tl-stats-tag-filters">' + (tagChips || '<span class="muted">（无标签可选）</span>') + '</div></div>' +
        '<div class="tl-stats-filter-row"><span class="lbl">完成状态：</span>' + radio('all', '全部') + radio('done', '已完成') + radio('undone', '未完成') +
        '<label class="tl-stats-status tl-stats-mainonly" title="事件主体：无子事件的事件本身＝主体；有子事件的事件由其子事件代表（主事件本身不计入主事件栏）"><input type="checkbox" data-tl-stats-mainonly="1"' + (tlStatsFilter.mainOnly ? ' checked' : '') + '> 只显示事件主体</label></div>';
      // 标签胶囊点击（事件委托，绑定在稳定容器上只绑一次；与主程式 #tlEvTagFilter 委托同模式）
      if (!tlStatsTagBoxBound) {
        tlStatsTagBoxBound = true;
        box.addEventListener('click', (e) => {
          const chip = e.target.closest ? e.target.closest('[data-tl-stats-tag]') : null;
          if (!chip) return;
          const v = chip.getAttribute('data-tl-stats-tag');
          if (tlStatsFilter.tags.has(v)) tlStatsFilter.tags.delete(v); else tlStatsFilter.tags.add(v);
          tlRenderStatsFilters();  // 重绘胶囊：即时切换主动/被动（继承）态
          tlRenderStatsBody();
        });
      }
      box.querySelectorAll('input[name="tlStatsStatus"]').forEach((rb) => {
        rb.addEventListener('change', () => { if (rb.checked) { tlStatsFilter.status = rb.value; tlRenderStatsBody(); } });
      });
      box.querySelectorAll('input[data-tl-stats-mainonly]').forEach((cb) => {
        cb.addEventListener('change', () => { tlStatsFilter.mainOnly = cb.checked; tlRenderStatsBody(); });
      });
    }
    function tlRenderStatsBody() {
      const body = document.getElementById('tlEvStatsBody');
      if (!body) return;
      const s = tlBuildStats(tlStatsFilter);
      const emptyMsg = (tlCalEvents.length === 0) ? 'calendar.md 中还没有任何行程事件' : '没有符合筛选条件的事件';
      body.innerHTML = (s.mainT || s.subT)
        ? tlStatsSummaryHtml(s) + tlStatsTableHtml(s)
        : '<div class="tl-stats-empty">' + emptyMsg + '</div>';
    }
    function tlOpenStats() {
      const overlay = document.getElementById('tlEvStatsOverlay');
      if (!overlay) return;
      const fileEl = document.getElementById('tlEvStatsFile');
      if (fileEl) fileEl.textContent = tlFileSizeLabel();
      tlRenderStatsFilters();
      tlRenderStatsBody();
      overlay.style.display = 'flex';
    }
    function tlCloseStats() {
      const overlay = document.getElementById('tlEvStatsOverlay');
      if (overlay) overlay.style.display = 'none';
      tlStatsTipHide();
    }
    // 🖱 事件统计：子事件内容悬停 → 浅蓝背景 tooltip（替代深色原生 title）
    let tlStatsTipEl = null;
    function tlStatsTipGet() {
      if (!tlStatsTipEl) {
        tlStatsTipEl = document.createElement('div');
        tlStatsTipEl.className = 'tl-stats-tip';
        tlStatsTipEl.setAttribute('role', 'tooltip');
        tlStatsTipEl.style.display = 'none';
        document.body.appendChild(tlStatsTipEl);
      }
      return tlStatsTipEl;
    }
    function tlStatsTipShow(text, x, y) {
      const tip = tlStatsTipGet();
      tip.textContent = text;
      tip.style.display = 'block';
      const r = tip.getBoundingClientRect();
      let left = x + 14, top = y + 14;
      if (left + r.width > window.innerWidth - 8) left = Math.max(8, x - r.width - 14);
      if (top + r.height > window.innerHeight - 8) top = Math.max(8, y - r.height - 14);
      tip.style.left = left + 'px';
      tip.style.top = top + 'px';
    }
    function tlStatsTipHide() { if (tlStatsTipEl) tlStatsTipEl.style.display = 'none'; }
    // UTF-8 字节长度（纯 JS，无依赖）：用于估算当前加载的 calendar.md 内容大小
    function tlUtf8Len(s) {
      if (!s) return 0;
      let n = 0;
      for (let i = 0; i < s.length; i++) {
        const c = s.charCodeAt(i);
        if (c < 0x80) n += 1;
        else if (c < 0x800) n += 2;
        else if (c >= 0xD800 && c <= 0xDBFF) { n += 4; i++; } // 代理对
        else n += 3;
      }
      return n;
    }
    // 统计弹层表头：展示「calendar.md 文件名 · 内容大小」（大小取当前编辑器缓冲，即正在统计的数据）
    function tlFileSizeLabel() {
      const t = currentFileTarget();
      const fname = (t && t.name) ? t.name : 'calendar.md';
      const ta = document.getElementById('taskText');
      const bytes = tlUtf8Len(ta ? (ta.value || '') : '');
      const sizeStr = bytes.toLocaleString('en-US') + ' Bytes'; // 固定 byte 顯示＋千分位逗號（不走 formatFileSizeShort 的 KB 縮寫）
      return fname + ' · ' + sizeStr;
    }

    // 日 / 周视图 时间网格（移植自 calendar 插件的 buildTimeGrid，使用 ev- 前缀类名）
    function tlRenderTimeGrid(dayDates) {
      const wrap = document.getElementById('tlEvWeekWrap');
      if (!wrap) return;
      // 重複展開視窗：網格首末日 ±7 天，避免 never 無限展開
      const first = dayDates[0], last = dayDates[dayDates.length - 1];
      tlSetRepeatWindow(tlFmtDate(new Date(first.getFullYear(), first.getMonth(), first.getDate() - 7)), tlFmtDate(new Date(last.getFullYear(), last.getMonth(), last.getDate() + 7)));
      const hourH = dayDates.length > 1 ? 48 : 56;
      const n = dayDates.length;
      const todayStr = tlFmtDate(new Date());
      const now = new Date();
      const allDayByCol = dayDates.map((d) => tlEventsOnDay(tlFmtDate(d)).filter((o) => o.ev.allDay));
      const hasAllDay = allDayByCol.some((arr) => arr.length > 0);
      const WD = ['日', '一', '二', '三', '四', '五', '六'];
      let html = '';
      // 🗓 欄位日期標題：讓每一「直行」看得出是哪一天。
      //    ⚠️ 與時間網格共用同一套 grid 模板（52px + repeat(--cols,1fr)）且一樣受 max-width 限制 → 必定對齊
      html += '<div class="ev-tg-head" style="--cols:' + n + '"><div class="ev-tg-head-gutter"></div>';
      dayDates.forEach((d) => {
        const ds = tlFmtDate(d);
        const dm = String(ds).match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
        const label = dm ? (+dm[2]) + '/' + (+dm[3]) : ds;
        // 📕 当天有日记 → 日期旁挂标记（与月格共用 tlDiaryMarkHtml）。
        // ⚠️ 必须放在 .dnum **内部**：.dnum 是 display:block，作为兄弟节点会另起一行 → 整行表头被顶高
        html += '<div class="ev-tg-head-cell' + (ds === todayStr ? ' today' : '') + (ds === tlCalSelected ? ' selected' : '') + '" data-date="' + ds + '" onclick="tlSelectWeekDay(\'' + ds + '\')">' +
          '<span class="dow">週' + WD[d.getDay()] + '</span><span class="dnum">' + label + tlDiaryMarkHtml(ds) + '</span></div>';
      });
      html += '</div>';
      if (hasAllDay) {
        html += '<div class="ev-allday-strip" style="--cols:' + n + '"><div class="label">全天</div>';
        allDayByCol.forEach((arr, ci) => {
          html += '<div class="ev-allday-col" data-date="' + tlFmtDate(dayDates[ci]) + '">';
          arr.forEach((o) => {
            const ev = o.ev;
            html += '<div class="ev-block all-day' + (ev.done ? ' done' : '') + '" data-uid="' + tlEscapeHtml(ev.uid) + '" data-occ-date="' + tlEscapeHtml(tlFmtDate(dayDates[ci])) + '" onclick="tlOpenEventForm(\'' + tlEscapeHtml(ev.uid) + '\')" style="--ev-color:' + tlEscapeHtml(ev.color || TL_CAL_COLORS[0]) + '">' +
              (ev.done ? '\u2713 ' : '') + tlRepeatIcon(ev) + tlRenderInlineMarkdown(ev.title) + tlSpanSuffix(o.idx, o.total) + tlEventTodoLinks(ev) + '</div>';
          });
          html += '</div>';
        });
        html += '</div>';
      }
      // ## HOLIDAY：日/週时间网格顶部「假期」条（与 EVENT 全天条视觉区隔：type 色块）
      const holByCol = dayDates.map((d) => tlHolidaysOnDay(tlFmtDate(d)));
      const hasHoliday = holByCol.some((arr) => arr.length > 0);
      if (hasHoliday) {
        html += '<div class="ev-holiday-strip" style="--cols:' + n + '"><div class="label">假期</div>';
        holByCol.forEach((arr, ci) => {
          html += '<div class="ev-holiday-col" data-date="' + tlFmtDate(dayDates[ci]) + '">';
          arr.forEach((h) => {
            const region = tlHolidayRegionMeta(h.region);
            // 跨天假日：与行程同款「(第几天/共几天)」，一天一格（ci＝所属列＝出现日）
            html += '<div class="ev-holiday-block" style="--holiday-color:' + tlEscapeHtml(region.color) + '" title="' + tlEscapeHtml(h.title) + '">' + region.icon + ' ' + tlRenderInlineMarkdown(h.title) + tlSpanDaySuffix(h, tlFmtDate(dayDates[ci])) + '</div>';
          });
          html += '</div>';
        });
        html += '</div>';
      }
      html += '<div class="ev-timegrid-scroll"><div class="ev-timegrid" style="--cols:' + n + ';--hour-h:' + hourH + 'px;">';
      html += '<div class="ev-tg-gutter">';
      for (let h = 0; h <= 23; h++) html += '<div class="ev-tg-hour-label" style="top:' + (h * hourH) + 'px">' + String(h).padStart(2, '0') + ':00</div>';
      html += '</div>';
      dayDates.forEach((d) => {
        html += '<div class="ev-tg-col" data-date="' + tlFmtDate(d) + '">';
        for (let h = 0; h <= 23; h++) html += '<div class="ev-tg-hour-line" style="top:' + (h * hourH) + 'px"></div>';
        const timed = tlLayoutDay(tlEventsOnDay(tlFmtDate(d)).filter((o) => !o.ev.allDay).map((o) => o.ev));
        timed.forEach(({ e, start, end, col, cols }) => {
          const top = start / 60 * hourH;
          const height = Math.max((end - start) / 60 * hourH, 18);
          const width = 100 / cols;
          const left = col * width;
          const cbg = e.color || TL_CAL_COLORS[0];
          // 時間範圍：有開始時間才顯示
          const tm = (e.allDay || !e.startTime) ? '' : (e.startTime + (e.endTime ? '–' + e.endTime : ''));
          // 備註：只有方塊夠高（日模式下 >=64px，約標題+時間+地點+兩行備註）才顯示，
          //       用 -webkit-line-clamp 限行數，超出仍由 .ev-block 的 overflow:hidden 裁掉
          const notes = (!e.allDay && height >= 64 && e.notes) ? String(e.notes).slice(0, 400) : '';
          html += '<div class="ev-block' + (e.done ? ' done' : '') + '" data-uid="' + tlEscapeHtml(e.uid) + '" data-occ-date="' + tlEscapeHtml(tlFmtDate(d)) + '" onclick="tlOpenEventForm(\'' + tlEscapeHtml(e.uid) + '\')" style="top:' + top + 'px;height:' + height + 'px;left:calc(' + left + '% + 1px);width:calc(' + width + '% - 3px);--ev-color:' + tlEscapeHtml(cbg) + '">' +
            // 跨天定时行程：该列即「出现日」，标题后标 (第几天/共几天)
            '<div class="t">' + (e.done ? '\u2713 ' : '') + tlRepeatIcon(e) + tlRenderInlineMarkdown(e.title) + tlSpanDaySuffix(e, tlFmtDate(d)) + tlEventTodoLinks(e) + '</div>' +
            (tm ? '<div class="tm">' + tlEscapeHtml(tm) + '</div>' : '') +
            (e.location ? '<div class="loc">' + tlEscapeHtml('\ud83d\udccd ' + e.location) + '</div>' : '') +
            (notes ? '<div class="notes">' + tlRenderNotes(notes, e.uid) + '</div>' : '') +
            '</div>';
        });
        html += '</div>';
      });
      dayDates.forEach((d) => {
        if (tlFmtDate(d) === todayStr) {
          const mins = now.getHours() * 60 + now.getMinutes();
          const top = mins / 60 * hourH;
          html += '<div class="ev-tg-now-line" style="top:' + top + 'px" data-date="' + tlFmtDate(d) + '"></div>';
        }
      });
      html += '</div></div>';
      // 上下可拖动分割：时间网格（.ev-split-top）自动占余量，行程明细（.ev-detail）高度由 --ev-detail-h 决定
      wrap.innerHTML = '<div class="ev-timegrid-col ev-split-top">' + html + '</div>' +
        '<div class="ev-hsplit" id="tlEvWeekSplit" title="拖动调整下方行程明细高度（双击复位）"></div>' +
        '<div id="tlEvDayGridList" class="events-list ev-detail"></div>';
      tlBindSplit(wrap, document.getElementById('tlEvWeekSplit'));
      tlRenderDayGridList();
      requestAnimationFrame(() => {
        const sc = wrap.querySelector('.ev-timegrid-scroll');
        if (sc) sc.scrollTop = Math.max(0, now.getHours() * hourH + now.getMinutes() - 120);
      });
    }
    // 日/週时间网格下方明细：日模式显示游标那天、週模式显示当周每天（仅含内容者），
    // 与列表模式一致——每天先假日（.ev-holiday）后行程（.ev-item），保证假日必定可见。
    // 日/週网格下方明细「所顯示的那一天」：日模式＝游标当天；週模式＝选定日（须在当週内），否则今天（若在当週）否则週一
    function tlGridSelectedDay() {
      if (tlCalMode === 'day') return tlFmtDate(tlCalCursor);
      const week = tlWeekDays(tlCalCursor).map(tlFmtDate);
      const today = tlFmtDate(new Date());
      return (tlCalSelected && week.indexOf(tlCalSelected) >= 0) ? tlCalSelected
           : (week.indexOf(today) >= 0 ? today : week[0]);
    }
    function tlRenderDayGridList() {
      const list = document.getElementById('tlEvDayGridList');
      if (!list) return;
      const prevScrollTop = list.scrollTop; // 渲染前记录（确定性还原依据，不依赖缓存）
      const isDay = tlCalMode === 'day';
      const today = tlFmtDate(new Date());
      // 重複展開視窗：整週＝網格首末 ±7 天；單日＝選定日當天
      let rwFrom, rwTo;
      if (tlCalScope === 'full' && !isDay) {
        const wk = tlWeekDays(tlCalCursor);
        rwFrom = tlFmtDate(new Date(wk[0].getFullYear(), wk[0].getMonth(), wk[0].getDate() - 7));
        rwTo = tlFmtDate(new Date(wk[6].getFullYear(), wk[6].getMonth(), wk[6].getDate() + 7));
      } else {
        const ds = tlGridSelectedDay();
        rwFrom = rwTo = ds;
      }
      tlSetRepeatWindow(rwFrom, rwTo);
      const toggle = tlScopeToggleHtml();
      let html = '';
      // 整週（週模式切到「週」）：遍历当周 7 天，跳过无内容日（与列表模式一致）
      if (tlCalScope === 'full' && !isDay) {
        let any = false;
        const sel = tlGridSelectedDay();
        for (const d of tlWeekDays(tlCalCursor)) {
          const ds = tlFmtDate(d);
          const dayItems = tlDayItems(ds);
          const evs = tlSorted(dayItems.events);
          const hols = dayItems.holidays;
          if (!evs.length && !hols.length) continue;
          // toggle 内联进每个日期标题条，随 sticky 一直可见（无需滚回週首）
          let g = tlDateHeader(ds, today, toggle, evs.length + hols.length);
          any = true;
          for (const h of hols) g += tlHolidayHtml(h, today, ds);
          for (const ev of evs) g += tlItemHtml(ev, today, ds);
          html += (ds === sel) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
        }
        if (!any) html += '<div class="ev-scope-row">' + toggle + '</div><div class="ev-empty">本周没有行程</div>';
        list.innerHTML = html;
        list.classList.add('scope-follow');
        tlBindActiveDateScroll(list);
        // 明细滚动策略（2026-09-30-v2）：仅显式导航才滚；编辑存档/过滤/搜索/切范围均不自动滚动
        if (tlDetailListScrollPending) { tlDetailListScrollPending = false; tlScrollListToDate(list, list, tlGridSelectedDay()); }
        else { list.scrollTop = prevScrollTop; }
        tlUpdateActiveDate(list);
        tlAfterCalRender();
        return;
      }
      // 单日（默认）：週模式=「选定日」、日模式=游标当天；空日也显示日期标题 + 空提示
      const ds = tlGridSelectedDay();
      const dayItems = tlDayItems(ds);
      const evs = tlSorted(dayItems.events);
      const hols = dayItems.holidays;
      html += tlDateHeader(ds, today, toggle, evs.length + hols.length);
      if (!evs.length && !hols.length) {
        html += '<div class="ev-empty">这一天没有行程</div>';
      } else {
        for (const h of hols) html += tlHolidayHtml(h, today, ds);
        for (const ev of evs) html += tlItemHtml(ev, today, ds);
      }
      list.innerHTML = html;
      list.classList.remove('scope-follow');
      // 日/週单日明细：仅显式导航才滚到该日日期条；否则恢复渲染前位置
      if (tlDetailListScrollPending) { tlDetailListScrollPending = false; tlScrollListToDate(list, list, ds); }
      else { list.scrollTop = prevScrollTop; }
      tlAfterCalRender();
    }
    // 日/週视图：点日期标题切换「下方明细」显示的那一天（与月模式「选中日」、日模式「游标日」一致，均只显示单日）
    function tlSelectWeekDay(ds) {
      tlCalSelected = ds;
      tlDetailListScrollPending = true; // 显式点选日期：明细滚到该日
      if (tlCalMode === 'week') tlRenderTimeGrid(tlWeekDays(tlCalCursor));
      else if (tlCalMode === 'day') tlRenderTimeGrid([tlCalCursor]);
    }
    // 明细范围切换（日 <-> 月/週）：月模式切「整月」、週模式切「整週」；日模式无意义不显示。默认「日」。
    function tlScopeToggleHtml() {
      if (tlCalMode !== 'month' && tlCalMode !== 'week' && tlCalMode !== 'year') return '';
      const isFull = tlCalScope === 'full';
      const fullLabel = tlCalMode === 'week' ? '週' : (tlCalMode === 'year' ? '年' : '月');
      return '<span class="ev-scope-seg" role="group" title="切换下方明细显示范围">' +
        '<button type="button" class="' + (!isFull ? 'active' : '') + '" onclick="tlSetCalScope(\'day\')">日</button>' +
        '<button type="button" class="' + (isFull ? 'active' : '') + '" onclick="tlSetCalScope(\'full\')">' + fullLabel + '</button>' +
        '</span>';
    }
    function tlSetCalScope(s) {
      tlCalScope = (s === 'full') ? 'full' : 'day';
      if (tlCalMode === 'month') tlRenderMonth(document.getElementById('taskText').value);
      else if (tlCalMode === 'week') tlRenderTimeGrid(tlWeekDays(tlCalCursor));
      else if (tlCalMode === 'day') tlRenderTimeGrid([tlCalCursor]);
      else if (tlCalMode === 'year') tlRenderYear(document.getElementById('taskText').value);
    }
    // 行程条 / 月格点击打开表单（阻止冒泡到单元格选择）
    function tlOpenEventFromChip(e, uid) { if (e) e.stopPropagation(); tlOpenEventForm(uid); }

    // 表单内「关联 Todo 卡片」面板
    function tlRenderEvTodoLinkPanel() {
      const panel = document.getElementById('tlEvTodoLinkPanel');
      if (!panel) return;
      if (!tlEvFormTodoIds.length) {
        const has = (typeof todos !== 'undefined') && todos.length;
        panel.innerHTML = '<div class="ev-todo-placeholder">' + (has ? '点此或按 ? 选择要关联的卡片' : '暂无 Todo 卡片') + '</div>';
        return;
      }
      panel.innerHTML = tlEvFormTodoIds.map((id) => {
        const t = (typeof todos !== 'undefined') ? todos.find((x) => x.id === id) : null;
        const name = t ? tlTodoTitle(t) : id;
        return '<span class="ev-todo-chip" data-id="' + tlEscapeHtml(id) + '" title="' + tlEscapeHtml(name) + '"><span class="ev-todo-chip-name" data-id="' + tlEscapeHtml(id) + '">' + tlRenderInlineMarkdown(name) + '</span><span class="ev-todo-chip-x" data-id="' + tlEscapeHtml(id) + '" title="移除">✕</span></span>';
      }).join('');
    }
    function tlRenderEvTodoDropdown() {
      const dd = document.getElementById('tlEvTodoDropdown');
      if (!dd) return;
      const candidates = ((typeof todos !== 'undefined') ? todos : []).filter((t) => tlEvFormTodoIds.indexOf(t.id) < 0);
      if (!candidates.length) { dd.innerHTML = '<div class="ev-todo-dropdown-empty">已无更多卡片可选</div>'; return; }
      dd.innerHTML = candidates.map((t) => '<div class="ev-todo-dropdown-item" data-id="' + tlEscapeHtml(t.id) + '">' + tlRenderInlineMarkdown(tlTodoTitle(t)) + '</div>').join('');
    }
    function tlEvToggleTodoDropdown() {
      const dd = document.getElementById('tlEvTodoDropdown');
      if (!dd) return;
      if (dd.classList.contains('show')) { dd.classList.remove('show'); return; }
      if (!(typeof todos !== 'undefined') || !todos.length) return;
      tlRenderEvTodoDropdown();
      dd.classList.add('show');
    }
    function tlEvAddTodoLink(id) {
      if (!id || tlEvFormTodoIds.indexOf(id) >= 0) return;
      tlEvFormTodoIds.push(id);
      tlRenderEvTodoLinkPanel();
      const left = ((typeof todos !== 'undefined') ? todos : []).filter((t) => tlEvFormTodoIds.indexOf(t.id) < 0);
      if (left.length) tlRenderEvTodoDropdown();
      else { const dd = document.getElementById('tlEvTodoDropdown'); if (dd) dd.classList.remove('show'); }
    }
    function tlEvRemoveTodoLink(id) {
      const i = tlEvFormTodoIds.indexOf(id);
      if (i >= 0) tlEvFormTodoIds.splice(i, 1);
      tlRenderEvTodoLinkPanel();
      const dd = document.getElementById('tlEvTodoDropdown');
      if (dd && dd.classList.contains('show')) tlRenderEvTodoDropdown();
    }

    // ===== 渲染 =====
    function tlRenderEventsContent() {
      if (!calEventsView) return;
      const mode = tlCalMode;
      const isMonth = mode === 'month';
      const isWeek = mode === 'week';
      const isDay = mode === 'day';
      const isYear = mode === 'year';
      const isGrid = isWeek || isDay; // 日/周共用时间网格
      const setDisp = (id, v) => { const el = document.getElementById(id); if (el) el.style.display = v; };
      const isList = mode === 'list';
      setDisp('tlEvMonthNav', (isMonth || isGrid || isList || isYear) ? '' : 'none');
      setDisp('tlEvMonthWrap', isMonth ? '' : 'none');
      setDisp('tlEvWeekWrap', isGrid ? '' : 'none');
      setDisp('tlEvList', mode === 'list' ? '' : 'none');
      setDisp('tlEvYearWrap', isYear ? '' : 'none');
      setDisp('tlEvDayGridList', isGrid ? '' : 'none');   // 日/週时间网格下方的「当日/当周明细」列表（含假日）
      // 「跨天一笔 / 跨天多笔」切换：只在列表模式出现（月/週/日不显示，也不受其影响）
      setDisp('tlEvMultiDayBtn', isList ? '' : 'none');
      if (isList) tlUpdateMultiDayBtn();
      const lb = document.getElementById('tlEvModeList'); if (lb) lb.classList.toggle('active', mode === 'list');
      const db = document.getElementById('tlEvModeDay'); if (db) db.classList.toggle('active', isDay);
      const wb = document.getElementById('tlEvModeWeek'); if (wb) wb.classList.toggle('active', isWeek);
      const mb = document.getElementById('tlEvModeMonth'); if (mb) mb.classList.toggle('active', isMonth);
      const yb = document.getElementById('tlEvModeYear'); if (yb) yb.classList.toggle('active', isYear);
      const content = document.getElementById('taskText').value;
      tlCalEvents = tlAllEvents(content);
      tlCalHolidays = tlAllHolidays(content);
      tlCalDiaries = tlAllDiaries(content);
      tlRenderTagBar();
      tlRenderHolidayLegend(); // 动态图例：列出 calendar.md 中出现过的地区，辅助「目视差别」
      tlCursorTitle(); // ⚠️ 導航列標題每種模式都要更新（周模式尤其會跨月，不能殘留上次的「X年X月」）
      if (isMonth) tlRenderMonth(content);
      else if (isYear) tlRenderYear(content);
      else if (isGrid) tlRenderTimeGrid(isDay ? [tlCalCursor] : tlWeekDays(tlCalCursor));
      else tlRenderList(content);
    }

    // 導航列標題：依模式顯示「月 / 週區間 / 單日」（與 LITE 版 calCursorTitle 同款）
    function tlCursorTitle() {
      const t = document.getElementById('tlEvMonthTitle');
      if (!t) return;
      const WD = ['日', '一', '二', '三', '四', '五', '六'];
      if (tlCalMode === 'day') {
        const d = tlCalCursor;
        t.textContent = d.getFullYear() + '年' + (d.getMonth() + 1) + '月' + d.getDate() + '日 週' + WD[d.getDay()];
      } else if (tlCalMode === 'week') {
        const ds = tlWeekDays(tlCalCursor);
        const y0 = ds[0].getFullYear(), y1 = ds[6].getFullYear();
        // 週區間：起始帶年；跨年時結尾也補年，避免「12/29 – 1/4」看不出年份
        t.textContent = y0 + '/' + (ds[0].getMonth() + 1) + '/' + ds[0].getDate() + ' – ' + (y1 === y0 ? '' : y1 + '/') + (ds[6].getMonth() + 1) + '/' + ds[6].getDate();
      } else if (tlCalMode === 'year') {
        t.textContent = tlCalCursor.getFullYear() + '年';
      } else if (tlCalMode === 'list') {
        t.textContent = '';
      } else {
        t.textContent = tlCalCursor.getFullYear() + '年' + (tlCalCursor.getMonth() + 1) + '月';
      }
    }

    // 🔁 重复规则「说人话」：把 ## EVENT(REPEAT) 的字段翻成一句可读文字（顶栏「重复事件一览」面板用）
    const TL_REPEAT_MODE_LABEL = { daily: '每天', weekly: '每周', monthly: '每月', yearly: '每年' };
    const TL_WD_LABEL = { sun: '日', mon: '一', tue: '二', wed: '三', thu: '四', fri: '五', sat: '六' };
    function tlRepeatRuleText(ev) {
      const mode = ev.repeatMode || '';
      if (!mode) return '';
      const interval = Math.max(1, parseInt(ev.repeatInterval, 10) || 1);
      const unit = { daily: '天', weekly: '周', monthly: '月', yearly: '年' }[mode] || '';
      let s = interval > 1 ? ('每 ' + interval + ' ' + unit) : (TL_REPEAT_MODE_LABEL[mode] || mode);
      if (mode === 'weekly') {
        // 未显式指定星期时按「起始日的星期」回退，与展开引擎 tlExpandRepeats 口径一致
        let wds = ev.repeatWeekDay || [];
        if (!wds.length && ev.date) { const d = new Date(ev.date + 'T00:00:00'); if (!isNaN(d)) wds = [TL_WD[d.getDay()]]; }
        if (wds.length) s += '（' + wds.map((w) => TL_WD_LABEL[w] || w).join('、') + '）';
      } else if (mode === 'monthly' && ev.repeatMonthDay) {
        s += ' 第 ' + (parseInt(ev.repeatMonthDay, 10) || ev.repeatMonthDay) + ' 日';
      } else if (mode === 'yearly' && ev.repeatYearMonthDay) {
        s += ' ' + String(ev.repeatYearMonthDay).replace(/^"|"$/g, '');
      }
      return s;
    }
    function tlRepeatEndText(ev) {
      const t = ev.repeatEndType || 'never';
      if (t === 'count') return '共 ' + (ev.repeatEndValue || '?') + ' 次';
      if (t === 'date') return '至 ' + (ev.repeatEndValue || '?');
      return '永不结束';
    }
    // 一览按钮图标（截图内的小「条列」字形）：三行 + 圆点
    const TL_REPEAT_OV_ICON = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>';

    // 顶栏过滤条：EVENT | HOLIDAY(地区细项) | REPEAT 三类顺序排列（EVENT/REPEAT 默认勾选）
    // EVENT/REPEAT 过滤普通/重复行程；HOLIDAY 分组内为「出现过的地区」细项（颜色/图标与渲染一致，零学习成本）
    function tlRenderHolidayLegend() {
      const el = document.getElementById('tlEvHolidayLegend');
      if (!el) return;
      const catEvent = '<label class="ev-legend-item ev-legend-cat' + (tlCalShowEvents ? '' : ' off') + '" title="勾选显示 / 取消勾选隐藏普通行程（EVENT）">' +
        '<input type="checkbox" ' + (tlCalShowEvents ? 'checked' : '') + ' onchange="tlSetCategoryChecked(\'event\', this.checked)">EVENT</label>';
      const catRepeat = '<label class="ev-legend-item ev-legend-cat' + (tlCalShowRepeat === 'none' ? ' off' : '') + '" title="REPEAT 三态：未勾选＝隐藏全部 / 半勾选＝只显示未来最近一次 / 全勾选＝最近的前一次＋未来4次（最多5次）；点击循环切换">' +
        '<input type="checkbox" id="tlEvRepeatChk" data-rep="repeat" onclick="tlCycleRepeat()" title="点击循环：隐藏全部 → 只显示未来最近一次 → 显示5次">REPEAT</label>';
      const items = [];
      const seen = {};
      for (const h of (tlCalHolidays || [])) {
        const r = (h.region || 'cn').toLowerCase();
        if (seen[r]) continue;
        seen[r] = true;
        const m = tlHolidayRegionMeta(r);
        const on = tlCalRegionFilter.indexOf(r) >= 0;
        items.push('<label class="ev-legend-item' + (on ? '' : ' off') + '" title="勾选显示 / 取消勾选隐藏该地区假日">' +
          '<input type="checkbox" ' + (on ? 'checked' : '') + ' style="accent-color:' + tlEscapeHtml(m.color) + '" onchange="tlSetRegionChecked(\'' + r + '\', this.checked)">' +
          '<span class="ev-legend-dot" style="background:' + tlEscapeHtml(m.color) + '"></span>' + m.icon + tlEscapeHtml(m.label) + '</label>');
      }
      let html = catEvent;
      if (items.length) html += '<span class="ev-legend-sep"></span><span class="ev-legend-label">HOLIDAY:</span>' + items.join('');
      // REPEAT 后接「条列」图标：点击开一览视窗（列出当前所有重复事件设定，点条目可直接编辑）
      const repeatMore = '<button type="button" class="ev-legend-more" title="查看全部重复事件设定" aria-label="查看全部重复事件设定" onclick="tlOpenRepeatOverview()">' + TL_REPEAT_OV_ICON + '</button>';
      html += '<span class="ev-legend-sep"></span>' + catRepeat + repeatMore;
      // 📓 「只显示日记」勾选：只在列表模式出现（月/週/日不显示，也不受其影响）
      if (TL_DIARY_FEATURE_ENABLED && tlCalMode === 'list') {
        tlLoadDiaryOnly();
        html += '<span class="ev-legend-sep"></span>' +
          '<label class="ev-legend-item ev-legend-cat' + (tlCalDiaryOnly ? '' : ' off') + '" title="只在列表模式生效：勾选后列表只列出有写日记的日期（行程与假日暂时隐藏）">' +
          '<input type="checkbox" ' + (tlCalDiaryOnly ? 'checked' : '') + ' onchange="tlSetDiaryOnly(this.checked)">只显示日记</label>';
      }
      // ☐ 「只显示未完成」：全模式生效（年/月/周/日/列表）——勾选后隐藏已完成（✓）的行程（假日无完成态，不受影响）
      tlLoadUndoneOnly();
      html += '<span class="ev-legend-sep"></span>' +
        '<label class="ev-legend-item ev-legend-cat' + (tlCalUndoneOnly ? '' : ' off') + '" title="勾选后隐藏已完成（✓）的行程，只看未完成（年/月/周/日/列表 全模式生效）">' +
        '<input type="checkbox" ' + (tlCalUndoneOnly ? 'checked' : '') + ' onchange="tlSetUndoneOnly(this.checked)">只显示未完成</label>';
      el.style.display = '';
      el.innerHTML = html;
      const repChk = el.querySelector('input[data-rep="repeat"]');
      if (repChk) { repChk.indeterminate = (tlCalShowRepeat === 'next'); repChk.checked = (tlCalShowRepeat === 'some'); }
    }

    // 🔁 重复事件一览：条列当前 calendar.md 中所有 ## EVENT(REPEAT)；点条目 → 套用既有行程编辑表单
    function tlRepeatOvItemHtml(ev) {
      const rule = tlRepeatRuleText(ev) + ' · ' + tlRepeatEndText(ev);
      const ex = (ev.repeatExcludeDates && ev.repeatExcludeDates.length) ? ' · 排除 ' + ev.repeatExcludeDates.length + ' 天' : '';
      const when = ev.allDay ? '全天' : (ev.startTime ? ev.startTime + (ev.endTime ? '-' + ev.endTime : '') : '');
      return '<div class="tl-repeat-ov-item" data-uid="' + tlEscapeHtml(ev.uid) + '" onclick="tlOpenRepeatEvent(\'' + tlEscapeHtml(ev.uid) + '\')">' +
        '<span class="tl-repeat-ov-swatch" style="background:' + tlEscapeHtml(ev.color) + '"></span>' +
        '<div class="tl-repeat-ov-main">' +
        '<div class="tl-repeat-ov-title">' + tlRepeatIcon(ev) + tlRenderInlineMarkdown(ev.title) + '</div>' +
        '<div class="tl-repeat-ov-rule">' + tlEscapeHtml(rule) + '</div>' +
        '<div class="tl-repeat-ov-meta">' + tlEscapeHtml('起始 ' + ev.date + (when ? ' · ' + when : '') + ex) + '</div>' +
        '</div></div>';
    }
    function tlOpenRepeatOverview() {
      if (!isCalendarMdDoc()) return;
      tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
      const reps = tlCalEvents.filter((e) => e.repeatMode).sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
      const cnt = document.getElementById('tlRepeatOvCount');
      if (cnt) cnt.textContent = reps.length ? '（共 ' + reps.length + ' 条）' : '';
      const list = document.getElementById('tlRepeatOvList');
      if (list) {
        list.innerHTML = reps.length ? reps.map(tlRepeatOvItemHtml).join('')
          : '<div class="tl-repeat-ov-empty">目前没有任何重复事件<br><span class="tl-repeat-ov-empty-hint">点下方「＋ 新增重复事件」开始</span></div>';
      }
      const ov = document.getElementById('tlRepeatOverviewOverlay');
      if (ov) ov.style.display = 'flex';
    }
    // 点条目：先关一览，再开既有编辑表单（uid 相同，编辑后写回缓冲，按编辑器「保存」落盘）
    function tlOpenRepeatEvent(uid) { tlCloseRepeatOverview(); tlOpenEventForm(uid); }
    // 一览面板的「新增重复事件」：关一览 → 开「新增行程」表单并预置为重复模式（不另写一套表单）
    function tlNewRepeatEvent() { tlCloseRepeatOverview(); tlOpenEventForm(null, null, { repeat: true }); }
    function tlCloseRepeatOverview() {
      const ov = document.getElementById('tlRepeatOverviewOverlay');
      if (ov) ov.style.display = 'none';
    }

    function tlSetMode(mode) {
      tlCalMode = (mode === 'month') ? 'month' : (mode === 'week') ? 'week' : (mode === 'day') ? 'day' : (mode === 'year') ? 'year' : 'list';
      // 第十一批：年视图下方明细默认「整年」（full）；月/週/日恢复「默认以日显示」（day）
      tlCalScope = (tlCalMode === 'year') ? 'full' : 'day';
      if ((tlCalMode === 'month' || tlCalMode === 'year') && !tlCalSelected) tlCalSelected = tlFmtDate(new Date());
      if (tlCalMode === 'year') tlYearAutoScrollPending = true; // 网格：切到年视图滚动到当前月份
      if (tlCalMode === 'month') tlMonthAutoScrollPending = true; // 网格：切到月视图滚动到今天日期
      // 模式切换 / 进入：表身明细（年/月/周/日）或列表滚到今天（满足"切换模式后定位今天"）；编辑存档不在此路径 → 不滚
      if (tlCalMode === 'list') tlListScrollAnchorPending = true;
      else tlDetailListScrollPending = true;
      tlRenderEventsContent();
    }

    // 上/下一期：按当前模式步进（月→月、周→周、日→日、年→年）
    function tlCalStepCursor(dir) {
      if (tlCalMode === 'week') tlCalCursor = tlAddDays(tlCalCursor, dir * 7);
      else if (tlCalMode === 'day') tlCalCursor = tlAddDays(tlCalCursor, dir);
      else if (tlCalMode === 'year') tlCalCursor = new Date(tlCalCursor.getFullYear() + dir, tlCalCursor.getMonth(), 1);
      else tlCalCursor = new Date(tlCalCursor.getFullYear(), tlCalCursor.getMonth() + dir, 1);
      if (tlCalMode === 'month' && !tlCalSelected) tlCalSelected = tlFmtDate(tlCalCursor);
      tlRenderEventsContent();
    }

    // ===== 年视图：12 个月迷你月历（点击日期选日→下部显示明细；点击月份名 → 月视图） =====
    function tlRenderYear(content) {
      const grid = document.getElementById('tlEvYearGrid');
      if (!grid) return;
      tlCalEvents = tlAllEvents(content);
      tlCalHolidays = tlAllHolidays(content);
      tlCalDiaries = tlAllDiaries(content);
      const y = tlCalCursor.getFullYear();
      // 重複展開視窗：整年，重复事件/跨天行程首尾由展开引擎自行处理
      tlSetRepeatWindow(y + '-01-01', y + '-12-31');
      // 全年逐日事件出现（含跨天/重复展开，套用标签/分类过滤）→ 12 个月共用同一份
      const occByDate = {};
      tlCalEvents.filter(tlEventShown).forEach((ev) => {
        tlEventOccurrences(ev).forEach((o) => { (occByDate[o.date] = occByDate[o.date] || []).push(o); });
      });
      const today = tlFmtDate(new Date());
      const todayY = +today.slice(0, 4);
      const todayM = +today.slice(5, 7) - 1; // 0-based：今天所在月份（年视图月份卡片金色外框用）
      if (!tlCalSelected) tlCalSelected = today;
      const WD = ['一', '二', '三', '四', '五', '六', '日'];
      let html = '';
      for (let m = 0; m < 12; m++) {
        const daysInMonth = new Date(y, m + 1, 0).getDate();
        const offset = (new Date(y, m, 1).getDay() + 6) % 7; // 周一=0
        // 第十一批续：今天所在月份加金色外框（.cur-month），随视图年份自动判定
        const isCurMonth = (y === todayY && m === todayM);
        html += '<div class="ev-year-month' + (isCurMonth ? ' cur-month' : '') + '"><div class="ev-year-mh" onclick="tlGotoMonthFromYear(' + y + ',' + m + ')">' + (m + 1) + '月</div>';
        html += '<div class="ev-year-grid">';
        html += WD.map((w) => '<div class="ev-year-wd">' + w + '</div>').join('');
        for (let k = 0; k < offset; k++) html += '<div></div>';
        for (let d = 1; d <= daysInMonth; d++) {
          const ds = y + '-' + String(m + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
          const occ = (occByDate[ds] || []).slice().sort(tlOccSort);
          const hols = tlHolidaysOnDay(ds);
          // 事件与假日合并成彩色圆点（最多 3 个；事件优先，假日其次），用 title 悬停列出标题
          const marks = [];
          for (const o of occ) marks.push({ color: o.ev.color || TL_CAL_COLORS[0], title: o.ev.title });
          for (const h of hols) marks.push({ color: tlHolidayRegionMeta(h.region).color, title: h.title });
          let dots = '';
          for (let i = 0; i < Math.min(3, marks.length); i++) {
            dots += '<span class="ev-year-dot" style="background:' + tlEscapeHtml(marks[i].color) + '"></span>';
          }
          if (marks.length > 3) dots += '<span class="ev-year-more">+' + (marks.length - 3) + '</span>';
          const evUids = occ.map((o) => o.ev.uid).join(',');
          html += '<div class="ev-year-day' + (ds === today ? ' today' : '') + (ds === tlCalSelected ? ' selected' : '') + '" data-date="' + ds + '" data-ev-uids="' + tlEscapeHtml(evUids) + '" onclick="tlSelectDateFromYear(\'' + ds + '\')">' +
            '<span class="n">' + d + '</span>' +
            (dots ? '<span class="ev-year-dots">' + dots + '</span>' : '') +
            '</div>';
        }
        html += '</div></div>';
      }
      grid.innerHTML = html;
      tlBindSplit(document.getElementById('tlEvYearWrap'), document.getElementById('tlEvYearSplit'));
      tlRenderYearDayList();
      if (tlYearAutoScrollPending) {
        tlYearAutoScrollPending = false;
        tlScrollYearToCurrentMonth();
      }
    }
    // 年视图：若「选中日所在月份」卡片未完整显示在滚动区内，则平滑滚动到可视区中央
    //   （tlCalSelected 为今天时即原「当前月份」行为；便利贴「滚动」会预先把选中日设到目标行程日期）
    function tlScrollYearToCurrentMonth(_n) {
      const selCell = tlCalSelected ? document.querySelector('#tlEvYearGrid .ev-year-day[data-date="' + tlCalSelected + '"]') : null;
      const cur = (selCell && selCell.closest('.ev-year-month')) || document.querySelector('#tlEvYearGrid .ev-year-month.cur-month');
      const scroller = document.querySelector('#tlEvYearWrap .ev-month-scroll');
      if (!cur || !scroller) return;
      // 📎 容器尚未布局（rect 全 0）时，误判为「已完整显示」会跳过滚动；未布局则延后一帧重试（上限 60）
      if (!scroller.offsetHeight) { if ((_n || 0) < 60) requestAnimationFrame(() => tlScrollYearToCurrentMonth((_n || 0) + 1)); return; }
      const sr = scroller.getBoundingClientRect();
      const cr = cur.getBoundingClientRect();
      // 已完整显示：无需滚动
      if (cr.top >= sr.top && cr.bottom <= sr.bottom) return;
      cur.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    }
    // 年视图：点日期选日 → 重绘选中态 + 下部明细；400ms 内连点同一天＝快速新增（与月视图一致）
    let tlYearLastCellClick = { date: null, t: 0 };
    function tlSelectDateFromYear(ds) {
      const now = Date.now();
      const isDbl = tlYearLastCellClick.date === ds && (now - tlYearLastCellClick.t) < 400;
      tlYearLastCellClick = isDbl ? { date: null, t: 0 } : { date: ds, t: now };
      tlCalSelected = ds;
      if (isDbl) { tlOpenEventForm(null, ds); return; }
      tlDetailListScrollPending = true; // 显式点选日期：明细滚到该日
      tlRenderYear(document.getElementById('taskText').value);
    }
    // 年视图下部：选定日行程明细（「日」=当天；年模式「年」=整年；月模式「月」=选中日所在整月，与月视图同口径）
    function tlRenderYearDayList() {
      const list = document.getElementById('tlEvYearDayList');
      if (!list) return;
      const prevScrollTop = list.scrollTop; // 渲染前记录（确定性还原依据，不依赖缓存）
      const today = tlFmtDate(new Date());
      const sel = tlCalSelected || today;
      const toggle = tlScopeToggleHtml();
      const mm = String(sel).match(/^(\d{4})-(\d{1,2})-\d{1,2}$/);
      const my = mm ? +mm[1] : tlCalCursor.getFullYear();
      const mo = mm ? +mm[2] - 1 : tlCalCursor.getMonth();
      if (tlCalScope === 'full') {
        // ⚠️ 年模式下的「年」范围必须取「整年」——曾一律沿用选中日所在月份 → 用户实测「by年 却只看到某一个月」
        const isYearScope = tlCalMode === 'year';
        const prefix = isYearScope ? String(my) : (my + '-' + String(mo + 1).padStart(2, '0'));
        // 重复展开视窗：年＝整年；月＝选中日所在月 + 前 7 天
        if (isYearScope) tlSetRepeatWindow(my + '-01-01', my + '-12-31');
        else tlSetRepeatWindow(tlFmtDate(new Date(my, mo, 1 - 7)), tlFmtDate(new Date(my, mo + 1, 0)));
        const byDate = tlEventsByDate(tlCalEvents.filter(tlEventShown), (ds) => typeof ds === 'string' && ds.slice(0, prefix.length) === prefix);
        const dates = Array.from(byDate.keys()).sort();
        let total = 0;
        byDate.forEach((g) => { total += g.events.length + g.holidays.length; });
        let html = '';
        if (!dates.length) html += '<div class="ev-date active">' + (isYearScope ? my + '年' : (mo + 1) + '月') + ' <span class="ev-week">全部 ' + total + ' 条</span>' +
          '<span style="flex:1"></span>' + toggle + '</div><div class="ev-empty">' + (isYearScope ? '本年没有行程' : '本月没有行程') + '</div>';
        else {
          for (let i = 0; i < dates.length; i++) {
            const grp = byDate.get(dates[i]);
            let g = tlDateHeader(dates[i], today, toggle, grp.events.length + grp.holidays.length);
            for (const h of grp.holidays) g += tlHolidayHtml(h, today, dates[i]);
            for (const ev of tlSorted(grp.events)) g += tlItemHtml(ev, today, dates[i]);
            html += (dates[i] === sel) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
          }
        }
        list.innerHTML = html;
        list.classList.add('scope-follow');
        tlBindActiveDateScroll(list);
        // 明细滚动策略（2026-09-30-v2）：仅显式导航（今天/点选日期）才滚到选定日；编辑存档/过滤/搜索/切范围均不自动滚动
        if (tlDetailListScrollPending) { tlDetailListScrollPending = false; tlScrollListToDate(list, list, sel); }
        else { list.scrollTop = prevScrollTop; }
        tlUpdateActiveDate(list);
        tlAfterCalRender();
        return;
      }
      // 「日」范围（默认）：选定日单日
      tlSetRepeatWindow(sel, sel);
      const dayItems = tlDayItems(sel);
      const evs = tlSorted(dayItems.events);
      const hols = dayItems.holidays;
      let html = tlDateHeader(sel, today, toggle, evs.length + hols.length);
      if (!evs.length && !hols.length) html += '<div class="ev-empty">这一天没有行程</div>';
      else {
        for (const h of hols) html += tlHolidayHtml(h, today, sel);
        for (const ev of evs) html += tlItemHtml(ev, today, sel);
      }
      list.classList.remove('scope-follow');
      list.innerHTML = html;
      tlAfterCalRender();
    }
    // 年视图：点月份名 → 切到该月的「月」视图
    function tlGotoMonthFromYear(y, m) {
      tlCalCursor = new Date(y, m, 1);
      tlCalSelected = tlFmtDate(new Date(y, m, 1));
      tlSetMode('month');
    }

    // ⏳ 倒計時標籤：今天 / N天后 / N天前（日期字符串安全運算，不受時區/夏令時影響）
    function tlCountdownLabel(date, today) {
      const p = (s) => { const m = String(s || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
      const a = p(date), b = p(today);
      if (!a || !b) return '';
      const diff = Math.round((a - b) / 86400000);
      if (diff === 0) return '今天';
      return diff > 0 ? diff + '天后' : (-diff) + '天前';
    }

    // opts.noAdd：抑制日期标题右侧的「＋ 新增」（「只显示日记」过滤下新增的行程不会出现在列表里，避免误导）
    function tlDateHeader(date, today, extra, count, opts) {
      const m = String(date || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
      const WD = ['日', '一', '二', '三', '四', '五', '六'];
      let label = '日期未知', week = '';
      if (m) {
        const d = new Date(+m[1], +m[2] - 1, +m[3]);
        label = (+m[1]) + '年' + (+m[2]) + '月' + (+m[3]) + '日';
        week = WD[d.getDay()];
      }
      const isToday = date === today;
      const cd = tlCountdownLabel(date, today);
      const cp = tlLunarCompact(date);
      const lunarHdr = cp.lunarText ? '農曆 ' + cp.lunarText + (cp.jieqi ? ' · ' + cp.jieqi : '') : (cp.jieqi || '');
      const dy = tlDiaryOnDate(date);
      const diaryBtn = '<button type="button" class="ev-day-diary' + (dy ? (dy.ro ? ' ro' : ' has') : '') + '" title="' + (dy ? '已有日记 · 点击编辑' : '写日记') + '" data-ev-diary="' + tlEscapeHtml(date) + '" onclick="tlOpenDiaryForm(\'' + date + '\')">\ud83d\udcd5</button>';
      return '<div class="ev-date' + (isToday ? ' today' : '') + '" data-ev-date="' + tlEscapeHtml(date) + '">' + label +
        (week ? '<span class="ev-week">週' + week + '</span>' : '') +
        // ⏳ 倒計時徽章：每天必顯示（今天＝高亮，其餘＝灰底），取代原先「僅今天顯示」
        (cd ? '<span class="ev-today-badge' + (isToday ? '' : ' dim') + '">' + cd + '</span>' : '') +
        // 当天条数（与「日」范围单日标题的「· N 条」一致；列表/整月/整週分组标题都显示）
        (typeof count === 'number' ? '<span class="ev-week">· ' + count + ' 条</span>' : '') +
        (lunarHdr ? '<span class="ev-lunar hdr" onclick="tlShowAlmanac(\'' + date + '\',this)" title="農民曆 / 老黃曆">' + tlEscapeHtml(lunarHdr) + '</span>' : '') +
        (extra || '') +
        diaryBtn +
        ((opts && opts.noAdd) ? '' : '<button type="button" class="ev-day-add" onclick="tlOpenEventForm(null, \'' + date + '\')">＋ 新增</button>') +
        '</div>';
    }

    // occDate＝该行所属的「出现日」（重复事件为展开后的当天；非重复＝ev.date）。
    // ⚠️ 重复事件的 ev.date 是「系列起始日」：若拿它算 past，则「过去开始的年度重复」在未来年份的实例会被误判为过去而淡化。
    // 📊 备注子事件完成进度徽章（标签旁「3/6」）：解析备注 checkbox 行，全部完成时徽章转绿
    function tlSubProgressBadge(ev) {
      const subs = tlParseNoteChecks(ev && ev.notes);
      if (!subs.length) return '';
      const done = subs.filter((s) => s.done).length;
      const all = done === subs.length;
      return '<span class="ev-sub-progress' + (all ? ' all-done' : '') + '" title="备注子事件：' + done + ' / ' + subs.length + ' 已完成">' + done + '/' + subs.length + '</span>';
    }
    function tlSpanDisplayModeBadge(ev) {
      const isToday = ev && ev.spanDisplay === 'today';
      if (!tlIsMultiDay(ev) && !isToday) return '';
      const mode = ev.spanDisplay === 'first' ? 'first' : ev.spanDisplay === 'last' ? 'last' : isToday ? 'today' : 'daily';
      const letter = mode === 'first' ? 'H' : mode === 'last' ? 'E' : mode === 'today' ? '今' : 'A';
      const label = mode === 'first' ? '首天显示' : mode === 'last' ? '末天显示' : mode === 'today' ? '显示在今天' : '每天显示';
      return '<span class="ev-span-display-mode" title="显示方式：' + label + '">' + letter + '</span>';
    }
    function tlEventUndoneChecksOnly(uid) {
      return tlUndoneChecksByEvent[uid] === true;
    }
    function tlToggleEventUndoneChecks(uid, button) {
      const next = !tlEventUndoneChecksOnly(uid);
      if (next) tlUndoneChecksByEvent[uid] = true;
      else delete tlUndoneChecksByEvent[uid];
      try {
        localStorage.setItem(TL_UNDONE_CHECKS_KEY, JSON.stringify(tlUndoneChecksByEvent));
      } catch (error) {
        showToast('无法保存该事件的 checkbox 显示设置：' + ((error && error.message) || error), 'danger');
      }
      const item = button && button.closest('.ev-item');
      if (item) item.classList.toggle('only-undone-checks', next);
      if (button) {
        button.classList.toggle('active', next);
        button.textContent = next ? '☑' : '☐';
        button.setAttribute('aria-pressed', next ? 'true' : 'false');
        button.title = next
          ? '仅显示该事件未完成的 checkbox 子事件（点击显示全部）'
          : '只显示该事件未完成的 checkbox 子事件';
      }
    }
    function tlItemHtml(ev, today, occDate) {
      const multi = tlIsMultiDay(ev);
      const isRep = !!ev.repeatMode;
      // 重复事件：该行代表「出现日当天」（单日）；非重复：用自身 date/endDate
      const effEnd = isRep ? (occDate || ev.date) : ((ev.endDate && ev.endDate !== ev.date) ? ev.endDate : ev.date);
      const past = effEnd < today;   // 等价于原「start<today 且 跨天未结束」——跨天 end<today 亦蕴含 start<today
      let time;
      if (tlIsSpanToday(ev)) {
        time = TL_SPAN_TODAY_TEXT;   // 显示在今天：不显示真实日期区间
      } else if (multi) {
        time = ev.allDay
          ? (tlRangeLabel(ev.date, ev.endDate) + ' \u00b7 \u5171' + tlSpanDays(ev.date, ev.endDate) + '\u5929')
          : tlRangeLabel(ev.date, ev.endDate, ev.startTime, ev.endTime);
      } else {
        time = ev.allDay ? '\u5168\u5929' : ((ev.startTime || '') + (ev.endTime ? '-' + ev.endTime : ''));
      }
      // 🆕 显示方式＝「显示在今天」：时间行已改固定字样，跨天徽标也不该再出现
      const spanBadge = (multi && !tlIsSpanToday(ev)) ? '<span class="ev-span-badge" title="\u8de8\u5929\u884c\u7a0b">\u2922 \u8de8' + tlSpanDays(ev.date, ev.endDate) + '\u5929</span>' : '';
      return '<div class="ev-item' + (past ? ' past' : '') + (ev.done ? ' done' : '') + (multi ? ' multi' : '') + (tlEventUndoneChecksOnly(ev.uid) ? ' only-undone-checks' : '') + '" data-uid="' + tlEscapeHtml(ev.uid) + '" data-occ-date="' + tlEscapeHtml(occDate || ev.date) + '">' +
        // 📎 只读（INCLUDE 进来的外部档）行程：完成状态同样不可改 → 直接 disabled。
        //    以前只靠 tlToggleDone 里的 ro 拦阻，但浏览器已先把勾选框翻过去、又不重绘 →
        //    看起来像「改成功了」，实际丢弃（2026-10-22 用户回馈「为什么这个禁止徽标的事件还能勾选」）。
        '<input type="checkbox" class="ev-check"' +
        (ev.ro ? ' disabled' : ' onchange="tlToggleDone(\'' + ev.uid + '\', this.checked, this)"') +
        (ev.done ? ' checked' : '') +
        ' title="' + (ev.ro ? '\u6765\u81ea\u88ab\u5305\u542b\u7684\u53ea\u8bfb\u6587\u4ef6\uff0c\u4e0d\u53ef\u4fee\u6539\u5b8c\u6210\u72b6\u6001' : '\u52fe\u9009=\u5df2\u5b8c\u6210\uff0c\u53d6\u6d88\u52fe\u9009=\u672a\u5b8c\u6210') + '">' +
        (ev.ro ? '<span class="ev-ro-icon" title="来自被包含的只读文件，不可编辑">\u26d4</span>' : '') +
        '<span class="ev-swatch" style="background:' + tlEscapeHtml(ev.color) + '"></span>' +
        '<div class="ev-body">' +
        // 跨天行程（含跨天重复）标题后紧跟「(第几天/共几天)」——让「回上海 (3/7)」一眼看出是第三天
        '<div class="ev-title">' + tlRepeatIcon(ev) + tlRenderInlineMarkdown(ev.title) + tlSpanDaySuffix(ev, occDate) + spanBadge +
        (ev.tags && ev.tags.length ? '<span class="ev-tags">' + ev.tags.map((t) => '<span class="ev-tag-view" data-tag="' + tlEscapeHtml(tlTagName(t)) + '">' + tlEscapeHtml(tlTagLabel(t)) + '</span>').join('') + '</span>' : '') +
        tlSubProgressBadge(ev) +
        tlSpanDisplayModeBadge(ev) +
        (ev.sticky > 0 ? '<button type="button" class="ev-sticky-flag" title="点击跳转到便利贴视窗" onclick="tlFocusStickyNote(\'' + tlEscapeHtml(ev.uid) + '\')">' + TL_STICKY_IC_SVG + '</button>' : '') +
        // 🆕 非便利贴事件：给一个「看得见」的入口，不必猜在哪右键。📌＝临时开启（不写入 calendar.md）
        (ev.sticky > 0 ? '' : '<button type="button" class="ev-temp-sticky-btn" data-uid="' + tlEscapeHtml(ev.uid) + '" title="临时开启为便利贴（仅本会话，未写入 calendar.md）" onclick="tlToggleTempSticky(\'' + tlEscapeHtml(ev.uid) + '\')">📌</button>') +
        // 📋 列表行「＋☐」：与编辑表单备注旁同一入口（开 CheckBox 小窗）；列表模式按「加入备注」直接存档
        (ev.ro ? '' : '<button type="button" class="ev-addcheck-btn" title="在备注末尾加入 CheckBox（加入后直接存档）" onclick="tlOpenAddCheckDialog(\'' + tlEscapeHtml(ev.uid) + '\')">＋☐</button>') +
        '<button type="button" class="ev-undone-filter-btn' + (tlEventUndoneChecksOnly(ev.uid) ? ' active' : '') + '" data-uid="' + tlEscapeHtml(ev.uid) + '" aria-pressed="' + (tlEventUndoneChecksOnly(ev.uid) ? 'true' : 'false') + '" title="' + (tlEventUndoneChecksOnly(ev.uid) ? '仅显示该事件未完成的 checkbox 子事件（点击显示全部）' : '只显示该事件未完成的 checkbox 子事件') + '">' + (tlEventUndoneChecksOnly(ev.uid) ? '☑' : '☐') + '</button>' +
        tlEventTodoLinks(ev) +
        '</div>' +
        '<div class="ev-meta">' + tlEscapeHtml(time) + (ev.location ? ' \u00b7 \ud83d\udccd' + tlEscapeHtml(ev.location) : '') + '</div>' +
        (ev.notes ? '<div class="ev-notes">' + tlRenderNotes(ev.notes, ev.uid) + '</div>' : '') +
        '</div>' +
        '<div class="ev-actions">' +
        '<button type="button" onclick="tlOpenEventForm(\'' + ev.uid + '\')">\u7f16\u8f91</button>' +
        '<button type="button" onclick="tlDeleteEvent(\'' + ev.uid + '\')">\u5220\u9664</button>' +
        '</div></div>';
    }

    // ===== ## HOLIDAY 辅助（日志/列表视图显示，与 EVENT 视觉区隔：左侧 type 色条＋类型徽章，无勾选框/编辑删除）=====
    // 地区调色板：决定假日「目视差别」的主色（与类型徽章正交）。可扩展：直接往此表加一项即可（如 kr 韩国 #003478 / jp 日本 #E60012）。
    // 缺省 cn：旧数据无 region 字段时回退中国大陆；非空但未知的地区→中性灰＋原始代号（不静默当大陆，避免误判）。
    const TL_HOLIDAY_REGIONS = {
      cn: { label: '大陆', icon: '<span class="ev-region-icon ev-region-cn" aria-label="中国大陆旗帜"></span>', color: '#E4002B' },
      hk: { label: '港',   icon: '<span class="ev-region-icon ev-region-hk" aria-label="香港旗帜"></span>', color: '#7B2FBE' },
      tw: { label: '台',   icon: '<span class="ev-region-icon ev-region-tw" aria-label="台湾旗帜"></span>', color: '#00A3A3' },
      us: { label: '美',   icon: '<span class="ev-region-icon ev-region-us" aria-label="美国旗帜"></span>', color: '#1F4E79' },
    };
    function tlHolidayRegionMeta(region) {
      const r = (region || '').toLowerCase();
      if (!r) return TL_HOLIDAY_REGIONS.cn;
      if (TL_HOLIDAY_REGIONS[r]) return TL_HOLIDAY_REGIONS[r];
      return { label: r.toUpperCase(), icon: '🌐', color: '#6B7280' };
    }
    function tlHolidayMeta(type) {
      switch ((type || '').toLowerCase()) {
        case 'workday': return { label: '补班', icon: '💼', color: '#FF9500' };
        case 'holiday': return { label: '假日', icon: '🎉', color: '#34C759' };
        case 'festival': return { label: '节日', icon: '🏮', color: '#FF3B30' };
        default: return { label: '假日', icon: '🎌', color: '#FF9500' };
      }
    }
    // 取某天出现的假日（含跨天展开）：dateStr 落在 [date, endDate] 区间内即命中
    // ## HOLIDAY 地区过滤：图例 checkbox 勾选要显示的地区（默认只勾大陆 cn）
    function tlRegionVisible(h) {
      return tlCalRegionFilter.indexOf((h.region || 'cn').toLowerCase()) >= 0;
    }
    // 只保留「勾选地区」的假日（供按日期分组 / 空态判断使用，避免绕过地区过滤）
    function tlVisibleHolidays() {
      return (tlCalHolidays || []).filter(tlRegionVisible);
    }
    // 按当前模式「直接」重渲染（勿走 tlRenderEventsContent —— 它开头有宿主守卫 if (!calEventsView) return，
    //    勾选过滤条时会被拦下导致画面不刷新），再同步顶栏过滤条勾选态。分类/地区过滤共用。
    function tlRerenderCalendarView() {
      const content = document.getElementById('taskText').value;
      if (tlCalMode === 'month') tlRenderMonth(content);
      else if (tlCalMode === 'week') tlRenderTimeGrid(tlWeekDays(tlCalCursor));
      else if (tlCalMode === 'day') tlRenderTimeGrid([tlCalCursor]);
      else if (tlCalMode === 'year') tlRenderYear(content);
      else tlRenderList(content);
      tlRenderHolidayLegend();
    }

    // 🔎 重繪收尾：行程視圖下的搜尋是「畫面上的內容」，任何一次 innerHTML 重建都會把 <mark> 抹掉。
    //    由每個「渲染葉子」函数（tlRenderList / tlRenderDiaryOnlyList / tlRenderDayList /
    //    tlRenderDayGridList）在收尾处调用，按搜索框里的关键词原样重建高亮 —— 否则高亮凭空消失、
    //    右上角计数却还在显示旧数字（说谎）。
    //    ⚠️ 只在「行程视图 + 关键词非空」时起作用，其余情况是空操作；定义在 index.html 的内联脚本里。
    function tlAfterCalRender() {
      if (typeof tlCalSearchReapply === 'function') tlCalSearchReapply();
      // 🆕 重绘后恢复「临时便利贴」的卡片描边与 📌 按钮状态（否则一切换视图标记就丢了）
      if (typeof tlRefreshTempStickyMarks === 'function') tlRefreshTempStickyMarks();
    }

    // 顶栏分类过滤：EVENT（普通行程）/ REPEAT（重复行程）
    function tlSetCategoryChecked(kind, on) {
      if (kind === 'event') tlCalShowEvents = !!on;
      else return;
      tlRerenderCalendarView();
    }
    // REPEAT 三態循環：none → next → some → none（點擊圖例 checkbox 切換）
    function tlCycleRepeat() {
      const order = ['none', 'next', 'some'];
      let i = order.indexOf(tlCalShowRepeat);
      if (i < 0) i = 0;
      tlCalShowRepeat = order[(i + 1) % order.length];
      tlRerenderCalendarView();
    }
    function tlSetRegionChecked(code, on) {
      const r = (code || '').toLowerCase();
      if (!r) return;
      const i = tlCalRegionFilter.indexOf(r);
      if (on && i < 0) tlCalRegionFilter.push(r);
      else if (!on && i >= 0) tlCalRegionFilter.splice(i, 1);
      tlRerenderCalendarView();
    }
    function tlHolidaysOnDay(dateStr) {
      if (!tlCalHolidays || !tlCalHolidays.length) return [];
      return tlCalHolidays.filter((h) => {
        const end = (h.endDate && h.endDate !== h.date) ? h.endDate : h.date;
        return tlRegionVisible(h) && dateStr >= h.date && dateStr <= end;
      });
    }
    // 🗓 依日期分組的「唯一入口」：跨天行程/假日一律「逐日展開」——在涵蓋的每一天都出現，
    //    與「日」範圍同口徑。（修復：by月/列表先前只認起始日 → 同一天 by日 4 條、by月 3 條）
    //    dateOk(ds) 可選：只收符合條件的日期（如「整月」只收游標月）。
    function tlEventsByDate(events, dateOk) {
      const byDate = new Map();
      const add = (ds, key, item) => {
        if (!ds || (dateOk && !dateOk(ds))) return;
        if (!byDate.has(ds)) byDate.set(ds, { events: [], holidays: [] });
        byDate.get(ds)[key].push(item);
      };
      (events || []).forEach((ev) => { tlEventOccurrences(ev).forEach((o) => add(o.date, 'events', ev)); });
      tlVisibleHolidays().forEach((h) => {
        const s = new Date(h.date + 'T00:00:00');
        const en = new Date(((h.endDate && h.endDate !== h.date) ? h.endDate : h.date) + 'T00:00:00');
        if (isNaN(s) || isNaN(en) || en < s) { add(h.date, 'holidays', h); return; }
        for (const cur = new Date(s); cur <= en; cur.setDate(cur.getDate() + 1)) add(tlFmtDate(cur), 'holidays', h);
      });
      return byDate;
    }
    // 某日明细的「唯一取数入口」（日/週/月三处明细都用它）→ 与列表/整月同口径，不会再分叉
    function tlDayItems(ds) {
      return tlEventsByDate(tlCalEvents.filter(tlEventShown), (d) => d === ds).get(ds) || { events: [], holidays: [] };
    }
    // occDate＝该列所属的「出现日」：跨天假日（endDate ≠ date）用它算「(第几天/共几天)」，与行程同款。
    // ⚠️ 必须由调用方传入（分组入口只给 h + 日期，h 自身不知道自己被渲染在哪一天）。
    function tlHolidayHtml(h, today, occDate) {
      const meta = tlHolidayMeta(h.holidayType);
      const region = tlHolidayRegionMeta(h.region);
      const accent = region.color; // 假日主色＝地区色（地区为目视差别唯一来源；color 字段不参与假日着色）
      const multi = h.endDate && h.endDate !== h.date;
      const time = multi
        ? (tlMdShort(h.date) + ' – ' + tlMdShort(h.endDate) + ' · 共' + tlSpanDays(h.date, h.endDate) + '天')
        : '全天';
      const tags = (h.tags && h.tags.length) ? '<span class="ev-tags">' + h.tags.map((t) => '<span class="ev-tag-view" data-tag="' + tlEscapeHtml(tlTagName(t)) + '">' + tlEscapeHtml(tlTagLabel(t)) + '</span>').join('') + '</span>' : '';
      return '<div class="ev-holiday" data-ev-holiday="' + tlEscapeHtml(h.uid) + '" style="--holiday-color:' + tlEscapeHtml(accent) + '">' +
        (h.ro ? '<span class="ev-ro-icon" title="来自被包含的只读文件，不可编辑">\u26d4</span>' : '') +
        '<span class="ev-holiday-region" style="--region-color:' + tlEscapeHtml(region.color) + '" title="' + tlEscapeHtml(region.label + '地区假日') + '">' + region.icon + tlEscapeHtml(region.label) + '</span>' +
        '<span class="ev-holiday-badge">' + meta.icon + ' ' + tlEscapeHtml(meta.label) + '</span>' +
        '<div class="ev-body">' +
        '<div class="ev-title">' + tlRenderInlineMarkdown(h.title) + tlSpanDaySuffix(h, occDate) + tags + '</div>' +
        '<div class="ev-meta">' + tlEscapeHtml(time) + (h.location ? ' · 📍' + tlEscapeHtml(h.location) : '') + '</div>' +
        (h.notes ? '<div class="ev-notes">' + tlRenderNotes(h.notes, null) + '</div>' : '') +
        '</div></div>';
    }

    // ===== 列表模式：「跨天行程」显示方式（跨天一笔 / 跨天多笔）=====
    // 纯 UI 偏好（内存 + localStorage，键 tlCalMultiDay；绝不写回 calendar.md）。
    // 只在列表模式生效：跨天行程要不要「跨几天就显示几笔」——默认多笔（与「日」范围同口径）。
    const TL_MULTIDAY_KEY = 'tlCalMultiDay';
    function tlLoadMultiDayMode() {
      if (tlMultiDayLoaded) return tlCalMultiDayMode;
      tlMultiDayLoaded = true;
      let v = '';
      try { v = localStorage.getItem(TL_MULTIDAY_KEY) || ''; } catch (e) {}
      tlCalMultiDayMode = (v === 'one') ? 'one' : 'multi';
      return tlCalMultiDayMode;
    }
    // 同步「跨天一笔 / 跨天多笔」按钮的文案与高亮（按钮只在列表模式显示）
    function tlUpdateMultiDayBtn() {
      const b = document.getElementById('tlEvMultiDayBtn');
      if (!b) return;
      tlLoadMultiDayMode();
      const one = tlCalMultiDayMode === 'one';
      b.textContent = one ? '跨天一笔' : '跨天多笔';
      b.classList.toggle('active', one);
      b.title = one
        ? '当前「跨天一笔」：每天显示的事件集中在首天，首天/末天设置按事件设定显示 · 点击改为「跨天多笔」'
        : '当前「跨天多笔」：跨天行程跨几天就显示几笔 · 点击改为「跨天一笔」';
    }
    function tlSetMultiDayMode(mode) {
      tlCalMultiDayMode = (mode === 'one') ? 'one' : 'multi';
      tlMultiDayLoaded = true;
      try { localStorage.setItem(TL_MULTIDAY_KEY, tlCalMultiDayMode); } catch (e) {}
      tlUpdateMultiDayBtn();
      tlRerenderCalendarView();
    }
    function tlToggleMultiDayMode() { tlSetMultiDayMode(tlCalMultiDayMode === 'one' ? 'multi' : 'one'); }
    // 「跨天一笔」：默认每天显示的跨天行程只保留首天；事件设为末天的则在末天显示。
    // 被清空的日期（原本只挂着这一个跨天行程）整条删掉，避免留下「· 0 条」的空标题。
    // ⚠️ 就地改的是 tlRenderList 自己那份 byDate 副本——tlEventsByDate 的「逐日展开」口径不动，
    //    所以月格 chip / 时间网格 / 日明细一律不受影响（用户约定：只调列表模式）。
    function tlCollapseMultiDayRows(byDate) {
      const seen = new Set();
      for (const ds of Array.from(byDate.keys()).sort()) {
        const grp = byDate.get(ds);
        grp.events = grp.events.filter((ev) => {
          if (!tlIsMultiDay(ev)) return true;   // 单日行程（含重复事件的每个出现日）逐日照显
          if (seen.has(ev.uid)) return false;   // 跨天行程：后续天不再重复出现
          seen.add(ev.uid);
          return true;
        });
        if (!grp.events.length && !grp.holidays.length) byDate.delete(ds);
      }
    }

    // ===== 列表模式：「只显示日记」过滤（勾选后行程/假日全部隐藏，只列有日记的日期）=====
    // 纯 UI 偏好（内存 + localStorage，键 tlCalDiaryOnly；绝不写回 calendar.md）。只在列表模式生效。
    const TL_DIARYONLY_KEY = 'tlCalDiaryOnly';
    function tlLoadDiaryOnly() {
      if (!TL_DIARY_FEATURE_ENABLED) return false;
      if (tlDiaryOnlyLoaded) return tlCalDiaryOnly;
      tlDiaryOnlyLoaded = true;
      let v = '';
      try { v = localStorage.getItem(TL_DIARYONLY_KEY) || ''; } catch (e) {}
      tlCalDiaryOnly = (v === '1');
      return tlCalDiaryOnly;
    }
    function tlSetDiaryOnly(on) {
      if (!TL_DIARY_FEATURE_ENABLED) return;
      tlCalDiaryOnly = !!on;
      tlDiaryOnlyLoaded = true;
      try { localStorage.setItem(TL_DIARYONLY_KEY, tlCalDiaryOnly ? '1' : '0'); } catch (e) {}
      tlRenderHolidayLegend();   // 同步顶栏勾选态（该勾选框只在列表模式渲染）
      tlRerenderCalendarView();
    }
    // ☐ 「只显示未完成」：纯 UI 偏好（内存 + localStorage，键 tlCalUndoneOnly；绝不写回 calendar.md）。全模式生效（收口于 tlEventShown）。
    const TL_UNDONEONLY_KEY = 'tlCalUndoneOnly';
    function tlLoadUndoneOnly() {
      if (tlUndoneOnlyLoaded) return tlCalUndoneOnly;
      tlUndoneOnlyLoaded = true;
      let v = '';
      try { v = localStorage.getItem(TL_UNDONEONLY_KEY) || ''; } catch (e) {}
      // 第十一批依用户截图设定：缺省（从未设过该键）＝默认「开」；仅当用户明确设过 '0' 才关闭
      tlCalUndoneOnly = (v === '' ? true : v === '1');
      return tlCalUndoneOnly;
    }
    function tlSetUndoneOnly(on) {
      tlCalUndoneOnly = !!on;
      tlUndoneOnlyLoaded = true;
      try { localStorage.setItem(TL_UNDONEONLY_KEY, tlCalUndoneOnly ? '1' : '0'); } catch (e) {}
      tlRenderHolidayLegend();   // 同步顶栏勾选态（该勾选框只在列表模式渲染）
      // 切换前：捕获当前画面顶部日期组＋偏移，用于切换后尽量不滚动（Feature #8）
      const list = tlActiveDetailList();
      let anchorDate = null, anchorOffset = 0;
      if (list) {
        const info = tlViewportTopDateInfo(list);
        if (info) { anchorDate = info.date; anchorOffset = info.offset; }
      }
      tlRerenderCalendarView();
      // 切换后：把锚点日期组对齐回原偏移（锚点被过滤掉 → 回落到最近的未过滤组）；覆盖重绘自带的 prevScrollTop 还原
      if (list && anchorDate) tlReanchorList(list, anchorDate, anchorOffset);
    }
    // 日记正文：压掉行尾空白并 trim 后以基础 Markdown 渲染（不截断）。
    // ⚠️ 绝不在这里截断：正文被截掉的部分根本没进 DOM，列表滚动条再怎么滚也滚不出来。
    function tlDiaryBody(content) {
      const raw = String(content || '').replace(/\r\n/g, '\n').replace(/[ \t]+\n/g, '\n').trim();
      return raw ? renderMarkdown(raw) : '';
    }
    // 日记条目：标题 + 心情/天气 + 标签 + 完整正文；「编辑」开既有日记表单。
    // ⚠️ 日记没有 color 字段 → 色点统一用日记绿 #16a34a（与日期标题上「已有日记」的 📕 勾同色）。
    function tlDiaryRowHtml(d) {
      const meta = [];
      if (d.mood) meta.push('心情 ' + d.mood);
      if (d.weather) meta.push(d.weather);
      const tags = (d.tags && d.tags.length)
        ? '<span class="ev-tags">' + d.tags.map((t) => '<span class="ev-tag-view" data-tag="' + tlEscapeHtml(tlTagName(t)) + '">' + tlEscapeHtml(tlTagLabel(t)) + '</span>').join('') + '</span>'
        : '';
      const body = tlDiaryBody(d.content);
      return '<div class="ev-item ev-diary-item" data-ev-diary-row="' + tlEscapeHtml(d.date) + '">' +
        '<span class="ev-swatch" style="background:#16a34a"></span>' +
        '<div class="ev-body">' +
        '<div class="ev-title">\ud83d\udcd5 ' + tlRenderInlineMarkdown(d.title || '（无标题）') + tags + '</div>' +
        (meta.length ? '<div class="ev-meta">' + tlEscapeHtml(meta.join(' · ')) + '</div>' : '') +
        (body ? '<div class="ev-notes">' + body + '</div>' : '') +
        '</div>' +
        '<div class="ev-actions">' +
        '<button type="button" onclick="tlOpenDiaryForm(\'' + d.date + '\')">\u7f16\u8f91</button>' +
        '<button type="button" onclick="tlDeleteDiaryByDate(\'' + d.date + '\')">\u5220\u9664</button>' +
        '</div></div>';
    }
    // 「只显示日记」的列表本体：日期组只来自 ## DIARY（行程/假日不参与），一天一条
    function tlRenderDiaryOnlyList(list) {
      const today = tlFmtDate(new Date());
      const prevScrollTop = list.scrollTop; // 渲染前先记下列表当前滚动位置（确定性还原依据）
      // 同一天只应有一条日记，但解析层不做唯一性保证 → 这里按日期去重（保留首条）
      const seen = {};
      const rows = (tlCalDiaries || []).filter((d) => d.date && !seen[d.date] && (seen[d.date] = true));
      if (!rows.length) {
        list.innerHTML = '<div class="ev-empty">尚未有日记<br><span style="font-size:12px">取消勾选「只显示日记」可回到行程清单；或在日期标题右侧点 \ud83d\udcd5 写一篇</span></div>';
        tlAfterCalRender();
        return;
      }
      const byDate = {};
      rows.forEach((d) => { byDate[d.date] = d; });
      const dates = rows.map((d) => d.date).sort();
      // 锚点日（「今天」或 < > 导航到的日期）：只用于判断「是否该框金边」与滚动，绝不因回退而漂移
      const anchor = tlListSel || today;
      const anchorInList = dates.indexOf(anchor) >= 0;
      // ⚠️ 「框选」只在锚点日本身真有分组时才生效：今天（或所选日）无内容 → 不框任何其它日
      const highlight = anchorInList ? anchor : null;
      const scrollTo = anchorInList ? anchor : (dates.find((d) => d > today) || dates[dates.length - 1] || today);
      if (anchorInList) tlListSel = anchor;
      let html = '';
      for (const ds of dates) {
        // 标题条不显示「· N 条」（一天一条，计数无信息量），并抑制「＋ 新增」（新增的是行程，此处不显示）
        let g = tlDateHeader(ds, today, '', undefined, { noAdd: true });
        g += tlDiaryRowHtml(byDate[ds]);
        html += (ds === highlight) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
      }
      list.innerHTML = html;
      // 列表滚动策略（2026-09-30，确定性）：除「今天 / < >」显式导航外，渲染后精确还原到渲染前的 scrollTop，绝不跳今天
      if (tlListScrollAnchorPending) {
        tlListScrollAnchorPending = false;
        tlScrollListToDate(list, list, scrollTo); // 仅显式导航：滚到锚点日（今天或所选日）
      } else {
        list.scrollTop = prevScrollTop; // 非显式导航：原地恢复，不自动滚动
      }
      tlAfterCalRender();
    }

    function tlRenderList(content) {
      const list = document.getElementById('tlEvList');
      if (!list) return;
      const prevScrollTop = list.scrollTop; // 渲染前先记下列表当前滚动位置（确定性还原依据，不依赖内存/缓存）
      tlCalEvents = tlAllEvents(content);
      tlCalHolidays = tlAllHolidays(content);
      tlCalDiaries = tlAllDiaries(content);
      // 📓 「只显示日记」：勾选后走专用分支（行程/假日不参与），连「尚未有行程」的空态也不适用
      tlLoadDiaryOnly();
      if (tlCalDiaryOnly) { tlRenderDiaryOnlyList(list); return; }
      if (!tlCalEvents.length && !tlVisibleHolidays().length) {
        list.innerHTML = '<div class="ev-empty">尚未有行程<br><span style="font-size:12px">点右上「＋ 新增行程」，或切回文本编辑直接改 calendar.md</span></div>';
        tlAfterCalRender();
        return;
      }
      const today = tlFmtDate(new Date());
      // 重複展開視窗（列表無固定範圍）：今天前 1 年 ~ 後 3 年，避免 never 無限展開
      tlSetRepeatWindow(tlAddDaysStr(today, -365), tlAddDaysStr(today, 1095));
      // 按日期分组（跨天行程/假日逐日展开，与「日」范围同口径）：每天先显示该日假日，再显示行程
      tlLoadMultiDayMode();
      // ☐ 「只显示未完成」已收口于 tlEventShown（全模式生效）：过滤链已排除 done ✓ 的行程
      tlLoadUndoneOnly();
      let evs = tlCalEvents.filter(tlEventShown);
      if (tlCalUndoneOnly && !evs.length && !tlVisibleHolidays().length) {
        list.innerHTML = '<div class="ev-empty">没有未完成的行程<br><span style="font-size:12px">取消勾选「只显示未完成」可查看全部</span></div>';
        tlAfterCalRender();
        return;
      }
      const byDate = tlEventsByDate(evs);
      if (tlCalMultiDayMode === 'one') tlCollapseMultiDayRows(byDate);   // 跨天一笔：跨天行程只在起始日显示一笔
      const dates = Array.from(byDate.keys()).sort();
      // 锚点日（「今天」或 < > 导航到的日期）：只用于判断「是否该框金边」与滚动，绝不因回退而漂移
      const anchor = tlListSel || today;
      const anchorInList = dates.indexOf(anchor) >= 0;
      // ⚠️ 「框选」（金色描边）只在锚点日本身真有分组时才生效：今天（或所选日）无行程 → 不框任何其它日
      const highlight = anchorInList ? anchor : null;
      // 滚动锚点：锚点日不在列表时回退「最近未来日」（仅滚动定位，不写回 tlListSel、不影响框选）
      const scrollTo = anchorInList ? anchor : (dates.find((d) => d > today) || dates[dates.length - 1] || today);
      if (anchorInList) tlListSel = anchor;
      let html = '';
      for (const ds of dates) {
        const grp = byDate.get(ds);
        let g = tlDateHeader(ds, today, '', grp.events.length + grp.holidays.length);
        for (const h of grp.holidays) g += tlHolidayHtml(h, today, ds);
        for (const ev of tlSorted(grp.events)) g += tlItemHtml(ev, today, ds);
        html += (ds === highlight) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
      }
      list.innerHTML = html;
      // 列表滚动策略（2026-09-30，确定性）：除「今天 / < >」显式导航外，渲染后精确还原到渲染前的 scrollTop，绝不跳今天
      if (tlListScrollAnchorPending) {
        tlListScrollAnchorPending = false;
        tlScrollListToDate(list, list, scrollTo); // 仅显式导航：滚到锚点日（今天 / 所选日；不在列表则最近未来日）
      } else {
        list.scrollTop = prevScrollTop; // 非显式导航（编辑/过滤/勾选/存档重载…）：原地恢复，不自动滚动
      }
      tlAfterCalRender();
    }

    // 自动滚动到离今天最近的日期悬浮条（优先今天，其次最近未来日期，最后最后一个）
    // ⚠️ 用 tlScrollElToTop 而不是 scrollIntoView：`.ev-date` 吸顶后 rect 是「位移后」的位置，
    //    scrollIntoView 会误判「已在视口内」而不滚（与 2026-09-19 那个单向滚动 bug 同源）。
    function tlScrollToNearestDate(list) {
      if (!list) return;
      const headers = list.querySelectorAll('.ev-date[data-ev-date]');
      if (!headers.length) return;
      const today = tlFmtDate(new Date());
      let pick = null;
      // 1. 精确匹配今天
      for (let i = 0; i < headers.length; i++) if (headers[i].dataset.evDate === today) { pick = headers[i]; break; }
      // 2. 找最近未来日期
      if (!pick) for (let i = 0; i < headers.length; i++) if (headers[i].dataset.evDate > today) { pick = headers[i]; break; }
      // 3. 全是过去日期 → 滚到最后一个
      if (!pick) pick = headers[headers.length - 1];
      tlScrollElToTop(pick, list);
    }

    // 列表模式：< > 逐日移动「选中日」（金色描边随其移动）并滚动到该日
    function tlListNavDay(dir) {
      const list = document.getElementById('tlEvList');
      if (!list) return;
      const dates = Array.from(list.querySelectorAll('.ev-date[data-ev-date]')).map((h) => h.dataset.evDate);
      if (!dates.length) return;
      const today = tlFmtDate(new Date());
      const anchor = tlListSel || today;
      let idx = dates.indexOf(anchor);
      if (idx < 0) {
        // 锚点日不在列表（如今天无行程）：改以「最近未来日」为基准——dir>0 落在该未来日，dir<0 落在其前一日
        const fi = dates.findIndex((d) => d > today);
        if (fi < 0) idx = dates.length - 1;           // 全是过去日 → 以末日为基准
        else idx = (dir > 0) ? fi - 1 : fi;
      }
      const target = idx + dir;
      if (target < 0 || target >= dates.length) return;
      tlListSel = dates[target];
      // ⚠️ 用户要求：< > 只移动「选中日」高亮，不再滚动表身（与「今天」按钮区分）
      tlRenderEventsContent();
    }

    // 在明细里挑「要滚动到的日期标题」：精确命中 → 其后最近 → 其前最近 → 首个（＝附近位置回退）
    function tlPickScrollTarget(headers, ds) {
      if (!headers || !headers.length) return null;
      for (const h of headers) if (h.dataset.evDate === ds) return h;
      for (const h of headers) if (h.dataset.evDate > ds) return h;
      for (let i = headers.length - 1; i >= 0; i--) if (headers[i].dataset.evDate < ds) return headers[i];
      return headers[0];
    }
    // 把元素滚到 scroller 顶部（sticky 安全版，月/週明细 + 列表模式共用）
    // ⚠️ 坑：`.ev-date` 是 position:sticky，**被「吸顶」时它的 offsetTop / getBoundingClientRect()
    //    返回的是「位移后」的渲染位置（≈ 当前 scrollTop），不是布局位置**（Chrome 实测：吸顶后
    //    offsetTop === scroller.offsetTop + scrollTop）。于是「点更早的日期」时，目标标题正被吸在
    //    滚动口顶部 → 算出的目标 scrollTop 恰好等于当前 scrollTop → 永远滚不上去；点更晚的日期时
    //    标题在下方、没被吸顶，所以只有单向能滚（2026-09-19 用户报告的 bug）。
    //    修法：读真实布局位置前先把该元素的 sticky 临时摘掉（同步 reflow，同一帧内还原，不会闪）。
    //    只改 scroller.scrollTop，不触碰祖先滚动容器。
    function tlScrollElToTop(el, scroller, _n) {
      if (!el || !scroller) return;
      // 📎 滚动容器尚未布局（高度为 0）时，offsetTop/scrollTop 计算会失效；未布局则延后一帧重试（上限 60）
      if (!scroller.offsetHeight) { if ((_n || 0) < 60) requestAnimationFrame(() => tlScrollElToTop(el, scroller, (_n || 0) + 1)); return; }
      scroller.scrollTop = tlElAbsTop(el, scroller);
    }
    function tlScrollListToDate(list, scroller, ds) {
      if (!list || !scroller || !ds) return;
      tlScrollElToTop(tlPickScrollTarget(list.querySelectorAll('.ev-date[data-ev-date]'), ds), scroller);
    }
    // 元素在 scroller 内的「绝对布局 scrollTop」（sticky 安全：先临时摘 .ev-date 再读，见 tlScrollElToTop）
    function tlElAbsTop(el, scroller) {
      const prevPos = el.style.position;
      el.style.position = 'static';
      const next = (el.offsetParent && el.offsetParent === scroller.offsetParent)
        ? el.offsetTop - scroller.offsetTop - (scroller.clientTop || 0)
        : scroller.scrollTop + (el.getBoundingClientRect().top - scroller.getBoundingClientRect().top);
      el.style.position = prevPos;
      return next;
    }
    // 当前模式下真正可见/可滚动的「明细列表」元素（undone 勾选切换只重锚这一条）
    function tlActiveDetailList() {
      if (tlCalMode === 'list') return document.getElementById('tlEvList');
      if (tlCalMode === 'year') return document.getElementById('tlEvYearDayList');
      return document.getElementById('tlEvDayList'); // month / week / day
    }
    // 切换前：捕获「视口顶部日期组」及其在滚动容器内的相对偏移（用于切换后尽量不滚动）
    function tlViewportTopDateInfo(list) {
      if (!list) return null;
      const active = tlPickActiveDate(list); // 复用顶部 sticky 日期条判定（已是 sticky 安全版）
      if (!active) return null;
      const offset = active.getBoundingClientRect().top - list.getBoundingClientRect().top;
      return { date: active.dataset.evDate, offset: offset };
    }
    // 给定一组日期标题，挑与 ds 日期距离最小者（tie → 较晚日期）；ds 已被过滤掉时用来回落到「最近的未过滤组」
    function tlNearestDateHeader(headers, ds) {
      if (!headers || !headers.length) return null;
      const base = parseInt(ds.replace(/-/g, ''), 10);
      let best = null, bestD = Infinity;
      for (const h of headers) {
        const d = Math.abs(parseInt(h.dataset.evDate.replace(/-/g, ''), 10) - base);
        if (d < bestD || (d === bestD && best && h.dataset.evDate > best.dataset.evDate)) { bestD = d; best = h; }
      }
      return best;
    }
    // 切换后把列表重锚：锚点存活→保持原偏移（＝不滚动）；锚点被过滤掉→滚到最近未过滤组（置顶）
    function tlReanchorList(list, anchorDate, anchorOffset) {
      const headers = list.querySelectorAll('.ev-date[data-ev-date]');
      if (!headers.length) { tlUndoneScrollResult = null; return; }
      let target = null, survived = false;
      for (const h of headers) if (h.dataset.evDate === anchorDate) { target = h; survived = true; break; }
      if (!target) target = tlNearestDateHeader(headers, anchorDate);
      if (!target) { tlUndoneScrollResult = null; return; }
      const absTop = tlElAbsTop(target, list);
      list.scrollTop = survived ? (absTop - anchorOffset) : absTop;
      tlUndoneScrollResult = target.dataset.evDate;
    }
    // 「日/月」切换只显示在当前画面顶部（第一个可见）的日期标题条上：
    // active = 已滚过顶部、当前贴着顶部的那条日期标题（sticky 顶条）。
    function tlPickActiveDate(list) {
      const heads = list.querySelectorAll('.ev-date[data-ev-date]');
      if (!heads.length) return null;
      const topLine = list.getBoundingClientRect().top + 16; // 16px：容纳首条 margin-top 与容器内边距
      let active = null;
      for (let i = 0; i < heads.length; i++) {
        if (heads[i].getBoundingClientRect().top <= topLine) active = heads[i];
      }
      return active;
    }
    function tlUpdateActiveDate(list) {
      if (!list) return;
      const active = tlPickActiveDate(list);
      list.querySelectorAll('.ev-date[data-ev-date].active').forEach((h) => h.classList.remove('active'));
      if (active) active.classList.add('active');
    }
    function tlBindActiveDateScroll(list) {
      if (!list || list.dataset.activeBound === '1') return;
      list.dataset.activeBound = '1';
      let raf = 0;
      list.addEventListener('scroll', () => {
        if (raf) return;
        raf = requestAnimationFrame(() => { raf = 0; tlUpdateActiveDate(list); });
      }, { passive: true });
    }

    // ===== 上下区域可拖動分割（月/週共用）=====
    // 拖動横条调整「下方行程明细」高度：写成 CSS 变量 --ev-detail-h（百分比）
    // → 窗口尺寸变化时比例自然保持，无需重算。纯 UI 偏好：内存 + localStorage，绝不写回数据文件。
    const TL_SPLIT_MIN_PX = 56;        // 明细最小（宽/高）度（至少看得见一条日期条）
    const TL_SPLIT_TOP_MIN_PX = 120;   // 上区最小高度（仍看得见月格 / 时间网格）
    const TL_SPLIT_LEFT_MIN_PX = 220;  // 左右布局下左区（日历）最小宽度
    const TL_SPLIT_DEFAULT = 30;       // 默认占比（%）
    let tlSplitPct = null;
    function tlLoadSplitPct() {
      if (tlSplitPct != null) return tlSplitPct;
      let v = NaN;
      try { v = parseFloat(localStorage.getItem('tlCalDetailH')); } catch (e) {}
      tlSplitPct = (isFinite(v) && v >= 10 && v <= 80) ? v : TL_SPLIT_DEFAULT;
      return tlSplitPct;
    }
    function tlSaveSplitPct(v) {
      tlSplitPct = Math.min(80, Math.max(10, Math.round(v * 10) / 10));
      try { localStorage.setItem('tlCalDetailH', String(tlSplitPct)); } catch (e) {}
    }
    // 指针 → 明细 尺寸百分比（实时量 rect，不依赖缓存尺寸）；只写 CSS 变量，不落盘
    // horizontal 模式（左右布局）：用宽度 + clientX 写 --ev-detail-w；否则用高度 + clientY 写 --ev-detail-h
    function tlApplySplitFromPointer(wrap, clientX, clientY) {
      const horizontal = wrap.classList.contains('horizontal');
      const r = wrap.getBoundingClientRect();
      if (horizontal) {
        if (!r.width) return null;
        const maxPx = Math.max(TL_SPLIT_MIN_PX, r.width - TL_SPLIT_LEFT_MIN_PX);
        const px = Math.min(Math.max(TL_SPLIT_MIN_PX, r.right - clientX), maxPx);
        const pct = px / r.width * 100;
        wrap.style.setProperty('--ev-detail-w', pct + '%');
        return pct;
      }
      if (!r.height) return null;
      const maxPx = Math.max(TL_SPLIT_MIN_PX, r.height - TL_SPLIT_TOP_MIN_PX);
      const px = Math.min(Math.max(TL_SPLIT_MIN_PX, r.bottom - clientY), maxPx);
      const pct = px / r.height * 100;
      wrap.style.setProperty('--ev-detail-h', pct + '%');
      return pct;
    }
    // 绑一次即可（重渲染换了新元素才会再绑）；每次调用都重新套用已存占比
    function tlBindSplit(wrap, split) {
      if (!wrap || !split) return;
      const pct0 = tlLoadSplitPct();
      wrap.style.setProperty('--ev-detail-h', pct0 + '%');
      wrap.style.setProperty('--ev-detail-w', pct0 + '%');
      if (split.dataset.splitBound === '1') return;
      split.dataset.splitBound = '1';
      let dragging = false;
      split.addEventListener('pointerdown', (e) => {
        if (e.button !== 0) return;
        dragging = true;
        split.classList.add('dragging');
        try { split.setPointerCapture(e.pointerId); } catch (err) {}
        e.preventDefault();   // 防止拖动时选中文本
      });
      // 有了 pointer capture，move/up 都会派发到 split 自身
      split.addEventListener('pointermove', (e) => {
        if (!dragging) return;
        if ((e.buttons & 1) !== 1) { dragging = false; split.classList.remove('dragging'); return; }
        tlApplySplitFromPointer(wrap, e.clientX, e.clientY);
      });
      const end = (e) => {
        if (!dragging) return;
        dragging = false;
        split.classList.remove('dragging');
        try { split.releasePointerCapture(e.pointerId); } catch (err) {}
        const pct = tlApplySplitFromPointer(wrap, e.clientX, e.clientY);
        if (pct != null) tlSaveSplitPct(pct);   // 松手才落盘
      };
      split.addEventListener('pointerup', end);
      split.addEventListener('pointercancel', end);
      split.addEventListener('dblclick', () => {
        tlSaveSplitPct(TL_SPLIT_DEFAULT);
        wrap.style.setProperty('--ev-detail-h', TL_SPLIT_DEFAULT + '%');
        wrap.style.setProperty('--ev-detail-w', TL_SPLIT_DEFAULT + '%');
      });
    }

    // ===== 上下 / 左右 布局切换（纯 UI 偏好，localStorage，绝不落盘数据文件）=====
    const TL_LAYOUT_KEY = 'tlCalSplitLayout';
    // 套用已存偏好：给三个 .ev-split 容器（周/月/年）统一加/去 .horizontal，并同步切换按钮文案
    function tlApplyCalLayout() {
      let horizontal = false;
      try { horizontal = localStorage.getItem(TL_LAYOUT_KEY) === '1'; } catch (e) {}
      ['tlEvWeekWrap', 'tlEvMonthWrap', 'tlEvYearWrap'].forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.classList.toggle('horizontal', horizontal);
      });
      const btn = document.getElementById('tlCalLayoutBtn');
      // 圆形图标钮：▤＝上下、▥＝左右；.active 高亮表示当前为左右布局（颜色即状态）
      if (btn) {
        btn.textContent = horizontal ? '▥' : '▤';
        btn.title = horizontal ? '当前：左右布局（点击切换为上下）' : '当前：上下布局（点击切换为左右）';
        btn.classList.toggle('active', horizontal);
      }
    }
    // 切换：读当前（以月视图容器为准，三容器状态一致），翻转后存盘并重套
    function tlToggleCalLayout() {
      const cur = (() => { const el = document.getElementById('tlEvMonthWrap'); return el && el.classList.contains('horizontal'); })();
      try { localStorage.setItem(TL_LAYOUT_KEY, cur ? '0' : '1'); } catch (e) {}
      tlApplyCalLayout();
    }

    const TL_TOOLBAR_EXPOSE_KEY = 'tlCalToolbarExposed.v2';  // .v2：新增 glossary 时升版，旧偏好重置为全选（新功能首次可见）
    function tlInitCalendarToolbarCombo() {
      const combo = document.getElementById('tlEvToolbarCombo');
      const exposed = document.getElementById('tlEvToolbarExposed');
      const trigger = document.getElementById('tlEvToolbarComboTrigger');
      const menu = document.getElementById('tlEvToolbarComboMenu');
      if (!combo || !exposed || !trigger || !menu || combo.dataset.initialized === '1') return;
      combo.dataset.initialized = '1';

      const definitions = [
        { key: 'layout', id: 'tlCalLayoutBtn' },
        { key: 'sticky', id: 'tlStickyWrap' },
        { key: 'stats', id: 'tlEvStatsBtn' },
        { key: 'includes', id: 'tlIncludeListBtn' },
        { key: 'glossary', id: 'tlGlossaryBtn' }
      ];
      const controls = new Map();
      let selected = definitions.map(item => item.key);
      try {
        const stored = JSON.parse(localStorage.getItem(TL_TOOLBAR_EXPOSE_KEY) || 'null');
        if (Array.isArray(stored)) selected = stored.filter(key => definitions.some(item => item.key === key));
      } catch (error) {
        console.warn('[TodoList] 读取日历工具列偏好失败:', error);
      }

      const items = new Map();
      definitions.forEach(item => {
        const control = document.getElementById(item.id);
        if (!control) return;
        controls.set(item.key, item.key === 'sticky' ? control.querySelector('#tlStickyBtn') : control);
        const wrapper = document.createElement('span');
        wrapper.className = 'ev-toolbar-combo-item';
        wrapper.dataset.toolbarItem = item.key;
        if (item.key === 'sticky') {
          wrapper.appendChild(control);
        } else {
          const parent = control.parentElement;
          if (parent && parent !== combo) parent.removeChild(control);
          wrapper.appendChild(control);
        }
        exposed.appendChild(wrapper);
        items.set(item.key, wrapper);
      });

      const checkboxes = Array.from(menu.querySelectorAll('input[data-toolbar-expose]'));
      const apply = () => {
        checkboxes.forEach(input => {
          const key = input.getAttribute('data-toolbar-expose');
          const wrapper = items.get(key);
          input.checked = selected.includes(key);
          if (wrapper) wrapper.hidden = !input.checked;
        });
      };
      const closeMenu = () => {
        menu.classList.remove('open');
        trigger.setAttribute('aria-expanded', 'false');
      };

      apply();
      trigger.addEventListener('click', event => {
        event.stopPropagation();
        const open = !menu.classList.contains('open');
        menu.classList.toggle('open', open);
        trigger.setAttribute('aria-expanded', String(open));
      });
      menu.addEventListener('click', event => event.stopPropagation());
      menu.querySelectorAll('button[data-toolbar-action]').forEach(button => {
        button.addEventListener('click', () => {
          const key = button.getAttribute('data-toolbar-action');
          closeMenu();
          const control = controls.get(key);
          if (control) { control.click(); return; }
          // alarms 没进 controls（不是 checkbox toggle 按钮），直接调函数
          if (key === 'alarms' && typeof tlOpenAlarmPreview === 'function') tlOpenAlarmPreview();
        });
      });
      checkboxes.forEach(input => input.addEventListener('change', () => {
        const key = input.getAttribute('data-toolbar-expose');
        selected = input.checked ? Array.from(new Set(selected.concat(key))) : selected.filter(item => item !== key);
        apply();
        try { localStorage.setItem(TL_TOOLBAR_EXPOSE_KEY, JSON.stringify(selected)); }
        catch (error) { console.warn('[TodoList] 保存日历工具列偏好失败:', error); }
      }));
      document.addEventListener('click', event => {
        if (!combo.contains(event.target)) closeMenu();
      });
    }

    function tlRenderMonth(content) {
      tlCalEvents = tlAllEvents(content);
      tlCalHolidays = tlAllHolidays(content);
      tlCalDiaries = tlAllDiaries(content);
      const cur = tlCalCursor;
      const y = cur.getFullYear(), m = cur.getMonth();
      // 重複展開視窗：當月 + 前後 7 天（網格含跨月首尾週），避免 never 無限展開
      const mFirst = new Date(y, m, 1), mLast = new Date(y, m + 1, 0);
      tlSetRepeatWindow(tlFmtDate(new Date(y, m, 1 - 7)), tlFmtDate(mLast));
      const occByDate = {};
      tlCalEvents.filter(tlEventShown).forEach((ev) => {
        tlEventOccurrences(ev).forEach((o) => { (occByDate[o.date] = occByDate[o.date] || []).push(o); });
      });
      if (!tlCalSelected) tlCalSelected = tlFmtDate(new Date());
      const today = tlFmtDate(new Date());
      const first = new Date(y, m, 1);
      const offset = (first.getDay() + 6) % 7;
      const start = new Date(y, m, 1 - offset);
      let html = ['一', '二', '三', '四', '五', '六', '日'].map((h) => '<div class="ev-mc-head">' + h + '</div>').join('');
      for (let i = 0; i < 42; i++) {
        const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
        const ds = tlFmtDate(d);
        const out = d.getMonth() !== m;
        const occ = (occByDate[ds] || []).slice().sort(tlOccSort);
        const hols = tlHolidaysOnDay(ds);
        let chips = '';
        // ## HOLIDAY：月格 chip（与 EVENT 视觉区隔：type 色块＋图标徽章）
        for (let k = 0; k < Math.min(2, hols.length); k++) {
          const region = tlHolidayRegionMeta(hols[k].region);
          chips += '<span class="ev-holiday-chip" style="--holiday-color:' + tlEscapeHtml(region.color) + '" title="' + tlEscapeHtml(hols[k].title) + '">' + region.icon + tlEscapeHtml(region.label) + '</span>';
        }
        if (hols.length > 2) chips += '<div class="ev-more">+' + (hols.length - 2) + '</div>';
        // 事件 chip（假日占用空间时收紧上限，避免月格溢出）
        const evCap = hols.length ? 2 : 3;
        for (let j = 0; j < Math.min(evCap, occ.length); j++) {
          chips += tlSpanChipHtml(occ[j].ev, occ[j].pos, occ[j].idx, occ[j].total, occ[j].date);
        }
        if (occ.length > evCap) chips += '<div class="ev-more">+' + (occ.length - evCap) + '</div>';
        const cp = tlLunarCompact(ds);
        const lunarCls = 'ev-lunar' + (cp.jieqi ? ' jieqi' : '');
        const lunarSpan = cp.text
          ? '<span class="' + lunarCls + '" onclick="event.stopPropagation();tlShowAlmanac(\'' + ds + '\',this)" title="農民曆 / 老黃曆">' + tlEscapeHtml(cp.text) + '</span>'
          : '';
        // 📕 当天有日记 → 日期数字旁挂一枚小图标（与日期标题上的「日记按钮」同图标，日期一眼可辨）
        const diaryMark = tlDiaryMarkHtml(ds);
        html += '<div class="ev-cell' + (out ? ' out' : '') + (ds === today ? ' today' : '') + (ds === tlCalSelected ? ' selected' : '') +
          '" data-date="' + ds + '" onclick="tlSelectDate(\'' + ds + '\')"><span class="ev-daynum">' + d.getDate() + '</span>' + diaryMark + lunarSpan + chips + '</div>';
      }
      const grid = document.getElementById('tlEvMonthGrid');
      if (grid) grid.innerHTML = html;
      tlBindSplit(document.getElementById('tlEvMonthWrap'), document.getElementById('tlEvMonthSplit'));
      tlRenderDayList();
      if (tlMonthAutoScrollPending) {
        tlMonthAutoScrollPending = false;
        tlScrollMonthToToday();
      }
    }

    // 月视图：若「选中日」日期格未完整显示在滚动区内，则平滑滚动到可视区中央
    //   （tlCalSelected 为今天时即原「今天」行为；便利贴「滚动」会预先把选中日设到目标行程日期）
    function tlScrollMonthToToday(_n) {
      const target = (tlCalSelected && document.querySelector('#tlEvMonthGrid .ev-cell[data-date="' + tlCalSelected + '"]'))
        || document.querySelector('#tlEvMonthGrid .ev-cell.today');
      const scroller = document.querySelector('#tlEvMonthWrap .ev-month-scroll');
      if (!target || !scroller) return;
      // 📎 容器尚未布局（rect 全 0）时误判已显示而跳过；未布局则延后一帧重试（上限 60）
      if (!scroller.offsetHeight) { if ((_n || 0) < 60) requestAnimationFrame(() => tlScrollMonthToToday((_n || 0) + 1)); return; }
      const sr = scroller.getBoundingClientRect();
      const cr = target.getBoundingClientRect();
      // 已完整显示：无需滚动
      if (cr.top >= sr.top && cr.bottom <= sr.bottom) return;
      target.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    }

    // 月格單擊＝選日；400ms 內連點同一天＝快速新增。
    // ⚠️ 不能用原生 dblclick：單擊會整格重繪 innerHTML，第二次點擊落在新節點上，
    //    瀏覽器視為不同目標，dblclick 事件根本不會派發（實測）——必須手動檢測。
    let tlLastCellClick = { date: null, t: 0 };
    function tlSelectDate(ds) {
      const now = Date.now();
      const isDbl = tlLastCellClick.date === ds && (now - tlLastCellClick.t) < 400;
      tlLastCellClick = isDbl ? { date: null, t: 0 } : { date: ds, t: now };
      tlCalSelected = ds;
      if (isDbl) { tlOpenEventForm(null, ds); return; }
      tlDetailListScrollPending = true; // 显式点选日期：明细滚到该日
      tlRenderMonth(document.getElementById('taskText').value);
    }

    // ===== 🛠 今日开工设定（纯函数区；回归 /tmp/start-work-test.cjs 以 slice 抽取） =====
    // 前一天＝本地日历日回退一天（不用时间戳相减，避开 DST / 时区偏移；跨月跨年交给 Date 归一化）
    function tlStartWorkDayBefore(todayStr) {
      const m = String(todayStr || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
      if (!m) return '';
      return tlFmtDate(new Date(+m[1], +m[2] - 1, +m[3] - 1));
    }
    // 「开始日期与结束日期都是同一天」＝没有 endDate，或 endDate 与 date 相同
    function tlStartWorkIsSingleDay(ev) {
      if (!ev || !ev.date) return false;
      return !ev.endDate || ev.endDate === ev.date;
    }
    // 候选＝主档（tlParseEvents 不含 include 的 ro 行程）里「前一天的单日行程」。
    // 排除重复行程：它自己会展开到今天，再复制一份只会重复显示。
    function tlStartWorkCandidates(md, todayStr) {
      const yesterday = tlStartWorkDayBefore(todayStr);
      const list = tlSorted((tlParseEvents(md) || []).filter(function (ev) {
        return ev.date === yesterday && tlStartWorkIsSingleDay(ev) && !ev.repeatMode && !ev.ro;
      }));
      return { today: todayStr, yesterday: yesterday, list: list };
    }
    // 今天已存在的标题（含跨天覆盖今天的行程）→ 避免「开工」重复建档
    function tlStartWorkExistingTitles(md, todayStr) {
      const set = new Set();
      (tlParseEvents(md) || []).forEach(function (ev) {
        const hit = ev.date === todayStr ||
          (ev.endDate && ev.date && ev.date <= todayStr && todayStr <= ev.endDate);
        if (hit) set.add(String(ev.title || '').trim());
      });
      return set;
    }
    // 复制成「今日行程」：日期改今天、完成状态重设为未完成、重复设定不带过来；
    // ⚠️ 只复制「标题＋排程骨架」（时间／地点／标签／颜色／便利贴数），**备注（内容／子事件）清空**——
    // 用户只要一个有标题的空框架，今天的明细会自己输入，不应把昨天的 checklist 一并带过来。
    function tlStartWorkCloneEvent(ev, todayStr) {
      return {
        uid: tlGenId(),
        title: ev.title || '',
        date: todayStr,
        endDate: '',
        spanDisplay: (ev.spanDisplay === 'first' || ev.spanDisplay === 'last' || ev.spanDisplay === 'today') ? ev.spanDisplay : 'daily',
        allDay: !!ev.allDay,
        done: false,
        startTime: ev.startTime || '',
        endTime: ev.endTime || '',
        location: ev.location || '',
        color: ev.color || TL_CAL_COLORS[0],
        sticky: Math.max(0, parseInt(ev.sticky, 10) || 0),
        tags: Array.isArray(ev.tags) ? ev.tags.slice() : [],
        todoIds: Array.isArray(ev.todoIds) ? ev.todoIds.slice() : [],
        notes: '',
        repeatMode: '', repeatInterval: '', repeatWeekDay: [], repeatMonthDay: '',
        repeatYearMonthDay: '', repeatEndType: 'never', repeatEndValue: '', repeatExcludeDates: []
      };
    }
    // ===== 🛠 今日开工设定（DOM / 交互区） =====
    let tlStartWorkRows = [];
    function tlStartWorkClose() {
      const ov = document.getElementById('tlStartWorkOverlay');
      if (ov) ov.style.display = 'none';
      tlStartWorkRows = [];
    }
    function tlStartWorkMeta(ev) {
      const bits = [];
      if (ev.allDay) bits.push('全天');
      else if (ev.startTime || ev.endTime) bits.push(String(ev.startTime || '') + (ev.endTime ? '–' + ev.endTime : ''));
      if (ev.location) bits.push('📍' + ev.location);
      if (Array.isArray(ev.tags) && ev.tags.length) bits.push(ev.tags.join(' / '));
      if (ev.done) bits.push('已完成');
      return bits.join(' · ');
    }
    function tlStartWorkUpdateCount() {
      const boxes = Array.prototype.slice.call(document.querySelectorAll('#tlStartWorkBody .tl-sw-check'));
      const on = boxes.filter(function (b) { return b.checked; }).length;
      const usable = boxes.filter(function (b) { return !b.disabled; }).length;
      const cnt = document.getElementById('tlStartWorkCount');
      if (cnt) cnt.textContent = '已勾选 ' + on + ' / 可建立 ' + usable + ' 项';
      const go = document.getElementById('tlStartWorkGo');
      if (go) go.disabled = (on === 0);
    }
    function tlStartWorkToggleAll(on) {
      document.querySelectorAll('#tlStartWorkBody .tl-sw-check').forEach(function (b) {
        if (!b.disabled) b.checked = !!on;
      });
      tlStartWorkUpdateCount();
    }
    function tlStartWorkRender(md, todayStr) {
      const body = document.getElementById('tlStartWorkBody');
      if (!body) return;
      const res = tlStartWorkCandidates(md, todayStr);
      const exists = tlStartWorkExistingTitles(md, todayStr);
      tlStartWorkRows = res.list.map(function (ev) {
        return {
          uid: ev.uid, title: ev.title, color: ev.color, meta: tlStartWorkMeta(ev),
          exists: exists.has(String(ev.title || '').trim())
        };
      });
      const dateEl = document.getElementById('tlStartWorkDate');
      if (dateEl) dateEl.textContent = todayStr;
      const sub = document.getElementById('tlStartWorkSub');
      if (sub) sub.innerHTML = '参考 <b>' + tlEscapeHtml(res.yesterday) + '</b>（前一天）「开始与结束同一天」的行程；勾选后按「开工」，在 <b>' + tlEscapeHtml(todayStr) + '</b> 建立同样的行程并存档。重复行程、跨天行程、外部档只读行程不列入。';
      if (!tlStartWorkRows.length) {
        body.innerHTML = '<div class="tl-sw-empty">前一天（' + tlEscapeHtml(res.yesterday) + '）没有可参考的单日行程。<br>可先在前一天建立行程，或改用右键「＋ 新增今日行程」。</div>';
      } else {
        body.innerHTML = tlStartWorkRows.map(function (r, i) {
          return '<label class="tl-sw-row' + (r.exists ? ' is-exists' : '') + '">' +
            '<input type="checkbox" class="tl-sw-check" data-sw-i="' + i + '"' + (r.exists ? ' disabled' : '') + ' onchange="tlStartWorkUpdateCount()">' +
            '<span class="tl-sw-dot" style="background:' + tlEscapeHtml(r.color || '#888888') + '"></span>' +
            '<span class="tl-sw-main"><span class="tl-sw-title">' + tlEscapeHtml(r.title) + '</span>' +
            (r.meta ? '<span class="tl-sw-meta">' + tlEscapeHtml(r.meta) + '</span>' : '') + '</span>' +
            (r.exists ? '<span class="tl-sw-exists">今日已存在</span>' : '') +
            '</label>';
        }).join('');
      }
      tlStartWorkUpdateCount();
    }
    function tlStartWorkOpen() {
      if (!isCalendarMdDoc() || !calEventsView) { showToast('请先开启 calendar.md 的行程视图', 'danger'); return; }
      const ta = document.getElementById('taskText');
      if (!ta) return;
      tlStartWorkRender(ta.value, tlFmtDate(new Date()));
      const ov = document.getElementById('tlStartWorkOverlay');
      if (ov) ov.style.display = 'flex';
    }
    async function tlStartWorkApply() {
      const picks = [];
      document.querySelectorAll('#tlStartWorkBody .tl-sw-check:checked').forEach(function (b) {
        const i = parseInt(b.getAttribute('data-sw-i'), 10);
        if (tlStartWorkRows[i]) picks.push(tlStartWorkRows[i]);
      });
      if (!picks.length) { showToast('请先勾选要建立的行程', 'danger'); return; }
      const ta = document.getElementById('taskText');
      if (!ta) return;
      const today = tlFmtDate(new Date());
      // 开窗期间缓冲可能已被改动 → 以当下内容重新判定候选与重复，绝不盲写
      const fresh = tlStartWorkCandidates(ta.value, today).list;
      const exists = tlStartWorkExistingTitles(ta.value, today);
      const chosen = picks.filter(function (p) {
        return !exists.has(String(p.title || '').trim()) && fresh.some(function (f) { return f.uid === p.uid; });
      });
      if (!chosen.length) { tlStartWorkClose(); showToast('没有可建立的行程（内容已变更或今天已存在）', 'danger'); return; }
      tlCalSelected = today;
      tlCalEvents = tlAllEvents(ta.value);
      chosen.forEach(function (p) {
        const src = fresh.find(function (f) { return f.uid === p.uid; });
        if (src) tlCalEvents.push(tlStartWorkCloneEvent(src, today));
      });
      tlApplyEventsToBuffer();
      let saved = false;
      try {
        saved = (typeof saveTask === 'function') ? !!(await saveTask(false, true, true)) : false;
      } catch (e) { saved = false; }
      tlStartWorkClose();
      showToast(saved
        ? ('已在 ' + today + ' 建立 ' + chosen.length + ' 笔行程并存档')
        : ('已建立 ' + chosen.length + ' 笔行程到缓冲，但尚未确认存档成功'),
        saved ? 'success' : 'danger');
    }
    function tlStartWorkHideMenu() {
      const m = document.getElementById('tlStartWorkCtxMenu');
      if (m) m.style.display = 'none';
    }
    function tlStartWorkShowMenu(x, y, todayStr) {
      let menu = document.getElementById('tlStartWorkCtxMenu');
      if (!menu) {
        menu = document.createElement('div');
        menu.id = 'tlStartWorkCtxMenu';
        menu.className = 'tl-startwork-ctx-menu';
        menu.setAttribute('role', 'menu');
        menu.style.display = 'none';
        menu.innerHTML =
          '<button type="button" data-sw-act="start" role="menuitem">1. 🛠 今日开工设定</button>' +
          '<button type="button" data-sw-act="add" role="menuitem">2. ＋ 新增今日行程</button>' +
          '<div class="tl-startwork-ctx-hint" id="tlStartWorkCtxHint"></div>';
        document.body.appendChild(menu);
        menu.addEventListener('click', function (ce) {
          const btn = ce.target.closest ? ce.target.closest('[data-sw-act]') : null;
          if (!btn) return;
          menu.style.display = 'none';
          const act = btn.getAttribute('data-sw-act');
          if (act === 'start') tlStartWorkOpen();
          else if (act === 'add' && typeof tlOpenEventForm === 'function') tlOpenEventForm(null, tlFmtDate(new Date()));
        });
      }
      const hint = menu.querySelector('#tlStartWorkCtxHint');
      if (hint) hint.textContent = '今天（' + todayStr + '）· 日期格或「今天」按钮右键可用';
      menu.style.display = 'block';
      const pw = menu.offsetWidth || 208, ph = menu.offsetHeight || 100;
      let left = x, top = y;
      if (left + pw > window.innerWidth - 8) left = window.innerWidth - pw - 8;
      if (top + ph > window.innerHeight - 8) top = window.innerHeight - ph - 8;
      menu.style.left = Math.max(4, left) + 'px';
      menu.style.top = Math.max(4, top) + 'px';
    }
    // 今天的日期格 / 顶列「今天」按钮 右键 → 下拉菜单；
    // 其它日期 / 行程卡片 / 标签 / 表单浮层一律放行给原处理器。
    // ⚠️ 只收自己的菜单：行程卡片右键菜单由 tlShowEventCtxMenu 自己管，收掉它会让卡片右键「没反应」。
    // ⚠️ isCalendarMdDoc() 依赖宿主 currentFileTarget，必须等命中「今天日期格或今天按钮」才呼叫（避免影响其它右键链路）。
    // ⚠️ #tlEvTodayBtn 语义恒为今天、不带 data-date，所以只有日期格才需要比对 data-date；左键「回到今天」不受影响。
    document.addEventListener('contextmenu', function (e) {
      tlStartWorkHideMenu();
      const t = e.target;
      if (!t || !t.closest) return;
      if (t.closest('[data-tag]') || t.closest('[data-uid]') || t.closest('.tl-ev-form-overlay')) return;
      const todayBtn = t.closest('#tlEvTodayBtn');
      const cell = todayBtn ? null : t.closest('.ev-cell[data-date], .ev-year-day[data-date], .ev-tg-head-cell[data-date], .ev-allday-col[data-date], .ev-tg-col[data-date]');
      if (!todayBtn && !cell) return;
      const today = tlFmtDate(new Date());
      if (cell && cell.getAttribute('data-date') !== today) return;
      if (!isCalendarMdDoc() || !calEventsView) return;
      e.preventDefault();
      tlStartWorkShowMenu(e.clientX, e.clientY, today);
    });
    document.addEventListener('click', function () { tlStartWorkHideMenu(); }, true);
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      const m = document.getElementById('tlStartWorkCtxMenu');
      if (m && m.style.display !== 'none') { m.style.display = 'none'; e.preventDefault(); return; }
      const ov = document.getElementById('tlStartWorkOverlay');
      if (ov && ov.style.display !== 'none') { tlStartWorkClose(); e.preventDefault(); }
    });

    function tlRenderDayList() {
      const list = document.getElementById('tlEvDayList');
      if (!list) return;
      const prevScrollTop = list.scrollTop; // 渲染前记录（确定性还原依据，不依赖缓存）
      const today = tlFmtDate(new Date());
      // 重複展開視窗：整月＝當月 + 前 7 天（含跨月首尾週）；單日＝選定日當天
      if (tlCalScope === 'full') {
        const mo = tlCalCursor.getMonth(), my = tlCalCursor.getFullYear();
        const mLast = new Date(my, mo + 1, 0);
        tlSetRepeatWindow(tlFmtDate(new Date(my, mo, 1 - 7)), tlFmtDate(mLast));
      } else {
        tlSetRepeatWindow(tlCalSelected || today, tlCalSelected || today);
      }
      const toggle = tlScopeToggleHtml();
      // 「月」范围：渲染游标月整月（按日期分组，只含该月开始的事件/假日），头部显示汇总 + 切换
      if (tlCalScope === 'full') {
        const mo = tlCalCursor.getMonth();
        const prefix = tlCalCursor.getFullYear() + '-' + String(mo + 1).padStart(2, '0');
        const byDate = tlEventsByDate(tlCalEvents.filter(tlEventShown), (ds) => typeof ds === 'string' && ds.slice(0, 7) === prefix);
        const dates = Array.from(byDate.keys()).sort();
        let total = 0;
        byDate.forEach((g) => { total += g.events.length + g.holidays.length; });
        // toggle 内联进每个日期标题条，随 sticky 让「第一笔可见日期」始终带切换控件；
        // 整月无内容时才退回独立汇总条放 toggle，保证切换仍可达
        let html = '';
        if (!dates.length) html += '<div class="ev-date active">' + (mo + 1) + '月 <span class="ev-week">全部 ' + total + ' 条</span>' +
          '<span style="flex:1"></span>' + toggle + '</div><div class="ev-empty">本月没有行程</div>';
        else {
          for (let i = 0; i < dates.length; i++) {
            const grp = byDate.get(dates[i]);
            let g = tlDateHeader(dates[i], today, toggle, grp.events.length + grp.holidays.length);
            for (const h of grp.holidays) g += tlHolidayHtml(h, today, dates[i]);
            for (const ev of tlSorted(grp.events)) g += tlItemHtml(ev, today, dates[i]);
            html += (dates[i] === tlCalSelected) ? '<div class="ev-date-group sel-date">' + g + '</div>' : g;
          }
        }
        list.innerHTML = html;
        list.classList.add('scope-follow');
        tlBindActiveDateScroll(list);
        // 整月：仅显式导航才滚到「选中日」日期条；编辑存档/过滤/搜索/切范围均不自动滚动
        if (tlDetailListScrollPending) { tlDetailListScrollPending = false; tlScrollListToDate(list, list, tlCalSelected); }
        else { list.scrollTop = prevScrollTop; }
        tlUpdateActiveDate(list);
        tlAfterCalRender();
        return;
      }
      // 「日」范围（默认）：选定日单日
      const ds = tlCalSelected || tlFmtDate(new Date());
      const dayItems = tlDayItems(ds);
      const evs = tlSorted(dayItems.events);
      const hols = dayItems.holidays;
      // 与「月」范围/列表模式共用 tlDateHeader（含倒计时/农历/日记按钮），避免两范围头部不一致
      let html = tlDateHeader(ds, today, toggle, evs.length + hols.length);
      if (!evs.length && !hols.length) html += '<div class="ev-empty">这一天没有行程</div>';
      else {
        for (const h of hols) html += tlHolidayHtml(h, today, ds);
        for (const ev of evs) html += tlItemHtml(ev, today, ds);
      }
      list.classList.remove('scope-follow');
      list.innerHTML = html;
      tlAfterCalRender();
    }

    // ===== 新增 / 编辑 / 删除（写入 taskText 缓冲） =====
    // 🗓 表單日期輸入框旁的星期提示：根據輸入的日期即時顯示「（星期五）」；結束日留空則清除
    function tlUpdateFormDow() {
      const WD = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
      const set = (id, val) => {
        const el = document.getElementById(id);
        if (!el) return;
        const m = String(val || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
        el.textContent = m ? '（' + WD[new Date(+m[1], +m[2] - 1, +m[3]).getDay()] + '）' : '';
      };
      set('tlEvFDateDow', document.getElementById('tlEvFDate') && document.getElementById('tlEvFDate').value);
      set('tlEvFEndDateDow', document.getElementById('tlEvFEndDate') && document.getElementById('tlEvFEndDate').value);
      // 📅 農民曆 / 老黃曆：日期輸入框旁即時顯示農曆日（或節氣），點擊開老黃曆詳情
      const setLunar = (id, val) => {
        const el = document.getElementById(id);
        if (!el) return;
        const cp = tlLunarCompact(val);
        el.textContent = cp.jieqi || cp.lunarText || '';
      };
      setLunar('tlEvFDateLunar', document.getElementById('tlEvFDate') && document.getElementById('tlEvFDate').value);
      setLunar('tlEvFEndDateLunar', document.getElementById('tlEvFEndDate') && document.getElementById('tlEvFEndDate').value);
    }

    // 🆕 编辑行程窗体的「只读模式」单一可信来源（用户 2026-11-04）：
    //    INCLUDE 进来的外部档行程（ev.ro）原本连窗体都打不开，现在开成「查看行程（只读）」。
    //    · input / select / button → disabled（键盘也进不去）；textarea → readOnly（仍可选中复制、卷动、闪烁定位）
    //    · 颜色 / 标签 / Todo 等非表单控件 → 由 overlay 的 .is-readonly CSS 关掉 pointer-events
    //    · 「关闭」按钮永远不 disabled；保存 / 删除 / ＋CheckBox 直接隐藏
    //    ⚠️ 必须在所有填值 + tlToggleAllDay / tlOnRepeatModeChange 之后呼叫：那些函数会重设 disabled，早设会被覆盖。
    function tlSetEventFormReadonly(ro, src) {
      const ov = document.getElementById('tlEvFormOverlay');
      if (!ov) return;
      const on = !!ro;
      tlEvFormReadOnly = on;
      tlEvFormReadOnlySrc = on ? String(src || '') : '';
      ov.classList.toggle('is-readonly', on);
      ov.querySelectorAll('input, select, textarea, button').forEach((el) => {
        if (el.id === 'tlEvFormCancel') { el.disabled = false; return; }
        if (el.tagName === 'TEXTAREA') { el.readOnly = on; el.disabled = false; }
        else el.disabled = on;
      });
      const title = document.getElementById('tlEvFormTitle');
      if (title) title.textContent = on ? '查看行程（只读）' : (tlEvFormUid ? '编辑行程' : '新增行程');
      const banner = document.getElementById('tlEvFormRoBanner');
      if (banner) {
        banner.style.display = on ? '' : 'none';
        banner.textContent = on
          ? ('🔒 只读 · 来自被包含的外部档 ' + (tlEvFormReadOnlySrc || 'calendar-*.md') + '（仅供查看；如需修改请开启该档案编辑）')
          : '';
      }
      const hint = document.getElementById('tlEvFormHint');
      if (hint) hint.textContent = on
        ? '此窗体不写回任何档案；便利贴内容仍可直接在便利贴窗修改并写回来源档。'
        : '写入后按编辑器「保存」，把改动写回 calendar.md';
      const del = document.getElementById('tlEvFormDelete');
      if (del) del.style.display = on ? 'none' : (tlEvFormUid ? '' : 'none');
      const save = document.getElementById('tlEvFormSave');
      if (save) save.style.display = on ? 'none' : '';
      const addCheck = document.getElementById('tlEvAddCheckBtn');
      if (addCheck) addCheck.style.display = on ? 'none' : '';
      const cancel = document.getElementById('tlEvFormCancel');
      if (cancel) cancel.textContent = on ? '关闭' : '取消';
      // 恢复可编辑时把「全天」对开始/结束时间的连带 disabled 重算回来（只读时全部被打开过）
      if (!on && typeof tlToggleAllDay === 'function') tlToggleAllDay();
    }

    function tlOpenEventForm(uid, defaultDate, pre) {
      tlHideTip();
      // 🆕 每次开窗体都重置来源（含 early return 路径），避免上一张便利贴窗体的标记残留到下一张主画面窗体。
      tlEvFormFromNote = !!(pre && pre.fromNote);
      if (!isCalendarMdDoc()) return;
      tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
      tlRenderTagOptions();
      tlEvFormUid = null;
      let ev = null;
      if (uid) {
        ev = tlCalEvents.find((x) => x.uid === uid);
        if (!ev) { showToast('找不到该条行程（内容可能已被修改）', 'danger'); return; }
        // 🆕 INCLUDE 外部档（ev.ro）不再 toast 拒绝：改成开启「只读查看」窗体（用户 2026-11-04）。
        //    主画面「编辑」按钮、便利贴双击 / 点标题栏、找出相同→切换 都走这里，自动得到同一张只读窗体。
        tlEvFormUid = uid;
      }
      const isRo = !!(ev && ev.ro);
      const roSrc = isRo ? String(ev.src || '') : '';
      const p = pre || {}; // 🖱 雙擊空白快速新增時的預填：{ allDay, startTime, endTime }；📄 Include 清单「＋」另带 { target: 文件名 }
      const today = tlFmtDate(new Date());
      document.getElementById('tlEvFormTitle').textContent = uid ? '编辑行程' : '新增行程';
      // 🆕 写入目标：只有「新增」才可换档；编辑既有行程恒为主文件（include 行程只开放「只读查看」，不写回）。
      //    下拉渲染完会回调 tlSyncEvTargetHint()：由它统一维护「标题 → 新增行程 / 新增行程 → xxx.md」与下方说明，
      //    因此这里不再重复写 #tlEvFormTitle（单一可信来源；只读标题由 tlSetEventFormReadonly 在最后统一设）。
      tlEvFormTarget = uid ? '' : String(p.target || '').trim();
      tlRenderEvTargetSelect(tlEvFormTarget);
      const targetRow = document.getElementById('tlEvFTargetRow');
      if (targetRow) targetRow.style.display = uid ? 'none' : '';
      document.getElementById('tlEvFTitle').value = ev ? ev.title : '';
      document.getElementById('tlEvFDate').value = ev ? ev.date : (defaultDate || (tlCalMode === 'month' ? tlCalSelected : today) || today);
      document.getElementById('tlEvFEndDate').value = ev ? (ev.endDate || '') : '';
      document.getElementById('tlEvFSpanDisplay').value = ev && (ev.spanDisplay === 'first' || ev.spanDisplay === 'last' || ev.spanDisplay === 'today') ? ev.spanDisplay : 'daily';
      // ===== 重複事件 =====
      // p.repeat：由「重复事件一览」的新增按钮传入 → 新增时直接进「重复」模式并带出起始日的星期
      const rMode = ev ? (ev.repeatMode || '') : (p.repeat ? 'weekly' : '');
      document.getElementById('tlEvFRepeatOn').checked = !!rMode;
      document.getElementById('tlEvFRepeatFields').style.display = rMode ? '' : 'none';
      document.getElementById('tlEvFRepeatMode').value = rMode || 'weekly';
      document.getElementById('tlEvFRepeatInterval').value = ev && ev.repeatInterval ? (parseInt(ev.repeatInterval, 10) || 1) : 1;
      tlRenderRepeatWeekDays(ev ? (ev.repeatWeekDay || []) : []);
      document.getElementById('tlEvFMonthDay').value = ev && ev.repeatMonthDay ? (parseInt(ev.repeatMonthDay, 10) || '') : '';
      document.getElementById('tlEvFYearMonthDay').value = ev && ev.repeatYearMonthDay ? String(ev.repeatYearMonthDay).replace(/^"|"$/g, '') : '';
      const rEnd = ev ? (ev.repeatEndType || 'never') : 'never';
      document.getElementById('tlEvFRepeatEndType').value = rEnd;
      document.getElementById('tlEvFRepeatEndValue').value = ev && ev.repeatEndValue != null ? String(ev.repeatEndValue) : '';
      document.getElementById('tlEvFRepeatExclude').value = (ev && ev.repeatExcludeDates && ev.repeatExcludeDates.length) ? ev.repeatExcludeDates.join(', ') : '';
      tlOnRepeatModeChange();
      tlOnRepeatEndTypeChange();
      if (!uid && p.repeat) tlToggleRepeat(); // 走既有入口：展开重复字段 + 自动勾上起始日所属星期
      tlUpdateFormDow(); // 🗓 依輸入日期即時顯示星期
      document.getElementById('tlEvFAllday').checked = ev ? ev.allDay : (p.allDay === true);
      // 完成状态：新增默认未完成（旧文件没有 - done 栏位时解析也是未完成）
      document.getElementById('tlEvFDone').checked = ev ? !!ev.done : false;
      document.getElementById('tlEvFStart').value = ev ? ev.startTime : (p.startTime || '');
      document.getElementById('tlEvFEnd').value = ev ? ev.endTime : (p.endTime || '');
      tlToggleAllDay();
      document.getElementById('tlEvFLocation').value = ev ? ev.location : '';
      tlEvFormColor = ev ? ev.color : TL_CAL_COLORS[0];
      tlEvFormSticky = ev ? (ev.sticky || 0) : 0;
      document.getElementById('tlEvFSticky').value = tlEvFormSticky;
      tlSyncStickyFlag();
      tlEvFormTags = tlNormalizeTags(ev && ev.tags ? ev.tags : []);
      document.getElementById('tlEvFTags').value = '';
      tlRenderTagPicker();
      document.getElementById('tlEvFNotes').value = ev ? ev.notes : '';
      // 删除按钮的显隐统一交给 tlSetEventFormReadonly（只读 / 新增 / 编辑 三态一次判完）
      tlEvFormTodoIds = ev ? (ev.todoIds || []).slice() : [];
      tlRenderEvTodoLinkPanel();
      tlRenderColors();
      // ⚠️ 只读态必须最后才套：上面 tlToggleAllDay / tlOnRepeatModeChange / tlRenderColors 会重设或重建控件。
      tlSetEventFormReadonly(isRo, roSrc);
      document.getElementById('tlEvFormOverlay').style.display = 'flex';
      tlEvFormDirty = false;
      tlAutoSizeNotes();
      // 只读时标题已 disabled（focus 无效）；备注框仍可 focus，供「找出相同→切换」的行闪烁定位使用。
      if (!isRo) document.getElementById('tlEvFTitle').focus();
      // 🆕 「找出相同的项目」切换定位：若带高亮行（0-based 行号区间），定位并闪烁备注框里那些行。
      //    延迟一帧确保 overlay 已显示、textarea 已渲染完成，再滚动＋选中＋金底闪烁两次。
      if (p && ((Array.isArray(p.highlightLines) && p.highlightLines.length) || p.highlightText)) {
        const hl = Array.isArray(p.highlightLines) ? p.highlightLines.map((x) => (+x || 0)).sort((a, b) => a - b) : [];
        setTimeout(function () { tlFlashEventFormLines(hl, p.highlightText); }, 60);
      }
    }
    // 🆕 把 Markdown 原文压成可跟「备注框原文」比对的形式：去掉链接目标 / [[…]] 标记 / 行首块级符号。
    //    用于「找出相同 → 切换」没拿到行号时的内容兜底定位。
    function tlPlainForMatch(s) {
      return String(s == null ? '' : s)
        .replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1')
        .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
        .replace(/\[\[[^\]]*\]\]/g, ' ')
        .replace(/^[\s>#*+~-]+/, ' ')
        .replace(/^\s*\d{1,9}[.)]\s*/, ' ')
        .replace(/[*_`~]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    }
    // 🆕 事件表单备注框命中行闪烁定位：「找出相同的项目」切换过来时，把备注框滚动到目标行、
    //   选中该行（浏览器原生选中即高亮），并叠加金底＋金环闪烁（4 秒）。
    //   lines 为空时用 text 兜底（按内容找行号），两者都没有就什么都不做。
    function tlFlashEventFormLines(lines, text) {
      const ta = document.getElementById('tlEvFNotes');
      if (!ta) return;
      let arr = Array.isArray(lines) ? lines.map((x) => (+x || 0)).sort((a, b) => a - b) : [];
      if (!arr.length && text) {
        const want = tlPlainForMatch(String(text).split('\n').map((l) => l.trim()).find((l) => l) || '');
        if (want.length >= 2) {
          const ls = String(ta.value || '').split('\n');
          for (let i = 0; i < ls.length; i += 1) {
            if (tlPlainForMatch(ls[i]).indexOf(want) >= 0) { arr = [i]; break; }
          }
        }
      }
      if (!arr.length) return;
      const start = Math.max(0, arr[0]);
      const end = Math.max(start, arr[arr.length - 1]);
      const value = ta.value || '';
      // 由 0-based 行号换算字符偏移（行号按 \n 计数；行首＝上一换行之后）
      function lineToOffset(targetLine) {
        let i = 0, ln = 0;
        while (i < value.length && ln < targetLine) { if (value[i] === '\n') ln++; i++; }
        return i;
      }
      const sOff = lineToOffset(start);
      let eOff = value.length;
      // end 行末尾＝下一换行之前（没有则到文末）
      (function () {
        let i = sOff, ln = start;
        while (i < value.length) {
          if (value[i] === '\n') { if (ln === end) { eOff = i; return; } ln++; }
          i++;
        }
        eOff = value.length;
      })();
      if (eOff < sOff) eOff = sOff;
      try { ta.focus(); ta.setSelectionRange(sOff, eOff); } catch (e) {}
      // 滚动到目标行（lineHeight 取实际计算值，退化 20px）
      try {
        const lh = parseFloat(getComputedStyle(ta).lineHeight) || (parseFloat(getComputedStyle(ta).fontSize) * 1.4) || 20;
        ta.scrollTop = Math.max(0, start * lh - ta.clientHeight / 3);
      } catch (e) {}
      ta.classList.remove('tl-evf-notes-flash');
      void ta.offsetWidth;   // 强制 reflow 重启动画
      ta.classList.add('tl-evf-notes-flash');
      // 🆕 4 秒（CSS 为 2s × 2 次脉冲）：与便利贴窗的命中闪烁时长一致，更醒目
      setTimeout(function () { ta.classList.remove('tl-evf-notes-flash'); }, 4200);
    }

    // 📝 開啟編輯/新增行程時，依備註內容自動加高 textarea（最多 15 行，不足 15 行按實際行數）
    function tlAutoSizeNotes() {
      const ta = document.getElementById('tlEvFNotes');
      if (!ta) return;
      ta.style.height = 'auto';
      const cs = getComputedStyle(ta);
      let lh = parseFloat(cs.lineHeight);
      if (!lh) lh = parseFloat(cs.fontSize) * 1.3;
      const pad = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
      const maxH = lh * 15 + pad;
      const h = Math.min(ta.scrollHeight, maxH);
      ta.style.height = h + 'px';
      ta.style.overflowY = ta.scrollHeight > maxH ? 'auto' : 'hidden';
    }

    function tlToggleAllDay() {
      const allDay = document.getElementById('tlEvFAllday').checked;
      document.getElementById('tlEvFStart').disabled = allDay;
      document.getElementById('tlEvFEnd').disabled = allDay;
    }

    // ===== ## EVENT(REPEAT) 表單控件 =====
    const TL_REPEAT_INTERVAL_UNIT = { daily: '天', weekly: '周', monthly: '月', yearly: '年' };
    function tlToggleRepeat() {
      const on = document.getElementById('tlEvFRepeatOn').checked;
      document.getElementById('tlEvFRepeatFields').style.display = on ? '' : 'none';
      if (on) {
        if (!document.getElementById('tlEvFRepeatMode').value) document.getElementById('tlEvFRepeatMode').value = 'weekly';
        if (!document.getElementById('tlEvFRepeatInterval').value) document.getElementById('tlEvFRepeatInterval').value = '1';
        const d = document.getElementById('tlEvFDate').value;
        if (d && !tlGetRepeatWeekDays().length) {
          const wd = TL_WD[new Date(d + 'T00:00:00').getDay()];
          tlSetWeekDay(wd, true);
        }
        tlOnRepeatModeChange();
        tlOnRepeatEndTypeChange();
      }
    }
    function tlRenderRepeatWeekDays(selected) {
      selected = selected || [];
      const labels = { sun: '日', mon: '一', tue: '二', wed: '三', thu: '四', fri: '五', sat: '六' };
      const box = document.getElementById('tlEvFWeekDays');
      if (!box) return;
      box.innerHTML = TL_WD.map((w) =>
        '<label class="tl-ev-f-wd"><input type="checkbox" data-wd="' + w + '"' + (selected.indexOf(w) >= 0 ? ' checked' : '') + ' onchange="tlOnWeekDayChange()">' + labels[w] + '</label>'
      ).join('');
    }
    function tlSetWeekDay(w, checked) {
      const el = document.querySelector('#tlEvFWeekDays input[data-wd="' + w + '"]');
      if (el) el.checked = checked;
    }
    function tlOnWeekDayChange() { /* 仅作委派占位，取值走 tlGetRepeatWeekDays */ }
    function tlGetRepeatWeekDays() {
      const els = document.querySelectorAll('#tlEvFWeekDays input[data-wd]:checked');
      return Array.prototype.map.call(els, (e) => e.getAttribute('data-wd'));
    }
    function tlOnRepeatModeChange() {
      const mode = document.getElementById('tlEvFRepeatMode').value;
      document.getElementById('tlEvFWeekDayBox').style.display = mode === 'weekly' ? '' : 'none';
      document.getElementById('tlEvFMonthDayBox').style.display = mode === 'monthly' ? '' : 'none';
      document.getElementById('tlEvFYearMonthDayBox').style.display = mode === 'yearly' ? '' : 'none';
      const unit = document.getElementById('tlEvFRepeatIntervalUnit');
      if (unit) unit.textContent = TL_REPEAT_INTERVAL_UNIT[mode] ? '（每 ' + TL_REPEAT_INTERVAL_UNIT[mode] + '）' : '';
    }
    function tlOnRepeatEndTypeChange() {
      const t = document.getElementById('tlEvFRepeatEndType').value;
      const box = document.getElementById('tlEvFEndValueBox');
      box.style.display = t === 'never' ? 'none' : '';
      const unit = document.getElementById('tlEvFEndValueUnit');
      const inp = document.getElementById('tlEvFRepeatEndValue');
      if (t === 'count') { unit.textContent = '（次）'; inp.type = 'number'; inp.placeholder = '如 20'; }
      else if (t === 'date') { unit.textContent = ''; inp.type = 'date'; inp.placeholder = ''; }
      else { unit.textContent = ''; inp.type = 'text'; inp.value = ''; }
    }
    // 规范化「每年月-日」：去掉可能存在的外层引号后统一加上，保证写回文件格式与用户一致（"MM-DD"）
    function tlNormalizeYmd(v) {
      v = (v || '').trim();
      if (!v) return '';
      if (v.length >= 2 && v[0] === '"' && v[v.length - 1] === '"') v = v.slice(1, -1);
      return '"' + v + '"';
    }

    function tlRenderColors() {
      const box = document.getElementById('tlEvFColors');
      if (!box) return;
      box.innerHTML = TL_CAL_COLORS.map((c) =>
        '<span class="sw' + (c === tlEvFormColor ? ' selected' : '') + '" data-color="' + c + '" style="background:' + c + '" onclick="tlPickColor(\'' + c + '\')"></span>'
      ).join('');
    }
    function tlPickColor(c) {
      if (tlEvFormReadOnly) return;
      tlEvFormColor = c;
      tlRenderColors();
    }

    function tlCloseEventForm(force = false) {
      if (!force && tlEvFormDirty) {
        showToast('行程编辑框有未保存内容，请按「取消」退出，或先写入编辑内容', 'danger');
        return false;
      }
      // 🆕 关闭编辑窗体＝**按来源决定要不要滚动**（用户 2026-11-04 两次说明后的最终规则）：
      //   · 从便利贴唤起（pre.fromNote=true）→ 关闭后必须滚动回「该行程」的位置；
      //   · 从主画面点「编辑」开的窗体 → 纯收起浮层，绝不动卷动位置，原来在哪里还是在哪里；
      //   · 删除（tlDeleteFromForm 先清 tlEvFormUid）→ 不滚动（事件已不在，滚动无意义）。
      //   写入路径：tlSaveEventForm → tlApplyEventsToBuffer() 已重绘且刻意不设锚点，主画面路径就停在原处；
      //   便利贴路径则在下面这个统一入口补做定位，不在保存函数里各写一份。
      const closingUid = tlEvFormUid;
      const backToNoteEvent = tlEvFormFromNote;
      const scrollAfterSave = tlEvFormScrollOnCloseUid === closingUid;
      const ov = document.getElementById('tlEvFormOverlay');
      if (ov) ov.style.display = 'none';
      tlEvFormUid = null;
      tlEvFormScrollOnCloseUid = null;
      tlEvFormFromNote = false;
      tlEvFormColor = null;
      tlEvFormTarget = '';
      tlEvFormDirty = false;
      // 🆕 复位只读态：下一张窗体可能是主档可编辑行程，不能带着 disabled / 隐藏按钮进去。
      tlSetEventFormReadonly(false, '');
      // 定位核心（tlScrollToEventByUid）与便利贴菜单「滚动」共用，避免两份实现漂移。
      if ((backToNoteEvent || scrollAfterSave) && closingUid) {
        try { tlScrollToEventByUid(closingUid); }
        catch (e) { console.warn('[TodoList] 编辑窗体关闭后定位失败:', e); }
      }
    }

    // 📋 备注「＋ CheckBox」：开小窗输入，保存后以 `- [ ] 内容` 追加到备注末尾（多行＝每行一个 checkbox）
    // 两种模式：tlAddCheckTargetUid=null＝编辑表单模式（追加到 #tlEvFNotes，等表单保存）；
    //          非空＝列表模式（追加到该事件备注后**直接存档**：写缓冲＋落盘 calendar.md，2026-10-10 用户需求）
    let tlAddCheckTargetUid = null;
    let tlEditNoteCheckTarget = null;
    let tlEditBlockTarget = null; // { uid, start, end, type } — 通用「最小 MD 区块」编辑区间
    let tlAddCheckDirty = false;
    // 🆕 「group 启用（唯一小事件）」：只在「编辑内容区块」出现，默认不启用；原本已整组时预勾。
    //    单一 setter：开任何对话框／关窗都走它，避免勾选状态跨模式残留。
    let tlGroupWasOn = false;
    function tlSyncGroupUi(src, hide) {
      const row = document.getElementById('tlGroupRow');
      const box = document.getElementById('tlGroupEnable');
      const label = row && row.querySelector('span');
      // 三种模式都提供：block＝编辑内容区块／check＝编辑 CheckBox 子事件／add＝建立 CheckBox 项目
      const mode = tlEditBlockTarget ? 'block' : (tlEditNoteCheckTarget ? 'check' : 'add');
      const show = !hide;
      const type = mode === 'block' ? tlEditBlockTarget.type : '';
      // 代码块（或内含围栏）不适用：围栏行加标记会破坏 isFence 判定，围栏内标记又会原样显示
      // 🆕 例外：整段已是「块级 {gpX}…{/gpX} 群」时不逐行加标记，围栏完全安全 → 照常启用
      const isFenceGroup = (typeof tlGpFenceWrap === 'function') && !!tlGpFenceWrap(src);
      const enabled = show && (isFenceGroup || (!(mode === 'block' && type === 'code') && !tlHasCodeFence(src)));
      // add 是「还没写入的草稿」永遠不预勾；block/check 依开框原文侦测
      const detected = (mode === 'block' || mode === 'check') && enabled && tlIsWholeGpBlock(src);
      tlGroupWasOn = !!detected;
      if (row) {
        row.style.display = show ? '' : 'none';
        row.classList.toggle('is-disabled', !enabled);
      }
      if (label) label.textContent = enabled ? 'group 启用（唯一小事件）' : 'group 启用（代码块不适用）';
      if (box) {
        box.disabled = !enabled;
        box.checked = !!detected;
      }
      return enabled;
    }
    function tlBindAddCheckDirty() {
      const ov = document.getElementById('tlAddCheckOverlay');
      if (!ov || ov.dataset.dirtyBound) return;
      ov.dataset.dirtyBound = '1';
      const markDirty = (e) => {
        if (e.target && e.target.matches && e.target.matches('input, textarea')) tlAddCheckDirty = true;
      };
      ov.addEventListener('input', markDirty);
      ov.addEventListener('change', markDirty);
    }
    function tlBlockTypeName(type) {
      return ({ code: '代码块', table: '表格', heading: '标题', hr: '分隔线', quote: '引用', list: '列表', para: '段落', gp: '分组' })[type] || '区块';
    }
    // 🆕 编辑小圆点的悬停提示：只说「这一颗编辑的是哪一类内容」，不显示内容本身。
    //    文案是给使用者看的口径（2026-10-20 指定）：文本内容／表格内容／分隔线／checkbox 子事件…
    //    渲染只发生在这里一次，主窗体卡片与便利贴共用同一份 HTML，故双端自动一致。
    function tlEditUnitTip(type) {
      return ({
        para: '编辑文本内容', list: '编辑列表内容', table: '编辑表格内容',
        code: '编辑代码块', heading: '编辑标题', hr: '编辑分隔线', quote: '编辑引用内容',
        gp: '编辑整个分组（连续 {gp} 行）'
      })[type] || '编辑内容区块';
    }
    function tlOpenAddCheckDialog(uid) {
      // 🆕 表单模式（uid 空）＝从「备注 ＋CheckBox」进入；只读窗体不开放追加子事件。
      //    列表模式传 uid，走原有 ev.ro / tlEvFormReadOnly 判断，不受影响。
      if (!uid && tlEvFormReadOnly) return;
      tlAddCheckTargetUid = uid || null;
      tlEditNoteCheckTarget = null;
      tlEditBlockTarget = null;
      tlExitTableMode();   // 同一个浮层也用来做表格网格，进一般模式前一定复位
      const ov = document.getElementById('tlAddCheckOverlay');
      const inp = document.getElementById('tlAddCheckInput');
      tlBindAddCheckDirty();
      const copyButton = document.getElementById('tlCopyNoteCheckButton');
      if (ov) ov.onkeydown = null;
      if (copyButton) copyButton.style.display = 'none';
      document.querySelector('#tlAddCheckOverlay .tl-ev-form-title').textContent = '建立 CheckBox 项目';
      document.querySelector('#tlAddCheckOverlay .tl-ev-form-hint').innerHTML = '每行一个项目，保存后以 <code>- [ ] …</code> 形式追加到「备注」末尾；系统自动补上建立日标记 <code>[[cr:今天]]</code>';
      document.querySelector('#tlAddCheckOverlay .btn-primary').textContent = '加入备注';
      if (inp) inp.value = '';
      tlSyncGroupUi('');   // 🆕 「建立 CheckBox 项目」也提供 group 勾选（草稿，默认不启用）
      tlAddCheckDirty = false;
      if (inp) inp.rows = 4;
      if (ov) ov.style.display = 'flex';
      if (inp) setTimeout(() => inp.focus(), 0);
    }
    // 🆕 编辑子事件编辑框：自动把文本里「未标注的已知术语」包成 [[term]] / [[term:释文]] 标记。
    //   规则：① 已位于 [[...]] 内的字串不重复标注；② 多术语重叠时最长匹配优先；③ 仅标注未在 [[...]] 内的出现。
    //   字典来源＝tlCollectTerms()（全事件里出现过的 [[term...]] 术语名＋释文）。
    function tlAutoMarkTermsInText(text) {
      const terms = tlCollectTerms();
      const dict = (terms || [])
        .map((t) => ({ term: t.term, def: (t.def || '').trim() }))
        .filter((t) => t.term && t.term.length >= 2)
        .sort((a, b) => b.term.length - a.term.length);   // 长词优先
      if (!dict.length) return { text: String(text), count: 0 };
      const src = String(text);
      const srcL = src.toLowerCase();   // 🆕 大小写不敏感匹配：字典去重按 toLowerCase，匹配口径须一致，否则定义过也会因大小写漏标
      // 1) 保护区：已存在的 [[...]] 不在此内标注（已标注的不重复标）
      const protectedSpans = [];
      let m; const br = /\[\[[^\]\n]*\]\]/g;
      while ((m = br.exec(src)) !== null) protectedSpans.push([m.index, m.index + m[0].length]);
      const inProtected = (i) => protectedSpans.some((sp) => i >= sp[0] && i < sp[1]);
      // 2) 收集候选命中（端点落入保护区则跳过）
      const cands = [];
      for (const d of dict) {
        const termL = d.term.toLowerCase(); let from = 0, idx;
        while ((idx = srcL.indexOf(termL, from)) !== -1) {
          const end = idx + d.term.length;   // 原始字串长度＝小写长度，定位用原串下標
          if (!inProtected(idx) && !inProtected(end - 1)) cands.push({ start: idx, end: end, term: d.term, def: d.def });
          from = idx + 1;
        }
      }
      if (!cands.length) return { text: src, count: 0 };
      // 3) 最长优先 + 非重叠贪心
      cands.sort((a, b) => (b.end - b.start) - (a.end - a.start) || a.start - b.start);
      const used = new Array(src.length).fill(false);
      const accepted = [];
      for (const c of cands) {
        let overlap = false;
        for (let i = c.start; i < c.end; i++) { if (used[i]) { overlap = true; break; } }
        if (overlap) continue;
        for (let i = c.start; i < c.end; i++) used[i] = true;
        accepted.push(c);
      }
      accepted.sort((a, b) => a.start - b.start);
      // 4) 重建文本
      let out = '', cursor = 0;
      for (const c of accepted) {
        out += src.slice(cursor, c.start);
        const marker = (c.def && c.def.indexOf(']]') === -1) ? ('[[' + c.term + ':' + c.def + ']]') : ('[[' + c.term + ']]');
        out += marker;
        cursor = c.end;
      }
      out += src.slice(cursor);
      return { text: out, count: accepted.length };
    }
    function tlAutoMarkTermsInEditBox() {
      const inp = document.getElementById('tlAddCheckInput');
      if (!inp) return;
      if (!inp.value.trim()) { showToast('编辑框为空，无可标示的内容', 'danger'); return; }
      const res = tlAutoMarkTermsInText(inp.value);
      if (!res.count) { showToast('没有发现可标示的未标注术语', 'info'); return; }
      inp.value = res.text;
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      showToast('已自动标示 ' + res.count + ' 处术语（最长匹配优先，已标注不重复）', 'success');
    }
    function tlOpenEditNoteCheckDialog(event, uid, line) {
      if (event) { event.preventDefault(); event.stopPropagation(); }
      tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
      const ev = tlCalEvents.find((item) => item.uid === uid);
      if (!ev) { showToast('找不到该条行程（内容可能已被修改）', 'danger'); return; }
      if (ev.ro) { showToast('此行程来自被包含的只读文件，不可修改', 'danger'); return; }
      const lines = String(ev.notes || '').split('\n');
      if (line < 0 || line >= lines.length) return;
      const match = lines[line].match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
      if (!match) { showToast('该子事件已被修改，请刷新后重试', 'danger'); return; }

      tlAddCheckTargetUid = null;
      tlEditNoteCheckTarget = { uid, line };
      tlEditBlockTarget = null;
      tlExitTableMode();   // 同上：子事件入口一律不用网格
      const ov = document.getElementById('tlAddCheckOverlay');
      const inp = document.getElementById('tlAddCheckInput');
      tlBindAddCheckDirty();
      const copyButton = document.getElementById('tlCopyNoteCheckButton');
      document.querySelector('#tlAddCheckOverlay .tl-ev-form-title').textContent = '编辑 CheckBox 子事件';
      document.querySelector('#tlAddCheckOverlay .tl-ev-form-hint').textContent = '只修改子事件文字；勾选状态会保留，日期标记（[[cr:…]] 建立日／[[dl:…]] 预计完成／[[cp:…]] 完成日，建立日会自动补在最前面）以原文显示可直接编辑；换行（shift+enter）＝拆成多个子事件（第一行保留本条的勾选状态）；清空内容并保存＝删除该子事件（会先确认）';
      document.querySelector('#tlAddCheckOverlay .btn-primary').textContent = '保存修改';
      if (copyButton) copyButton.style.display = '';
      if (ov) ov.onkeydown = (e) => {
        if ((e.metaKey || e.ctrlKey) && !e.altKey && (e.key === 's' || e.key === 'S')) {
          e.preventDefault();
          e.stopPropagation();
          tlSaveAddCheckDialog();
          return;
        }
        // 🆕 只有下方「取消」按钮能关窗：Esc 一律不关闭（吃掉按键、挡住全局快捷键）
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); }
      };
      if (inp) {
        // 🆕 原文保真：编辑框显示原始文本（含 [[dl:…]]/[[cp:…]] 等 [[]] 符号），不剥离、不折叠空白；保存时直接写回
        inp.value = match[3];
        tlSyncGroupUi(match[3]);   // 🆕 编辑 CheckBox 子事件也提供 group 勾选；原文已带 {gp} 时预勾
        inp.rows = 2;
      }
      if (ov) ov.style.display = 'flex';
      if (inp) setTimeout(() => inp.focus(), 0);
    }
    // ── 🆕 表格网格编辑器（区块圆点 type==='table' 时启用）───────────────────────────
    //  引擎住在 md-table-grid.js（主窗体与便利贴共用同一份），这里只接「本窗体的节点＋配色」；
    //  改表格行为请改共用档，别在这里写第二套。
    //  网格只是 #tlAddCheckInput 的另一层视图：格子改动即时序列化回 textarea，
    //  落盘仍走 tlSaveAddCheckDialog 的「按区块 start..end 区间回写备注」，没有第二条存档分支。
    let tlTableGrid = null;
    function tlTableGridInstance() {
      if (tlTableGrid) return tlTableGrid;
      if (!window.MdTableGrid || !document.getElementById('tlTableGrid')) return null;
      const byId = (id) => document.getElementById(id);
      const box = document.querySelector('#tlAddCheckOverlay .tl-ev-form-box');
      tlTableGrid = window.MdTableGrid.createGrid({
        textarea: byId('tlAddCheckInput'),
        grid: byId('tlTableGrid'),
        scroll: byId('tlTableGridScroll'),
        controls: {
          rows: byId('tlTableRows'), cols: byId('tlTableCols'), build: byId('tlTableBuild'),
          addRow: byId('tlTableAddRow'), delRow: byId('tlTableDelRow'),
          addCol: byId('tlTableAddCol'), delCol: byId('tlTableDelCol'), toggle: byId('tlTableViewText')
        },
        setWide: (on) => { if (box) box.style.maxWidth = on ? '860px' : '440px'; },   // 440px 装不下宽表
        toast: showToast
        // ⌘S／Esc 这里不接：本浮层的快捷键已由 #tlAddCheckOverlay 的 onkeydown 统一处理
      });
      return tlTableGrid;
    }
    function tlBindTableButtons() { const g = tlTableGridInstance(); if (g) g.bind(); }
    function tlEnterTableMode(src) { const g = tlTableGridInstance(); if (!g) return false; g.bind(); return g.enter(src); }
    function tlExitTableMode() { if (tlTableGrid) tlTableGrid.exit(); }
    // 🆕 通用「最小 MD 区块」编辑对话框：编辑 notes 中 lines[start..end] 的 Markdown 原文。
    //   ⌘S 保存（不关闭，可继续编辑）· 关闭请按下方「取消」按钮；清空并保存＝删除该区块（需确认）。
    function tlOpenEditBlockDialog(event, uid, start, end, type) {
      if (event) { event.preventDefault(); event.stopPropagation(); }
      tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
      const ev = tlCalEvents.find((x) => x.uid === uid);
      if (!ev) { showToast('找不到该条行程（内容可能已被修改）', 'danger'); return; }
      if (ev.ro) { showToast('此行程来自被包含的只读文件，不可修改', 'danger'); return; }
      const lines = String(ev.notes || '').split('\n');
      if (!(start >= 0 && end < lines.length && start <= end)) { showToast('该区块已被修改，请刷新后重试', 'danger'); return; }
      const src = lines.slice(start, end + 1).join('\n');

      tlAddCheckTargetUid = null;
      tlEditNoteCheckTarget = null;
      tlEditBlockTarget = { uid, start, end, type };
      const ov = document.getElementById('tlAddCheckOverlay');
      const inp = document.getElementById('tlAddCheckInput');
      tlBindAddCheckDirty();
      const copyButton = document.getElementById('tlCopyNoteCheckButton');
      document.querySelector('#tlAddCheckOverlay .tl-ev-form-title').textContent = '编辑内容区块（' + tlBlockTypeName(type) + '）';
      document.querySelector('#tlAddCheckOverlay .tl-ev-form-hint').textContent = '直接编辑此区块的 Markdown 原文；⌘S 保存（不关闭，可继续编辑）· 关闭请按下方「取消」按钮；清空并保存＝删除该区块（会先确认）';
      document.querySelector('#tlAddCheckOverlay .btn-primary').textContent = '保存修改';
      if (copyButton) copyButton.style.display = '';
      if (ov) ov.onkeydown = (e) => {
        if ((e.metaKey || e.ctrlKey) && !e.altKey && (e.key === 's' || e.key === 'S')) {
          e.preventDefault(); e.stopPropagation(); tlSaveAddCheckDialog(); return;
        }
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); }
      };
      if (inp) { inp.value = src; inp.rows = Math.min(18, Math.max(4, (end - start + 1) + 1)); }
      tlSyncGroupUi(src);   // 🆕 区块编辑才显示 group 勾选；原本已整组带 {gp} 时预勾
      tlAddCheckDirty = false;
      // 🆕 表格区块 → 进网格模式（解析失败仍留原文模式，不挡路）
      tlExitTableMode();
      let tableMode = false;
      if (type === 'table') { tlBindTableButtons(); tableMode = tlEnterTableMode(src); }
      if (tableMode) {
        document.querySelector('#tlAddCheckOverlay .tl-ev-form-title').textContent = '编辑表格内容';
        document.querySelector('#tlAddCheckOverlay .tl-ev-form-hint').textContent = '在格子里填内容即可；「＋行／＋列」增删，或填「行×列」按「建立空白表」重画一张；⌘S 保存（不关闭，可继续编辑）· 关闭请按下方「取消」按钮；需要手写 Markdown 时按「改 Markdown 原文」切换';
      }
      if (ov) ov.style.display = 'flex';
      if (inp && !tableMode) setTimeout(() => inp.focus(), 0);
      else { const first = document.querySelector('#tlTableGridScroll input'); if (first) setTimeout(() => first.focus(), 0); }
    }
    async function tlCopyNoteCheckText() {
      const inp = document.getElementById('tlAddCheckInput');
      if (!inp || !inp.value) { showToast('没有可复制的子事件内容', 'danger'); return; }
      try {
        if (!window.electronAPI || typeof window.electronAPI.writeTextToClipboard !== 'function') {
          throw new Error('剪贴板功能不可用');
        }
        const result = await window.electronAPI.writeTextToClipboard(inp.value);
        if (!result || result.success !== true) throw new Error((result && result.error) || '写入剪贴板失败');
        showToast('子事件内容已复制', 'success');
      } catch (error) {
        showToast('复制子事件失败：' + (error.message || error), 'danger');
      }
    }
    function tlCloseAddCheckDialog(force = false) {
      if (!force && tlAddCheckDirty) {
        showToast('编辑内容区块有未保存内容，请按「取消」退出，或先保存修改', 'danger');
        return false;
      }
      const ov = document.getElementById('tlAddCheckOverlay');
      if (ov) ov.style.display = 'none';
      tlAddCheckTargetUid = null;
      tlEditNoteCheckTarget = null;
      tlEditBlockTarget = null;
      tlAddCheckDirty = false;
      tlSyncGroupUi('', true);   // 🆕 关窗一律复位，下次开任何对话框都不会残留上次的勾选
      tlExitTableMode();   // 🆕 收掉网格模式，下次开一般对话框别残留
    }
    async function tlSaveAddCheckDialog() {
      const inp = document.getElementById('tlAddCheckInput');
      if (!inp) return;
      tlAddCheckDirty = false;
      if (tlEditBlockTarget) {
        const target = tlEditBlockTarget;
        // 🆕 group 启用：勾选时逐行补 {gp}（整块＝一个小事件）；原本整组却取消勾选＝拆组；其余原样
        const gpBox = document.getElementById('tlGroupEnable');
        const grouped = tlResolveGroupText(inp.value.replace(/\r\n/g, '\n'), !!(gpBox && gpBox.checked && !gpBox.disabled), tlGroupWasOn);
        const blockText = tlEnsureCrMarkersForCheckboxLines(grouped, tlFmtDateTime(new Date()));
        tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
        const ev = tlCalEvents.find((x) => x.uid === target.uid);
        if (!ev) { tlCloseAddCheckDialog(); showToast('找不到该条行程（内容可能已被修改）', 'danger'); return; }
        if (ev.ro) { tlCloseAddCheckDialog(); showToast('此行程来自被包含的只读文件，不可修改', 'danger'); return; }
        const lines = String(ev.notes || '').split('\n');
        if (!(target.start >= 0 && target.end < lines.length)) {
          tlCloseAddCheckDialog(); showToast('该区块已被修改，请重新打开后编辑', 'danger'); return;
        }
        const span = target.end - target.start + 1;
        if (!blockText.trim()) {
          if (!window.confirm('区块内容为空＝删除该区块。\n\n确定要删除吗？删除后将直接写回并存档，无法从本窗口恢复（可先按「复制」留存原文）。')) return;
          lines.splice(target.start, span);
          ev.notes = lines.join('\n');
          tlCloseAddCheckDialog();
          tlApplyEventsToBuffer();
          const savedDel = typeof saveTask === 'function' ? await saveTask(false) : false;
          showToast(savedDel ? '区块已删除并存档' : '区块已删除到行程缓冲，但尚未确认存档成功', savedDel ? 'success' : 'danger');
          return;
        }
        const newLines = blockText.split('\n');
        lines.splice(target.start, span, ...newLines);
        ev.notes = lines.join('\n');
        // 更新区间为新写入的区块，便于继续 ⌘S 覆写同一段
        tlEditBlockTarget = { uid: target.uid, start: target.start, end: target.start + newLines.length - 1, type: target.type };
        // 🆕 2026-11-08：group 启用已升级成块级 {gpX}…{/gpX}，编辑框同步显示真实底稿，
        //    避免继续编辑旧的行尾式原文时把块级群降级回去（直接赋值不触发 input，不会误标脏）。
        inp.value = blockText;
        tlApplyEventsToBuffer();
        const saved = typeof saveTask === 'function' ? await saveTask(false) : false;
        showToast(saved ? '区块已保存并存档' : '区块已写入行程缓冲，但尚未确认存档成功', saved ? 'success' : 'danger');
        return;
      }
      if (tlEditNoteCheckTarget) {
        const target = tlEditNoteCheckTarget;
        // 🆕 多行＝拆成多个子事件（与 ＋☐ 新增、便利贴端同一口径）：第一行继承原条目的勾选状态，
        //    其余每行成为同缩进的未完成子事件紧接其后；单行输入行为不变。
        const rows = inp.value.replace(/\r\n/g, '\n').split('\n').map((l) => l.trim()).filter(Boolean);
        // 🆕 内容清空＝删除该子事件：必须先经使用者确认（拒绝则留在编辑框，可先「复制」留存原文）
        if (!rows.length && !window.confirm('子事件内容为空＝删除该子事件。\n\n确定要删除吗？删除后将直接写回并存档，无法从本窗口恢复（可先按「复制」留存原文）。')) return;
        tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
        const ev = tlCalEvents.find((item) => item.uid === target.uid);
        if (!ev) { tlCloseAddCheckDialog(); showToast('找不到该条行程（内容可能已被修改）', 'danger'); return; }
        if (ev.ro) { tlCloseAddCheckDialog(); showToast('此行程来自被包含的只读文件，不可修改', 'danger'); return; }
        const lines = String(ev.notes || '').split('\n');
        if (target.line < 0 || target.line >= lines.length) {
          tlCloseAddCheckDialog();
          showToast('该子事件已被修改，请重新打开后编辑', 'danger');
          return;
        }
        const match = lines[target.line].match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
        if (!match) {
          tlCloseAddCheckDialog();
          showToast('该子事件已被修改，请重新打开后编辑', 'danger');
          return;
        }
        if (!rows.length) {
          // 🆕 空内容＝删除：移除该行后写回并存档（上方 confirm 已获使用者同意）
          lines.splice(target.line, 1);
          ev.notes = lines.join('\n');
          tlCloseAddCheckDialog();
          tlApplyEventsToBuffer();
          const saved = typeof saveTask === 'function' ? await saveTask(false) : false;
          showToast(saved ? '子事件已删除并存档' : '子事件已删除到行程缓冲，但尚未确认存档成功', saved ? 'success' : 'danger');
          return;
        }
        // 🆕 原文保真：编辑框已是完整原文（含 [[]] 标记），保存时直接写回；并自动补建立日标记 [[cr:今天]]
        //    （已含 cr 则不動＝保留原始建立日、不重複補；若含 dl/cp 則 cr 排在最前）
        const todayCr = tlFmtDateTime(new Date());
        const rawMd = rows.map((l, i) => match[1] + '- [' + (i === 0 ? match[2] : ' ') + '] ' + l).join('\n');
        const mdText = tlGroupMd(rawMd, todayCr, () => rows.map((l, i) => match[1] + '- [' + (i === 0 ? match[2] : ' ') + '] ' + tlEnsureCrMarker(l, todayCr)).join('\n'));
        const newLines = mdText.split('\n');
        lines.splice(target.line, 1, ...newLines);
        ev.notes = lines.join('\n');
        tlCloseAddCheckDialog();
        tlApplyEventsToBuffer();
        const saved = typeof saveTask === 'function' ? await saveTask(false) : false;
        const doneMsg = rows.length > 1 ? ('已拆成 ' + rows.length + ' 项子事件并存档') : '子事件已修改并存档';
        showToast(saved ? doneMsg : '子事件已修改到行程缓冲，但尚未确认存档成功', saved ? 'success' : 'danger');
        return;
      }
      const lines = inp.value.replace(/\r\n/g, '\n').split('\n').map((l) => l.trim()).filter((l) => l.length);
      if (!lines.length) { tlCloseAddCheckDialog(); return; }
      const todayCr = tlFmtDateTime(new Date());  // 新增子事件：自動補建立日標記 [[cr:今天 HH:mm]]（已含則不重複補）
      const rawMd = lines.map((l) => '- [ ] ' + l).join('\n');
      const md = tlGroupMd(rawMd, todayCr, () => lines.map((l) => '- [ ] ' + tlEnsureCrMarker(l, todayCr)).join('\n'), true);
      // 列表模式：追加到目标事件备注，并直接存档（写缓冲 + saveTask 落盘），无需打开编辑表单
      if (tlAddCheckTargetUid) {
        const uid = tlAddCheckTargetUid;
        tlCloseAddCheckDialog(); // 先清 target 再走异步/重绘，避免残留
        tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
        const ev = tlCalEvents.find((x) => x.uid === uid);
        if (!ev) { showToast('找不到该条行程（内容可能已被修改）', 'danger'); return; }
        if (ev.ro) { showToast('此行程来自被包含的只读文件，不可修改', 'danger'); return; }
        ev.notes = (ev.notes ? String(ev.notes).replace(/\s*$/, '') + '\n' : '') + md + '\n';
        tlApplyEventsToBuffer();
        if (typeof saveTask === 'function') saveTask(false); // 直接存档：写回 calendar.md
        showToast('已在备注末尾加入 CheckBox 并存档', 'success');
        return;
      }
      // 编辑表单模式：追加到表单备注 textarea（原行为，随表单保存一起写入）
      const notes = document.getElementById('tlEvFNotes');
      if (!notes) return;
      const cur = notes.value || '';
      notes.value = (cur ? cur.replace(/\s*$/, '') + '\n' : '') + md + '\n';
      tlCloseAddCheckDialog();
    }

    async function tlSaveEventForm(closeAfterSave = true) {
      // 🆕 只读窗体硬守卫：按钮虽已隐藏，仍挡住 onclick 直呼 / 快捷键等旁路，绝不写回任何档案。
      if (tlEvFormReadOnly) return;
      const title = document.getElementById('tlEvFTitle').value.trim();
      let date = document.getElementById('tlEvFDate').value;
      let endDate = document.getElementById('tlEvFEndDate').value;
      if (!title) { alert('请输入标题'); return; }
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) { alert('请选择日期'); return; }
      // 跨天：结束日早于起始日则互换；等于起始日视为单日（清空 endDate）
      if (endDate && endDate < date) { const tmp = date; date = endDate; endDate = tmp; }
      if (endDate === date) endDate = '';
      const allDay = document.getElementById('tlEvFAllday').checked;
      const ev = {
        uid: tlEvFormUid || tlGenId(),
        title, date, endDate: endDate || '', allDay,
        spanDisplay: document.getElementById('tlEvFSpanDisplay').value,
        done: document.getElementById('tlEvFDone').checked,
        startTime: allDay ? '' : document.getElementById('tlEvFStart').value,
        endTime: allDay ? '' : document.getElementById('tlEvFEnd').value,
        location: document.getElementById('tlEvFLocation').value.trim(),
        color: tlEvFormColor || TL_CAL_COLORS[0],
        // 🆕 桌面便利贴 instance 数（0 = 不显示为便利贴）
        sticky: Math.max(0, parseInt(document.getElementById('tlEvFSticky').value, 10) || 0),
        tags: tlEvFormTags.slice(),
        notes: tlEnsureCrMarkersForUnits(document.getElementById('tlEvFNotes').value.replace(/\r\n/g, '\n'), tlFmtDateTime(new Date())),
        todoIds: tlEvFormTodoIds.slice()
      };
      // ===== 重複事件：依表單寫回欄位（未勾選則清空，序列化降回 ## EVENT）=====
      if (document.getElementById('tlEvFRepeatOn').checked) {
        const rMode = document.getElementById('tlEvFRepeatMode').value;
        const interval = Math.max(1, parseInt(document.getElementById('tlEvFRepeatInterval').value, 10) || 1);
        ev.repeatMode = rMode;
        ev.repeatInterval = String(interval);
        if (rMode === 'weekly') {
          ev.repeatWeekDay = tlGetRepeatWeekDays();
          ev.repeatMonthDay = '';
          ev.repeatYearMonthDay = '';
        } else if (rMode === 'monthly') {
          ev.repeatWeekDay = [];
          const md = parseInt(document.getElementById('tlEvFMonthDay').value, 10);
          ev.repeatMonthDay = (md >= 1 && md <= 31) ? String(md) : '';
          ev.repeatYearMonthDay = '';
        } else if (rMode === 'yearly') {
          ev.repeatWeekDay = [];
          ev.repeatMonthDay = '';
          ev.repeatYearMonthDay = tlNormalizeYmd(document.getElementById('tlEvFYearMonthDay').value);
        } else {
          ev.repeatWeekDay = [];
          ev.repeatMonthDay = '';
          ev.repeatYearMonthDay = '';
        }
        const endType = document.getElementById('tlEvFRepeatEndType').value;
        ev.repeatEndType = endType;
        ev.repeatEndValue = endType === 'never' ? '' : document.getElementById('tlEvFRepeatEndValue').value.trim();
        const exRaw = document.getElementById('tlEvFRepeatExclude').value;
        ev.repeatExcludeDates = exRaw.split(',').map((x) => x.trim()).filter((x) => /^\d{4}-\d{2}-\d{2}$/.test(x));
      } else {
        ev.repeatMode = '';
        ev.repeatInterval = '';
        ev.repeatWeekDay = [];
        ev.repeatMonthDay = '';
        ev.repeatYearMonthDay = '';
        ev.repeatEndType = 'never';
        ev.repeatEndValue = '';
        ev.repeatExcludeDates = [];
      }
      // 🆕 写入目标＝INCLUDE 来源档：直接追加落盘，**绝不进缓冲**（缓冲代表的就是 calendar.md）。
      //    必须放在下面 `tlCalEvents = tlAllEvents(...)` upsert 之前 return，否则新事件会被顺手写进主文件。
      if (!tlEvFormUid && tlEvFormTarget) {
        const target = tlEvFormTarget;
        let r = null;
        try {
          r = await tlAppendEventToIncludeFile(target, ev);
        } catch (err) {
          // 本函数已改成 async：任何漏网的异常都必须在这里收口，否则变成 unhandled rejection、表单停在半开半关
          showToast('写入 ' + target + ' 失败：' + ((err && err.message) || err), 'danger');
          return;
        }
        if (!r || !r.ok) { showToast((r && r.error) || '写入 ' + target + ' 失败', 'danger'); return; }
        tlEvFormScrollOnCloseUid = ev.uid;
        // 立即重载 INCLUDE（合并新行程 → 重绘 + 重算便利贴集合）：新便利贴会经 sticky-note-sync 自动出现
        await tlKickIncludeRefresh();
        if (closeAfterSave) { tlEvFormDirty = false; tlCloseEventForm(true); }
        tlFlashIncludedEvent(target, ev);
        showToast('已新建行程到 ' + target + '（直接落盘，无需再按「保存」）', 'success');
        return;
      }
      // 以当前编辑内容为准重新解析（保留用户手改过的其它条目），再 upsert
      tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
      const i = tlCalEvents.findIndex((x) => x.uid === ev.uid);
      if (i >= 0) tlCalEvents[i] = ev; else tlCalEvents.push(ev);
      // 写入后返回列表：不设滚动锚点（pending 保持 false）→ tlRenderList 走「保留原 scrollTop」分支，原地不动
      tlApplyEventsToBuffer();
      // 关键修复（新增行程重复建档）：uid 不落盘——解析时按文件位置临时生成 'evp'+idx，
      // 首次保存生成的新 uid 在下一次重新解析后必然失配 → 又 push 一条。
      // 因此写缓冲后必须重新解析，把表单「重新指向上一条已落盘事件」（＝模拟你点「编辑」按钮），
      // 使后续 Cmd+S / 写入编辑内容 走「更新同一条」而非再建档。
      // 匹配用「内容指纹 + 排序位置」双重定位，不依赖脆弱的长度相等（真实文件含 HOLIDAY/DIARY/TAGS/INCLUDE 时计数易错位）。
      try {
        const reparsed = tlParseEvents(document.getElementById('taskText').value);
        const sortedMain = tlSorted(tlCalEvents.filter((e) => !e.ro).slice());
        // 与序列化一致的内容指纹（忽略 uid，专盯会写进文件的字段）
        const sig = (e) => [e.title, e.date, e.allDay, e.startTime, e.endTime, e.location, e.color, (e.notes || ''), JSON.stringify(e.tags || [])].join('');
        const want = sig(ev);
        const k = sortedMain.indexOf(ev); // 本事件在「序列化顺序」中的位置（＝文件顺序，与 reparsed 对齐）
        // 优先：同位置且同签名（最精确，可避开同名/同内容重复事件）；否则回退到任一同签名事件（至少不再新增）
        if (k >= 0 && reparsed[k] && sig(reparsed[k]) === want) tlEvFormUid = reparsed[k].uid;
        else {
          const m = reparsed.find((r) => sig(r) === want);
          if (m) tlEvFormUid = m.uid;
        }
      } catch (e) { /* 记回失败不影响本次保存 */ }
      tlEvFormScrollOnCloseUid = tlEvFormUid;
      if (closeAfterSave) { tlEvFormDirty = false; tlCloseEventForm(true); }
      showToast(closeAfterSave
        ? '已写入编辑内容，按「保存」写回 calendar.md'
        : '已写入编辑内容，可继续编辑（按「保存」写回 calendar.md）', 'success');
    }

    function tlDeleteEvent(uid) {
      tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
      const ev = tlCalEvents.find((x) => x.uid === uid);
      if (!ev) { showToast('找不到该条行程（内容可能已被修改）', 'danger'); return; }
      if (ev.ro) { showToast('此行程来自被包含的只读文件，不可删除', 'danger'); return; }
      if (!confirm('确定删除行程「' + ev.title + '」（' + ev.date + '）吗？\n\n写入后按「保存」才会真正写回文件。')) return;
      tlCalEvents = tlCalEvents.filter((x) => x.uid !== uid);
      tlApplyEventsToBuffer();
      showToast('已删除「' + ev.title + '」，按「保存」写回文件', 'success');
    }

    function tlDeleteFromForm() {
      if (tlEvFormReadOnly) return;   // 🆕 只读窗体：删除按钮已隐藏，这里再挡一次旁路呼叫
      if (!tlEvFormUid) return;
      const uid = tlEvFormUid;
      tlEvFormUid = null;                 // 🆕 删除前先清 uid，使 tlCloseEventForm 即使来自便利贴也不做定位（删除后该事件已不在，滚动无意义）
      tlCloseEventForm(true);
      tlDeleteEvent(uid);
    }

    // ===== ## DIARY 新增/编辑/删除（写回 taskText 缓冲，按「保存」落盘）=====
    let tlDiaryFormDate = null;
    let tlDiaryFormReadonly = false;
    function tlOpenDiaryForm(date) {
      if (!TL_DIARY_FEATURE_ENABLED) return;
      tlHideTip();
      if (!isCalendarMdDoc()) return;
      tlCalDiaries = tlParseDiaries(document.getElementById('taskText').value);
      // 📎 只读日记：主文件无此日期、但 include 里有 → 只读查看（字段只读，隐藏保存/删除，可看不可改）
      const own = tlCalDiaries.find((x) => x.date === date);
      const roD = own ? null : (tlIncludedDiaries || []).find((d) => d.date === date);
      const isRo = !!roD;
      const d = isRo ? roD : own;
      tlDiaryFormDate = date;
      document.getElementById('tlDiaryFTitle').value = d ? d.title : '';
      document.getElementById('tlDiaryFDate').textContent = date;
      document.getElementById('tlDiaryFMood').value = d ? (d.mood || '') : '';
      document.getElementById('tlDiaryFTags').value = d ? (d.tags || []).map(tlTagName).join(', ') : '';
      document.getElementById('tlDiaryFWeather').value = d ? (d.weather || '') : '';
      document.getElementById('tlDiaryFContent').value = d ? (d.content || '') : '';
      document.getElementById('tlDiaryFRemark').value = d ? (d.remark || '') : '';
      tlSetDiaryFormReadonly(isRo);
      tlDiaryFormReadonly = isRo;
      document.getElementById('tlDiaryFormDelete').style.display = (d && !isRo) ? '' : 'none';
      document.getElementById('tlDiaryFormOverlay').style.display = 'flex';
      if (!isRo) document.getElementById('tlDiaryFContent').focus();
    }
    function tlSetDiaryFormReadonly(ro) {
      ['tlDiaryFTitle', 'tlDiaryFMood', 'tlDiaryFWeather', 'tlDiaryFTags', 'tlDiaryFContent', 'tlDiaryFRemark'].forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.readOnly = !!ro;
      });
      const t = document.getElementById('tlDiaryFormTitleText');
      if (t) t.textContent = ro ? '查看日记（只读）' : '写日记';
      const save = document.getElementById('tlDiaryFormSave');
      if (save) save.style.display = ro ? 'none' : '';
      const hint = document.getElementById('tlDiaryFormHint');
      if (hint) hint.textContent = ro ? '此日记来自被包含的只读文件，仅供查看' : '写入后按编辑器「保存」，把改动写回 calendar.md';
    }
    function tlCloseDiaryForm() {
      const ov = document.getElementById('tlDiaryFormOverlay');
      if (ov) ov.style.display = 'none';
      tlDiaryFormDate = null;
      tlDiaryFormReadonly = false;
      // 恢复「合并」状态（含 include 的只读日记）：tlOpenDiaryForm 曾把 tlCalDiaries 重置为仅主文件，
      // 若不恢复，关闭表单后日记图标 tooltip / 日期标记会因找不到 include 日记而失效（用户实测）。
      if (isCalendarMdDoc()) {
        const ta = document.getElementById('taskText');
        if (ta) tlCalDiaries = tlAllDiaries(ta.value);
      }
    }
    function tlSaveDiaryForm() {
      if (tlDiaryFormReadonly) return;
      const date = tlDiaryFormDate;
      if (!date) return;
      const title = document.getElementById('tlDiaryFTitle').value.trim();
      if (!title) { alert('请输入日记标题'); return; }
      const tags = document.getElementById('tlDiaryFTags').value.split(/[,，]/).map((t) => t.trim()).filter(Boolean).map((nm) => ({ name: nm, cat: '' }));
      const diary = {
        date,
        title,
        mood: document.getElementById('tlDiaryFMood').value.trim(),
        tags,
        weather: document.getElementById('tlDiaryFWeather').value.trim(),
        content: document.getElementById('tlDiaryFContent').value.replace(/\r\n/g, '\n'),
        remark: document.getElementById('tlDiaryFRemark').value.trim()
      };
      tlCalDiaries = tlParseDiaries(document.getElementById('taskText').value);
      const i = tlCalDiaries.findIndex((x) => x.date === date);
      if (i >= 0) tlCalDiaries[i] = diary; else tlCalDiaries.push(diary);
      tlApplyDiariesToBuffer();
      tlCloseDiaryForm();
      showToast('已写入日记，按「保存」写回 calendar.md', 'success');
    }
    // 删除日记的「唯一收口」：确认 → 从缓冲重解析 → 剔除该日 → 序列化写回（按「保存」才落盘）。
    // 表单内删除与列表条目删除共用；返回是否真的删了（日记表单据此决定要不要关窗）。
    function tlRemoveDiary(date) {
      const d = tlDiaryOnDate(date);
      if (!d) return false;
      if (d.ro) { showToast('此日记来自被包含的只读文件，不可删除', 'danger'); return false; }
      if (!confirm('确定删除 ' + date + ' 的日记「' + d.title + '」吗？\n\n按「保存」才会真正写回文件。')) return false;
      tlCalDiaries = tlParseDiaries(document.getElementById('taskText').value);
      tlCalDiaries = tlCalDiaries.filter((x) => x.date !== date);
      tlApplyDiariesToBuffer();
      showToast('已删除日记，按「保存」写回文件', 'success');
      return true;
    }
    function tlDeleteDiary() {
      if (tlDiaryFormReadonly) return;
      const date = tlDiaryFormDate;
      if (!date) return;
      if (!tlDiaryOnDate(date)) { tlCloseDiaryForm(); return; }
      if (tlRemoveDiary(date)) tlCloseDiaryForm();
    }
    // 「只显示日记」列表条目上的删除按钮（不经日记表单，直接按日期删）
    function tlDeleteDiaryByDate(date) {
      if (!date || !tlDiaryOnDate(date)) return;
      tlRemoveDiary(date);
    }
    // 序列化整份 calendar.md（events + holidays + diaries）写回 taskText：从当前缓冲重解析 events/holidays，
    // 再以最新 tlCalDiaries 覆盖日记段，避免保存日记时把用户手写的事件/假日覆盖掉。
    function tlApplyDiariesToBuffer() {
      const ta = document.getElementById('taskText');
      const events = tlParseEvents(ta.value);
      const holidays = tlParseHolidays(ta.value);
      tlCalEvents = events;
      tlCalHolidays = holidays;
      // 📎 重画后保留 ## TAGS / ## INCLUDE（避免父阶标签、Include 勾选被清掉）
      ta.value = tlPreserveMetaBlocks(ta.value, tlCalendarToMarkdown(events, holidays, tlCalDiaries.filter((d) => !d.ro)));
      if (typeof autoGrowTextarea === 'function') autoGrowTextarea(ta);
      if (typeof markCurrentTabDirty === 'function') markCurrentTabDirty();
      tlRenderEventsContent();
    }

    // 清单上的「完成」勾选框：切换 done → 序列化写回 taskText 缓冲（按「保存」才落盘）
    //   el＝触发本次变更的勾选框（只读/找不到时要把 DOM 状态拨回去，否则画面会「假装」勾上了）
    function tlToggleDone(uid, done, el) {
      tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
      const ev = tlCalEvents.find((x) => x.uid === uid);
      if (!ev) { if (el) el.checked = false; showToast('找不到该条行程（内容可能已被修改）', 'danger'); return; }
      // 📎 只读（INCLUDE 外部档）行程：不该改完成状态（只读档渲染时已 disabled，这里再兜一层）
      if (ev.ro) { if (el) el.checked = !!ev.done; showToast('此行程来自被包含的只读文件，不可修改完成状态', 'danger'); return; }
      ev.done = !!done;
      tlApplyEventsToBuffer(); // 内部会重绘行程视图
      showToast(ev.done ? '已标记完成，按「保存」写回 calendar.md' : '已取消完成，按「保存」写回 calendar.md', 'success');
    }

    // 備註 checkbox 行：確保帶有 [[cr:建立日期]] 標記（不存在才補 today；已有則不動，避免重複／改到原始建立日）。
    // 建立日期一律排在最前：若正文已有 [[dl:…]]/[[cp:…]] 則插到它們前面；否則補在行尾。純函數，不改入參。
    function tlEnsureCrMarker(body, todayStr) {
      if (/\[\[cr:\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/.test(body)) return body;  // 已有建立日：保留原值、不重複補
      const cr = '[[cr:' + todayStr + ']]';
      const trimmed = body.replace(/\s+$/, '');
      if (!trimmed.trim()) return cr;  // 空正文：直接給建立日標記（不帶前導空白）
      const m = body.match(/\[\[(dl|cp):\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/);
      if (m && typeof m.index === 'number') {
        return body.slice(0, m.index).replace(/\s+$/, '') + ' ' + cr + ' ' + body.slice(m.index);
      }
      return trimmed + ' ' + cr;
    }
    // 備註 checkbox 行勾選互換 + dl/cp/cr 標記維護（純函數，不改入參；便於單測）：newDone=true 勾選、false 取消；todayStr 為 YYYY-MM-DD
    function tlNoteCheckTransform(line, newDone, todayStr) {
      const m = line.match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
      if (!m) return line;
      let body = m[3] || '';
      if (newDone) {
        // 勾選：先把裸日期 [[YYYY-MM-DD]] 歸一為 [[dl:YYYY-MM-DD]]
        body = body.replace(/\[\[(\d{4}-\d{2}-\d{2})\]\]/g, '[[dl:$1]]');
        // 勾選一律補 [[cp:今天]]（無論有無 dl；已有 cp 則不重複）
        if (!/\[\[cp:\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/.test(body)) {
          body = body.replace(/\s+$/, '') + ' [[cp:' + todayStr + ']]';
        }
      } else {
        // 取消勾選：移除 cp 塊（保留 dl）
        body = body.replace(/\s*\[\[cp:\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2})?\]\]/g, '');
      }
      return m[1] + '- [' + (newDone ? 'x' : ' ') + '] ' + tlEnsureCrMarker(body, todayStr);
    }
    // 備註裡的 Markdown checkbox 勾選/取消：定位 ev.notes 的對應行，互換 - [ ] ↔ - [x]，序列化寫回 taskText（按「保存」才落盤）
    function tlToggleNoteCheck(e, uid, line) {
      if (e) { e.stopPropagation(); e.preventDefault(); } // 阻止冒泡到 .ev-block 的 onclick 打開編輯表單
      tlCalEvents = tlAllEvents(document.getElementById('taskText').value);
      const ev = tlCalEvents.find((x) => x.uid === uid);
      if (!ev) { showToast('找不到该条行程（内容可能已被修改）', 'danger'); return; }
      if (ev.ro) { showToast('此行程来自被包含的只读文件，不可勾选', 'danger'); return; }
      const lines = String(ev.notes || '').split('\n');
      if (line < 0 || line >= lines.length) return;
      const m = lines[line].match(/^(\s*)-\s+\[([ xX])\]\s?(.*)$/);
      if (!m) return; // 該行已被用戶改得不再是 checkbox，跳過以免破壞原文
      const wasDone = m[2] !== ' ';
      lines[line] = tlNoteCheckTransform(lines[line], !wasDone, tlFmtDateTime(new Date()));
      ev.notes = lines.join('\n');
      tlApplyEventsToBuffer(); // 序列化 + 標髒 + 重繪（多天事件多列自動同步）
      showToast(wasDone ? '已取消勾选，按「保存」写回 calendar.md' : '已勾选，按「保存」写回 calendar.md', 'success');
    }
    function tlCalCheckKey(e, uid, line) {
      if (e && (e.key === ' ' || e.key === 'Spacebar' || e.key === 'Enter')) {
        e.preventDefault();
        tlToggleNoteCheck(e, uid, line);
      }
    }

    // 序列化整份 calendar.md 写回 taskText（不动 editSnapshot → 未保存检测自动判定为脏，「保存」亮起）
    // 📎 事件/日记保存会把整份 calendar.md 重画（tlCalendarToMarkdown 只产 EVENT/HOLIDAY/DIARY），
    // 必须把原本的 ## TAGS / ## INCLUDE 元數據块保留下来，否则按「保存」落盘会把这两个块清掉。
    // 从 original 抽出这两个块（含内容，直到下一个 ## 标题或文末），重新贴回 newMd 末尾。
    function tlPreserveMetaBlocks(original, newMd) {
      const kept = [];
      ['TAGS', 'INCLUDE'].forEach((name) => {
        const idx = String(original || '').search(new RegExp('^##[ \\t]*' + name + '[ \\t]*$', 'm'));
        if (idx < 0) return;
        const after = String(original).slice(idx);
        const next = after.search(/\n##[ \t]/m);
        const end = next >= 0 ? idx + next : String(original).length;
        kept.push(String(original).slice(idx, end).replace(/\s+$/, ''));
      });
      if (!kept.length) return newMd;
      return String(newMd).replace(/\s*$/, '') + '\n\n' + kept.join('\n\n') + '\n';
    }
    function tlApplyEventsToBuffer() {
      const ta = document.getElementById('taskText');
      // ⚠️ 从当前缓冲重新解析 holiday / diary，避免保存事件时把用户手写的 ## HOLIDAY / ## DIARY 整体覆盖掉（事件序列化器会重画整份文件）
      const holidays = tlParseHolidays(ta.value);
      const diaries = tlParseDiaries(ta.value);
      tlCalHolidays = holidays;
      tlCalDiaries = [];
      // 📎 重画后保留 ## TAGS / ## INCLUDE（避免父阶标签、Include 勾选被清掉）
      ta.value = tlPreserveMetaBlocks(ta.value, tlCalendarToMarkdown(tlCalEvents.filter((e) => !e.ro), holidays, diaries));
      if (typeof autoGrowTextarea === 'function') autoGrowTextarea(ta);
      if (typeof markCurrentTabDirty === 'function') markCurrentTabDirty();
      tlRenderEventsContent();
      if (typeof tlUpdateStickyBadge === 'function') tlUpdateStickyBadge();
      if (typeof tlPushStickyRefreshes === 'function') tlPushStickyRefreshes();
    }

    // ===== 🖱 悬停行程事件 → 放大提示框（更大字体显示事件内容） =====
    let tlTipEl = null, tlTipUid = null;
    function tlGetTipEl() {
      if (!tlTipEl) {
        tlTipEl = document.createElement('div');
        tlTipEl.className = 'ev-tip';
        tlTipEl.setAttribute('role', 'tooltip');
        tlTipEl.style.display = 'none';
        document.body.appendChild(tlTipEl);
      }
      return tlTipEl;
    }
    // occDate＝該列所屬「出現日」：跨天行程要標 (第幾天/共幾天)，與列表行/月格 chip 同款
    function tlTipHtml(ev, occDate) {
      const multi = tlIsMultiDay(ev);
      let when;
      if (tlIsSpanToday(ev)) when = TL_SPAN_TODAY_TEXT;   // 显示在今天：不显示真实日期区间
      else if (multi) when = ev.allDay
        ? (tlRangeLabel(ev.date, ev.endDate) + ' · 共' + tlSpanDays(ev.date, ev.endDate) + '天')
        : tlRangeLabel(ev.date, ev.endDate, ev.startTime, ev.endTime);
      else when = ev.allDay ? '全天' : ((ev.startTime || '') + (ev.endTime ? '-' + ev.endTime : ''));
      const tags = (ev.tags && ev.tags.length) ? '<div class="ev-tip-tags">' + ev.tags.map((t) => '<span class="ev-tag-view" data-tag="' + tlEscapeHtml(tlTagName(t)) + '">' + tlEscapeHtml(tlTagLabel(t)) + '</span>').join('') + '</div>' : '';
      const loc = ev.location ? '\ud83d\udccd ' + tlEscapeHtml(ev.location) : '';
      const notes = ev.notes ? '<div class="ev-tip-notes">' + tlRenderNotes(ev.notes, null) + '</div>' : '';
      const links = tlEventTodoLinks(ev);
      return '<div class="ev-tip-title">' + tlRepeatIcon(ev) + tlRenderInlineMarkdown(ev.title) + tlSpanDaySuffix(ev, occDate) + (ev.done ? ' <span class="ev-tip-done">\u2713</span>' : '') + '</div>' +
        '<div class="ev-tip-meta">' + tlEscapeHtml(when) + (loc ? ' · ' + loc : '') + '</div>' + tags + links + notes;
    }
    function tlShowTip(uid, occDate, x, y) {
      const ev = tlCalEvents.find((e) => e.uid === uid);
      if (!ev) return;
      const tip = tlGetTipEl();
      // ⚠️ 跨天行程同一 uid 会出现在多天 → 缓存 key 必须带上 occDate，否则在「第1天」悬停后切到「第3天」仍显示 (1/7)
      const key = uid + '@' + (occDate || '');
      if (tlTipUid !== key) { tip.innerHTML = tlTipHtml(ev, occDate); tlTipUid = key; }
      tip.style.display = 'block';
      // 定位：跟随光标，越界则翻转到另一侧（避免超出视口）
      const r = tip.getBoundingClientRect();
      let left = x + 16, top = y + 16;
      if (left + r.width > window.innerWidth - 8) left = Math.max(8, x - r.width - 16);
      if (top + r.height > window.innerHeight - 8) top = Math.max(8, y - r.height - 16);
      tip.style.left = left + 'px';
      tip.style.top = top + 'px';
    }
    function tlHideTip() { if (tlTipEl) { tlTipEl.style.display = 'none'; tlTipUid = null; } }

    // 🆕 年视图日期格悬停：显示当天所有日程的富文本 tips（同表身列表 hover 的 tlTipHtml 样式）
    function tlShowDayTip(ds, uids, x, y) {
      const tip = tlGetTipEl();
      let html = '';
      if (uids && uids.length) {
        for (const uid of uids) {
          const ev = tlCalEvents.find((e) => e.uid === uid);
          if (!ev) continue;
          html += '<div class="ev-tip-day-item">' + tlTipHtml(ev, ds) + '</div>';
        }
      }
      const hols = tlHolidaysOnDay(ds);
      if (hols.length) {
        html += '<div class="ev-tip-day-hols">';
        for (const h of hols) {
          const region = tlHolidayRegionMeta(h.region);
          html += '<div class="ev-tip-day-hol"><span class="dot" style="background:' + tlEscapeHtml(region.color) + '"></span>' + tlEscapeHtml(h.title) + '</div>';
        }
        html += '</div>';
      }
      if (!html) { tip.style.display = 'none'; tlTipUid = null; return; }
      // 按日期缓存：同一天重复 mousemove 不重建 innerHTML（避免闪烁），仅重新定位
      const key = 'day:' + ds;
      if (tlTipUid !== key) { tip.innerHTML = html; tlTipUid = key; }
      tip.style.display = 'block';
      const r = tip.getBoundingClientRect();
      let left = x + 16, top = y + 16;
      if (left + r.width > window.innerWidth - 8) left = Math.max(8, x - r.width - 16);
      if (top + r.height > window.innerHeight - 8) top = Math.max(8, y - r.height - 16);
      tip.style.left = left + 'px';
      tip.style.top = top + 'px';
    }
    function tlShowYearDayTip(el, e) {
      const ds = el.getAttribute('data-date');
      const uids = (el.getAttribute('data-ev-uids') || '').split(',').filter(Boolean);
      if (!ds) return;
      tlShowDayTip(ds, uids, e.clientX, e.clientY);
    }

    // ===== 📓 悬停日记图标 → 放大提示框（复用 .ev-tip 结构，仅当天有日记时显示） =====
    function tlDiaryTipHtml(d) {
      const meta = [d.date, d.mood, d.weather].filter(Boolean).join(' · ');
      const tags = (d.tags && d.tags.length) ? '<div class="ev-tip-tags">' + d.tags.map((t) => '<span class="ev-tag-view" data-tag="' + tlEscapeHtml(tlTagName(t)) + '">' + tlEscapeHtml(tlTagLabel(t)) + '</span>').join('') + '</div>' : '';
      const body = d.content ? '<div class="ev-tip-notes">' + tlDiaryBody(d.content) + '</div>' : '';
      const remark = d.remark ? '<div class="ev-tip-meta" style="margin-top:6px;">备注：' + tlRenderInlineMarkdown(d.remark) + '</div>' : '';
      return '<div class="ev-tip-title">\ud83d\udcd5 ' + tlRenderInlineMarkdown(d.title || '日记') + '</div>' +
        (meta ? '<div class="ev-tip-meta">' + tlEscapeHtml(meta) + '</div>' : '') + tags + body + remark;
    }
    function tlShowDiaryTip(date, x, y) {
      const d = tlDiaryOnDate(date);
      if (!d) return;
      const tip = tlGetTipEl();
      const key = 'diary:' + date;
      if (tlTipUid !== key) { tip.innerHTML = tlDiaryTipHtml(d); tlTipUid = key; }
      tip.style.display = 'block';
      const r = tip.getBoundingClientRect();
      let left = x + 16, top = y + 16;
      if (left + r.width > window.innerWidth - 8) left = Math.max(8, x - r.width - 16);
      if (top + r.height > window.innerHeight - 8) top = Math.max(8, y - r.height - 16);
      tip.style.left = left + 'px';
      tip.style.top = top + 'px';
    }

    // ===== 📅 農民曆 / 老黃曆取數（lunar-javascript，繁體）=====
    // 以 <script> 載入的 window.Solar / window.Lunar 為資料源；Map 快取避免重複計算。
    const tlAlmanacCache = new Map();
    function tlAlmanac(dateStr) {
      if (tlAlmanacCache.has(dateStr)) return tlAlmanacCache.get(dateStr);
      let data = { error: 'lunar lib 未載入或日期無效' };
      try {
        if (typeof Solar === 'undefined' || typeof Lunar === 'undefined') throw new Error('lunar lib 未載入');
        const m = String(dateStr || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
        if (!m) throw new Error('日期格式錯誤');
        const lunar = Solar.fromYmd(+m[1], +m[2], +m[3]).getLunar();
        data = {
          lunarMonth: lunar.getMonthInChinese(),
          lunarDay: lunar.getDayInChinese(),
          lunarText: lunar.getMonthInChinese() + '月' + lunar.getDayInChinese(),
          isLeap: lunar.getMonth() < 0,
          yearGanZhi: lunar.getYearInGanZhi(),
          monthGanZhi: lunar.getMonthInGanZhi(),
          dayGanZhi: lunar.getDayInGanZhi(),
          shengxiao: lunar.getYearShengXiao(),
          yearChinese: lunar.getYearInChinese(),
          jieqi: lunar.getJieQi() || '',
          // 宜忌/彭祖/吉神/凶神/納音/宿/建除 均為簡體 → 逐詞轉繁體（almanacToTrad）
          yi: (lunar.getDayYi() || []).map(almanacToTrad),
          ji: (lunar.getDayJi() || []).map(almanacToTrad),
          chong: lunar.getDayChong() || '',
          chongShengXiao: almanacToTrad(lunar.getDayChongShengXiao() || ''),
          sha: lunar.getDaySha() || '',
          pengZuGan: almanacToTrad(lunar.getPengZuGan() || ''),
          pengZuZhi: almanacToTrad(lunar.getPengZuZhi() || ''),
          jiShen: (lunar.getDayJiShen() || []).map(almanacToTrad),
          xiongSha: (lunar.getDayXiongSha() || []).map(almanacToTrad),
          naYin: almanacToTrad(lunar.getDayNaYin() || ''),
          xiu: almanacToTrad(lunar.getXiu() || ''),
          xiuLuck: lunar.getXiuLuck() || '',
          zhiXing: almanacToTrad(lunar.getZhiXing() || ''),
          posXi: lunar.getDayPositionXiDesc() || '',
          posCai: lunar.getDayPositionCaiDesc() || '',
          posFu: lunar.getDayPositionFuDesc() || '',
          posYangGui: lunar.getDayPositionYangGuiDesc() || '',
          posYinGui: lunar.getDayPositionYinGuiDesc() || ''
        };
      } catch (e) {
        data = { error: String((e && e.message) || e) };
      }
      tlAlmanacCache.set(dateStr, data);
      return data;
    }

    function tlLunarCompact(dateStr) {
      const a = tlAlmanac(dateStr);
      if (a.error) return { text: '', jieqi: '', lunar: '', lunarText: '', yearGanZhi: '', shengxiao: '', monthGanZhi: '', dayGanZhi: '' };
      return {
        text: a.jieqi || a.lunarDay,
        jieqi: a.jieqi || '',
        lunar: a.lunarDay,
        lunarText: a.lunarText,
        yearGanZhi: a.yearGanZhi,
        shengxiao: a.shengxiao,
        monthGanZhi: a.monthGanZhi,
        dayGanZhi: a.dayGanZhi
      };
    }

    function tlAlmanacHtml(dateStr) {
      const a = tlAlmanac(dateStr);
      const E = tlEscapeHtml;
      const join = (arr) => (arr && arr.length ? arr.map(E).join('、') : '—');
      const row = (k, v) => '<div class="ev-alm-row"><span class="ev-alm-k">' + k + '</span><span class="ev-alm-v">' + v + '</span></div>';
      if (a.error) return '<div class="ev-alm-empty">無法取得農民曆：' + E(a.error) + '</div>';
      const WD = ['日', '一', '二', '三', '四', '五', '六'];
      const m = String(dateStr || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
      const d = m ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date();
      const solarLabel = m ? (+m[1]) + '年' + (+m[2]) + '月' + (+m[3]) + '日 週' + WD[d.getDay()] : dateStr;
      let html = '<div class="ev-alm-head">';
      html += '<div class="ev-alm-solar">' + E(solarLabel) + '</div>';
      html += '<div class="ev-alm-lunar">農曆 ' + E(a.yearGanZhi) + '年（' + E(a.shengxiao) + '）' + E(a.lunarText) + (a.jieqi ? ' · ' + E(a.jieqi) : '') + '</div>';
      html += '</div><div class="ev-alm-grid">';
      html += row('干支', E(a.yearGanZhi) + '（年） / ' + E(a.monthGanZhi) + '（月） / ' + E(a.dayGanZhi) + '（日）');
      html += row('五行納音', E(a.naYin));
      if (a.jieqi) html += row('節氣', E(a.jieqi));
      html += row('宜', '<span class="ev-alm-yi">' + join(a.yi) + '</span>');
      html += row('忌', '<span class="ev-alm-ji">' + join(a.ji) + '</span>');
      html += row('沖煞', '沖' + E(a.chongShengXiao) + '（' + E(a.chong) + '）· 煞' + E(a.sha) + '方');
      html += row('彭祖百忌', E(a.pengZuGan) + '；' + E(a.pengZuZhi));
      html += row('吉神宜趨', join(a.jiShen));
      html += row('凶神宜忌', join(a.xiongSha));
      html += row('二十八宿', E(a.xiu) + '（' + E(a.xiuLuck) + '）');
      html += row('十二建除', E(a.zhiXing));
      html += row('喜神', E(a.posXi));
      html += row('財神', E(a.posCai));
      html += row('福神', E(a.posFu));
      html += row('陽貴', E(a.posYangGui));
      html += row('陰貴', E(a.posYinGui));
      html += '</div>';
      return html;
    }

    let tlAlmanacEl = null;
    function tlShowAlmanac(dateStr, anchorEl) {
      tlRemoveAlmanac();
      const pop = document.createElement('div');
      pop.className = 'ev-almanac-pop';
      pop.setAttribute('role', 'dialog');
      pop.setAttribute('aria-label', '老黃曆');
      pop.innerHTML = '<button type="button" class="ev-almanac-close" aria-label="關閉">✕</button>' + tlAlmanacHtml(dateStr);
      document.body.appendChild(pop);
      tlAlmanacEl = pop;
      const pw = pop.offsetWidth || 320, ph = pop.offsetHeight || 320;
      const r = anchorEl ? anchorEl.getBoundingClientRect() : null;
      let left = r ? r.left : (window.innerWidth - pw) / 2;
      let top = r ? r.bottom + 6 : (window.innerHeight - ph) / 2;
      if (left + pw > window.innerWidth - 8) left = window.innerWidth - pw - 8;
      if (top + ph > window.innerHeight - 8) top = window.innerHeight - ph - 8;
      pop.style.left = Math.max(8, left) + 'px';
      pop.style.top = Math.max(8, top) + 'px';
      pop.querySelector('.ev-almanac-close').addEventListener('click', tlRemoveAlmanac);
      setTimeout(() => document.addEventListener('click', tlAlmanacDocClick, true), 0);
    }
    function tlRemoveAlmanac() {
      if (tlAlmanacEl) { tlAlmanacEl.remove(); tlAlmanacEl = null; }
      document.removeEventListener('click', tlAlmanacDocClick, true);
    }
    function tlAlmanacDocClick(e) {
      if (tlAlmanacEl && !tlAlmanacEl.contains(e.target)) tlRemoveAlmanac();
    }

    // 事件绑定（DOM 就绪时执行一次）
    (function bindCalendarEventsUI() {
      const on = (id, ev, fn) => { const el = document.getElementById(id); if (el) el.addEventListener(ev, fn); };
      tlInitCalendarToolbarCombo();
      on('tlEvModeList', 'click', () => tlSetMode('list'));
      on('tlEvModeDay', 'click', () => tlSetMode('day'));
      on('tlEvModeWeek', 'click', () => tlSetMode('week'));
      on('tlEvModeMonth', 'click', () => tlSetMode('month'));
      on('tlEvModeYear', 'click', () => tlSetMode('year'));
      on('tlEvAddBtn', 'click', () => tlOpenEventForm(null));
      on('tlEvStatsBtn', 'click', () => tlOpenStats());
      document.addEventListener('click', (event) => {
        const button = event.target instanceof Element ? event.target.closest('.ev-undone-filter-btn') : null;
        if (!button) return;
        event.preventDefault();
        event.stopPropagation();
        tlToggleEventUndoneChecks(button.getAttribute('data-uid') || '', button);
      });
      on('tlEvPrevMonth', 'click', () => { if (tlCalMode === 'list') tlListNavDay(-1); else tlCalStepCursor(-1); });
      on('tlEvNextMonth', 'click', () => { if (tlCalMode === 'list') tlListNavDay(1); else tlCalStepCursor(1); });
      on('tlEvTodayBtn', 'click', () => {
        tlCalCursor = new Date();
        tlCalSelected = tlFmtDate(new Date());
        tlListSel = tlFmtDate(new Date());
        // 年/月视图点「今天」时，确保当前月份/今天日期完整显示
        if (tlCalMode === 'year') tlYearAutoScrollPending = true;
        if (tlCalMode === 'month') tlMonthAutoScrollPending = true;
        if (tlCalMode === 'list') tlListScrollAnchorPending = true; // 列表：显式导航→滚到今天
        else tlDetailListScrollPending = true; // 年/月/周/日 明细：显式导航→滚到今天
        tlRenderEventsContent();
      });
      on('tlEvMultiDayBtn', 'click', () => tlToggleMultiDayMode());   // 列表模式：跨天一笔 / 跨天多笔
      // 🗓 表單日期輸入變更 → 即時更新輸入框旁的星期提示
      on('tlEvFDate', 'change', tlUpdateFormDow);
      on('tlEvFDate', 'input', tlUpdateFormDow);
      on('tlEvFEndDate', 'change', tlUpdateFormDow);
      on('tlEvFEndDate', 'input', tlUpdateFormDow);
      const tagPicker = document.getElementById('tl-ev-tag-picker');
      const tagInput = document.getElementById('tlEvFTags');
      if (tagPicker && tagInput) {
        tagPicker.addEventListener('click', (e) => {
          const edit = e.target.closest('[data-tl-ev-tag-edit]');
          const editSubcat = e.target.closest('[data-tl-ev-tag-subcat-edit]');
          if (edit) {
            tlEvTagEditIndex = parseInt(edit.getAttribute('data-tl-ev-tag-edit'), 10);
            tlEvTagEditLevel = 'cat';
            tlRenderTagPicker();
            return;
          }
          if (editSubcat) {
            tlEvTagEditIndex = parseInt(editSubcat.getAttribute('data-tl-ev-tag-subcat-edit'), 10);
            tlEvTagEditLevel = 'subcat';
            tlRenderTagPicker();
            return;
          }
          const remove = e.target.closest('[data-tl-ev-tag-remove]');
          const option = e.target.closest('[data-tl-ev-tag-option]');
          if (remove) tlRemoveFormTag(remove.getAttribute('data-tl-ev-tag-remove'));
          else if (option) tlToggleFormTag(option.getAttribute('data-tl-ev-tag-option'));
          else { tagPicker.classList.add('open'); tlRenderTagPicker(); }
        });
        tagInput.addEventListener('input', () => { tagPicker.classList.add('open'); tlRenderTagPicker(); });
        tagInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') { e.preventDefault(); tlAddFormTag(tagInput.value); }
          else if (e.key === 'Backspace' && !tagInput.value) tlRemoveFormTag(tlEvFormTags[tlEvFormTags.length - 1]);
        });
        document.addEventListener('click', (e) => { if (!tagPicker.contains(e.target)) tagPicker.classList.remove('open'); });
      }
      // 标签过滤 chips（事件委托）
      const tf = document.getElementById('tlEvTagFilter');
      if (tf) tf.addEventListener('click', (e) => {
        const chip = e.target.closest('.ev-tag-chip');
        if (!chip) return;
        const t = chip.getAttribute('data-tag');
        const i = tlCalTagFilter.indexOf(t);
        if (i >= 0) tlCalTagFilter.splice(i, 1); else tlCalTagFilter.push(t);
        tlRenderEventsContent();
      });
      // 关联 Todo 卡片面板
      const tlp = document.getElementById('tlEvTodoLinkPanel');
      if (tlp) {
        tlp.addEventListener('dblclick', () => tlEvToggleTodoDropdown());
        tlp.addEventListener('keydown', (e) => { if (e.key === '?' || e.key === '/') { e.preventDefault(); tlEvToggleTodoDropdown(); } });
        tlp.addEventListener('click', (e) => {
          const x = e.target.closest('.ev-todo-chip-x');
          if (x) { tlEvRemoveTodoLink(x.getAttribute('data-id')); return; }
          const name = e.target.closest('.ev-todo-chip-name');
          if (name) {
            const id = name.getAttribute('data-id');
            if (id && typeof openEditModal === 'function') openEditModal(id);
            return;
          }
          tlEvToggleTodoDropdown();
        });
      }
      const tld = document.getElementById('tlEvTodoDropdown');
      if (tld) tld.addEventListener('click', (e) => {
        const item = e.target.closest('.ev-todo-dropdown-item');
        if (item) tlEvAddTodoLink(item.getAttribute('data-id'));
      });
      const ov = document.getElementById('tlEvFormOverlay');
      if (ov) ov.addEventListener('click', (e) => { if (e.target === ov) tlCloseEventForm(); });
      if (ov) {
        const markDirty = (e) => {
          if (e.target && e.target.matches && e.target.matches('input, select, textarea')) {
            if (!tlEvFormReadOnly) tlEvFormDirty = true;
          }
        };
        ov.addEventListener('input', markDirty);
        ov.addEventListener('change', markDirty);
      }
      // ⌨️ 行程編輯表單快捷鍵：Esc＝取消關閉、Command/Ctrl+S＝寫入編輯內容
      document.addEventListener('keydown', (e) => {
        if (!ov || ov.style.display === 'none') return;
        if (e.key === 'Escape') { e.preventDefault(); tlCloseEventForm(); }
        if ((e.metaKey || e.ctrlKey) && (e.key === 's' || e.key === 'S')) { e.preventDefault(); e.stopPropagation(); tlSaveEventForm(false); if (typeof saveTask === 'function') saveTask(false); }
      });
      // 🔁 重复事件一览：点遮罩关闭 + Esc 关闭
      const rov = document.getElementById('tlRepeatOverviewOverlay');
      if (rov) {
        rov.addEventListener('click', (e) => { if (e.target === rov) tlCloseRepeatOverview(); });
        document.addEventListener('keydown', (e) => {
          if (e.key === 'Escape' && rov.style.display !== 'none') tlCloseRepeatOverview();
        });
      }
      // 🖱 雙擊空白處快速新增：時間網格＝日期+時間（15 分鐘取整，默認 1 小時）、全天條＝日期(全天)、月格＝僅日期
      function tlGridDblClickNew(e) {
        if (e.target.closest('.ev-block') || e.target.closest('button')) return; // 點在已有行程上不新增
        const col = e.target.closest('.ev-tg-col[data-date]');
        if (col) {
          const rect = col.getBoundingClientRect();
          if (rect.height <= 0) return;
          const mins = Math.max(0, Math.min(23 * 60, Math.floor((e.clientY - rect.top) / rect.height * 24 * 60 / 15) * 15));
          const pad = (x) => String(x).padStart(2, '0');
          const endM = mins + 60;
          tlOpenEventForm(null, col.getAttribute('data-date'), {
            allDay: false,
            startTime: pad(Math.floor(mins / 60)) + ':' + pad(mins % 60),
            endTime: endM >= 24 * 60 ? '' : pad(Math.floor(endM / 60)) + ':' + pad(endM % 60),
          });
          return;
        }
        const ad = e.target.closest('.ev-allday-col[data-date]');
        if (ad) tlOpenEventForm(null, ad.getAttribute('data-date'), { allDay: true });
      }
      // 月模式不走原生 dblclick（單擊重繪導致 dblclick 不派發，見 tlSelectDate 內手動檢測）
      on('tlEvWeekWrap', 'dblclick', tlGridDblClickNew);
      // 🖱 列表模式：双击条目直接进入编辑状态（条目本身无单击打开，故用 dblclick 快捷编辑）
      document.addEventListener('dblclick', (e) => {
        // 📓「只显示日记」列表条目：双击进日记编辑（同样无单击打开；按钮区除外）
        const diaryRow = e.target.closest('.ev-item.ev-diary-item[data-ev-diary-row]');
        if (diaryRow) {
          // 「编辑 / 删除」按钮不触发双击编辑，避免与单击操作冲突（尤其删除按钮二次确认）
          if (e.target.closest('.ev-actions')) return;
          tlOpenDiaryForm(diaryRow.getAttribute('data-ev-diary-row'));
          return;
        }
        // 📎 双击假日（.ev-holiday）：被 include 进来的只读假日提示不可编辑（假日本无编辑入口，无 uid 的 ev-item 不会命中）
        const holidayEl = e.target.closest('.ev-holiday[data-ev-holiday]');
        if (holidayEl) {
          const hid = holidayEl.getAttribute('data-ev-holiday');
          const h = (tlCalHolidays || []).find((x) => x.uid === hid);
          if (h && h.ro) showToast('此假日来自被包含的只读文件，不可编辑', 'danger');
          return;
        }
        const item = e.target.closest('.ev-item[data-uid]');
        if (!item) return;
        // 勾选框 / 备注清单勾选框 / 编辑删除按钮不触发双击编辑，避免与单击操作冲突（尤其删除按钮二次删除）
        if (e.target.closest('.ev-check') || e.target.closest('.ev-actions') || e.target.closest('.ev-md-check')) return;
        tlOpenEventForm(item.getAttribute('data-uid'));
      });
      // 🖱 悬停行程事件 → 放大提示框（事件委托；tooltip 用 pointer-events:none 不挡点击）
      //    ⚠️ 只覆盖「内容被截断」的网格元素：月格 .ev-chip、周/日网格 .ev-block。
      //    列表行 .ev-item（列表模式 + 月/週/日下方明细）已完整显示内容，不再弹 tooltip（用户 2026-09-29 要求取消）。
      const tlTipPane = document.getElementById('calEventsPane');
      if (tlTipPane) {
        const evSel = '.ev-chip, .ev-block';
        tlTipPane.addEventListener('mouseover', (e) => {
          // 日记图标 hover → 显示日记 tip（仅当天有日记时）
          const dyBtn = e.target.closest('.ev-day-diary');
          if (dyBtn && dyBtn.getAttribute('data-ev-diary')) {
            const d = tlDiaryOnDate(dyBtn.getAttribute('data-ev-diary'));
            if (d) { tlShowDiaryTip(d.date, e.clientX, e.clientY); return; }
          }
          // 年视图日期格 hover → 显示当天所有日程/假日的富文本 tips（与表身列表 hover 同款）
          const yd = e.target.closest('.ev-year-day[data-ev-uids]');
          if (yd) { tlShowYearDayTip(yd, e); return; }
          const el = e.target.closest(evSel);
          if (el && el.getAttribute('data-uid')) tlShowTip(el.getAttribute('data-uid'), el.getAttribute('data-occ-date'), e.clientX, e.clientY);
        });
        tlTipPane.addEventListener('mousemove', (e) => {
          if (!tlTipEl || tlTipEl.style.display === 'none') return;
          const dyBtn = e.target.closest('.ev-day-diary');
          if (dyBtn && dyBtn.getAttribute('data-ev-diary')) {
            const d = tlDiaryOnDate(dyBtn.getAttribute('data-ev-diary'));
            if (d) { tlShowDiaryTip(d.date, e.clientX, e.clientY); return; }
          }
          // 年视图日期格：移动也保持/重定位 tips（不调用 tlHideTip 以免刚显示就被隐藏）
          const yd = e.target.closest('.ev-year-day[data-ev-uids]');
          if (yd) { tlShowYearDayTip(yd, e); return; }
          const el = e.target.closest(evSel);
          if (el && el.getAttribute('data-uid')) tlShowTip(el.getAttribute('data-uid'), el.getAttribute('data-occ-date'), e.clientX, e.clientY);
          else tlHideTip();
        });
        tlTipPane.addEventListener('mouseout', (e) => {
          const to = e.relatedTarget;
          if (to && to.closest) {
            if (to.closest(evSel)) return;                 // 仍在事件元素间移动，不隐藏
            if (to.closest('.ev-day-diary')) return;       // 仍在日记按钮上，不隐藏
            if (to.closest('.ev-year-day[data-ev-uids]')) return; // 仍在年视图日期格上（含子元素/相邻格），不隐藏
          }
          tlHideTip();
        });
        tlTipPane.addEventListener('mouseleave', tlHideTip);
      }
      // 🖱 事件统计：子事件内容悬停 → 浅蓝背景 tooltip（事件委托；替代原生深色 title）
      const tlStatsOverlayEl = document.getElementById('tlEvStatsOverlay');
      if (tlStatsOverlayEl) {
        const statsSel = '.tl-stats-detail-table .d-content[data-tip]';
        tlStatsOverlayEl.addEventListener('mouseover', (e) => {
          const cell = e.target.closest ? e.target.closest(statsSel) : null;
          if (cell) tlStatsTipShow(cell.getAttribute('data-tip'), e.clientX, e.clientY);
        });
        tlStatsOverlayEl.addEventListener('mousemove', (e) => {
          const cell = e.target.closest ? e.target.closest(statsSel) : null;
          if (cell) tlStatsTipShow(cell.getAttribute('data-tip'), e.clientX, e.clientY);
          else tlStatsTipHide();
        });
        tlStatsOverlayEl.addEventListener('mouseout', (e) => {
          const to = e.relatedTarget;
          if (to && to.closest && to.closest(statsSel)) return;
          tlStatsTipHide();
        });
      }
      // 🆕 闹铃查询：定位按钮事件委托（表格行里的「定位」是动态生成的 data-*）
      document.addEventListener('click', (e) => {
        const jumpBtn = e.target.closest ? e.target.closest('[data-tl-alarm-jump]') : null;
        if (jumpBtn) {
          const tab = jumpBtn.getAttribute('data-tab') || 'pending';
          const idx = parseInt(jumpBtn.getAttribute('data-idx'), 10);
          if (!isNaN(idx)) tlJumpToAlarmItem(tab, idx);
        }
      });
    })();
