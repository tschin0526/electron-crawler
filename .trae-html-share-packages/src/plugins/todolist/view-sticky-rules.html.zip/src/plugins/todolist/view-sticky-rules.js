/* ============================================================
 * 🧩 自定义「VIEW 便利贴」引擎（桌面版）
 * ------------------------------------------------------------
 * 这张文件做的事只有一件：照「🔔 提醒」投影贴（calendar-editor.js 的
 * tlViewStickyGroups / tlViewStickyRef）那一套逻辑，用「使用者自己设定的
 * 过滤条件」再多做几张一模一样的投影贴。
 *
 * 与 🔔 的关系：口径完全相同（同一个收集流程、同一个渲染管线、同一套只读规则），
 * 唯一的差别是「哪些行算数」——🔔 写死「带 [[remind:]] 的行」，
 * 这里改成规则里的 关键词／标记／行型态 三个条件。
 *
 * ⚠️ 故意为之的两件事：
 *   1. 🔔 那份代码留在 calendar-editor.js 里，没有搬进来共用。
 *      搬进来会让「投影贴」这个功能同时挂在两个档案上，而 🔔 已经有整套
 *      回归（含与 LITE 端的逐字比对）；改动的风险大于省下的几十行。
 *      ⇒ 改这里的收集／渲染口径时，先看一眼 calendar-editor.js:1176 起的母本，
 *        两边要一起改才不会出现「🔔 跟自定义贴行为不同」。
 *        唯一刻意不同的一处：**0 命中**时自订规则仍建一张贴（贴面写清「这个条件没抓到任何行」，
 *        见 EMPTY_NOTES），而 🔔 是没内容就没这张贴 —— 使用者要能翻到规则标题才知道去哪改。
 *   2. 三条例外口径沿用 🔔（主进程与便利贴窗都按 key 前缀 __view__ 认得它们）：
 *      ① 内容不落盘（key 是保留字，正文每次由行程现算；这张贴的外观／位置照一般便利贴存盘）；
 *      ② 只读（checkbox 不可点、小圆点不开编辑浮层、菜单只留 复制／找出相同）；
 *      ③ 浏览功能与普通便利贴完全一致（清单／翻页／搜索定位／样式）。
 *
 * 存档：规则本体存在主进程的 data/view-sticky-rules.json（全应用共用一份），
 *       这个档案只负责「规则 → 便利贴」，不读档、不写档、不碰 DOM。
 * ============================================================ */
(function (global) {
  'use strict';

  // ===== key：投影贴的身份证 =====
  //   🔔 的 key 是 '__view__'（历史保留字，也是没有 ruleId 时的形状）；
  //   自定义贴是 '__view__:<规则 id>'。主进程与便利贴窗都用「前缀」判断它是投影贴。
  const KEY_PREFIX = '__view__';
  const viewKeyOf = (ruleId) => (ruleId === '__builtin_remind__' || !ruleId)
    ? KEY_PREFIX : KEY_PREFIX + ':' + ruleId;
  const isViewKey = (key) => {
    const s = String(key == null ? '' : key);
    return s === KEY_PREFIX || s.indexOf(KEY_PREFIX + ':') === 0;
  };

  // ===== 行型态判定（三个正则与 🔔 的 TL_VIEW_*_RE 同名同值，别单独调这里）=====
  const TASK_RE = /^-\s+\[([ xX])\]\s?([\s\S]*)$/;                                       // = TL_VIEW_TASK_RE
  // 渲染 checkbox 行时要保留原始缩进 → 这条多带一个「行首空白」捕获组（＝🔔 的 tlViewTaskLineHtml 内联式）
  const TASK_LINE_RE = /^(\s*)-\s+\[([ xX])\]\s?([\s\S]*)$/;
  const DONE_CHECK_RE = /^[ \t]*(?:>[ \t]*)*(?:[-*+]|\d+[.)])[ \t]+\[[xX]\](?=[ \t]|$)/; // = TL_VIEW_DONE_CHECK_RE
  const LIST_ITEM_RE = /^[ \t]*(?:[-*+]|\d+[.)])[ \t]+\S/;                              // = TL_VIEW_LIST_ITEM_RE
  const QUOTE_RE = /^>[ \t]*/;
  const HEADING_RE = /^#{1,6}(\s|$)/;
  const FENCE_RE = /^\s*(```|~~~)/;
  const ROW_TYPES = ['todo', 'done', 'list', 'para', 'quote', 'heading'];
  const ROW_TYPE_LABEL = {
    todo: '未完成 checkbox', done: '已完成 checkbox', list: '列表项',
    para: '段落／纯文字', quote: '引用（>）', heading: '标题（#）'
  };
  // ===== 🆕 启动通知：勾了「通知讯息」的 VIEW 贴，在便利贴启动时先闪烁显示 =====
  //   这两个值属于「显示行为」不是过滤条件，但同样收在规则里（维护作业唯一写入端）。
  //   默认不勾；秒数默认 15 秒，夹在 1–600 秒（避免 0 秒／负数／浮夸值）。
  const NOTIFY_DEFAULT_SECONDS = 15;
  const NOTIFY_MIN_SECONDS = 1;
  const NOTIFY_MAX_SECONDS = 600;
  function normalizeNotifySeconds(v) {
    const n = typeof v === 'number' && isFinite(v) ? Math.round(v) : NOTIFY_DEFAULT_SECONDS;
    return Math.min(NOTIFY_MAX_SECONDS, Math.max(NOTIFY_MIN_SECONDS, n));
  }
  // 是否要当启动通知：必须是启用中的规则且勾了通知
  function isNotifyRule(rule) {
    const r = normalizeRule(rule);
    return r.enabled && r.notify === true;
  }

  const BUILTIN_REMIND_RULE = {
    id: '__builtin_remind__',
    title: '🔔 提醒',
    enabled: true,
    keywords: [],
    keywordMode: 'ANY',
    marker: 'remind',
    caseSensitive: false,
    emptyBehavior: 'hide',
    builtin: true,
    notify: false,
    notifySeconds: NOTIFY_DEFAULT_SECONDS,
    rowTypes: { todo: true, done: false, list: true, para: true, quote: true, heading: true }
  };
  const MARKERS = [
    { value: '', label: '不限（有命中条件就算）' },
    { value: 'remind', label: '[[remind:…]] 提醒标记' },
    { value: 'bookmark', label: '[[bookmark:…]] 收藏标记' },
    { value: 'alert', label: '[[alert:…]] 闹铃标记' },
    { value: 'cr', label: '[[cr:…]] 建立日期标记' },
    { value: 'dl', label: '[[dl:…]] deadline 标记' },
    { value: 'cp', label: '[[cp:…]] completed 标记' }
  ];

  // 一行属于哪种「型态」。判定顺序＝🔔 的过滤顺序：围栏 > 已打勾 > checkbox > 列表 > 引用 > 标题 > 段落。
  function rowTypeOf(rawLine, trimmed) {
    if (DONE_CHECK_RE.test(rawLine)) return 'done';
    if (TASK_RE.test(trimmed)) return 'todo';
    if (LIST_ITEM_RE.test(rawLine)) return 'list';
    if (QUOTE_RE.test(trimmed)) return 'quote';
    if (HEADING_RE.test(trimmed)) return 'heading';
    return 'para';
  }

  // ===== 规则：读进来的 JSON 一律先归一化（缺字段补默认值，脏值不让它炸）=====
  // 段落（segment）：每一段＝一个完整的搜索（关键词＋标记＋模式＋大小写＋行型态）。
  //   旧版规则没有 segments 字段 → 用顶层条件合成「单一段落」（向后兼容，外观与旧版一致）。
  function normalizeSegment(raw) {
    const s = raw && typeof raw === 'object' ? raw : {};
    const kw = Array.isArray(s.keywords) ? s.keywords
      : (typeof s.keywords === 'string' ? String(s.keywords).split(/[,，、\n]/) : []);
    const tags = Array.isArray(s.tags) ? s.tags
      : (typeof s.tags === 'string' ? String(s.tags).split(/[,，、\n]/) : []);
    const marker = MARKERS.some((m) => m.value === s.marker) ? s.marker : '';
    const rt = s.rowTypes && typeof s.rowTypes === 'object' ? s.rowTypes : null;  // null＝继承规则层
    // 🆕 日期条件：建档日(cr)／完成日(cp)／预计完成(dl)，两种比较口径——固定日期(kind 省略) 或 距今天数(kind:'age')：
    //   • 固定日期：该日期 比较 设定日(value: YYYY-MM-DD)；
    //   • 距今天数：该日期 到今天 经过 N 天（ageDays = today − d），再拿 N 跟 days 比较（> 超过／< 不到／= 正好）。
    //   两者都限定小事件勾选状态(doneState)。合法条件＝field + op + (固定日期的 value ｜ 距今天数的 days≥0)。
    const FIELDS = { cr: 1, dl: 1, cp: 1, ev: 1 }, OPS = { '>': 1, '<': 1, '=': 1 }, DONE = { any: 1, undone: 1, done: 1 };
    const dc = (s.dateCond && typeof s.dateCond === 'object') ? s.dateCond : null;
    let dateCond = null;
    if (dc && FIELDS[dc.field] && OPS[dc.op]) {
      const doneState = DONE[dc.doneState] ? dc.doneState : 'any';
      if (dc.kind === 'age') {
        const rawDays = typeof dc.days === 'number' ? Math.round(dc.days) : parseInt(String(dc.days), 10);
        if (isFinite(rawDays) && rawDays >= 0) dateCond = { field: dc.field, op: dc.op, kind: 'age', days: rawDays, doneState };
      } else if (/^\d{4}-\d{2}-\d{2}$/.test(dc.value || '')) {
        dateCond = { field: dc.field, op: dc.op, value: dc.value, doneState };
      }
    }
    return {
      title: String(s.title == null ? '' : s.title).replace(/\s+/g, ' ').trim(),
      keywords: kw.map((x) => String(x == null ? '' : x).trim()).filter(Boolean),
      keywordMode: s.keywordMode === 'ALL' ? 'ALL' : 'ANY',
      tags: tags.map((x) => String(x == null ? '' : x).trim()).filter(Boolean),
      tagMode: s.tagMode === 'ALL' ? 'ALL' : 'ANY',
      detail: s.detail === false ? false : true,   // false＝只显示事件标题（不收明细行）
      includeDoneEvents: s.includeDoneEvents === false ? false : true,  // 标题模式下是否也列「已完成」事件的标题（默认列）
      // 🆕 单开关「只列含未完 checkbox 的事件」：① 收录判定只看是否真有未打勾 checkbox 行（type==='todo'）→ 隐藏无子项的纯标题事件（台雄生日等）；
      //   ② 事件级「未完成」闸门对「已勾完成却仍含未完 checkbox」的事件放行（保留「留尾巴」资料）。二者同源（都围绕「未完 checkbox」），
      //      合并为单一开关，去掉维护窗两个语义重叠的勾选框（用户 2026-11-03 指摘冗余）。旧配置 keepUndoneInDone 视为同义开启，平滑迁移。
      hideNoHitEvents: s.hideNoHitEvents === true || s.keepUndoneInDone === true,
      marker: marker,
      dateCond: dateCond,
      caseSensitive: !!s.caseSensitive,
      rowTypes: rt ? {
        todo: rt.todo !== false,
        done: rt.done === true,        // 默认不收已打勾（与 🔔 同口径：打勾＝不必再提醒）
        list: rt.list !== false,
        para: rt.para !== false,
        quote: rt.quote !== false,
        heading: rt.heading !== false
      } : null
    };
  }
  function blankSegment() { return normalizeSegment({ title: '', keywords: [], keywordMode: 'ANY', tags: [], tagMode: 'ANY', detail: true, includeDoneEvents: true, marker: '', caseSensitive: false, rowTypes: null }); }
  function normalizeRule(raw) {
    const r = raw && typeof raw === 'object' ? raw : {};
    const rt = r.rowTypes && typeof r.rowTypes === 'object' ? r.rowTypes : {};
    const ruleRowTypes = {
      todo: rt.todo !== false, done: rt.done === true, list: rt.list !== false,
      para: rt.para !== false, quote: rt.quote !== false, heading: rt.heading !== false
    };
    // 段落：优先用显式 segments；否则（旧版规则）用顶层条件合成单一段落
    let segments;
    if (Array.isArray(r.segments) && r.segments.length) segments = r.segments.map(normalizeSegment);
    else segments = [normalizeSegment({
      title: '', keywords: r.keywords, keywordMode: r.keywordMode,
      marker: r.marker, caseSensitive: r.caseSensitive, rowTypes: r.rowTypes
    })];
    segments.forEach((s) => { if (!s.rowTypes) s.rowTypes = ruleRowTypes; });  // 未明写行型态→继承规则层
    return {
      id: String(r.id == null ? '' : r.id),
      title: String(r.title == null ? '' : r.title).replace(/\s+/g, ' ').trim() || '自定义便利贴',
      enabled: r.enabled !== false,
      segments: segments,
      emptyBehavior: r.emptyBehavior === 'hide' ? 'hide' : 'show',
      builtin: r.builtin === true,
      // 🆕 内置「提醒」规则改为「可编辑但不可删」：不再因为 builtin 而自动 readonly。
      //   readonly 只留给显式标记 r.readonly===true 的规则（目前没有），保留这个字段以备将来锁定用。
      readonly: r.readonly === true,
      // 🆕 启动通知（便利贴启动时先闪烁显示这张贴，秒数到或手动关闭后才进正常显示）
      notify: r.notify === true,
      notifySeconds: normalizeNotifySeconds(r.notifySeconds)
    };
  }
  function normalizeList(list) {
    return (Array.isArray(list) ? list : []).filter((r) => r && typeof r === 'object').map(normalizeRule);
  }
  function newRuleId() { return 'vsr-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7); }
  function blankRule() { return normalizeRule({ id: newRuleId(), title: '' }); }
  function builtinRules() { return [normalizeRule(BUILTIN_REMIND_RULE)]; }

  // 单段条件文案（不含「段落」前缀）：维护窗清单、徽标弹层、段落标题共用，保证同口径。
  //   ⚠️ 标记用「标记＝remind」而不是「[[remind:…]]」——后者会被 termDefs 当胶囊解析，
  //      这里只是说明文字，不能出现成对的双方括号。
  function conditionText(cond) {
    if (!cond) return '⚠ 没有条件（不会抓到内容）';
    // 🆕 只显示事件标题：带标签条件的段落自动走此模式（用户 2026-10-31 要求标签搜索只列标题）；
    //    行级条件（标记／行型态）在此模式不适用，只列事件级条件＋明确标注「只显示事件标题」。
    const titleOnly = (cond.tags && cond.tags.length > 0) || cond.detail === false;
    if (titleOnly) {
      const parts = [];
      if (cond.tags && cond.tags.length) parts.push('标签' + (cond.tagMode === 'ALL' ? '全有' : '任一') + '：' + cond.tags.join('、'));
      if (cond.keywords && cond.keywords.length) parts.push('标题关键词' + (cond.keywordMode === 'ALL' ? '全中' : '任一') + '：' + cond.keywords.join('、') + (cond.caseSensitive ? '（区分大小写）' : ''));
      if (!parts.length) parts.push('⚠ 没有条件（不会抓到内容）');
      parts.push('只显示事件标题');
      if (cond.includeDoneEvents === false) parts.push('（不含已完成事件）');
      return parts.join(' ＋ ');
    }
    const parts = [];
    if (cond.marker) parts.push('标记＝' + cond.marker);
    if (cond.keywords.length) parts.push('关键词' + (cond.keywordMode === 'ALL' ? '全中' : '任一') + '：' + cond.keywords.join('、') + (cond.caseSensitive ? '（区分大小写）' : ''));
    if (cond.tags && cond.tags.length) parts.push('标签' + (cond.tagMode === 'ALL' ? '全有' : '任一') + '：' + cond.tags.join('、'));
    if (cond.dateCond) {
      const fld = { cr: '建档日期', dl: '预计完成', cp: '完成日期', ev: '事件日期' }[cond.dateCond.field] || cond.dateCond.field;
      const st = { undone: '未完成', done: '已完成', any: '' }[cond.dateCond.doneState] || '';
      if (cond.dateCond.kind === 'age') {
        // 距今天数口径（直觉版）：> 距离今天 N 天后（未来侧）／< 距离今天 N 天前（过去侧）／= 距今天正好 N 天
        const opAge = {
          '>': '距离今天 ' + cond.dateCond.days + ' 天后',
          '<': '距离今天 ' + cond.dateCond.days + ' 天前',
          '=': '距离今天 正好 ' + cond.dateCond.days + ' 天'
        }[cond.dateCond.op] || cond.dateCond.op;
        parts.push(fld + ' ' + opAge + (st ? '（' + st + '）' : ''));
      } else {
        const op = { '>': '晚于', '<': '早于', '=': '等于' }[cond.dateCond.op] || cond.dateCond.op;
        parts.push(fld + op + cond.dateCond.value + (st ? '（' + st + '）' : ''));
      }
    }
    if (!parts.length) parts.push('⚠ 没有条件（不会抓到内容）');
    const types = ROW_TYPES.filter((t) => cond.rowTypes && cond.rowTypes[t]).map((t) => ROW_TYPE_LABEL[t]);
    parts.push('行型态：' + (types.join('／') || '无'));
    if (cond.hideNoHitEvents) parts.push('只列含未完 checkbox 的事件（隐藏无子项纯标题、保留已勾完成却留尾巴）');
    return parts.join(' ＋ ');
  }
  // 规则摘要（人类可读）：单段＝旧格式（与旧版一致）；多段＝「共 N 段：段落1（…）｜段落2（…）」。
  function ruleSummary(rule) {
    const r = normalizeRule(rule);
    if (r.segments.length === 1) return conditionText(r.segments[0]);
    return '共 ' + r.segments.length + ' 段：' + r.segments.map((s, i) =>
      '段落' + (i + 1) + (s.title ? '：' + s.title : '') + '（' + conditionText(s) + '）').join(' ｜ ');
  }

  // 这一段是否算「有搜索条件」（关键词／标记至少要有一个）；整条规则＝任一段有即可
  function segmentHasCondition(seg) {
    return !!seg && (seg.keywords.length > 0 || !!seg.marker || (seg.tags && seg.tags.length > 0) || !!seg.dateCond);
  }
  function ruleHasCondition(rule) {
    return (rule && Array.isArray(rule.segments) ? rule.segments : []).some(segmentHasCondition);
  }
  function lineHitsRule(line, trimmed, cond) {
    if (cond.marker && !new RegExp('\\[\\[' + cond.marker + ':', 'i').test(line)) return false;
    if (!cond.keywords.length) return true;
    const hay = cond.caseSensitive ? trimmed : trimmed.toLowerCase();
    const ok = cond.keywords.map((k) => (cond.caseSensitive ? k : k.toLowerCase()))
      .filter((k) => k).map((k) => hay.indexOf(k) >= 0);
    return cond.keywordMode === 'ALL' ? ok.every(Boolean) : ok.some(Boolean);
  }

  // 0 命中时贴面上的话：把「为什么是空的」和「去哪改」直接写在贴子上。
  //   ⚠️ 这段刻意不出现成对的双方括号：它会先过 termDefs（术语胶囊）再进 markdown，
  //      写成 `[[remind:` 那种示范文字有被解析器咬掉的风险，所以只讲「顺序、括号位置要对得上」。
  const EMPTY_NOTES = '**这个条件目前没抓到任何行**\n\n关键词要和行程档里出现的文字一模一样（顺序与括号位置都要对得上）；要抓提醒，请把上方的「标记条件」选成 remind。改条件请开便利贴菜单的「🧩 自定义 VIEW 便利贴设定维护作业」。';

  // ===== 依赖注入 =====
  //   渲染器由宿主（calendar-editor.js）传进来，保持「单一可信来源」：
  //   投影贴的文字必须跟列表行、普通便利贴走同一条管线，否则 <BIG>／[[术语]] 会显示成原文。
  //   没传就退回全局函数（calendar-editor.js 的 function 声明就是全局）；再没有才降级成纯文字。
  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  }
  function makeDeps(d) {
    if (d && typeof d.esc === 'function' && typeof d.inline === 'function') return d;   // 已解析过的 deps 直接用
    const e = d && typeof d === 'object' ? d : {};
    const pick = (name, fallback) => {
      if (typeof e[name] === 'function') return e[name];
      if (typeof global[name] === 'function') return global[name];
      return fallback;
    };
    return {
      esc: pick('tlEscapeHtml', escapeHtml),
      inline: pick('tlRenderInlineMarkdown', (s) => String(s == null ? '' : s)),
      noteMarkers: pick('tlRenderNoteMarkers', (s) => String(s == null ? '' : s)),
      termDefs: pick('tlRenderTermDefs', (s) => String(s == null ? '' : s)),
      nameRefs: pick('tlRenderNameRefs', (s) => String(s == null ? '' : s)),
      markdown: pick('renderMarkdown', (s) => String(s == null ? '' : s)),
      shortDate: pick('tlMdShort', (s) => String(s == null ? '' : s))
    };
  }

  // ===== 收集：一段条件 ＋ 全部行程 → 分组（结构与 🔔 的 tlViewStickyGroups 逐字相同）=====
  //   回传 [{ ev, hits }]，hits＝[{ raw, line, uid, text, task, type }]＋分隔用空行 { raw:'', sep:true }。
  //   line＝来源行程备注里的 0-based 行号；text＝checkbox 内文（便利贴窗右键「找出相同」要比对的字）。
  //   收哪些行：围栏程式码块内的标记是范例→不收；其余按 rowTypes／关键词／标记过滤。
  //   ⚠️ 「列表项」后面直接接「非列表行」＝CommonMark 的 lazy continuation，会被并到上一条里面，
  //      所以中间要补一个空行（收集来的行原本未必相邻，源档的空行不会一起带过来）。
  //   cond＝一个段落（segment）：{ keywords, keywordMode, marker, caseSensitive, rowTypes }。
  // 🆕 事件是否「已完成」：
  //   ① 优先认事件级的「已完成」勾选框（编辑器里「已完成」写入的 ev.done，与标题旁「· 已完成」同为一条数据）；
  //   ② 兜底：事件备注里的 checkbox 子项（与 TASK_RE 同口径，仅认 `- [ ]`／`- [x]`）至少有一项、且全部已打勾（[x]）。
  //   没有任何 checkbox 子项、且事件级未勾选「已完成」的事件 → 不算已完成（照常显示，不受 includeDoneEvents 影响）。
  function eventIsCompleted(ev) {
    if (!ev) return false;
    // ① 事件级「已完成」勾选框（编辑器「已完成」写入的 ev.done）—— 这是最直接的信号
    if (ev.done === true) return true;
    // ② 兜底：备注里 checkbox 子项全部已打勾
    const notes = String(ev.notes || '');
    let any = false, allDone = true;
    notes.replace(/\r\n/g, '\n').split('\n').forEach((line) => {
      const t = line.trim();
      if (!t) return;
      const m = t.match(TASK_RE);
      if (m) { any = true; if (m[1] !== 'x' && m[1] !== 'X') allDone = false; }
    });
    return any && allDone;
  }
  // 🆕 事件备注里是否含有「未完成的 checkbox」（− [ ]）：用于「事件已勾『已完成』却还留尾巴」的边界——
  //   用户要求这类事件的未完 checkbox 也要被抓出来（见 collectGroups 的 ev+undone 闸门：hideNoHitEvents 开启时对「已勾完成却留尾巴」的事件放行）。
  function eventHasUncompletedCheckbox(ev) {
    if (!ev) return false;
    return /\n?[ \t]*-\s+\[\s\]\s?/.test('\n' + String(ev.notes || ''));
  }
  // 🆕 今天的日期（本地，YYYY-MM-DD）：相对日期条件用
  function todayStr() {
    const t = new Date();
    const y = t.getFullYear();
    const m = String(t.getMonth() + 1).padStart(2, '0');
    const d = String(t.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + d;
  }
  // 🆕 两个 YYYY-MM-DD 相差的整数天（按 UTC 计算，避开日光节约时间造成的 ±1 小时误差）；a→b 为正表示 b 较晚
  function daysBetween(a, b) {
    const da = Date.parse(a + 'T00:00:00Z');
    const db = Date.parse(b + 'T00:00:00Z');
    if (!isFinite(da) || !isFinite(db)) return NaN;
    return Math.floor((db - da) / 86400000);
  }
  // 🆕 在 YYYY-MM-DD 上加／减 N 天（UTC 计算，避开日光节约误差），回传 YYYY-MM-DD
  function addDays(dateStr, n) {
    const t = Date.parse(dateStr + 'T00:00:00Z');
    if (!isFinite(t)) return '';
    const d = new Date(t + n * 86400000);
    const y = d.getUTCFullYear();
    const m = String(d.getUTCMonth() + 1).padStart(2, '0');
    const day = String(d.getUTCDate()).padStart(2, '0');
    return y + '-' + m + '-' + day;
  }
  // 🆕 日期条件匹配：小事件须是 checkbox（按 doneState 限定 未完成／已完成），且行内含 [[field:YYYY-MM-DD]]；
  //   固定模式＝该日期 比较 设定日；相对模式（kind:'age'）＝该日期 到今天 经过的天数 比较 N 天。
  //   🆕 2026-11-08：cr/cp 新写入格式为 [[cr:YYYY-MM-DD HH:mm]]，故日期后面允许可选的本机 HH:mm；
  //      capture 仍只取「日历日」，日期条件一律按日比较（时间只用于 VIEW 排序，见便利贴窗 viewSortKey）。
  function dateCondMatch(type, line, dc) {
    if (dc.doneState === 'undone' && type !== 'todo') return false;
    if (dc.doneState === 'done' && type !== 'done') return false;
    if (dc.doneState === 'any' && type !== 'todo' && type !== 'done') return false;
    const m = line.match(new RegExp('\\[\\[' + dc.field + ':(\\d{4}-\\d{2}-\\d{2})(?:[ T]\\d{2}:\\d{2})?\\]\\]', 'i'));
    if (!m) return false;
    const d = m[1];
    if (dc.kind === 'age') {
      // 🆕 用户直觉口径（2026-11-01 调整）：> ＝「距离今天 N 天后」（field 在 今天+N 之后，未来侧）；
      //    < ＝「距离今天 N 天前」（field 在 今天−N 之前，过去侧，如建档已满 N 天）；= ＝「距今天正好 N 天」（前后皆可）。
      //    以「今天 ± N 天」为比较基准，operator 方向不再与直觉相反（旧版用「该日期已存放几天」再比，导致 > 反而抓到更旧的）。
      const today = todayStr();
      if (dc.op === '=') return Math.abs(daysBetween(d, today)) === dc.days;   // 正好距离今天 N 天
      const target = addDays(today, dc.op === '>' ? dc.days : -dc.days);        // 后：今天+N；前：今天−N
      if (!target) return false;
      const cmp = d < target ? -1 : (d > target ? 1 : 0);
      if (dc.op === '>') return cmp > 0;   // 距离今天 N 天后（未来侧）
      if (dc.op === '<') return cmp < 0;   // 距离今天 N 天前（过去侧）
      return false;
    }
    const cmp = d < dc.value ? -1 : (d > dc.value ? 1 : 0);
    if (dc.op === '>') return cmp > 0;
    if (dc.op === '<') return cmp < 0;
    return cmp === 0;
  }
  // 🆕 事件日期条件（dateCond.field === 'ev'）：比对「事件本身的日历日」ev.date，而非行内 [[cr/dl/cp:…]] 标记。
  //    只在「事件级」判定整张事件是否收（在 collectGroups 的事件循环外调用）；固定模式比 value，距今天数模式比 今天±N。
  //    ⚠️ 跨天行程（endDate 存在且 ≠ date）：事件日期是一个「区间 [lo, hi]」而非单日——与日历「某天 occurring」同口径，
  //       今天／指定日 落在 [lo, hi] 内即算该日有此行程。这是修复核心：旧版只比起始日 ev.date，导致「10/31–11/1」的行程
  //       在 11/1（今天）因 起始日距今天 1 天 ≠ 0 而被「正好 0 天（今天）」条件漏掉。
  //    复用 todayStr/addDays/daysBetween；operator 语义与 dateCondMatch 一致（> 后／< 前／= 正好），边界含当日。
  function eventDateMatch(ev, dc) {
    const today = todayStr();
    const d0 = (ev && typeof ev.date === 'string') ? ev.date : '';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d0)) return false;
    // 跨天行程 → 区间 [lo, hi]（ISO 串可直接按字典序比较）；否则单日 lo=hi=date。
    //   ⚠️ endDate 必须是合法日期串才视为跨天——单日事件 endDate 多为空串 ''，若误当成区间下界会把 lo 变成 ''，
    //      使「today >= lo」恒真而把未来单日事件也漏进「今天」匹配（2026-11-01 测试发现）。
    const d1 = (ev && typeof ev.endDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(ev.endDate) && ev.endDate !== d0) ? ev.endDate : d0;
    let lo = d0 <= d1 ? d0 : d1, hi = d0 <= d1 ? d1 : d0;
    // 🆕 显示方式（spanDisplay）＝锚定「行程实际被渲染的那一天」，与日历 tlEventOccurrences / tlEventDisplayDate 完全同口径，
    //   否则「显示在今天」的行程在 VIEW 便利贴里会被漏掉（2026-11-02 用户回报：日历能显示、VIEW 抓不到）。
    //   • 'today'（显示在今天）：无视真实 date/endDate，整张只锚定今天 → 「正好今天(days:0)」命中、其余日期不命中；
    //     固定日期查询 value===today 也命中（它确实「显式出现在今天」），value===真实日期则不命中（它今天不渲染）。
    //   • 'first'/'last'（首末天）：仅多天行程的 首天／末天 被渲染（tlFilterSpanDisplay），区间收缩为 [lo,lo]／[hi,hi]；单天等同 daily。
    //   • 其余（'daily' 或空）→ 维持原区间 [lo, hi]（跨天行程整段可命中，见 2026-11-01 修复）。
    const span = (ev && typeof ev.spanDisplay === 'string') ? ev.spanDisplay : 'daily';
    if (span === 'today') { lo = hi = today; }
    else if (span === 'first') { hi = lo; }
    else if (span === 'last') { lo = hi; }
    if (dc.kind === 'age') {
      if (dc.op === '=') {
        // 正好 N 天：N=0 → 今天落在行程区间内（含跨天，与日历「今天」一致）；N>0 → 行程发生的某天正好是「今天±N」（前后皆可）
        if (dc.days === 0) return today >= lo && today <= hi;
        const fwd = addDays(today, dc.days), bwd = addDays(today, -dc.days);
        return (fwd >= lo && fwd <= hi) || (bwd >= lo && bwd <= hi);
      }
      const target = addDays(today, dc.op === '>' ? dc.days : -dc.days);   // 后：今天+N；前：今天−N
      if (!target) return false;
      // > 后（未来侧）：行程起始在 target 当天或之后（N=1 即「明天」起，与维护窗说明一致）；
      // < 前（过去侧）：行程结束在 target 当天或之前（整段已过去）。
      if (dc.op === '>') return lo >= target;
      return hi <= target;
    }
    // 固定日期：该日期落在行程区间内即命中（与日历「某天 occurring」同口径）；op 仍区分 晚于／早于／等于（边界含当日）
    const v = dc.value;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
    if (dc.op === '=') return v >= lo && v <= hi;   // 指定日在区间内（含跨天）
    if (dc.op === '>') return lo >= v;               // 晚于：行程起始在 value 当天或之后
    return hi <= v;                                   // 早于：行程结束在 value 当天或之前
  }
  function collectGroups(events, cond, deps, includeTitle) {
    const D = makeDeps(deps);
    const searchTitle = includeTitle !== false;   // 默认纳入标题搜索；🔔 内置贴传 false 保持只搜正文
    const groups = [];
    if (!segmentHasCondition(cond)) return groups;
    (Array.isArray(events) ? events : []).forEach((ev) => {
      if (!ev) return;
      // 🆕 事件级标签过滤：事件须带指定标签（tags 任一／全部）才纳入本段搜索；与下方行级条件为「且」
      if (cond.tags && cond.tags.length) {
        const evTagNames = (ev.tags || []).map((t) => (t && typeof t === 'object' ? (t.name || '') : (t || '')));
        const tagHit = cond.tagMode === 'ALL'
          ? cond.tags.every((tg) => evTagNames.indexOf(tg) >= 0)
          : cond.tags.some((tg) => evTagNames.indexOf(tg) >= 0);
        if (!tagHit) return;
      }
      // 🆕 事件日期条件（dateCond.field==='ev'）：事件级闸口，整张事件按其日历日 ev.date 过滤；命中才继续收内容。
      //    与「行内标记」日期条件（cr/dl/cp）不同——ev 比的是事件本身的日期，用于「某天（或今天）的日程汇总」。
      if (cond.dateCond && cond.dateCond.field === 'ev' && !eventDateMatch(ev, cond.dateCond)) return;
      // 🆕 事件状态（dateCond.doneState）在 field:'ev' 时作用于「整张事件」，而非逐行 checkbox：
      //   'undone' → 排除已完成的事件（ev.done 为真，或备注里 checkbox 子项全部已打勾）；'done' → 只收已完成的；'any'（默认）→ 不限制。
      //   否则「所有未完成的项目」这类规则会把「小事件全打勾 ＋ 事件本身已勾」的已完成行程也列进来——
      //   因为明细模式只要有「任意一行」（如备注里的段落文字）命中就收整张事件，导致已完成行程照样出现（2026-11-02 用户回报）。
      //   🆕 hideNoHitEvents（单开关「只列含未完 checkbox 的事件」，ev+undone）：事件虽已勾「已完成」，但备注里仍有未完 checkbox 时，不整张排除——
      //     把那张事件的未完 checkbox 也抓出来（用户 2026-11-03 明确要求「已勾完成却留尾巴的 checkbox 也要」）。
      //     判断「真正全完」＝ eventIsCompleted 且 不含未完 checkbox；只要还有未完 checkbox，就保留该事件。
      if (cond.dateCond && cond.dateCond.field === 'ev' && cond.dateCond.doneState && cond.dateCond.doneState !== 'any') {
        const completed = eventIsCompleted(ev);
        if (cond.dateCond.doneState === 'undone') {
          const keep = cond.hideNoHitEvents && eventHasUncompletedCheckbox(ev);
          if (completed && !keep) return;   // 真正全完才排除；留尾巴则保留
        } else if (cond.dateCond.doneState === 'done' && !completed) {
          return;    // 只收已完成
        }
      }
      // 🆕 自动「只显示事件标题」：带标签条件的段落，事件级命中即收整张行程、不展开其下的小事件
      //    （checkbox 子项）——用户 2026-10-31 明确要求：标签搜索只列事件标题，不要把小事件也列出。
      //    亦兼容旧手动开关 detail:false（残留则同样走此分支）。行级条件（标记／行型态）在此无意义→忽略；
      //    若段落另设了关键词，则只比对事件标题（标题命中才收这张行程）。
      // 🆕 日期条件只在明细（行）模式有意义 → 有 dateCond 时强制走明细分支（即便也设了标签／只显示标题）
      const titleOnly = cond.dateCond && cond.dateCond.field ? false : ((cond.tags && cond.tags.length > 0) || cond.detail === false);
      if (titleOnly) {
        // 🆕 关闭「包含已完成事件」时，跳过「已完成」事件的标题（事件级「已完成」勾选框已勾，
        //    或其备注里 checkbox 子项全部已打勾）。仅影响标题模式的事件级收录；明细模式由行型态的
        //    已完成 checkbox 控制，与此无关。
        if (cond.includeDoneEvents === false && eventIsCompleted(ev)) return;
        let ok = true;
        if (cond.keywords && cond.keywords.length) {
          const titleRaw = String(ev.title == null ? '' : ev.title);
          ok = searchTitle && titleRaw.trim() ? lineHitsRule(titleRaw, titleRaw.trim(), cond) : false;
        }
        if (ok) groups.push({ ev, hits: [] });
        return;
      }
      const hits = [];
      let inFence = false;
      // 🆕 块级 {gpX}…{/gpX}：先扫 fenceInfo，再按 range 整块保留
      const noteLines = String(ev.notes || '').replace(/\r\n/g, '\n').split('\n');
      const fenceInfo = gpFenceScan(noteLines);
      const fenceMarkers = new Set(fenceInfo.markers);
      const fenceBlockAt = new Map();
      const rangeAttrs = new Map();   // rangeIndex → visual attrs
      fenceInfo.ranges.forEach((r, n) => {
        const blockId = '\u0000blk' + n;
        for (let k = r.start + 1; k < r.end; k++) fenceBlockAt.set(k, blockId);
        // 🆕 从 open 行提取 fg/bg attrs
        const openLine = noteLines[r.start] || '';
        const a = extractGpAttrsLocal(openLine);
        rangeAttrs.set(n, { fg: a && a.fg ? a.fg : '', bg: a && a.bg ? a.bg : '', anim: a && a.anim ? a.anim : '', alert: !!(a && a.alert), termName: a && a.termName ? a.termName : '', name: a && a.name ? a.name : '', railStyle: a && a.railStyle ? a.railStyle : '', railA: a && a.railA ? a.railA : '', railB: a && a.railB ? a.railB : '' });
      });
      // 🆕 预扫每个 gp fence range：区间内**至少一行命中过滤条件** → 整块保留
      //    （不是只保留命中行！否则排序会把同一块内的命中行和未命中行打散到不同位置。）
      const gpWholeBlocks = new Set();  // rangeIndex → 整块保留
      fenceInfo.ranges.forEach((r, n) => {
        for (let k = r.start + 1; k < r.end; k++) {
          if (isLineHit(noteLines[k])) { gpWholeBlocks.add(n); break; }
        }
      });
      function isLineHit(line) {
        const t = String(line == null ? '' : line).trim();
        if (!t) return false;
        const type = rowTypeOf(line, t);
        if (cond.dateCond && cond.dateCond.field && cond.dateCond.field !== 'ev') {
          if (!dateCondMatch(type, line, cond.dateCond)) return false;
        } else if (cond.dateCond && cond.dateCond.field === 'ev' && (type === 'todo' || type === 'done')) {
          const ds = cond.dateCond.doneState;
          if (ds === 'undone' && type !== 'todo') return false;
          if (ds === 'done' && type !== 'done') return false;
        } else {
          if (!cond.rowTypes[type]) return false;
        }
        return lineHitsRule(line, t, cond);
      }
      // 🆕 标题也纳入搜索范围：标题命中关键词／标记（不受 rowType 限制）时，这张行程也算命中，
      //    这样「便利贴标题」含关键词／标记的行程也会被收进这张 VIEW 投影贴。
      const titleRaw = String(ev.title == null ? '' : ev.title);
      const titleTrim = titleRaw.trim();
      const titleHit = (searchTitle && titleTrim && !(cond.dateCond && cond.dateCond.field && cond.dateCond.field !== 'ev')) ? lineHitsRule(titleRaw, titleTrim, cond) : false;
      // 🆕 先收 gp fence 整块（按 range 顺序），再收非 gp 的命中行
      fenceInfo.ranges.forEach((r, n) => {
        if (!gpWholeBlocks.has(n)) return;
        const blockId = '\u0000blk' + n;
        const blockAttrs = rangeAttrs.get(n) || {};
        for (let k = r.start + 1; k < r.end; k++) {
          const line = noteLines[k];
          const t = line.trim();
          if (!t) continue;
          if (!isLineHit(line) && !gpWholeBlocks.has(n)) continue;  // 整块模式下所有非空行都进
          const type = rowTypeOf(line, t);
          const m = (type === 'todo' || type === 'done') ? t.match(TASK_RE) : null;
          if (hits.length && !LIST_ITEM_RE.test(t) && LIST_ITEM_RE.test(hits[hits.length - 1].raw)) {
            hits.push({ raw: '', sep: true, blockGp: blockId, wholeGp: true });
          }
          hits.push({ raw: t, line: k, uid: ev.uid || '', text: m ? (m[2] || '').trim() : '',
            task: !!m, type: type, blockGp: blockId, wholeGp: true,
            gpFg: blockAttrs.fg, gpBg: blockAttrs.bg, gpAnim: blockAttrs.anim, gpAlert: blockAttrs.alert, gpTermName: blockAttrs.termName, gpName: blockAttrs.name, gpRailStyle: blockAttrs.railStyle, gpRailA: blockAttrs.railA, gpRailB: blockAttrs.railB });
        }
      });
      // 🆕 再收非 gp fence 的命中行（排除 gp 区间内容，避免重复）
      noteLines.forEach((line, i) => {
        if (FENCE_RE.test(line)) { inFence = !inFence; return; }
        if (inFence) return;
        if (fenceMarkers.has(i)) return;    // gp 标记行跳过
        if (fenceBlockAt.has(i)) return;    // gp 区间内已由整块模式收了
        const t = line.trim();
        if (!t) return;
        if (!isLineHit(line)) return;
        const type = rowTypeOf(line, t);
        const m = (type === 'todo' || type === 'done') ? t.match(TASK_RE) : null;
        if (hits.length && !LIST_ITEM_RE.test(t) && LIST_ITEM_RE.test(hits[hits.length - 1].raw)) {
          hits.push({ raw: '', sep: true });
        }
        hits.push({ raw: t, line: i, uid: ev.uid || '', text: m ? (m[2] || '').trim() : '',
          task: !!m, type: type, blockGp: null });
      });
      // 正文有命中行 → 照常收；正文无命中但标题命中 → 仍收这张行程（其分组标题即来源标题，
      //   可经 groupHeadHtml 的切换徽标一键跳回来源）。不再压入独立的「标题命中」单元，
      //   避免与分组标题的切换徽标重复显示（2026-10-30 用户要求）。
      // 🆕 hideNoHitEvents：只列「含未完 checkbox（todo 行）」的事件，隐藏无子项的纯标题事件（如生日/纯日程）——
      //   用户 2026-11-03 明确不要这些没有任务的事件出现在「所有未完成的项目」。开启时无视 titleHit。
      //   ⚠️ 不能用 hits.length>0：normalizeSegment 会把 rowTypes 展开成「para/list/quote/heading 默认 true」，
      //      纯标题事件若带任意段落备注，其段落会被收进 hits → 误判「有命中」。本意是「含未完 checkbox」，
      //      故只看是否真有 type==='todo'（未打勾的 checkbox）行。
      const include = cond.hideNoHitEvents ? hits.some((h) => h.type === 'todo') : (hits.length || titleHit);
      if (include) groups.push({ ev, hits });
    });
    return groups;
  }

  // ===== 分组标题＝来源行程的标题＋（日期）＋（📎 来源文件名，仅 INCLUDE 事件显示）=====
  //   标题本身带 `#`／`<BIG>`／[[术语]] 时照其语义渲染（不要再包 ** 变成字面符号）；
  //   纯文字标题才补 **粗体**，维持「分组」的可辨识度。
  //   🆕 INCLUDE 外部文件的事件（ev.src 非空）尾巴加 `· 📎 文件名`，主档事件不显示（默认来源）。
  function groupHeadMd(ev, deps) {
    const D = makeDeps(deps);
    const title = String((ev && ev.title) || '(无标题)').replace(/\s+/g, ' ').trim();
    const evDate = (ev && ev.date) ? ev.date : '';
    const evEnd = (ev && ev.endDate && ev.endDate !== evDate) ? ev.endDate : '';
    const date = evDate ? '（' + D.shortDate(evDate) + (evEnd ? ' – ' + D.shortDate(evEnd) : '') + '）' : '';
    const src = (ev && ev.src) ? ' · 📎 ' + D.esc(String(ev.src).trim()) : '';
    const head = HEADING_RE.test(title) ? title + date : '**' + title + '**' + date;
    return head + src;
  }
  function groupsToMd(groups, deps) {
    if (!groups || !groups.length) return '';
    return groups.map((g) => groupHeadMd(g.ev, deps) + (g.hits && g.hits.length ? '\n' + g.hits.map((h) => h.raw).join('\n') : '')).join('\n\n');
  }

  // 从一行／一整块原文里抽取 [[cr:YYYY-MM-DD]] 建立日期标记（没有则返回 ''）。
  //   排序用：行事件按自身 cr 日期排，没有 cr 的回退到来源行程的日期（在调用处拼）。
  function extractCrDate(raw) {
    const m = String(raw || '').match(/\[\[cr:(\d{4}-\d{2}-\d{2})(?: \d{2}:\d{2})?\]\]/);
    return m ? m[1] : '';
  }
  // 🆕 逐行套用「建立日／截止／完成」显示转换（跳过代码围栏），与母本
  //   calendar-editor.js::tlRenderNoteMarkersLines 完全同口径。
  //   deps 只提供单行的 tlRenderNoteMarkers，故在此自己逐行包一层，不要求主窗多传一个 dep。
  //   ⚠️ 非 checkbox 单元原本只走 D.markdown(D.termDefs(chunk))，漏了这一层 →
  //      [[cr:…]] 会以原文显示（普通便利贴走母本已正确），VIEW 投影贴因而与正式贴不一致。
  function noteMarkersLines(text, D) {
    let inFence = false;
    return String(text == null ? '' : text).split('\n').map((line) => {
      if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; return line; }
      if (inFence) return line;
      // 🆕 块级标记行整行剥成空行（与桌面 tlStripGpMarkers 同口径；hits 已排除，这里是防御）
      if (/^\{[ \t]*\/?[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\}[ \t]*$/i.test(line.trim())) return '';
      // 🆕 {gp} 是结构控制标记，只在渲染副本里剥掉；圆点 data-text / ref.notes 仍保留原文，
      //    供「找出相同的项目」按整块原文比对（与桌面 tlStripGpMarkers 同口径）。
      //    只有真的剥到标记的那行才清尾随空白，避免破坏 Markdown 行尾两空格换行语义。
      const stripped = line.replace(/[ \t]*\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*[^{}]*\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/gi, '');
      const clean = stripped === line ? line : stripped.replace(/[ \t]+$/, '');
      return D.noteMarkers(clean);
    }).join('\n');
  }
  function separateGpHorizontalRules(text) {
    let inFence = false;
    const lines = [];
    String(text == null ? '' : text).split('\n').forEach((line) => {
      if (/^\s*(```|~~~)/.test(line)) {
        inFence = !inFence;
        lines.push(line);
        return;
      }
      if (!inFence && /^\s{0,3}-{3,}\s*$/.test(line)) {
        if (lines.length && lines[lines.length - 1].trim()) lines.push('');
        lines.push(line);
        lines.push('');
        return;
      }
      lines.push(line);
    });
    return lines.join('\n');
  }
  // ===== 分组标题（来源行程的标题）渲染成「可点整块＋📍 切换按钮」=====
  //   与标题命中项的「📍 切换回来源」同一机制：点击唤起主程式打开该来源行程表单
  //   （noteFindSameOpenSourceEvent → wake-main-from-note → tlOpenEventForm(uid)）。
  //   整块标题都可点（data-src＝来源行程 uid），让使用者一眼看到「这段内容来自哪张行程」并随手切换；
  //   标题前方放一个 gold 圆形「切换」徽标（class vsr-goto-source，外观仿编辑小圆点）。
  function groupHeadHtml(ev, deps) {
    const D = makeDeps(deps);
    const inner = D.inline(groupHeadMd(ev, D));   // 维持原本的标题（粗体/标题语义）＋日期＋来源档
    const src = (ev && ev.uid) ? ev.uid : '';
    const stitle = D.esc(String((ev && ev.title) || '').replace(/\s+/g, ' ').trim() || '(无标题)');
    // 切换徽标：放在标题「最前面」，外观仿照编辑小圆点（同尺寸圆形），但用 gold 主色与圆点（purple）区分——
    //   purple＝编辑/复制/找出相同；gold＝跳回来源行程。点击经 .vsr-goto-source 委托切换来源。
    //   ⚠️ 整块用 display:flex 横排（而非 block＋inline 徽标）：来源标题若本身是 # 标题会被渲染成 block 元素，
    //      inline 徽标会被挤到单独一行（台雄生日 即此例）；flex 横排可保证徽标与标题永远同一行。
    const dot = '<button type="button" class="vsr-goto-source" data-src="' + D.esc(src) +
      '" title="切换到来源：' + stitle + '"' +
      ' style="display:inline-flex;flex:none;width:13px;height:13px;padding:0;margin:0;align-items:center;justify-content:center;vertical-align:-2px;border:0;border-radius:50%;background:var(--gold,#D4AF37);color:#fff;font-size:9px;line-height:1;cursor:pointer;opacity:.85;-webkit-app-region:no-drag;">↪</button>';
    return '<div class="vsr-group-head" data-src="' + D.esc(src) + '" data-group-date="' + D.esc(String((ev && ev.date) || '')) + '" title="点击切换到来源：' + stitle + '"' +
      ' style="cursor:pointer;display:flex;align-items:center;gap:4px;flex-wrap:nowrap;margin:2px 0 4px;">' + dot + inner + '</div>';
  }

  // ===== 渲染 =====
  //   checkbox 行：结构照抄 🔔 的 tlViewTaskLineHtml（同一套 CSS），差别只在「只读」——
  //   checkbox 不带 onclick／data-uid（不可勾）；小圆点照样显示（右键 复制／找出相同 的入口），
  //   但 data-uid＝这张投影贴自己的 key（便利贴窗据此走只读分支），
  //   data-src／data-stitle／data-text＝来源行程的身份（右键比对要用，不能拿来源当「自己」）。
  function taskLineHtml(h, ev, selfKey, deps) {
    const D = makeDeps(deps);
    const m = h.raw.match(TASK_LINE_RE);
    if (!m) return '';
    const done = m[2] !== ' ';
    const stitle = D.esc(String((ev && ev.title) || '').replace(/\s+/g, ' ').trim() || '(无标题)');
    const dot = '<button type="button" class="ev-md-edit" title="右键：复制／找出相同的项目"' +
      ' data-uid="' + D.esc(selfKey) + '" data-src="' + D.esc(h.uid || '') +
      '" data-stitle="' + stitle + '" data-line="' + h.line + '" data-text="' + D.esc(h.text) + '">\u270e</button>';
    const cr = extractCrDate(h.raw);
    const sd = cr || String((ev && ev.date) || '');
    // 🆕 2026-11-16：行内 {include name="…"} → 就地替换为只读 .gp-include-box（不挂来源 uid，绝不回写）。
    //   先在原文上走既有 inline/marker/nameRefs 管线（token 是 {…} 花括号，不被这些函数改写），
    //   再在渲染后的 HTML 上做就地替换 —— 插入的 box HTML 不再被二次 render 破坏（与桌面 tlGpIncludeBoxHtml 同口径）。
    const renderedText = gpRenderWithIncludes(m[3] || '',
      (t) => D.nameRefs(D.inline(D.noteMarkers(t))), D);
    return '<div class="vsr-sort-unit" data-sort-date="' + D.esc(sd) + '" data-cr-date="' + D.esc(cr) + '">' + m[1] +
      '<span class="ev-md-check' + (done ? ' done' : '') + '">' + dot +
      '<span class="ev-cb">' + (done ? '\u2713' : '') + '</span>' +
      '<span class="ev-md-check-text">' + renderedText + '</span></span></div>';
  }
  // 非 task 行（段落／列表项／引用／标题／含 [[…]] 胶囊的行）：投影贴里同样给编辑小圆点，
  //   但「最小 MD 单元」口径必须与来源便利贴（calendar-editor.js::tlSplitMdBlocks）一致——
  //   连续同类行合并成一个单元、一颗圆点（例如连续两条 - 列表项＝一个 list 块＝一颗圆点），
  //   而不是像之前那样「每行一颗」。否则 VIEW 投影贴会把同一 list 块的 2 条 bullet 显示成 2 颗圆点，
  //   与来源便利贴（1 颗）不一致，让使用者误以为「比来源多了编辑单元」（2026-10-30 使用者回报）。
  //   ⚠️ 圆点保持只读：不开编辑浮层（投影贴无落盘位置）；用 .md-unit 包住以复用来源便利贴的左侧凹槽定位。
  //   ⚠️ 圆点的 data-text 携带「整块原文」（多行用 \n 连接），供「找出相同的项目」比整块而非单行；
  //      见 desktop-note.js noteFindSameComputeMatches 的整块比对分支。
  function viewMergeCategory(h) {
    // 与 tlSplitMdBlocks 同口径：list/para/quote 连续可并；heading/hr/code/table 各自独立（每命中即新单元）
    if (h.type === 'list') return 'list';
    if (h.type === 'para') return 'para';
    if (h.type === 'quote') return 'quote';
    // heading/hr/code/table：用行号保证每命中独立成单元（不会与相邻同类合并）
    return 'solo:' + (h.line != null ? h.line : Math.random());
  }
  // ── group 标记语法（2026-11-06 宽放）：花括号内「开头」是 gp 或 group 即算；大小写不拘、冒号可省略 ──
  //   {gp}＝{GP}＝{GroUP}＝{group} → 无名组；{gp:ABC}＝{gpABC}＝{GROUP:ABC} → 'ABC'；{gp1}＝{gp:1} → '1'。
  //   ⚠️ 位置：标记必须在行尾、或行尾 [[...]] 标记序列之前才算结构标记；行中的 {gp} 是普通文字，原样显示也不分组。
  //   前缀 group 优先于 gp；组名仍区分大小写；正则与桌面主窗／LITE／便利贴窗同口径。
  // ── 🆕 块级（围栏式）小事件群（2026-11-08）：单独一行 {gpX} 开启、单独一行 {/gpX} 结束 ──
  //  与桌面 tlGpFenceOfLine／tlGpFenceScan、LITE calGpFence*、便利贴 noteGpFence* 同口径。
  //  投影贴的 hits 是「过滤后」的行，故必须先从原始 notes 算出区间，再把命中行打成同一个排序单元。
  function gpFenceOfLine(line) {
    const s = String(line == null ? '' : line).trim();
    // 🆕 key 部分用 [^{}|]*（不含 |），attrs 用可选 (?:\|[^{}]*)? 后缀 — 与桌面主窗 / LITE / 便利贴同口径
    let m = s.match(/^\{[ \t]*\/[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}|]*)(?:\|[^{}]*)?\}[ \t]*$/i);
    if (m) return { kind: 'close', key: String(m[1] || '').trim() };
    m = s.match(/^\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}|]*)(?:\|[^{}]*)?\}[ \t]*$/i);
    if (m) return { kind: 'open', key: String(m[1] || '').trim() };
    return null;
  }
  function gpFenceScan(lines) {
    const ranges = [], markers = [];
    let inFence = false, open = null;
    for (let i = 0; i < lines.length; i++) {
      const line = String(lines[i] == null ? '' : lines[i]);
      if (FENCE_RE.test(line)) { inFence = !inFence; continue; }
      if (inFence) continue;
      const f = gpFenceOfLine(line);
      if (!f) continue;
      if (f.kind === 'open') { if (!open) open = { i: i, key: f.key }; continue; }
      if (open && open.key === f.key) {
        ranges.push({ start: open.i, end: i, key: f.key });
        markers.push(open.i, i);
        open = null;
      }
    }
    return { ranges: ranges, markers: markers };
  }
  // 🆕 2026-11-16：{include name="NAME"} 围栏内容插入（VIEW 投影贴只读口径）。
  //   索引：扫 events 全部行程的 gp 围栏 NAME → Map<lowercaseName, Array<rawInnerText>>。
  function gpIncludeIndexFromEvents(events) {
    const map = new Map();
    map.nameChoices = { NAME: [], TERM: [] };
    const seenNames = { NAME: new Set(), TERM: new Set() };
    (Array.isArray(events) ? events : []).forEach((ev) => {
      if (!ev || !ev.notes) return;
      const lines = String(ev.notes).replace(/\r\n/g, '\n').split('\n');
      const scan = gpFenceScan(lines);
      (scan.ranges || []).forEach((r) => {
        const a = extractGpAttrsLocal(lines[r.start] || '');
        const body = lines.slice(r.start + 1, r.end).join('\n');
        const nm = String((a && a.name) || '').trim();
        if (nm) {
          const nkey = nm.toLowerCase();
          if (!seenNames.NAME.has(nkey)) { seenNames.NAME.add(nkey); map.nameChoices.NAME.push(nm); }
          const key = nkey;
          let arr = map.get(key);
          if (!arr) { arr = []; map.set(key, arr); }
          arr.push(body);
        }
        const tm = String((a && a.termName) || '').trim();
        if (tm) {
          const tkey = 'term:' + tm.toLowerCase();
          if (!seenNames.TERM.has(tkey)) { seenNames.TERM.add(tkey); map.nameChoices.TERM.push(tm); }
          let arr = map.get(tkey);
          if (!arr) { arr = []; map.set(tkey, arr); }
          arr.push(body);
        }
      });
    });
    return map;
  }
  const GP_INCLUDE_RE_ANY = /\{include\s[^}]*\}/i;
  const GP_INCLUDE_RE_ONE = /\{include\s[^}]*\}/gi;
  // 2026-11-18：名称类恢复兼容读取；写回仍统一输出 NAME="X"。
  function gpQuotedVal(raw) {
    const s = String(raw == null ? '' : raw).trim();
    if (!s) return '';
    // 兼容读取：任意成对/混搭引号（ASCII " '、中文 “ ” ‘ ’、直角 「 」 『 』、全角 ＂・）一律剥离；裸值原样返回。
    //   写回仍统一输出 NAME="X"（渐进规范化）。旧正则只认 4 种配对，直角/全角/混搭会落裸值兜底→引号残留（2026-11-18 修复）。
    const OPEN = '"\'“‘「『＂﹁﹃';
    const CLOSE = '"\'”’」』＂﹂﹄';
    if (s.length >= 2 && OPEN.indexOf(s[0]) >= 0 && CLOSE.indexOf(s[s.length - 1]) >= 0) {
      return s.slice(1, -1).trim();
    }
    return s;
  }
  // 解析单个 {include …} token：name / TERM / picture 均兼容引号与裸值（旧资料不失效）。
  function gpParseIncludeToken(token) {
      const s = String(token == null ? '' : token);
      const readVal = (m) => {
        if (!m) return '';
        for (let i = 1; i < m.length; i++) if (m[i] != null) return String(m[i]).trim();
        return '';
      };
      const nmVal = readVal(s.match(/(?:^|\s)name\s*=\s*(?:"([^"\n]*)"|'([^'\n]*)'|“([^”\n]*)”|‘([^’\n]*)’|([^\s}]+))/i));
      const tmVal = readVal(s.match(/(?:^|\s)TERM\s*=\s*(?:"([^"\n]*)"|'([^'\n]*)'|“([^”\n]*)”|‘([^’\n]*)’|([^\s}]+))/i));
      const picVal = readVal(s.match(/(?:^|\s)picture\s*=\s*(?:"([^"\n]*)"|'([^'\n]*)'|“([^”\n]*)”|‘([^’\n]*)’|([^\s}]+))/i));
      const isTerm = !nmVal && !!tmVal;
      const isPicture = !nmVal && !tmVal && !!picVal;
      const name = isTerm ? tmVal : (isPicture ? picVal : nmVal);
      const kind = isTerm ? 'term' : (isPicture ? 'picture' : 'name');
      const lookupKey = isTerm ? ('term:' + tmVal.toLowerCase())
        : isPicture ? ('picture:' + picVal.toLowerCase()) : nmVal.toLowerCase();
      // folded 三态：未指定=null（沿用主进程 store 旧行为）；true/false＝指令显式指定，渲染端输出 data-gp-fold-default 标记。
      const boolTri = (key) => {
        const m = s.match(new RegExp('(?:^|\\s)' + key + '\\s*=\\s*(?:"([^"]*)"|\'([^\']*)\'|“([^”]*)”|‘([^’]*)’|([^\\s}]+))', 'i'));
        if (!m) return null;
        let first = '';
        for (let i = 1; i < m.length; i++) if (m[i] != null) { first = m[i]; break; }
        const v = first.toLowerCase();
        return v === 'true' || v === 'on' || v === '1' || v === 'yes';
      };
      const truthy = (key) => boolTri(key) === true;
    return { name, kind, lookupKey, showLabel: truthy('showLabel'), showDirective: truthy('showDirective'), folded: boolTri('folded') };
  }
  // 就地展开：同名全部按原顺序插入到 {include} 语法所在位置（不在段尾追加），递归防环（深度 8），代码围栏内不解析。
  //   renderInsert(raw,name)：可选回调，把展开后的内容预渲染成 HTML（如 .gp-include-box）；无回调则返回纯文本。
  //   递归时把回调一并下传，保证嵌套 include 也套上同样的框。
  function gpExpandIncludesText(text, index, depth, chain, renderInsert) {
    const src = String(text == null ? '' : text);
    if (!src) return src;
    const d = depth || 0;
    if (d > 8) return src;
    const seen = chain || new Set();
    const render = typeof renderInsert === 'function' ? renderInsert : null;
    let inFence = false;
    const out = [];
    src.split('\n').forEach((line) => {
      if (FENCE_RE.test(line)) { inFence = !inFence; out.push(line); return; }
      if (inFence || !GP_INCLUDE_RE_ANY.test(line)) { out.push(line); return; }
      out.push(line.replace(GP_INCLUDE_RE_ONE, function (m) {
        const p = gpParseIncludeToken(m);
        const nm = p.name;
        if (!nm) return m;
        // picture= 不查围栏索引
        if (p.kind === 'picture') return render ? render('', nm, p.showLabel, m, p.showDirective, p.kind, p.folded) : m;
        const key = p.lookupKey;
        if (seen.has(key)) return '';
        const contents = index.get(key);
        if (!contents || !contents.length) return render ? render('', nm, p.showLabel, m, p.showDirective, p.kind, p.folded, true) : m;
        return contents.map((raw) => {
          const sub = gpExpandIncludesText(raw, index, d + 1, new Set(seen).add(key), renderInsert);
          return render ? render(sub, nm, p.showLabel, m, p.showDirective, p.kind, p.folded) : sub;
        }).join('');
      }));
    });
    return out.join('\n');
  }
  // 单个名称的内容 → 只读 HTML（走 VIEW 既有管线：gpCheckboxLines → noteMarkersLines → termDefs → nameRefs → markdown）。
  function gpIncludeContentHtml(name, D, chain) {
    const idx = D && D.gpIncludeIndex;
    const key = String(name == null ? '' : name).trim().toLowerCase();
    if (!idx || !key) return '';
    const seen = chain || new Set();
    if (seen.has(key)) return '';
    const contents = idx.get(key);
    if (!contents || !contents.length) return '';
    return contents.map((raw) => {
      const expanded = gpExpandIncludesText(raw, idx, seen.size + 1, new Set(seen).add(key));
      const marked = noteMarkersLines(gpCheckboxLines(expanded, D), D);
      return D.markdown(D.nameRefs(D.termDefs(marked)));
    }).join('');
  }
  // 🆕 {gpG8}：结果框临时参数控件（只改 DOM/缓存，不写 .md）。
  // 🆕 结果框参数抽屉：每个 .gp-include-box 自带把手/面板；开合与位置只存本会话（sessionStorage，不写文件）。
  const GP_DRAWER_KEY = 'gpParamDrawerState';
  const gpDrawerMem = new Map();
  function gpDrawerStateRead() {
    try {
      if (typeof window !== 'undefined' && window.sessionStorage) {
        const raw = window.sessionStorage.getItem(GP_DRAWER_KEY);
        return raw ? (JSON.parse(raw) || {}) : {};
      }
    } catch (_) { /* fail-safe */ }
    const out = {};
    gpDrawerMem.forEach((v, k) => { out[k] = v; });
    return out;
  }
  function gpDrawerStateWrite(state) {
    gpDrawerMem.clear();
    Object.keys(state || {}).forEach((k) => gpDrawerMem.set(k, state[k]));
    try {
      if (typeof window !== 'undefined' && window.sessionStorage) {
        window.sessionStorage.setItem(GP_DRAWER_KEY, JSON.stringify(state || {}));
      }
    } catch (_) { /* 不影响主功能 */ }
  }
  function gpDrawerOrd(box) {
    if (!box || typeof document === 'undefined' || !document.querySelectorAll) return -1;
    return Array.prototype.indexOf.call(document.querySelectorAll('.gp-include-box') || [], box);
  }
  function gpDrawerStateSave(box, patch) {
    const ord = gpDrawerOrd(box);
    if (ord < 0 || !patch) return;
    const all = gpDrawerStateRead();
    const key = String(ord);
    all[key] = Object.assign({}, all[key] || {}, patch);
    gpDrawerStateWrite(all);
  }
  function gpGpDrawerHtml(inner) {
    return '<div class="gp-param-drawer">' +
      '<button type="button" class="gp-param-drawer-handle" title="属性调整" aria-label="属性调整"><span class="gp-drawer-badge" aria-hidden="true">\u2699</span></button>' +
      '<div class="gp-param-drawer-panel">' +
        '<div class="gp-param-drawer-head"><span>属性调整</span>' +
          '<button type="button" class="gp-param-drawer-close" title="收起">\u00D7</button></div>' +
        '<div class="gp-drawer-directive-wrap"><span class="gp-drawer-directive-label">当前指令</span><code class="gp-drawer-directive"></code></div>' +
        '<div class="gp-param-drawer-body">' + inner + '</div>' +
      '</div></div>';
  }
  function gpGpDrawerQuote(v) {
    const s = String(v == null ? '' : v);
    if (s.indexOf('"') >= 0 && s.indexOf("'") < 0) return "'" + s + "'";
    if (s.indexOf('"') >= 0 && s.indexOf("'") >= 0) return '\u201C' + s + '\u201D';
    return '"' + s + '"';
  }
  function gpGpDrawerCtrl(box, key) {
    return box && box.querySelector ? box.querySelector('[data-gp-temp-param="' + key + '"]') : null;
  }
  function gpGpDrawerBool(box, key) {
    const c = gpGpDrawerCtrl(box, key);
    return !!(c && c.checked);
  }
  function gpGpDrawerBuildDirective(box) {
    if (!box || !box.classList) return '';
    const q = gpGpDrawerQuote;
    const b = (k) => gpGpDrawerBool(box, k);
    const patternCtrl = gpGpDrawerCtrl(box, 'pattern');
    const pattern = patternCtrl ? String(patternCtrl.value == null ? '' : patternCtrl.value) : '';
    // ★ whereuse 框带 gp-name-list-box（复用临时过滤），必须先判它，否则误显示成 {list NAME}。
    if (box.classList.contains('gp-whereuse-box')) {
      const kind = String(box.getAttribute('data-gp-whereuse-kind') || 'TERM').toUpperCase();
      const paramKey = kind === 'NAME' ? 'name' : kind === 'TEXT' ? 'text' : 'term';
      const attrKey = kind === 'NAME' ? 'NAME' : kind === 'TEXT' ? 'TEXT' : 'TERM';
      const ctrl = gpGpDrawerCtrl(box, paramKey);
      let val = ctrl ? String(ctrl.value == null ? '' : ctrl.value).trim()
        : String(box.getAttribute('data-gp-whereuse') || '');
      if (kind === 'NAME') val = gpWhereuseNameCleanName(val);
      if (kind === 'TEXT') val = gpWhereuseTextCleanText(val);
      return ['{whereuse ' + attrKey + '=' + q(val),
        'showCount=' + (b('showCount') ? 'true' : 'false'),
        'showDirective=' + (b('showDirective') ? 'true' : 'false'),
        'folded=' + (b('folded') ? 'true' : 'false')].join(' ') + '}';
    }
    if (box.classList.contains('gp-pmenu-box')) {
      const kind = String(box.getAttribute('data-gp-pmenu-kind') || 'NAME').toUpperCase();
      const parts = [pattern ? '{pmenu ' + kind + '=' + q(pattern) : '{pmenu ' + kind];
      if (kind === 'TERM') parts.push('all=' + (b('all') ? 'true' : 'false'));
      parts.push('showDirective=' + (b('showDirective') ? 'true' : 'false'));
      parts.push('folded=' + (b('folded') ? 'true' : 'false'));
      return parts.join(' ') + '}';
    }
    if (box.classList.contains('gp-name-list-box')) {
      const kind = box.getAttribute('data-gp-term-list') === '1' ? 'TERM' : 'NAME';
      const parts = [pattern ? '{list ' + kind + '=' + q(pattern) : '{list ' + kind];
      parts.push('showCount=' + (b('showCount') ? 'true' : 'false'));
      parts.push('showDirective=' + (b('showDirective') ? 'true' : 'false'));
      parts.push('folded=' + (b('folded') ? 'true' : 'false'));
      return parts.join(' ') + '}';
    }
    const kind = String(box.getAttribute('data-gp-include-kind') || 'name').toLowerCase();
    const key = kind === 'term' ? 'TERM' : (kind === 'picture' ? 'picture' : 'NAME');
    const nameCtrl = gpGpDrawerCtrl(box, 'includeName');
    const name = nameCtrl ? String(nameCtrl.value == null ? '' : nameCtrl.value) : (box.getAttribute('data-gp-include') || '');
    return ['{include', key + '=' + q(name),
      'showLabel=' + (b('showLabel') ? 'true' : 'false'),
      'showDirective=' + (b('showDirective') ? 'true' : 'false'),
      'folded=' + (b('folded') ? 'true' : 'false')].join(' ') + '}';
  }
  function gpDrawerBodiesPayload(index, D) {
    const bodies = {};
    if (index && typeof index.forEach === 'function') {
      index.forEach((v, k) => {
        if (Array.isArray(v)) bodies[k] = v.map((raw) => gpIncludeTextBodyHtml(raw, D)).join('');
      });
    }
    const json = JSON.stringify(bodies).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
    return '<span hidden data-gp-include-bodies="' + json + '"></span>';
  }
  function gpDrawerBodiesRead() {
    if (typeof window !== 'undefined' && window.gpGpDrawerBodies) return window.gpGpDrawerBodies;
    if (typeof document === 'undefined' || !document.querySelector) return null;
    const el = document.querySelector('[data-gp-include-bodies]');
    if (!el || !el.getAttribute) return null;
    try {
      const obj = JSON.parse(el.getAttribute('data-gp-include-bodies') || '');
      if (typeof window !== 'undefined') window.gpGpDrawerBodies = obj;
      return obj;
    } catch (_) { return null; }
  }
  function gpDrawerApplyName(box, name) {
    if (!box || !box.querySelector || !name) return;
    const kind = String(box.getAttribute('data-gp-include-kind') || 'name').toLowerCase();
    const key = (kind === 'term' ? 'term:' : '') + String(name).toLowerCase();
    const bodies = gpDrawerBodiesRead();
    const index = (typeof window !== 'undefined' && window.gpGpDrawerIndex) || null;
    const D = (typeof window !== 'undefined' && window.gpGpDrawerD) || null;
    const contents = index && typeof index.get === 'function' ? index.get(key) : null;
    const body = box.querySelector('.gp-include-body');
    if (body && bodies && typeof bodies[key] === 'string') {
      body.innerHTML = bodies[key];
    } else if (body && contents && contents.length && D) {
      body.innerHTML = contents.map((raw) => gpIncludeTextBodyHtml(raw, D)).join('');
    }
    const label = box.querySelector('.gp-include-label-text');
    if (label) label.textContent = String(name);
    if (box.setAttribute) box.setAttribute('data-gp-include', String(name));
  }
  function gpGpExecDirectiveHtml(show) {
    return '<div class="gp-exec-directive"' + (show ? '' : ' hidden') + '><span class="gp-exec-directive-label">当前执行：</span><code class="gp-exec-directive-code"></code></div>';
  }
  function gpGpDrawerSync(box) {
    if (!box || !box.querySelector) return;
    const text = gpGpDrawerBuildDirective(box);
    const out = box.querySelector('.gp-drawer-directive');
    if (out) out.textContent = text;
    const exec = box.querySelector('.gp-exec-directive-code');
    if (exec) exec.textContent = text;
  }
  function gpGpDrawerHydrate(root) {
    const scope = root && root.querySelectorAll ? root : document;
    if (!scope || !scope.querySelectorAll) return;
    const boxes = Array.prototype.slice.call(scope.querySelectorAll('.gp-include-box') || []);
    const state = gpDrawerStateRead();
    boxes.forEach((box, ord) => {
      const drawer = box.querySelector ? box.querySelector('.gp-param-drawer') : null;
      if (!drawer || drawer.getAttribute('data-gp-drawer-hydrated') === '1') return;
      drawer.setAttribute('data-gp-drawer-hydrated', '1');
      gpGpDrawerSync(box);
      const st = state[String(ord)] || {};
      if (st.open) drawer.classList.add('is-open');
      if (typeof st.x === 'number' && typeof st.y === 'number') {
        const panel = drawer.querySelector('.gp-param-drawer-panel');
        if (panel) {
          panel.style.right = 'auto';
          panel.style.left = st.x + 'px';
          panel.style.top = st.y + 'px';
        }
      }
    });
  }
  function gpGpDrawerInstall() {
    if (typeof document === 'undefined' || !document.addEventListener) return;
    if (typeof window !== 'undefined' && window.__gpDrawerBound) { gpGpDrawerHydrate(document); return; }
    if (typeof window !== 'undefined') window.__gpDrawerBound = true;
    document.addEventListener('click', (ev) => {
      const t = ev.target;
      if (!t || !t.closest) return;
      const handle = t.closest('.gp-param-drawer-handle');
      if (handle) {
        ev.preventDefault(); ev.stopPropagation();
        const drawer = handle.closest('.gp-param-drawer');
        if (!drawer) return;
        const open = !drawer.classList.contains('is-open');
        drawer.classList.toggle('is-open', open);
        gpDrawerStateSave(drawer.closest('.gp-include-box'), { open: open ? 1 : 0 });
        return;
      }
      const close = t.closest('.gp-param-drawer-close');
      if (close) {
        ev.preventDefault(); ev.stopPropagation();
        const drawer = close.closest('.gp-param-drawer');
        if (!drawer) return;
        drawer.classList.remove('is-open');
        gpDrawerStateSave(drawer.closest('.gp-include-box'), { open: 0 });
      }
    });
    const syncDirective = (ev) => {
      const t = ev.target;
      if (!t || !t.closest || !t.closest('[data-gp-temp-param], .gp-include-fold-cb')) return;
      const box = t.closest('.gp-include-box');
      if (!box) return;
      if (t.getAttribute && t.getAttribute('data-gp-temp-param') === 'includeName') {
        gpDrawerApplyName(box, t.value);
      }
      gpGpDrawerSync(box);
    };
    document.addEventListener('change', syncDirective);
    document.addEventListener('input', syncDirective);
    document.addEventListener('mousedown', (ev) => {
      const t = ev.target;
      if (!t || !t.closest || t.closest('.gp-param-drawer-close')) return;
      const head = t.closest('.gp-param-drawer-head');
      if (!head) return;
      const drawer = head.closest('.gp-param-drawer');
      const panel = drawer && drawer.querySelector ? drawer.querySelector('.gp-param-drawer-panel') : null;
      const box = drawer && drawer.closest ? drawer.closest('.gp-include-box') : null;
      if (!panel || !box || !box.getBoundingClientRect || !panel.getBoundingClientRect) return;
      const boxRect = box.getBoundingClientRect();
      const panelRect = panel.getBoundingClientRect();
      panel.style.right = 'auto';
      panel.style.left = (panelRect.left - boxRect.left) + 'px';
      panel.style.top = (panelRect.top - boxRect.top) + 'px';
      const sx = ev.clientX || 0, sy = ev.clientY || 0;
      const ox = parseFloat(panel.style.left) || 0, oy = parseFloat(panel.style.top) || 0;
      ev.preventDefault(); ev.stopPropagation();
      const move = (e) => {
        panel.style.left = (ox + (e.clientX || 0) - sx) + 'px';
        panel.style.top = (oy + (e.clientY || 0) - sy) + 'px';
      };
      const up = () => {
        if (document.removeEventListener) {
          document.removeEventListener('mousemove', move);
          document.removeEventListener('mouseup', up);
        }
        gpDrawerStateSave(box, { x: parseFloat(panel.style.left) || 0, y: parseFloat(panel.style.top) || 0 });
      };
      if (document.addEventListener) {
        document.addEventListener('mousemove', move);
        document.addEventListener('mouseup', up);
      }
    });
    const start = () => {
      gpGpDrawerHydrate(document);
      if (typeof MutationObserver !== 'undefined' && document.body) {
        new MutationObserver(() => gpGpDrawerHydrate(document))
          .observe(document.body, { childList: true, subtree: true });
      }
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();
  }
  gpGpDrawerInstall();
  function gpTempToggle(D, key, label, on, title) {
    return '<label class="gp-temp-toggle" title="' + D.esc(title || '') + '">' +
      '<input type="checkbox" data-gp-temp-param="' + key + '"' + (on ? ' checked' : '') + '>' + label + '</label>';
  }
  function gpTempBar(parts) {
    const list = (parts || []).filter(Boolean);
    return list.length ? '<div class="gp-temp-param-bar">' + list.join('') + '</div>' : '';
  }
  function gpTempNameSelect(kindKey, current, choices) {
    const list = ((choices && choices[kindKey]) || []).slice();
    const cur = String(current == null ? '' : current);
    if (cur && list.indexOf(cur) < 0) list.unshift(cur);
    const opts = list.map((nm) => '<option value="' + String(nm).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;') + '"' + (nm === cur ? ' selected' : '') + '>' + String(nm).replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</option>').join('');
    return '<label class="gp-temp-name" title="选择要引用的' + (kindKey === 'TERM' ? '术语' : '名称') + '">' +
      '<span>' + (kindKey === 'TERM' ? '术语' : '名称') + '</span>' +
      '<select data-gp-temp-param="includeName">' + opts + '</select></label>';
  }
  function gpCollectGpTempParams(box) {
    const out = {};
    const ctrls = box && box.querySelectorAll ? box.querySelectorAll('[data-gp-temp-param]') || [] : [];
    Array.prototype.forEach.call(ctrls, (c) => {
      const key = c.getAttribute && c.getAttribute('data-gp-temp-param');
      if (!key) return;
      out[key] = c.type === 'checkbox' ? !!c.checked : String(c.value == null ? '' : c.value);
    });
    return out;
  }
  function gpApplyGpParams(box, params) {
    if (!box) return;
    const p = params || {};
    const hide = (sel, on) => {
      const nodes = box.querySelectorAll ? box.querySelectorAll(sel) || [] : [];
      Array.prototype.forEach.call(nodes, (n) => { n.hidden = !!on; });
    };
    if ('showLabel' in p) hide('.gp-include-label-text', p.showLabel === false);
    if ('showDirective' in p) hide('.gp-include-directive, .gp-exec-directive', p.showDirective === false);
    if ('showCount' in p) {
      hide('.gp-name-list-count', p.showCount === false);
      hide('.gp-name-list-total', p.showCount === false);
    }
    if ('folded' in p) {
      const foldCb = box.querySelector ? box.querySelector('.gp-include-fold-cb') : null;
      if (foldCb) foldCb.checked = p.folded === true;
    }
    if ('includeName' in p && box.classList && box.classList.contains('gp-include-box')) {
      const nameCtrl = gpGpDrawerCtrl(box, 'includeName');
      const chosen = String(p.includeName == null ? '' : p.includeName);
      if (nameCtrl) nameCtrl.value = chosen;
      if (chosen) gpDrawerApplyName(box, chosen);
    }
    // ★ whereuse 的输入框是查询词本体（TERM／NAME）：换词要重跑搜索，⛔不能落进 gp-name-list-box 的 pattern 过滤。
    if (box.classList && box.classList.contains('gp-whereuse-box')) {
      if ('term' in p || 'name' in p) {
        const term = String(('name' in p ? p.name : p.term) == null ? '' : ('name' in p ? p.name : p.term)).trim();
        const old = String(box.getAttribute('data-gp-whereuse') || '').trim();
        if (term !== old) gpWhereuseRerender(box, term, (typeof window !== 'undefined' && window.gpGpDrawerD) || null);
      }
      return;
    }
    if (box.classList && box.classList.contains('gp-pmenu-box')) gpApplyPmenuFilter(box, p.pattern || '');
    else if (box.classList && box.classList.contains('gp-name-list-box')) gpApplyListFilter(box, p.pattern || '');
  }
  // 单个 include 内容 → inline-safe 的 .gp-include-box HTML（就地替换 token 用）。
  //   与桌面 tlGpIncludeBoxHtml 同口径：checkbox 行先转只读 .ev-md-check（不挂 uid/onclick/data-line），
  //   再走 noteMarkers → termDefs → nameRefs → markdown，剥最外层 <p> 后包虚线框，避免二次 render 拆 <ul>／巢状 <p>。
  function gpIncludeTextBodyHtml(raw, D) {
    const prepared = String(raw == null ? '' : raw).split('\n').map((l) => {
      const m = String(l || '').match(TASK_LINE_RE);
      if (!m) return l;
      const done = m[2] !== ' ';
      const textProcessed = D.inline(D.noteMarkers(m[3] || '')).trim();
      return m[1] + ' <span class="ev-md-check' + (done ? ' done' : '') + '">' +
        '<span class="ev-cb">' + (done ? '\u2713' : '') + '</span>' +
        '<span class="ev-md-check-text">' + textProcessed + '</span></span>';
    }).join('\n');
    const marked = noteMarkersLines(prepared, D);
    let html = D.markdown(D.nameRefs(D.termDefs(marked)));
    if (/^<p>[\s\S]*<\/p>$/.test(html) && !/<\/p>\s*<p>/.test(html) && !/<ul[\s>]/.test(html) && !/<ol[\s>]/.test(html)) {
      html = html.replace(/^<p>([\s\S]*?)<\/p>\s*$/, '$1').trim();
    }
    return html;
  }
  function gpGpIncludeMissingHtml(name, kind, D) {
    const label = kind === 'term' ? '术语围栏' : (kind === 'picture' ? '图片' : '围栏小事件群');
    return '<div class="gp-include-missing" role="status">找不到' + label + '「' + D.esc(name || '') + '」：没有可插入的内容。</div>';
  }
  function gpIncludeBoxHtml(raw, name, D, showLabel, directive, showDirective, kind, folded, indexArg, missing) {
    const nameChoices = indexArg && indexArg.nameChoices ? indexArg.nameChoices : indexArg;
    if (indexArg && typeof indexArg.get === 'function' && typeof window !== 'undefined') {
      window.gpGpDrawerIndex = indexArg;
      window.gpGpDrawerD = D;
    }
    const isPicture = kind === 'picture' || /\{include\s+picture\s*=/i.test(directive || '');
    let html;
    if (missing) {
      html = gpGpIncludeMissingHtml(name, kind, D);
    } else if (isPicture) {
      const pic = D.esc(name || '');
      html = '<img class="gp-include-picture" data-gp-pic="' + pic + '" alt="' + pic + '">';
    } else {
      html = gpIncludeTextBodyHtml(raw, D);
    }
    // <fieldset> 的 <legend> 骑在虚线边框顶部左上角。徽标常显（与 showLabel 无关，供视觉区分）：
    //   TERM → 📖 书徽标；NAME → 🏷️ 标签牌徽标。只显示徽标、不显示 "TERM" 文字；showLabel=true 时徽标后附名称。
    //   directive 即原始 {include …} token，据此判来源（不改传递链）。
    const isTerm = !isPicture && (kind === 'term' || /\{include\s+TERM\s*=/i.test(directive || ''));
    const badge = isPicture
      ? '<span class="gp-include-badge is-picture" title="同目录图片">\u{1F5BC}\uFE0F</span>'
      : isTerm
      ? '<span class="gp-include-badge is-term" title="术语详细说明">\u{1F4D6}</span>'
      : '<span class="gp-include-badge is-name" title="围栏名称引用"><span class="gp-brace-mark">{ }</span></span>';
    // 折叠按钮：藏在 legend（左上角），只折叠 .gp-include-body；徽标、名称、directive 永不折叠。纯 CSS :has(:checked)。
    //   folded 三态：true → checked + data-gp-fold-default="1"（默认折叠）；false → data-gp-fold-default="0"（默认展开）；
    //                null/未指定 → 无标记，沿用主进程 store 旧行为。
    const foldAttr = folded === true ? ' checked data-gp-fold-default="1"'
      : folded === false ? ' data-gp-fold-default="0"' : '';
    const fold = '<label class="gp-include-fold" title="折叠/展开内容"><input type="checkbox" class="gp-include-fold-cb"' + foldAttr + '><span class="gp-include-fold-ico">\u25BE</span></label>';
    const legend = '<legend class="gp-include-label">' + fold + badge +
      '<span class="gp-include-label-text"' + (showLabel ? '' : ' hidden') + '>' + D.esc(name) + '</span></legend>';
    const dirHtml = '<div class="gp-include-directive"' + (showDirective ? '' : ' hidden') + '>' + D.esc(directive || '') + '</div>' + gpGpExecDirectiveHtml(showDirective);
    const incKind = String(kind || 'name').toLowerCase();
    const paramBar = gpTempBar([
      incKind === 'picture' ? '' : gpTempNameSelect(incKind === 'term' ? 'TERM' : 'NAME', name, nameChoices),
      gpTempToggle(D, 'showLabel', '显示名称', !!showLabel, '临时切换 showLabel'),
      gpTempToggle(D, 'showDirective', '显示指令', !!showDirective, '临时切换 showDirective'),
      gpTempToggle(D, 'folded', '折叠', !!folded, '临时切换 folded（与折叠箭头同步）')
    ]);
    return '<fieldset class="gp-include-box" data-gp-include="' + D.esc(name) + '" data-gp-include-kind="' + D.esc(kind || 'name') + '">' + legend + dirHtml + gpGpDrawerHtml(paramBar) +
      '<div class="gp-include-body">' + html + '</div></fieldset>';
  }
  // 渲染前把 {include} 换成唯一占位符（此时引号尚未被 esc 成 &quot;），渲染后再把占位符换成 .gp-include-box HTML。
  //   ① 正则只在原始纯文本层匹配 → 不会误伤 data-text 属性里的转义语法（data-text 仍保留原文供「找出相同」）。
  //   ② 插入的 box HTML 在渲染完成后才注入 → 不会被 inline/marker/termDefs/markdown 二次处理、不会拆 <ul>／巢状 <p>。
  function gpRenderWithIncludes(rawText, renderText, D) {
    const idx = D && D.gpIncludeIndex;
    const hasPicture = /\{include\s+picture\s*=/i.test(String(rawText || ''));
    const hasList = GP_LIST_RE_ANY.test(String(rawText || ''));
    const hasPmenu = GP_PMENU_RE_ANY.test(String(rawText || ''));
    const hasTermList = GP_TERM_LIST_RE_ANY.test(String(rawText || ''));
    const hasWhereuse = GP_WHEREUSE_RE_ANY.test(String(rawText || ''));
    const hasWhereuseName = GP_WHEREUSE_NAME_RE_ANY.test(String(rawText || ''));
    const hasWhereuseText = GP_WHEREUSE_TEXT_RE_ANY.test(String(rawText || ''));
    if (!hasList && !hasPmenu && !hasTermList && !hasWhereuse && !hasWhereuseName && !hasWhereuseText && !GP_INCLUDE_RE_ANY.test(rawText)) return renderText(rawText);
    // 占位符用普通 ASCII（真 renderer 剥 NUL 控制字符 → 裸露标记、注入失败）；%%TLINC_n_ZZ%% 真引擎验证可原样穿过。
    let seq = 0;
    const ph = new Map();
    let prepared = rawText;
    if (true) {
      prepared = gpExpandIncludesText(rawText, idx || new Map(), 0, new Set(), (r, nm, showLabel, directive, showDirective, kind, folded, missing) => {
        const tok = '%%TLINC_' + (seq++) + '_ZZ%%';
        ph.set(tok, { raw: r, nm: nm, showLabel: showLabel, directive: directive, showDirective: showDirective, kind: kind, folded: folded, missing: missing });
        return tok;
      });
    }
    if (hasList) {
      const all = gpCollectGpNameList(D);
      prepared = String(prepared).replace(GP_LIST_RE_ONE, (m) => {
        const p = gpParseListToken(m);
        const list = all;
        const tok = '%%TLLST_' + (seq++) + '_ZZ%%';
        ph.set(tok, { isList: true, list, showCount: p.showCount, directive: m, folded: p.folded, pattern: p.pattern, showDirective: p.showDirective });
        return tok;
      });
    }
    if (hasPmenu) {
      prepared = String(prepared).replace(GP_PMENU_RE_ONE, (m) => {
        // 🆕 kind 由头部关键字定（⛔不用整 token 含 'TERM' 判断：pattern 值里也可能有 TERM）
        const kind = /\{\s*pmenu\s+TERM\b/i.test(m) ? 'TERM' : 'NAME';
        const p = gpParseListToken(m, kind);
        const tok = '%%TLPMENU_' + (seq++) + '_ZZ%%';
        ph.set(tok, { isPmenu: true, directive: m, folded: p.folded, pattern: p.pattern, kind: kind, all: p.all, showDirective: p.showDirective });
        return tok;
      });
    }
    if (hasTermList) {
      prepared = String(prepared).replace(GP_TERM_LIST_RE_ONE, (m) => {
        const p = gpParseListToken(m, 'TERM');
        const tok = '%%TLTERM_' + (seq++) + '_ZZ%%';
        ph.set(tok, { isTermList: true, list: gpCollectGpTermList('', D), showCount: p.showCount, directive: m, folded: p.folded, pattern: p.pattern, showDirective: p.showDirective });
        return tok;
      });
    }
    if (hasWhereuse) {
      prepared = String(prepared).replace(GP_WHEREUSE_RE_ONE, (m) => {
        const p = gpParseWhereuseTokenLocal(m);
        const tok = '%%TLWHERE_' + (seq++) + '_ZZ%%';
        ph.set(tok, { isWhereuse: true, term: p.term, hits: gpCollectGpWhereuseHits(p.term, D),
          showCount: p.showCount, directive: gpWhereuseCleanDirective(m, p.term), folded: p.folded, showDirective: p.showDirective,
          boxNo: ++_gpWhereuseBoxSeq });
        return tok;
      });
    }
    if (hasWhereuseName) {
      prepared = String(prepared).replace(GP_WHEREUSE_NAME_RE_ONE, (m) => {
        const p = gpParseWhereuseNameToken(m);
        const tok = '%%TLWHEREN_' + (seq++) + '_ZZ%%';
        ph.set(tok, { isWhereuseName: true, name: p.name, hits: gpWhereuseNameSearchCorpus((D && D.gpEvents) ? gpWhereuseCorpusFromEvents(D.gpEvents) : [], p.name),
          showCount: p.showCount, directive: gpWhereuseNameCleanDirective(m, p.name), folded: p.folded, showDirective: p.showDirective,
          boxNo: ++_gpWhereuseBoxSeq });
        return tok;
      });
    }
    if (hasWhereuseText) {
      prepared = String(prepared).replace(GP_WHEREUSE_TEXT_RE_ONE, (m) => {
        const p = gpParseWhereuseTextToken(m);
        const tok = '%%TLWHERET_' + (seq++) + '_ZZ%%';
        ph.set(tok, { isWhereuseText: true, text: p.text, hits: gpWhereuseTextSearchCorpus((D && D.gpEvents) ? gpWhereuseCorpusFromEvents(D.gpEvents) : [], p.text),
          showCount: p.showCount, directive: gpWhereuseTextCleanDirective(m, p.text), folded: p.folded, showDirective: p.showDirective,
          boxNo: ++_gpWhereuseBoxSeq });
        return tok;
      });
    }
    let out = renderText(prepared);
    const whereuseHits = {};
    ph.forEach((v, tok) => {
      const box = v.isWhereuseText ? gpGpWhereuseBoxHtml(v.text, v.hits, v.showCount, v.directive, v.folded, v.showDirective, v.boxNo, D, 'TEXT')
        : v.isWhereuseName ? gpGpWhereuseBoxHtml(v.name, v.hits, v.showCount, v.directive, v.folded, v.showDirective, v.boxNo, D, 'NAME')
        : v.isWhereuse ? gpGpWhereuseBoxHtml(v.term, v.hits, v.showCount, v.directive, v.folded, v.showDirective, v.boxNo, D)
        : v.isPmenu ? gpPmenuBoxHtml(v.directive, v.folded, v.pattern, D, v.kind, v.all, v.showDirective)
        : v.isTermList ? gpTermListBoxHtml(v.list, v.showCount, v.directive, v.folded, D, v.pattern, v.showDirective)
        : v.isList ? gpNameListBoxHtml(v.list, v.showCount, v.directive, v.folded, D, v.pattern, v.showDirective)
        : gpIncludeBoxHtml(v.raw, v.nm, D, v.showLabel, v.directive, v.showDirective, v.kind, v.folded, idx, v.missing);
      if (v.isWhereuse || v.isWhereuseName || v.isWhereuseText) whereuseHits[v.boxNo] = v.hits;
      out = out.split(tok).join(box);
    });
    return out + gpDrawerBodiesPayload(idx, D) + gpWhereusePayload(whereuseHits, D);
  }
  // ========== 🆕 2026-11-24：{whereuse TERM="..."} 全文位置清单（共享 VIEW 引擎，与桌面/LITE 同口径） ==========
  // 语义：搜纯文本 TERM 在档案中出现的所有位置；每条记录 = 事件识别 + 事件内锚点
  //   {kind:'check',line,text,focus:'content'} / {kind:'block',start,end,name}，与内容定位小盒子同格式。
  const GP_WHEREUSE_RE_ANY = /\{whereuse\s+TERM\b[^}]*\}/i;
  const GP_WHEREUSE_RE_ONE = /\{whereuse\s+TERM\b[^}]*\}/gi;
  const GP_WHEREUSE_NAME_RE_ANY = /\{whereuse\s+NAME\b[^}]*\}/i;
  const GP_WHEREUSE_NAME_RE_ONE = /\{whereuse\s+NAME\b[^}]*\}/gi;
  const GP_WHEREUSE_TEXT_RE_ANY = /\{whereuse\s+TEXT\b[^}]*\}/i;
  const GP_WHEREUSE_TEXT_RE_ONE = /\{whereuse\s+TEXT\b[^}]*\}/gi;
  const GP_WHEREUSE_TEXT_MAX = 160;  // 结果清单每行显示上限（原 80，加倍以露出命中关键字）
  // ★ TERM 可能被贴进渲染后的术语胶囊 HTML → 还原纯词条名（与桌面/LITE 同口径）。
  function gpWhereuseCleanTerm(v) {
    let s = String(v == null ? '' : v).trim();
    if (!s) return '';
    const br = s.match(/^\[\[([^\]]+)\]\]$/);
    if (br) {
      const nm = String(br[1]).split(/[:：]/)[0].replace(/^📖\s*/, '').trim();
      if (nm) return nm;
    }
    if (!/[<>]/.test(s) && !/&(?:quot|amp|lt|gt|nbsp|#39);/i.test(s)) return s.replace(/^📖\s*/, '').trim();
    const dt = s.match(/data-term\s*=\s*(?:"([^"]*)"|'([^']*)')/i);
    if (dt && (dt[1] || dt[2])) return String(dt[1] || dt[2]).trim();
    s = s.replace(/<[^>]*>/g, '').replace(/<[^>]*$/g, '');
    s = s.replace(/&quot;/gi, '"').replace(/&#39;/gi, "'").replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&');
    return s.replace(/[\u200B-\u200D\uFEFF\u{1F4D6}\u{1F4D7}]/gu, '').replace(/\s+/g, ' ').trim();
  }
  function gpWhereuseReadTerm(s) {
    const m = s.match(/\bTERM\s*=\s*"([^}]*)"/i) || s.match(/\bTERM\s*=\s*'([^}]*)'/i) || s.match(/\bTERM\s*=\s*“([^}]*)”/i);
    return m ? m[1] : '';
  }
  function gpWhereuseCleanDirective(m, term) {
    return String(m).replace(/(\bTERM\s*=\s*)"[^}]*"/i, '$1"' + term + '"')
      .replace(/(\bTERM\s*=\s*)'[^}]*'/i, "$1'" + term + "'");
  }
  let _gpWhereuseBoxSeq = 0;
  function gpParseWhereuseTokenLocal(token) {
    const s = String(token == null ? '' : token);
    const readVal = (key) => {
      const m = s.match(new RegExp('(?:^|\\s)' + key + '\\s*=\\s*(?:"([^"\\n]*)"|\'([^\'\\n]*)\'|“([^”\\n]*)”|‘([^’\\n]*)’|([^\\s}]+))', 'i'));
      if (!m) return '';
      for (let i = 1; i < m.length; i++) if (m[i] != null) return String(m[i]).trim();
      return '';
    };
    const bool = (key) => {
      const v = readVal(key).toLowerCase();
      return v === 'true' || v === 'on' || v === '1' || v === 'yes';
    };
    const sd = readVal('showDirective');
    return { term: gpWhereuseCleanTerm(gpWhereuseReadTerm(s) || readVal('TERM')), showCount: bool('showCount'), folded: bool('folded'),
      showDirective: sd ? bool('showDirective') : null };
  }
  // 🆕 语料快照随 HTML 下发：便利贴窗没有全量事件（makeDeps 不产 gpEvents），
  //   要实时换 TERM 只能靠这份语料在本地重搜，⛔不要依赖 D.gpEvents。
  function gpWhereuseCorpusFromEvents(events) {
    return (Array.isArray(events) ? events : []).filter(Boolean).map((ev) => {
      const lines = String(ev.notes == null ? '' : ev.notes).replace(/\r\n/g, '\n').split('\n');
      const scan = gpFenceScan(lines);
      return {
        uid: String(ev.uid || ''), title: String(ev.title || ''), date: String(ev.date || ''),
        lines: lines,
        fences: (scan.ranges || []).map((r) => {
          const a = extractGpAttrsLocal(lines[r.start] || '') || {};
          return { start: r.start, end: r.end, name: String(a.name || a.termName || '').trim() };
        })
      };
    });
  }
  // 纯函数：从语料搜 TERM → 与内容定位小盒子同格式的位置记录。
  // TERM 候选：[[TERM:释义]] 取名称段、TERM="..." 取属性段；都没有才用整行文字。
  //   ★ 比对统一走 gpGpNamePatternHit（无 * 完全比对），⛔不用 indexOf 子串。
  // TERM 候选：只搜 [[TERM:释义:领域]]（取名称段）。⛔不搜 TERM="..." 属性。
  function gpWhereuseHit(text, pattern) {
    const s = String(text == null ? '' : text);
    const cands = [];
    s.replace(/\[\[([^\]\n]+)\]\]/g, (m, inner) => {
      const nm = String(inner).split(/[:：]/)[0].trim();
      if (nm) cands.push(nm);
      return m;
    });
    if (!cands.length) return false;
    return cands.some((c) => gpGpNamePatternHit(c, pattern));
  }
  function gpWhereuseSearchCorpus(corpus, term) {
    const q = String(term == null ? '' : term).trim();
    if (!q) return [];
    const out = [];
    (Array.isArray(corpus) ? corpus : []).forEach((ev) => {
      if (!ev) return;
      const uid = String(ev.uid || ''), title = String(ev.title || ''), date = String(ev.date || '');
      const push = (anchor, text, kind, line) => out.push({ uid: uid, title: title, date: date, anchor: anchor, text: text, kind: kind, line: line });
      if (gpWhereuseHit(title, q)) push({ kind: 'card' }, title.slice(0, GP_WHEREUSE_TEXT_MAX), 'title', -1);
      (Array.isArray(ev.lines) ? ev.lines : []).forEach((raw, i) => {
        if (!gpWhereuseHit(raw, q)) return;
        const text = String(raw).replace(/^\s*(?:[-*+]\s+\[[ xX]\]\s?|[-*+]\s+|#{1,6}\s+)/, '').trim().slice(0, GP_WHEREUSE_TEXT_MAX);
        const fence = (Array.isArray(ev.fences) ? ev.fences : []).find((r) => i > r.start && i < r.end);
        if (fence) push({ kind: 'block', start: fence.start, end: fence.end,
          name: String(fence.name || '').trim(), line: i, text: text, focus: 'content' }, text, 'fence', i);
        else push({ kind: 'check', line: i, text: text, focus: 'content' }, text, 'line', i);
      });
    });
    return out;
  }
  function gpCollectGpWhereuseHits(term, D) {
    return gpWhereuseSearchCorpus(gpWhereuseCorpusFromEvents((D && D.gpEvents) || []), term);
  }
  // ★ 命中关键字反白：先在原文上定位匹配区间，再逐段 esc()，命中段包 <mark>（与桌面/LITE 同口径）。
  function gpWhereuseHighlight(text, pattern, esc) {
    const s = String(text == null ? '' : text);
    const q = String(pattern == null ? '' : pattern).trim();
    if (!s || !q) return esc(s);
    const segs = q.split('*').filter((x) => x !== '');
    if (!segs.length) return esc(s);
    const lower = s.toLowerCase();
    const ranges = [];
    segs.forEach((seg) => {
      const needle = seg.toLowerCase();
      let from = 0, at;
      while ((at = lower.indexOf(needle, from)) >= 0) {
        ranges.push({ start: at, end: at + needle.length });
        from = at + needle.length;
      }
    });
    if (!ranges.length) return esc(s);
    ranges.sort((a, b) => a.start - b.start);
    const merged = [];
    ranges.forEach((r) => {
      const last = merged[merged.length - 1];
      if (last && r.start <= last.end) last.end = Math.max(last.end, r.end);
      else merged.push({ start: r.start, end: r.end });
    });
    let out = '', pos = 0;
    merged.forEach((r) => {
      if (r.start > pos) out += esc(s.slice(pos, r.start));
      out += '<mark class="gp-whereuse-hit">' + esc(s.slice(r.start, r.end)) + '</mark>';
      pos = r.end;
    });
    if (pos < s.length) out += esc(s.slice(pos));
    return out;
  }
  // ★ NAME 与 TERM 共享相同的渲染结构：序号 + 位置(行号) + 事件标题+日期 + 内容 + 定位按钮。
  function gpWhereuseListHtml(term, hits, esc, kind) {
    const entries = hits || [];
    const k = String(kind || 'TERM').toUpperCase();
    const isName = k === 'NAME';
    const isText = k === 'TEXT';
    const missing = '<div class="gp-include-missing" role="status">' +
      (isText ? '找不到符合 TEXT「' + esc(term) + '」的文本内容。'
        : isName ? '找不到符合 NAME「' + esc(term) + '」的围栏小事件群。'
        : '找不到 TERM「' + esc(term) + '」在档案中的出现位置。') + '</div>';
    return entries.length
      ? '<ul class="gp-name-list gp-whereuse-list">' + entries.map((it, idx) => {
          const who = String(it.title || '(无标题)') + (it.date ? ' · ' + it.date : '');
          const where = isName ? ('便利贴/日程事件 起始第 ' + ((+it.line || 0) + 1) + ' 行')
            : (it.kind === 'title' ? '标题' : '便利贴/日程事件 第 ' + ((+it.line || 0) + 1) + ' 行');
          return '<li data-list-item-name="' + esc(who + ' ' + it.text) + '" data-hit-idx="' + idx + '">' +
            '<span class="gp-whereuse-seq">' + (idx + 1) + '.</span>' +
            '<span class="gp-whereuse-meta">' + esc(where) + '</span> ' +
            '<span class="gp-whereuse-who">' + gpWhereuseHighlight(who, term, esc) + '</span>' +
            '<span class="gp-whereuse-text">' + gpWhereuseHighlight(it.text, term, esc) + '</span>' +
            '<button type="button" class="gp-whereuse-go" data-hit-idx="' + idx + '" title="定位到此处">定位</button></li>';
        }).join('') + '</ul>'
      : missing;
  }
  function gpGpWhereuseBoxHtml(term, hits, showCount, directive, folded, showDirective, boxNo, D, kind) {
    const esc = (s) => (D && typeof D.esc === 'function') ? D.esc(s) : String(s == null ? '' : s);
    const showDir = showDirective !== false;
    const initCount = (hits || []).length;
    const k = String(kind || 'TERM').toUpperCase();
    const isName = k === 'NAME';
    const isText = k === 'TEXT';
    const placeholder = isName ? '输入 NAME 重新查找围栏小事件群名称（不写入文件）'
      : isText ? '输入 TEXT 重新查找文本位置（不写入文件）'
      : '输入 TERM 重新查找位置（不写入文件）';
    const ariaLabel = isName ? '临时更换 NAME 重新查找围栏名称'
      : isText ? '临时更换 TEXT 重新查找'
      : '临时更换 TERM 重新查找';
    const filterBar = '<div class="gp-list-filter-bar"><input type="text" class="gp-list-filter-input" data-gp-temp-param="' + (isName ? 'name' : isText ? 'text' : 'term') + '" aria-label="' + ariaLabel + '" placeholder="' + placeholder + '" value="' + esc(term || '') + '">' +
      gpTempToggle(D, 'showCount', '显示数量', !!showCount, '临时切换 showCount') +
      gpTempToggle(D, 'showDirective', '显示指令', showDir, '临时切换 showDirective') +
      gpTempToggle(D, 'folded', '折叠', !!folded, '临时切换 folded（与折叠箭头同步）') +
      '<span class="gp-list-filter-count">' + initCount + '/' + initCount + '</span></div>';
    const body = gpWhereuseListHtml(term, hits, esc, k);
    const foldAttr = folded === true ? ' checked data-gp-fold-default="1"'
      : folded === false ? ' data-gp-fold-default="0"' : '';
    const fold = '<label class="gp-include-fold" title="折叠/展开内容"><input type="checkbox" class="gp-include-fold-cb"' + foldAttr + '><span class="gp-include-fold-ico">\u25BE</span></label>';
    const legendTitle = isName ? '围栏小事件群名称清单' : isText ? '文本内容位置清单' : '文字出现位置清单';
    const legend = '<legend class="gp-include-label">' + fold +
      '<span class="gp-include-badge is-whereuse' + (isName ? ' gp-brace-mark' : '') + '" title="' + legendTitle + '">' + (isName ? '{ }' : '\u{1F4CD}') + '</span>' +
      (isName ? '名称清单' : isText ? '文本位置' : '使用位置') + ' <span class="gp-name-list-total"' + (showCount ? '' : ' hidden') + '>' + initCount + '</span></legend>';
    const fieldsetClass = 'gp-include-box gp-name-list-box gp-whereuse-box' + (isName ? ' is-whereuse-name' : '');
    return '<fieldset class="' + fieldsetClass + '" data-gp-whereuse="' + esc(term) + '" data-gp-whereuse-kind="' + k + '" data-gp-whereuse-box="' + (+boxNo || 0) + '">' +
      legend + '<div class="gp-include-directive"' + (showDir ? '' : ' hidden') + '>' + esc(directive || '') + '</div>' +
      gpGpExecDirectiveHtml(showDir) + gpGpDrawerHtml(filterBar) + '<div class="gp-include-body">' + body + '</div></fieldset>';
  }
  function gpWhereuseJson(obj) {
    return JSON.stringify(obj || {}).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  }
  function gpWhereusePayload(byBox, D) {
    // corpus 让便利贴窗（没有全量事件）能就地重搜 TERM；hits 仍是点击定位的位置来源。
    const corpus = gpWhereuseCorpusFromEvents((D && D.gpEvents) || []);
    return '<span hidden data-gp-whereuse-hits="' + gpWhereuseJson({ hits: byBox || {}, corpus: corpus }) + '"></span>';
  }
  function gpWhereuseHitsRead() {
    if (typeof document === 'undefined' || !document.querySelectorAll) return { hits: {}, corpus: [] };
    const merged = { hits: {}, corpus: [] };
    Array.prototype.forEach.call(document.querySelectorAll('[data-gp-whereuse-hits]'), (el) => {
      try {
        const o = JSON.parse(el.getAttribute('data-gp-whereuse-hits') || '{}');
        const h = (o && o.hits) ? o.hits : o;   // 兼容旧格式（整个 JSON 就是 hits map）
        Object.keys(h || {}).forEach((k) => { merged.hits[k] = h[k]; });
        if (Array.isArray(o.corpus) && o.corpus.length) merged.corpus = o.corpus;
      } catch (_) {}
    });
    return merged;
  }
  function gpWhereusePayloadUpdate(box, hits) {
    if (typeof document === 'undefined' || !document.querySelectorAll) return;
    const boxNo = +box.getAttribute('data-gp-whereuse-box') || 0;
    Array.prototype.forEach.call(document.querySelectorAll('[data-gp-whereuse-hits]'), (el) => {
      try {
        let o = JSON.parse(el.getAttribute('data-gp-whereuse-hits') || '{}');
        if (!o.hits) o = { hits: o, corpus: [] };
        if (!o.hits[boxNo]) return;
        o.hits[boxNo] = hits;
        el.setAttribute('data-gp-whereuse-hits', gpWhereuseJson(o));
      } catch (_) {}
    });
  }
  // 输入新 TERM → 本地重搜 → 只替换清单正文（折叠态、抽屉位置都不受影响）。
  function gpWhereuseRerender(box, term, D) {
    if (!box) return;
    const q = String(term == null ? '' : term).trim();
    const kind = String(box.getAttribute && box.getAttribute('data-gp-whereuse-kind') || 'TERM').toUpperCase();
    const isName = kind === 'NAME';
    const isText = kind === 'TEXT';
    const hits = isText ? gpWhereuseTextSearchCorpus(gpWhereuseHitsRead().corpus, q)
      : isName ? gpWhereuseNameSearchCorpus(gpWhereuseHitsRead().corpus, q)
      : gpWhereuseSearchCorpus(gpWhereuseHitsRead().corpus, q);
    // ★ 点击定位优先读这里（重搜后的最新结果）；payload 只作翻页前的持久来源。
    box.__whereuseHits = hits;
    box.setAttribute('data-gp-whereuse', q);
    const esc = (s) => (D && typeof D.esc === 'function') ? D.esc(s) : String(s == null ? '' : s);
    const body = box.querySelector ? box.querySelector('.gp-include-body') : null;
    if (body) body.innerHTML = gpWhereuseListHtml(q, hits, esc, kind);
    const cnt = box.querySelector ? box.querySelector('.gp-list-filter-count') : null;
    if (cnt) cnt.textContent = hits.length + '/' + hits.length;
    const total = box.querySelector ? box.querySelector('.gp-name-list-total') : null;
    if (total) total.textContent = String(hits.length);
    gpWhereusePayloadUpdate(box, hits);
    gpGpDrawerSync(box);
  }
  // ========== 🆕 2026-11-25：{whereuse NAME="..."} 围栏小事件群名称清单（VIEW 引擎） ==========
  function gpWhereuseNameReadName(s) {
    const m = s.match(/\bNAME\s*=\s*"([^}]*)"/i) || s.match(/\bNAME\s*=\s*'([^}]*)'/i) || s.match(/\bNAME\s*=\s*"([^}]*)"/i);
    return m ? m[1] : '';
  }
  // ★ NAME 值的 * 可能被 markdown 渲染成 <em>/<strong> → 还原成 * / **（保留万用字元语义）。
  function gpWhereuseNameCleanName(v) {
    let s = String(v == null ? '' : v).trim();
    if (!s || !/[<>]/.test(s)) return s;
    s = s.replace(/<\s*(em|i)\b[^>]*>([\s\S]*?)<\s*\/\s*\1\s*>/gi, '*$2*');
    s = s.replace(/<\s*(strong|b)\b[^>]*>([\s\S]*?)<\s*\/\s*\1\s*>/gi, '**$2**');
    s = s.replace(/<br\s*\/?>/gi, ' ');
    s = s.replace(/<[^>]*>/g, '').replace(/<[^>]*$/g, '');
    s = s.replace(/&quot;/gi, '"').replace(/&#39;/gi, "'").replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&');
    return s.replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
  }
  function gpWhereuseNameCleanDirective(m, name) {
    return String(m).replace(/(\bNAME\s*=\s*)"[^}]*"/i, '$1"' + name + '"')
      .replace(/(\bNAME\s*=\s*)'[^}]*'/i, "$1'" + name + "'");
  }
  function gpParseWhereuseNameToken(token) {
    const s = String(token == null ? '' : token);
    const readVal = (key) => {
      const m = s.match(new RegExp('(?:^|\\s)' + key + '\\s*=\\s*(?:"([^"\\n]*)"|\'([^\'\\n]*)\'|“([^”\\n]*)”|‘([^’\\n]*)’|([^\\s}]+))', 'i'));
      if (!m) return '';
      for (let i = 1; i < m.length; i++) if (m[i] != null) return String(m[i]).trim();
      return '';
    };
    const bool = (key) => {
      const v = readVal(key).toLowerCase();
      return v === 'true' || v === 'on' || v === '1' || v === 'yes';
    };
    const sd = readVal('showDirective');
    const name = gpWhereuseNameReadName(s) || readVal('NAME');
    return { name: gpWhereuseNameCleanName(name),
      showCount: bool('showCount'), folded: bool('folded'),
      showDirective: sd ? bool('showDirective') : null };
  }
  // ★ NAME 候选：独立引用 {NAME="X"} / {NAME='X'} / {NAME=X} → 取 NAME 属性值。
  //   ⛔围栏 open 行 '{gpJ|NAME="X"}' 里的 NAME 不算（那是围栏定义，不是「使用」围栏）。
  function gpWhereuseNameHit(text, pattern) {
    const s = String(text == null ? '' : text);
    const cands = [];
    s.replace(/\{NAME=(?:"([^"\n]*)"|'([^'\n]*)'|“([^”\n]*)”|‘([^’\n]*)’|([^{}\n]+))\}/g,
      (m, a, b, c, d, e) => {
        const nm = String(a || b || c || d || e || '').trim();
        if (nm) cands.push(nm);
        return m;
      });
    if (!cands.length) return false;
    return cands.some((c) => gpGpNamePatternHit(c, pattern));
  }
  function gpWhereuseNameSearchCorpus(corpus, namePattern) {
    const q = String(namePattern == null ? '' : namePattern).trim();
    if (!q) return [];
    const out = [];
    (Array.isArray(corpus) ? corpus : []).forEach((ev) => {
      if (!ev) return;
      const uid = String(ev.uid || ''), title = String(ev.title || ''), date = String(ev.date || '');
      const push = (anchor, text, kind, line) => out.push({
        uid: uid, title: title, date: date, anchor: anchor, text: text, kind: kind, line: line
      });
      if (gpWhereuseNameHit(title, q)) push({ kind: 'card' }, title.slice(0, 200), 'title', -1);
      (Array.isArray(ev.lines) ? ev.lines : []).forEach((raw, i) => {
        if (!gpWhereuseNameHit(raw, q)) return;
        const m = raw.match(/\{NAME=(?:"([^"\n]*)"|'([^'\n]*)'|“([^”\n]*)”|‘([^’\n]*)’|([^{}\n]+))\}/);
        const hitName = m ? String(m[1] || m[2] || m[3] || m[4] || m[5] || '').trim() : '';
        push({ kind: 'block', start: i, end: i, name: hitName, line: i, focus: 'content' },
          raw.trim().slice(0, 200), 'fence', i);
      });
    });
    return out;
  }
  // ========== 🆕 2026-11-26：{whereuse TEXT="..."} 任意文本内容搜索（VIEW 引擎） ==========
  // 语义：列出所有包含搜索词（万用字元 *）的**任意文本行**——⛔不需要 [[TERM]] 或 {NAME=} 等标记。
  function gpWhereuseTextReadText(s) {
    const m = s.match(/\bTEXT\s*=\s*"([^}]*)"/i) || s.match(/\bTEXT\s*=\s*'([^}]*)'/i) || s.match(/\bTEXT\s*=\s*"([^}]*)"/i);
    return m ? m[1] : '';
  }
  function gpWhereuseTextCleanText(v) {
    let s = String(v == null ? '' : v).trim();
    if (!s || !/[<>]/.test(s)) return s;
    s = s.replace(/<\s*(em|i)\b[^>]*>([\s\S]*?)<\s*\/\s*\1\s*>/gi, '*$2*');
    s = s.replace(/<\s*(strong|b)\b[^>]*>([\s\S]*?)<\s*\/\s*\1\s*>/gi, '**$2**');
    s = s.replace(/<br\s*\/?>/gi, ' ');
    s = s.replace(/<[^>]*>/g, '').replace(/<[^>]*$/g, '');
    s = s.replace(/&quot;/gi, '"').replace(/&#39;/gi, "'").replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&');
    return s.replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
  }
  function gpWhereuseTextCleanDirective(m, text) {
    return String(m).replace(/(\bTEXT\s*=\s*)"[^}]*"/i, '$1"' + text + '"')
      .replace(/(\bTEXT\s*=\s*)'[^}]*'/i, "$1'" + text + "'");
  }
  function gpParseWhereuseTextToken(token) {
    const s = String(token == null ? '' : token);
    const readVal = (key) => {
      const m = s.match(new RegExp('(?:^|\\s)' + key + '\\s*=\\s*(?:"([^"\\n]*)"|\'([^\'\\n]*)\'|“([^”\\n]*)”|‘([^’\\n]*)’|([^\\s}]+))', 'i'));
      if (!m) return '';
      for (let i = 1; i < m.length; i++) if (m[i] != null) return String(m[i]).trim();
      return '';
    };
    const bool = (key) => {
      const v = readVal(key).toLowerCase();
      return v === 'true' || v === 'on' || v === '1' || v === 'yes';
    };
    const sd = readVal('showDirective');
    const text = gpWhereuseTextReadText(s) || readVal('TEXT');
    return { text: gpWhereuseTextCleanText(text),
      showCount: bool('showCount'), folded: bool('folded'),
      showDirective: sd ? bool('showDirective') : null };
  }
  function gpWhereuseTextHit(text, pattern) {
    return gpGpNamePatternHit(text, pattern);
  }
  function gpWhereuseTextSearchCorpus(corpus, textPattern) {
    const q = String(textPattern == null ? '' : textPattern).trim();
    if (!q) return [];
    const out = [];
    (Array.isArray(corpus) ? corpus : []).forEach((ev) => {
      if (!ev) return;
      const uid = String(ev.uid || ''), title = String(ev.title || ''), date = String(ev.date || '');
      const push = (anchor, text, kind, line) => out.push({
        uid: uid, title: title, date: date, anchor: anchor, text: text, kind: kind, line: line
      });
      if (gpWhereuseTextHit(title, q)) push({ kind: 'card' }, title.slice(0, GP_WHEREUSE_TEXT_MAX), 'title', -1);
      (Array.isArray(ev.lines) ? ev.lines : []).forEach((raw, i) => {
        if (!gpWhereuseTextHit(raw, q)) return;
        const text = String(raw).replace(/^\s*(?:[-*+]\s+\[[ xX]\]\s?|[-*+]\s+|#{1,6}\s+)/, '').trim().slice(0, GP_WHEREUSE_TEXT_MAX);
        const fence = (Array.isArray(ev.fences) ? ev.fences : []).find((r) => i > r.start && i < r.end);
        if (fence) push({ kind: 'block', start: fence.start, end: fence.end,
          name: String(fence.name || '').trim(), line: i, text: text, focus: 'content' }, text, 'fence', i);
        else push({ kind: 'check', line: i, text: text, focus: 'content' }, text, 'line', i);
      });
    });
    return out;
  }
  // ========== 🆕 2026-11-20：{list NAME} 具名围栏名称清单（共享 VIEW 引擎，与桌面/LITE 同口径） ==========
  //   · 数据源：从 D.gpIncludeIndex 的 key 重建（key 即围栏 NAME 小写；排除 'term:' 前缀）。
  //     若 index 因无 {include} 语法未建，则回退按本次 events 扫围栏 NAME。
  const GP_LIST_RE_ANY = /\{list\s+NAME\b[^}]*\}/i;
  const GP_LIST_RE_ONE = /\{list\s+NAME\b[^}]*\}/gi;
  function gpParseListToken(token, listKey) {
    const s = String(token == null ? '' : token);
    const key = listKey || 'NAME';
    const readVal = (m) => {
      if (!m) return '';
      for (let i = 1; i < m.length; i++) if (m[i] != null) return String(m[i]).trim();
      return '';
    };
    const boolTri = (key) => {
      const m = s.match(new RegExp('(?:^|\\s)' + key + '\\s*=\\s*(?:"([^"]*)"|\'([^\']*)\'|“([^”]*)”|‘([^’]*)’|([^\\s}]+))', 'i'));
      if (!m) return null;
      const v = readVal(m).toLowerCase();
      return v === 'true' || v === 'on' || v === '1' || v === 'yes';
    };
    // NAME="…"：万用字元查询（* 通配任意字符）。无 NAME= 时为空＝列全部。
    const pattern = readVal(s.match(new RegExp('(?:^|\\s)' + key + '\\s*=\\s*(?:"([^"\\n]*)"|\'([^\'\\n]*)\'|“([^”\\n]*)”|‘([^’\\n]*)’|([^\\s}]+))', 'i')));
    // 🆕 2026-11-22：{pmenu TERM all=true} → 列出全部术语（含只有 [[term]] 无围栏者）。
    return { showCount: boolTri('showCount') === true, folded: boolTri('folded'), pattern,
      all: boolTri('all') === true, showDirective: boolTri('showDirective') };
  }
  // 万用字元匹配（list/pmenu 共用）：无 * 完全符合；*X* 包含；*X 结尾；X* 开头；大小写不敏感。
  function gpGpNamePatternHit(name, pattern) {
    if (!pattern) return true;
    const hay = String(name == null ? '' : name).toLowerCase();
    const needle = String(pattern).toLowerCase();
    if (needle.indexOf('*') < 0) return hay === needle;
    const parts = needle.split('*');
    if (!parts.some((x) => x !== '')) return true;
    let pos = 0;
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (!part) continue;
      const at = hay.indexOf(part, pos);
      if (at < 0) return false;
      if (i === 0 && parts[0] !== '' && at !== 0) return false;
      pos = at + part.length;
    }
    if (parts[parts.length - 1] !== '') return pos === hay.length;
    return true;
  }
  // list/pmenu 命中 0 笔时写清楚讯息（与 include 找不到同口径）
  function gpGpListMissingHtml(kind, pattern, D) {
    const label = kind === 'term' ? '术语' : (kind === 'pmenu-term' ? '术语详细说明' : '围栏名称');
    const p = pattern ? '「' + D.esc(pattern) + '」' : '';
    return '<div class="gp-include-missing" role="status">找不到符合' + p + '的' + label + '：没有可显示的内容。</div>';
  }
  // 🆕 {gpG8}：list NAME/TERM 临时过滤——只切 li.hidden / 计数，⛔不写 .md、不写 store。
  function gpApplyListFilter(box, userKw) {
    const list = box && box.querySelector ? box.querySelector('.gp-name-list') : null;
    if (!list || !list.children) return;
    // 🆕 当前指令驱动：临时 pattern 是唯一过滤条件；清空＝列出全部（⛔不再叠加原始硬底）。
    const kw = String(userKw == null ? '' : userKw).trim();
    let shown = 0, total = 0;
    for (let i = 0; i < list.children.length; i++) {
      const li = list.children[i];
      const nm = String(li.getAttribute && li.getAttribute('data-list-item-name') || '');
      if (!nm) continue;
      total++;
      const visible = !kw || gpGpNamePatternHit(nm, kw);
      li.hidden = !visible;
      if (visible) shown++;
    }
    const cnt = box.querySelector ? box.querySelector('.gp-list-filter-count') : null;
    if (cnt) cnt.textContent = shown + '/' + total;
  }
  function gpFilterGpNameList(list, pattern) {
    if (!pattern) return list;
    const out = new Map();
    list.forEach((v, k) => { if (gpGpNamePatternHit(v.name, pattern)) out.set(k, v); });
    return out;
  }
  function gpCollectGpNameList(D) {
    const out = new Map();
    // 统一按本次 events 扫围栏 NAME（{gpJ} 无 NAME 自动跳过），拿到正确大小写名称与同名计数。
    const events = (D && D.gpEvents) || [];
    (Array.isArray(events) ? events : []).forEach((ev) => {
      if (!ev || !ev.notes) return;
      const lines = String(ev.notes).replace(/\r\n/g, '\n').split('\n');
      const scan = gpFenceScan(lines);
      (scan.ranges || []).forEach((r) => {
        const a = extractGpAttrsLocal(lines[r.start] || '');
        const nm = String((a && a.name) || '').trim();
        if (!nm) return;
        const key = nm.toLowerCase();
        const hit = out.get(key);
        if (hit) { hit.count++; hit.name = nm; }
        else out.set(key, { name: nm, count: 1 });
      });
    });
    return out;
  }
  function gpNameListBoxHtml(list, showCount, directive, folded, D, pattern, showDirective) {
    const showDir = showDirective !== false;
    const entries = Array.from(list.values());
    const initCount = entries.filter((it) => gpGpNamePatternHit(it.name, pattern)).length;
    const filterBar = '<div class="gp-list-filter-bar"><input type="text" class="gp-list-filter-input" data-gp-temp-param="pattern" aria-label="临时关键字过滤" placeholder="输入关键字过滤（可用 * 通配，不写入文件）" value="' + D.esc(pattern || '') + '">' +
      gpTempToggle(D, 'showCount', '显示数量', !!showCount, '临时切换 showCount') +
      gpTempToggle(D, 'showDirective', '显示指令', showDir, '临时切换 showDirective') +
      gpTempToggle(D, 'folded', '折叠', !!folded, '临时切换 folded（与折叠箭头同步）') +
      '<span class="gp-list-filter-count">' + initCount + '/' + entries.length + '</span></div>';
    const body = (initCount
      ? '<ul class="gp-name-list">' + entries.map((it) => {
          const cnt = ' <span class="gp-name-list-count"' + (showCount ? '' : ' hidden') + '>(' + it.count + ')</span>';
          const hide = gpGpNamePatternHit(it.name, pattern) ? '' : ' hidden';
          return '<li' + hide + ' data-list-item-name="' + D.esc(it.name) + '"><span class="gp-name-ref" data-gp-name-ref="' + D.esc(it.name) + '"' +
            ' title="跳转到围栏：' + D.esc(it.name) + '"><span class="gp-brace-mark">{ }</span> ' + D.esc(it.name) + '</span>' + cnt + '</li>';
        }).join('') + '</ul>'
      : gpGpListMissingHtml('name', pattern, D));
    const foldAttr = folded === true ? ' checked data-gp-fold-default="1"'
      : folded === false ? ' data-gp-fold-default="0"' : '';
    const fold = '<label class="gp-include-fold" title="折叠/展开内容"><input type="checkbox" class="gp-include-fold-cb"' + foldAttr + '><span class="gp-include-fold-ico">\u25BE</span></label>';
    const legend = '<legend class="gp-include-label">' + fold + '<span class="gp-include-badge is-name" title="具名围栏清单"><span class="gp-brace-mark">{ }</span></span>围栏名称清单 <span class="gp-name-list-total"' + (showCount ? '' : ' hidden') + '>' + initCount + '</span></legend>';
    const dirHtml = '<div class="gp-include-directive"' + (showDir ? '' : ' hidden') + '>' + D.esc(directive || '') + '</div>' + gpGpExecDirectiveHtml(showDir);
    return '<fieldset class="gp-include-box gp-name-list-box" data-gp-name-list="1"' +
      ' data-gp-list-pattern="' + D.esc(pattern || '') + '">' + legend + dirHtml + gpGpDrawerHtml(filterBar) + '<div class="gp-include-body">' + body + '</div></fieldset>';
  }
  // ========== 🆕 2026-11-21：{pmenu NAME} 围栏内容弹出式选单（共享 VIEW 引擎） ==========
  //   · 与 {list NAME} 共用 gpParseListToken / gpGpNamePatternHit（通配与混搭引号口径一致）。
  //   · 菜单内容为「已渲染 HTML」存在 option 的 data-content，选择时直接写入 .gp-pmenu-content。
  // 🆕 2026-11-22：正则通用化，{pmenu NAME} 与 {pmenu TERM} 共用同一条链。
  const GP_PMENU_RE_ANY = /\{pmenu\s+(?:NAME|TERM)\b[^}]*\}/i;
  const GP_PMENU_RE_ONE = /\{pmenu\s+(?:NAME|TERM)\b[^}]*\}/gi;
  function gpRenderGpBodyHtml(raw, D) {
    const prepared = String(raw == null ? '' : raw).split('\n').map((l) => {
      const m = String(l || '').match(TASK_LINE_RE);
      if (!m) return l;
      const done = m[2] !== ' ';
      const textProcessed = D.inline(D.noteMarkers(m[3] || '')).trim();
      return m[1] + ' <span class="ev-md-check' + (done ? ' done' : '') + '">' +
        '<span class="ev-cb">' + (done ? '\u2713' : '') + '</span>' +
        '<span class="ev-md-check-text">' + textProcessed + '</span></span>';
    }).join('\n');
    let html = D.markdown(D.nameRefs(D.termDefs(noteMarkersLines(prepared, D))));
    if (/^<p>[\s\S]*<\/p>$/.test(html) && !/<\/p>\s*<p>/.test(html) && !/<ul[\s>]/.test(html) && !/<ol[\s>]/.test(html)) {
      html = html.replace(/^<p>([\s\S]*?)<\/p>\s*$/, '$1').trim();
    }
    return html;
  }
  // 🆕 2026-11-22：轻量术语栏位解析（[[term:释义:领域:首发:父阶]]），共享引擎无 tlParseTermToken 故内嵌同口径。
  function gpTermInfoOf(inner) {
    const full = String(inner == null ? '' : inner).trim();
    const i = full.indexOf(':');
    const term = (i < 0 ? full : full.slice(0, i)).trim();
    if (!term || /^(dl|cp|cr|remind|bookmark|alert)$/i.test(term)) return null;
    if (/^\d{4}-\d{2}-\d{2}$/.test(term)) return null;
    const parts = (i < 0 ? '' : full.slice(i + 1)).split(':');
    let def = '', domain = '', release = '', parent = '';
    if (parts.length >= 4) {
      parent = parts[parts.length - 1].trim(); release = parts[parts.length - 2].trim();
      domain = parts[parts.length - 3].trim(); def = parts.slice(0, -3).join(':').trim();
    } else if (parts.length >= 3) {
      release = parts[parts.length - 1].trim(); domain = parts[parts.length - 2].trim();
      def = parts.slice(0, -2).join(':').trim();
    } else {
      const last = parts.length > 1 ? parts.length - 1 : -1;
      def = last < 0 ? parts[0].trim() : parts.slice(0, last).join(':').trim();
      domain = last < 0 ? '' : parts[last].trim();
    }
    return { term: term, def: def, domain: domain, release: release, parent: parent };
  }
  function gpTermInfoBody(t) {
    const lines = [];
    if (t && t.def) lines.push('释义：' + t.def);
    if (t && t.domain) lines.push('领域：' + t.domain);
    if (t && t.release) lines.push('首发：' + t.release);
    if (t && t.parent) lines.push('父阶：' + t.parent);
    return lines.length ? lines.join('\n') : '（此术语尚未填写释义或说明）';
  }
  // 🆕 2026-11-22：kind='TERM' 时按围栏 TERM= 建项（{pmenu TERM}），与 NAME 共用扫描/通配。
  function gpCollectGpPmenuItems(pattern, D, kind, all) {
    const useTerm = String(kind || '').toUpperCase() === 'TERM';
    const out = new Map();
    const events = (D && D.gpEvents) || [];
    const list = Array.isArray(events) ? events : [];
    list.forEach((ev) => {
      if (!ev || !ev.notes) return;
      const lines = String(ev.notes).replace(/\r\n/g, '\n').split('\n');
      (gpFenceScan(lines).ranges || []).forEach((r) => {
        const a = extractGpAttrsLocal(lines[r.start] || '');
        const nm = String(((useTerm ? (a && a.termName) : (a && a.name))) || '').trim();
        if (!nm || !gpGpNamePatternHit(nm, pattern)) return;
        const key = nm.toLowerCase();
        const body = lines.slice((+r.start || 0) + 1, +r.end || 0).join('\n').trim();
        const hit = out.get(key);
        if (hit) { hit.parts.push(body); hit.hasFence = true; }
        else out.set(key, { name: nm, parts: [body], hasFence: true });
      });
    });
    // all=true：并入全部 [[term]]（含无围栏者）显示术语资讯；有围栏者保留正文并标 hasFence。
    if (all === true && useTerm) {
      list.forEach((ev) => {
        if (!ev) return;
        [ev.title, ev.notes].forEach((txt) => {
          String(txt == null ? '' : txt).replace(/\[\[([^\]\n]+)\]\]/g, (m, inner) => {
            const t = gpTermInfoOf(inner);
            if (!t || !gpGpNamePatternHit(t.term, pattern)) return m;
            const key = t.term.toLowerCase();
            const hit = out.get(key);
            if (hit) { if (hit.parts.length === 0) hit.parts.push(gpTermInfoBody(t)); return m; }
            out.set(key, { name: t.term, parts: [gpTermInfoBody(t)], hasFence: false });
            return m;
          });
        });
      });
    }
    return Array.from(out.values()).map((it) => ({
      name: it.name,
      body: it.parts.filter((x) => x !== '').join('\n\n'),
      hasFence: it.hasFence === true
    }));
  }
  function gpPmenuBoxHtml(directive, folded, pattern, D, kind, all, showDirective) {
    const showDir = showDirective !== false;
    const useTerm = String(kind || '').toUpperCase() === 'TERM';
    const badge = useTerm
      ? '<span class="gp-include-badge is-term" title="术语内容弹出式选单">\u{1F4D6}</span>'
      : '<span class="gp-include-badge is-name" title="围栏内容弹出式选单"><span class="gp-brace-mark">{ }</span></span>';
    const selLabel = useTerm ? '选择术语' : '选择围栏名称';
    // 🆕 2026-11-22：临时参数调整——预存不含 pattern 的「全量候选」，让输入框可在结果框内临时收窄关键字，
    //   ⛔ 不改 .md、不写 store：只前端切换 option 的 hidden/data-content。all 的初始态仍按指令，作为「含无围栏」开关。
    const rawItems = gpCollectGpPmenuItems('', D, kind, true);
    const opts = rawItems.map((it, i) => {
      const html = gpRenderGpBodyHtml(it.body, D);
      const brace = (useTerm && it.hasFence) ? '{ } ' : '';
      const prefix = useTerm ? '\u{1F4D6} ' : '{ } ';
      const navAttr = (it.hasFence || !useTerm) ? ' data-nav-name="' + D.esc(it.name) + '"' : '';
      // ★ data-item-name 供临时关键字过滤匹配；初始仍按指令 pattern + all 隐藏，保持原执行结果。
      const passBase = gpGpNamePatternHit(it.name, pattern);
      const hide = (!passBase || (useTerm && !all && !it.hasFence)) ? ' hidden' : '';
      return '<option value="' + i + '" data-content="' + D.esc(html) + '" data-item-name="' + D.esc(it.name) + '"' +
        ' data-fence="' + (it.hasFence ? '1' : '0') + '"' + navAttr + hide + '>' + prefix + brace + D.esc(it.name) + '</option>';
    }).join('');
    // ★ 初始按指令 pattern 预过滤（与原本 collect(pattern) 等价），all 初始态写进 data 属性供开关复原。
    const initCount = rawItems.filter((it) => (!useTerm || all || it.hasFence) && gpGpNamePatternHit(it.name, pattern)).length;
    const filterBar = '<div class="gp-pmenu-filter-bar"><input type="text" class="gp-pmenu-filter-input" data-gp-temp-param="pattern" aria-label="临时关键字过滤" placeholder="输入关键字过滤（可用 * 通配，不写入文件）" value="' + D.esc(pattern || '') + '">' +
      (useTerm ? '<label class="gp-pmenu-all-toggle" title="临时显示没有围栏说明的术语"><input type="checkbox" class="gp-pmenu-all-cb" data-gp-temp-param="all"' + (all ? ' checked' : '') + '>全部</label>' : '') +
      gpTempToggle(D, 'showDirective', '显示指令', showDir, '临时切换 showDirective') +
      gpTempToggle(D, 'folded', '折叠', !!folded, '临时切换 folded（与折叠箭头同步）') +
      '<span class="gp-pmenu-filter-count">' + initCount + '/' + rawItems.length + '</span></div>';
    const body = (initCount
      ? '<div class="gp-pmenu-nav-row"><select class="gp-pmenu-select" aria-label="' + selLabel + '"><option value="">请选择' + selLabel + '…</option>' + opts + '</select>' +
        '<button type="button" class="gp-pmenu-nav-btn" hidden title="跳转到该围栏小事件群">定位</button></div>' +
        '<div class="gp-pmenu-content">选择上方菜单项目以显示围栏小事件群的内容</div>'
      : gpGpListMissingHtml(useTerm ? 'pmenu-term' : 'name', pattern, D));
    const foldAttr = folded === true ? ' checked data-gp-fold-default="1"'
      : folded === false ? ' data-gp-fold-default="0"' : '';
    const fold = '<label class="gp-include-fold" title="折叠/展开内容"><input type="checkbox" class="gp-include-fold-cb"' + foldAttr + '><span class="gp-include-fold-ico">\u25BE</span></label>';
    const legend = '<legend class="gp-include-label">' + fold + badge +
      (useTerm ? '术语内容选单' : '围栏内容选单') + ' <span class="gp-name-list-total">' + initCount + '</span></legend>';
    return '<fieldset class="gp-include-box gp-pmenu-box" data-gp-pmenu="1"' + (useTerm ? ' data-gp-pmenu-kind="TERM"' : '') +
      ' data-gp-pmenu-pattern="' + D.esc(pattern || '') + '" data-gp-pmenu-all="' + (all ? '1' : '0') + '">' + legend +
      '<div class="gp-include-directive"' + (showDir ? '' : ' hidden') + '>' + D.esc(directive || '') + '</div>' + gpGpExecDirectiveHtml(showDir) + gpGpDrawerHtml(filterBar) +
      '<div class="gp-include-body">' + body + '</div></fieldset>';
  }
  // 单一委派：桌面主窗与便利贴都载入本引擎；共用 window.__gpPmenuBound 防止重复绑定。
  function gpPmenuInstall() {
    if (typeof window !== 'undefined') {
      if (window.__gpPmenuBound) return;
      window.__gpPmenuBound = true;
    }
    if (typeof document === 'undefined' || typeof document.addEventListener !== 'function') return;
    document.addEventListener('change', (e) => {
      const cb = e.target && typeof e.target.getAttribute === 'function' && e.target.getAttribute('data-gp-temp-param') ? e.target : null;
      if (cb) {
        const b = typeof cb.closest === 'function' ? cb.closest('.gp-include-box') : null;
        if (b) gpApplyGpParams(b, gpCollectGpTempParams(b));
        return;
      }
      const sel = e.target && e.target.classList && e.target.classList.contains('gp-pmenu-select') ? e.target : null;
      if (!sel) return;
      const box = typeof sel.closest === 'function' ? sel.closest('.gp-pmenu-box') : null;
      const out = box && box.querySelector ? box.querySelector('.gp-pmenu-content') : null;
      if (!out) return;
      const opt = sel.selectedOptions && sel.selectedOptions[0];
      out.innerHTML = (opt && opt.getAttribute('data-content')) || '选择上方菜单项目以显示围栏小事件群的内容';
      gpSyncPmenuNavBtn(box, opt);
    });
    // 🆕 2026-11-22：临时参数调整（关键字输入 / all 开关）——纯前端切换 option hidden，⛔不写 .md、不写 store。
    document.addEventListener('input', (e) => {
      const t = e.target;
      if (!t || typeof t.getAttribute !== 'function' || !t.getAttribute('data-gp-temp-param')) return;
      const box = typeof t.closest === 'function' ? t.closest('.gp-include-box') : null;
      if (box) gpApplyGpParams(box, gpCollectGpTempParams(box));
    });
  }
  // 依「指令原始 pattern + 用户输入关键字 + all 开关」前端过滤 option；不触碰底稿。
  function gpApplyPmenuFilter(box, userKw) {
    const sel = box.querySelector ? box.querySelector('.gp-pmenu-select') : null;
    if (!sel || !sel.options) return;
    // 🆕 当前指令驱动：临时 pattern 是唯一过滤条件；清空＝列出全部（⛔不再叠加原始硬底）。
    const allOn = !!(box.querySelector('.gp-pmenu-all-cb') && box.querySelector('.gp-pmenu-all-cb').checked);
    const kw = String(userKw == null ? '' : userKw).trim();
    let shown = 0, total = 0;
    for (let i = 0; i < sel.options.length; i++) {
      const opt = sel.options[i];
      if (!opt.value) continue;                       // 跳过「请选择…」占位
      total++;
      const nm = String(opt.getAttribute('data-item-name') || '');
      const fence = opt.getAttribute('data-fence') === '1';
      const passKw = !kw || gpGpNamePatternHit(nm, kw);
      const passAll = allOn || fence || box.getAttribute('data-gp-pmenu-kind') !== 'TERM';
      const visible = passKw && passAll;
      opt.hidden = !visible;
      if (visible) shown++;
    }
    const cnt = box.querySelector ? box.querySelector('.gp-pmenu-filter-count') : null;
    if (cnt) cnt.textContent = shown + '/' + total;
    // 若当前选中项被过滤隐藏，清空结果区（不删 store，用户清掉关键字后可再选）。
    const cur = sel.selectedOptions && sel.selectedOptions[0];
    const out = box.querySelector ? box.querySelector('.gp-pmenu-content') : null;
    if (cur && cur.hidden && out) {
      out.innerHTML = '选择上方菜单项目以显示围栏小事件群的内容';
      gpSyncPmenuNavBtn(box, null);
    }
  }
  // ★ 定位按钮显隐／目标名与选中项同源；便利贴翻页回填也复用（⛔别在回填里另写一套）。
  function gpSyncPmenuNavBtn(box, opt) {
    const navBtn = box && box.querySelector ? box.querySelector('.gp-pmenu-nav-btn') : null;
    if (!navBtn) return;
    const navName = (opt && typeof opt.getAttribute === 'function') ? String(opt.getAttribute('data-nav-name') || '') : '';
    navBtn.hidden = !navName;
    if (navName) navBtn.setAttribute('data-nav-name', navName);
    else navBtn.removeAttribute('data-nav-name');
  }
  gpPmenuInstall();
  // ========== 🆕 2026-11-21：{list TERM} 术语清单（共享 VIEW 引擎） ==========
  const GP_TERM_LIST_RE_ANY = /\{list\s+TERM\b[^}]*\}/i;
  const GP_TERM_LIST_RE_ONE = /\{list\s+TERM\b[^}]*\}/gi;
  function gpTermNameOf(inner) {
    const full = String(inner == null ? '' : inner).trim();
    if (!full) return '';
    const i = full.indexOf(':');
    const term = (i < 0 ? full : full.slice(0, i)).trim();
    if (!term || /^(dl|cp|cr|remind|bookmark|alert)$/i.test(term)) return '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(term)) return '';
    return term;
  }
  // 与桌面 tlCollectTerms 同口径：[[term:…]] 的标题＋备注命中，与围栏 TERM= 的每一处都计数。
  function gpCollectGpTermList(pattern, D) {
    const out = new Map();
    const bump = (nm, hasFence) => {
      const name = String(nm || '').trim();
      if (!name || !gpGpNamePatternHit(name, pattern)) return;
      const key = name.toLowerCase();
      const hit = out.get(key);
      if (hit) {
        hit.count++;
        if (hasFence) hit.hasFence = true;   // 🆕 2026-11-22：围栏 TERM= 命中 → 有详细说明
      } else {
        out.set(key, { name, count: 1, hasFence: hasFence === true });
      }
    };
    const events = (D && D.gpEvents) || [];
    (Array.isArray(events) ? events : []).forEach((ev) => {
      if (!ev) return;
      [ev.title, ev.notes].forEach((txt) => {
        String(txt == null ? '' : txt).replace(/\[\[([^\]\n]+)\]\]/g, (m, inner) => {
          bump(gpTermNameOf(inner)); return m;
        });
      });
      if (!ev.notes) return;
      const lines = String(ev.notes).replace(/\r\n/g, '\n').split('\n');
      (gpFenceScan(lines).ranges || []).forEach((r) => {
        const a = extractGpAttrsLocal(lines[r.start] || '');
        if (a && a.termName) bump(a.termName, true);
      });
    });
    return out;
  }
  function gpTermListBoxHtml(list, showCount, directive, folded, D, pattern, showDirective) {
    const showDir = showDirective !== false;
    const entries = Array.from(list.values());
    const initCount = entries.filter((it) => gpGpNamePatternHit(it.name, pattern)).length;
    const filterBar = '<div class="gp-list-filter-bar"><input type="text" class="gp-list-filter-input" data-gp-temp-param="pattern" aria-label="临时关键字过滤" placeholder="输入关键字过滤（可用 * 通配，不写入文件）" value="' + D.esc(pattern || '') + '">' +
      gpTempToggle(D, 'showCount', '显示数量', !!showCount, '临时切换 showCount') +
      gpTempToggle(D, 'showDirective', '显示指令', showDir, '临时切换 showDirective') +
      gpTempToggle(D, 'folded', '折叠', !!folded, '临时切换 folded（与折叠箭头同步）') +
      '<span class="gp-list-filter-count">' + initCount + '/' + entries.length + '</span></div>';
    const body = (initCount
      ? '<ul class="gp-name-list">' + entries.map((it) => {
          const cnt = ' <span class="gp-name-list-count"' + (showCount ? '' : ' hidden') + '>(' + it.count + ')</span>';
          const fenceBrace = it.hasFence ? '<span class="gp-brace-mark" title="有围栏详细说明">{ }</span> ' : '';
          const navAttr = it.hasFence ? ' data-gp-term-nav="' + D.esc(it.name) + '"' : '';
          const hide = gpGpNamePatternHit(it.name, pattern) ? '' : ' hidden';
          return '<li' + hide + ' data-list-item-name="' + D.esc(it.name) + '"><span class="tl-term-cap" data-term="' + D.esc(it.name) + '"' + navAttr +
            ' title="术语：' + D.esc(it.name) + (it.hasFence ? '（点击定位到围栏）' : '') + '">📖 ' + fenceBrace + D.esc(it.name) + '</span>' + cnt + '</li>';
        }).join('') + '</ul>'
      : gpGpListMissingHtml('term', pattern, D));
    const foldAttr = folded === true ? ' checked data-gp-fold-default="1"'
      : folded === false ? ' data-gp-fold-default="0"' : '';
    const fold = '<label class="gp-include-fold" title="折叠/展开内容"><input type="checkbox" class="gp-include-fold-cb"' + foldAttr + '><span class="gp-include-fold-ico">\u25BE</span></label>';
    const legend = '<legend class="gp-include-label">' + fold +
      '<span class="gp-include-badge is-term" title="术语清单">\u{1F4D6}</span>术语清单 <span class="gp-name-list-total"' + (showCount ? '' : ' hidden') + '>' + initCount + '</span></legend>';
    return '<fieldset class="gp-include-box gp-name-list-box gp-term-list-box" data-gp-term-list="1"' +
      ' data-gp-list-pattern="' + D.esc(pattern || '') + '">' + legend +
      '<div class="gp-include-directive"' + (showDir ? '' : ' hidden') + '>' + D.esc(directive || '') + '</div>' + gpGpExecDirectiveHtml(showDir) + gpGpDrawerHtml(filterBar) +
      '<div class="gp-include-body">' + body + '</div></fieldset>';
  }
  // 🆕 {gp} / {gp:名称} 分组标记解析（与 calendar-editor.js::tlGpKeyOfLine 同口径）。
  //   null＝无标记；''＝{gp} 无名组；名称＝{gp:名称}。VIEW 投影贴的排序单元必须以此为准，
  //   不能把「连续同名 {gp} 的 3 行」拆成 3 个 .vsr-sort-unit，否则排序会当 3 个小事件。
  function gpKeyOf(raw) {
    const m = String(raw == null ? '' : raw).match(/\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}]*)\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
    if (!m) return null;
    return String(m[1] || '').trim();
  }
  // 把一组命中切成「编辑单元」：
  //   ① 连续且 group 名相同的 {gp} 行 → 一个单元（覆盖 task 分支，组内 checkbox 也只算一颗圆点）；
  //   ② 其余沿用旧口径：连续同类非 task 行合并、task 行各自独立。
  //   名称不同 / 中间夹无标记行 / 同名但不连续 → 各自成组（组＝连续区段，不做全域合并）。
  //   ⚠️ 空白行规则（2026-11-06）：投影贴只收「命中行」，来源的纯空白行根本不会进 hits，
  //      因此被空白行隔开的两段同 key {gp} 在 hits 里天然相邻 → 本来就合并成 1 个排序单元。
  //      h.sep 是「列表行后接非列表行」时插入的**虚拟**分隔，不是来源空白行，必须继续丢弃；
  //      绝不能塞进 gp 单元，否则 data-text 与显示内容会多出一条来源没有的空行。
  function groupHitsIntoUnits(hits) {
    const units = [];
    let cur = null;        // 普通合并单元 {cat, task:false, hits}
    let gpCur = null;      // {gp} 合并单元 {gp, task:false, hits, fg, bg, anim, alert, termName}
    const flushGp = () => { if (gpCur) { units.push(gpCur); gpCur = null; } };
    (hits || []).forEach((h) => {
      if (h.sep) return;   // 虚拟空行只作分隔、不打断连续性（沿用旧行为）
      // 🆕 块级群优先：同一个 {gpX}…{/gpX} 区间的命中行共用一个虚拟 key；
      //    前缀 '\u0000blk' 保证绝不会与任何行尾 {gpX} 的真实 key 撞名。
      const gp = (h.blockGp != null) ? h.blockGp : gpKeyOf(h.raw);
      if (gp !== null) {
        if (cur) { units.push(cur); cur = null; }
        if (gpCur && gpCur.gp === gp) gpCur.hits.push(h);
        // 🆕 2026-11-09：gp unit 带上 attrs（fg/bg），从第一个 hit 拿（整块 hits 的 attrs 全相同）
        else { flushGp(); gpCur = { gp: gp, task: false, hits: [h], fg: h.gpFg || '', bg: h.gpBg || '', anim: h.gpAnim || '', alert: !!h.gpAlert, termName: h.gpTermName || '', name: h.gpName || '', railStyle: h.gpRailStyle || '', railA: h.gpRailA || '', railB: h.gpRailB || '' }; }
        return;
      }
      flushGp();
      if (h.task) { if (cur) units.push(cur); units.push({ task: true, hits: [h] }); cur = null; return; }
      const cat = viewMergeCategory(h);
      if (cur && !cur.task && cur.cat === cat) cur.hits.push(h);
      else { if (cur) units.push(cur); cur = { cat: cat, task: false, hits: [h] }; }
    });
    flushGp();
    if (cur) units.push(cur);
    return units;
  }
  // ── 顏色名解析（2026-11-09，擴展：深/浅/淡 級別前綴） ──
  const CN_COLORS = {
    '红': '#e74c3c', '橙': '#e67e22', '黄': '#f1c40f', '金': '#d4af37',
    '粉': '#ff6b9d', '紫': '#8e44ad', '蓝': '#3498db',
    '绿': '#27ae60', '青': '#1abc9c', '灰': '#95a5a6', '黑': '#2c3e50', '白': '#ecf0f1',
    '卡其': '#bdb76b', '棕': '#8b5a2b', '酒红': '#722f37', '米': '#f5f0dc'
  };
  function _hexToHsl(hex) {
    const h = hex.replace('#', '');
    const r = parseInt(h.slice(0, 2), 16) / 255;
    const g = parseInt(h.slice(2, 4), 16) / 255;
    const b = parseInt(h.slice(4, 6), 16) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const l = (max + min) / 2;
    let hh, s = 0;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) { case r: hh = (g - b) / d + (g < b ? 6 : 0); break; case g: hh = (b - r) / d + 2; break; default: hh = (r - g) / d + 4; }
      hh /= 6;
    } else hh = 0;
    return { h: hh * 360, s: s * 100, l: l * 100 };
  }
  function _hslToHex(hsl) {
    const h = hsl.h / 360, s = hsl.s / 100, l = hsl.l / 100;
    function hue2rgb(p, q, t) {
      if (t < 0) t += 1; if (t > 1) t -= 1;
      if (t < 1/6) return p + (q - p) * 6 * t;
      if (t < 1/2) return q;
      if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
      return p;
    }
    let r, g, b;
    if (s === 0) { r = g = b = l; }
    else {
      const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
      const p = 2 * l - q;
      r = hue2rgb(p, q, h + 1/3); g = hue2rgb(p, q, h); b = hue2rgb(p, q, h - 1/3);
    }
    const toHex = (v) => Math.round(v * 255).toString(16).padStart(2, '0');
    return '#' + toHex(r) + toHex(g) + toHex(b);
  }
  function _shiftBrightness(baseHex, op, n) {
    const hsl = _hexToHsl(baseHex);
    let newL = hsl.l;
    if (op === '+') newL = hsl.l * (1 - Math.min(10, n) / 10 * 0.75);
    else if (op === '-') newL = hsl.l + (100 - hsl.l) * Math.min(10, n) / 10 * 0.75;
    else if (op === '深') newL = hsl.l * 0.65;
    else if (op === '浅') newL = hsl.l + (100 - hsl.l) * 0.28;
    else if (op === '淡') newL = hsl.l + (100 - hsl.l) * 0.48;
    newL = Math.max(3, Math.min(97, newL));
    return _hslToHex({ h: hsl.h, s: hsl.s, l: newL });
  }
  function resolveColorNameLocal(input) {
    if (!input) return '';
    const s = String(input).trim();
    if (!s) return '';
    const gm = s.match(/^渐变\s*\(\s*([^→)]+)\s*→\s*([^)]+)\s*\)$/);
    if (gm) {
      const a = resolveColorNameLocal(gm[1]);
      const b = resolveColorNameLocal(gm[2]);
      if (a && b) return 'linear-gradient(135deg, ' + a + ', ' + b + ')';
    }
    const nm = s.match(/^(.+?)\s*([+\-])\s*(\d+)$/);
    if (nm) {
      const base = nm[1].trim(), op = nm[2], n = parseInt(nm[3], 10);
      const baseHex = CN_COLORS[base];
      if (baseHex && n >= 1 && n <= 10) return _shiftBrightness(baseHex, op, n);
    }
    const tm = s.match(/^(深|浅|淡)(.+)$/);
    if (tm) {
      const op = tm[1], base = tm[2].trim();
      const baseHex = CN_COLORS[base];
      if (baseHex) return _shiftBrightness(baseHex, op);
    }
    if (CN_COLORS[s]) return CN_COLORS[s];
    if (/^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(s)) return s;
    if (/^(rgb|rgba|hsl|hsla)\s*\(/i.test(s)) return s;
    return s;
  }
  function extractGpAttrsLocal(line) {
    const s = String(line == null ? '' : line);
    let m = s.trim().match(/^\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}]*)\}[ \t]*$/i);
    if (m) return parseGpAttrLocal(m[1]);
    m = s.match(/\{[ \t]*(?:group|gp)[ \t]*:?[ \t]*([^{}]*)\}(?=[ \t]*(?:\[\[[^\]]*\]\][ \t]*)*$)/i);
    if (m) return parseGpAttrLocal(m[1]);
    return { key: '', fg: '', bg: '', anim: '', alert: false, termName: '', name: '', railStyle: '', railA: '', railB: '' };
  }
  function parseGpAttrLocal(raw) {
    const s = String(raw == null ? '' : raw).trim();
    if (!s) return { key: '', fg: '', bg: '', anim: '', alert: false, termName: '', name: '', railStyle: '', railA: '', railB: '' };
    const pipe1 = s.indexOf('|');
    if (pipe1 < 0) return { key: s, fg: '', bg: '', anim: '', alert: false, termName: '', name: '', railStyle: '', railA: '', railB: '' };
    const key = s.slice(0, pipe1).trim();
    const rest = s.slice(pipe1 + 1);
    const pipe2 = rest.indexOf('|');
    const attrsPart = pipe2 >= 0 ? rest.slice(0, pipe2) : rest;
    let termPart = pipe2 >= 0 ? rest.slice(pipe2 + 1) : '';
    let fg = '', bg = '', anim = '', alert = false, termName = '', name = '', railStyle = '', railA = '', railB = '';
    // 解析 attrs 段（, 分隔）
    attrsPart.split(',').forEach((pair) => {
      const p = pair.trim();
      if (!p) return;
      const eq = p.indexOf('=');
      if (eq < 0) return;
      const k = p.slice(0, eq).trim().toLowerCase();
      const v = p.slice(eq + 1).trim();
      if (k === 'fg') fg = resolveColorNameLocal(v);
      else if (k === 'bg') bg = resolveColorNameLocal(v);
      else if (k === 'anim' && /^(pulse|scan|data|aurora|orbit|arc|holo|signal|glitch)$/.test(v)) anim = v;
      // TERM 在 attrs 段兜底（同时加回 termPart，避免写回时丢失）
      else if (/^TERM\s*$/i.test(k)) {
        const q = gpQuotedVal(v);
        if (q) termName = q;
        if (!termPart) termPart = 'TERM=' + (v.startsWith('"') || v.startsWith("'") ? v : '"' + v + '"');
      }
      else if (k === 'name') { const q = gpQuotedVal(v); if (q) name = q; }
      else if (k === 'rail') {
        const rp = v.split('#');
        if (rp.length >= 3 && ['斜栏', '直栏', '>形栏', '圆弧栏'].indexOf(rp[0].trim()) >= 0) {
          railStyle = rp[0].trim();
          railA = resolveColorNameLocal(rp[1].trim());
          railB = resolveColorNameLocal(rp[2].trim());
        }
      }
    });
    // 解析 term 段（支持逗号混写：TERM=xxx,rail=斜栏#白#黑）
    if (termPart) {
      termPart.split('|').forEach((seg) => {
        seg.split(',').forEach((item) => {
          const segTrim = item.trim();
          if (!segTrim) return;
          const eq = segTrim.indexOf('=');
          if (eq < 0) {
            if (/^(dl|cp|cr|alert|remind|bookmark)$/i.test(segTrim)) alert = true;
            return;
          }
          const k = segTrim.slice(0, eq).trim().toUpperCase();
          const v = segTrim.slice(eq + 1).trim();
          if (k === 'TERM') { const q = gpQuotedVal(v); if (q) termName = q; }
          else if (k === 'NAME') { const q = gpQuotedVal(v); if (q) name = q; }
          else if (k === 'ALERT') alert = v.toLowerCase() === 'true';
          else if (k === 'RAIL') {
            const rp = v.split('#');
            if (rp.length >= 3 && ['斜栏', '直栏', '>形栏', '圆弧栏'].indexOf(rp[0].trim()) >= 0) {
              railStyle = rp[0].trim();
              railA = resolveColorNameLocal(rp[1].trim());
              railB = resolveColorNameLocal(rp[2].trim());
            }
          }
        });
      });
    }
    return { key: key, fg: fg, bg: bg, anim: anim, alert: alert, term: termPart, termName: termName, name: name, railStyle: railStyle, railA: railA, railB: railB };
  }
  // 🆕 gp 单元里的 - [ ] 行：转成与一般 checkbox 相同的 .ev-md-check/.ev-cb（只读框、无圆点）。
  //    否则 D.markdown 会把它们渲染成 <ul><li>，便利贴 CSS 的 .body ul li{list-style:disc}
  //    就多出那个「.」项目符号，方框也变成浏览器原生灰框（与来源贴不一致）。
  //    整组只有外层一颗圆点 → 这里不给 .ev-md-edit，也不给 interactive（投影贴本来就只读）。
  //    checkbox 文字沿用 tlTaskLineHtml 的行内渲染 helper，避免在 VIEW 路径使用不同的 Markdown 处理方式。
  function gpCheckboxLines(rawChunk, deps) {
    const D = makeDeps(deps);
    const raws = String(rawChunk).split('\n');
    return raws.map((line) => {
      const m = String(line || '').match(TASK_LINE_RE);
      if (!m) return line;
      const done = m[2] !== ' ';
      const textProcessed = D.inline(D.noteMarkers(m[3] || '')).trim();
      return m[1] + ' <span class="ev-md-check' + (done ? ' done' : '') + '">' +
        '<span class="ev-cb">' + (done ? '\u2713' : '') + '</span>' +
        '<span class="ev-md-check-text">' + textProcessed + '</span></span>';
    }).join('\n');
  }
  // 一个非 task 编辑单元（可能含 1..n 条连续同类行）：整块渲染成 1 个 .md-unit ＋ 1 颗只读圆点。
  function nonTaskUnitHtml(hits, ev, selfKey, deps, isGp, gpFg, gpBg, gpAnim, gpAlert, gpTermName, gpRailStyle, gpRailA, gpRailB, gpName) {
    const D = makeDeps(deps);
    const list = (hits && hits.length) ? hits : [];
    if (!list.length) return '';
    const first = list[0];
    const stitle = D.esc(String((ev && ev.title) || '').replace(/\s+/g, ' ').trim() || '(无标题)');
    const chunk = list.map((h) => String(h.raw || '').trim()).join('\n');   // 整块原文（多行用 \n 连接）
    const renderChunk = isGp ? separateGpHorizontalRules(chunk) : chunk;
    const dot = '<button type="button" class="ev-md-edit" title="右键：复制／找出相同的项目"' +
      ' data-uid="' + D.esc(selfKey) + '" data-src="' + D.esc(first.uid || '') +
      '" data-stitle="' + stitle + '" data-line="' + (first.line != null ? first.line : '') +
      '" data-text="' + D.esc(chunk) + '">\u270e</button>';
    // 🆕 data-start/data-end：与 tlRenderNotes 的 .md-unit 同口径（0-based 行区间），
    //    让「找出相同的项目 → 切换」能在便利贴窗里用同一个选择器定位到这个单元并闪烁。
    const last = list[list.length - 1];
    const cr = extractCrDate(chunk);
    const sd = cr || String((ev && ev.date) || '');
    // 🆕 2026-11-09：对齐源便利贴 tlSplitMdBlocks 渲染顺序 ——
    //    源便利贴 = renderMarkdown(tlRenderTermDefs(tlRenderNoteMarkersLines(prepared)))
    //    即「先 checkbox HTML 转换 → noteMarkersLines → termDefs → renderMarkdown」，termDefs 只做一次！
    //    🆕 昨天改坏了：把 termDefs 提到 body 变量里一次 + 外面又做一次 → 双重 termDefs！
    // 🆕 2026-11-16：非 checkbox 单元的 {include name="…"} 用占位符法就地展开（只读），
    //   与桌面同口径 —— 插入的 .gp-include-box HTML 不被 checkbox/marker/termDefs/markdown 二次处理。
    // 🆕 gp attrs 直接从参数取（由 groupHitsIntoUnits 的 unit 传入），不再从 chunk 猜
    let gpStyle = '';
    if (isGp) {
      const fg = gpFg || '', bg = gpBg || '';
      if (fg || bg || gpRailStyle) {
        const parts = [];
        if (fg) parts.push('--gp-fg:' + fg);
        if (bg) { parts.push('--gp-bg:' + bg); if (fg) parts.push('--gp-border:' + fg); }
        if (gpRailStyle) {
          parts.push('--gp-rail-style:' + gpRailStyle);
          if (gpRailA) parts.push('--gp-rail-a:' + gpRailA);
          if (gpRailB) parts.push('--gp-rail-b:' + gpRailB);
        }
        gpStyle = ' style="' + parts.join(';') + '"';
      }
    }
    // 🆕 2026-11-14：gp 围栏属性徽标 HTML — TERM + ALERT（🔔），与 tlGpBadgesHtml 同口径
    // 🆕 2026-11-15：TERM 那颗＝正文同款术语胶囊本体（喂 D.termDefs），尺寸由 CSS 压到徽标同高
    let gpBadges = '';
    if (isGp) {
      const badges = [];
      if (gpName) badges.push('<span class="gp-badge gp-badge-name" title="围栏名称：' + D.esc(gpName) + '"><span class="gp-brace-mark">{ }</span> ' + D.esc(gpName) + '</span>');
      if (gpTermName) badges.push(D.termDefs('[[' + gpTermName + ']]'));
      if (gpAlert) badges.push('<span class="gp-badge gp-badge-alert" title="ALERT 闹铃">\u{1F514}</span>');
      if (badges.length) gpBadges = '<span class="gp-badges">' + badges.join('') + '</span>';
    }
    return '<div class="vsr-sort-unit" data-sort-date="' + D.esc(sd) + '" data-cr-date="' + D.esc(cr) + '"><div class="md-unit' + (isGp ? ' is-gp' : '') + '"' +
      (isGp && /^(pulse|scan|data|aurora|orbit|arc|holo|signal|glitch)$/.test(gpAnim || '') ? ' data-gp-anim="' + gpAnim + '"' : '') +
      (isGp && gpRailStyle ? ' data-gp-rail="' + gpRailStyle + '"' : '') +
      (isGp && gpName ? ' data-gp-name="' + D.esc(gpName) + '"' : '') +
      (isGp && gpTermName ? ' data-gp-term="' + D.esc(gpTermName) + '"' : '') +
      gpStyle + ' data-start="' + (first.line != null ? first.line : '') +
      '" data-end="' + (last.line != null ? last.line : (first.line != null ? first.line : '')) + '">' +
      gpBadges + dot + gpRenderWithIncludes(renderChunk, (t) => {
        const p = isGp ? gpCheckboxLines(t, deps) : t;
        return D.markdown(D.nameRefs(D.termDefs(noteMarkersLines(p, D))));
      }, D) + '</div></div>';
  }
  function groupsToHtml(groups, selfKey, deps) {
    const D = makeDeps(deps);
    let out = '';
    (groups || []).forEach((g) => {
      out += groupHeadHtml(g.ev, D) + '\n';
      groupHitsIntoUnits(g.hits).forEach((u) => {
        out += u.task ? taskLineHtml(u.hits[0], g.ev, selfKey, D) + '\n'
          // 🆕 2026-11-09：gp attrs 从 unit 直接传
          : nonTaskUnitHtml(u.hits, g.ev, selfKey, D, u.gp != null, u.fg || '', u.bg || '', u.anim || '', !!u.alert, u.termName || '', u.railStyle || '', u.railA || '', u.railB || '', u.name || '') + '\n';
      });
    });
    return out;
  }

  // 段落标题（markdown）：多段落时渲染「段落 N：标题」；单段落与旧版一致不加标题。
  //   条件说明不再铺在便利贴里，改为悬停 tooltip（见 buildRef）。
  //   🆕 标题开头的 # 层级标记（#{1,6}）决定整段段落标题的层级：带 #＝用户自定层级（如 #→H1、##→H2），
  //      不带 #＝默认 H3（与旧版「### 段落 N：」一致）。这样 # 真的会改变渲染（层级不同、字号不同），
  //      且 # 在一行开头当标题标记用、不会变成字面符号，整行仍与「段落 N：」并成一行（满足「不要换行」）。
  function segmentHeaderMd(seg, i) {
    const titleRaw = seg.title ? String(seg.title).replace(/\s+/g, ' ').trim() : '';
    const m = titleRaw.match(/^(#{1,6})\s*/);          // 提取开头的标题层级
    const level = m ? m[1].length : 3;                // 默认 H3（与旧版一致）
    const body = m ? titleRaw.slice(m[0].length) : titleRaw;  // 去掉层级标记后的标题正文
    const hashes = '#'.repeat(level);
    return body ? (hashes + ' 段落 ' + (i + 1) + '：' + body) : (hashes + ' 段落 ' + (i + 1));
  }

  // ===== 一张自定义投影贴 =====
  //   回传 null 只有两种：规则关闭、或所有段落都没有命中条件（＝还没填好，不是「抓完发现没有」）。
  //   有条件但 0 命中 → 照建一张，贴面写明原因（见 EMPTY_NOTES）。
  //   🆕 多段落：每段各是一个完整搜索，按 segments 顺序显示为多个「段落 N」区块；
  //      单段落（含 🔔 内置、旧版自定义）外观与旧版完全一致（不加标题）。
  function buildRef(rule, events, deps) {
    const D = makeDeps(deps);
    // 🆕 2026-11-16：{include} 索引按本次 events 建一次，挂在 D 上供 taskLineHtml/nonTaskUnitHtml 共用。
    D.gpIncludeIndex = gpIncludeIndexFromEvents(events);
    // 🆕 2026-11-20：{list NAME} 需要全部 events 扫具名围栏，挂在 D 上供 gpRenderWithIncludes 共用。
    D.gpEvents = events;
    const r = normalizeRule(rule);
    if (!r.enabled) return null;                     // 关闭的规则＝不要这张贴
    if (!r.segments.some(segmentHasCondition)) return null;   // 全部段落都没条件＝还没填好
    const key = viewKeyOf(r.id);
    const base = {
      key, idx: 0, view: true, customView: true, ruleId: r.id,
      titleHtml: D.inline(r.title), title: r.title, date: '', endDate: '', color: '', done: false, tags: [], src: '',
      notify: r.notify === true,
      notifySeconds: r.notifySeconds
    };
    // 每段独立收集（只收「有」条件的段落）
    // 🆕 searchTitle 对所有规则一致（不再 !r.builtin）：内置「提醒」规则现在可像自定义规则一样被编辑
    //   （改标题／加段落／改用关键词或标记收集），若仍对内置关掉标题搜索，编辑后的内置规则与同条件的自定义规则
    //   会产出不同结果——仅「标题命中」的事件（如标题里带 ⭐／关键词、正文无对应标记行）会被漏抓。
    //   默认内置（marker=remind、无关键词）标题里没有 [[remind:]]，searchTitle=true 对其行为无影响 → 零回归。
    const segResults = r.segments
      .filter(segmentHasCondition)
      .map((seg) => ({ seg, groups: collectGroups(events, seg, D, true) }));
    const totalHits = segResults.reduce((a, s) => a + s.groups.length, 0);
    if (totalHits === 0) {
      if (r.emptyBehavior === 'hide') return null;
      // 🆕 事件日期便利贴（任一段用 field==='ev'）0 命中时，给一句「这一天没有行程」比通用 EMPTY_NOTES 更贴切
      const isEvDate = segResults.some((sr) => sr.seg.dateCond && sr.seg.dateCond.field === 'ev');
      const emptyNotes = isEvDate
        ? '**这一天没有行程**\n\n事件本身的日期没匹配到任何日程。改日期条件请开便利贴菜单的「🧩 自定义 VIEW 便利贴设定维护作业」。'
        : EMPTY_NOTES;
      return Object.assign(base, { notes: emptyNotes, html: D.markdown(D.termDefs(emptyNotes)) });
    }
    const multi = segResults.length > 1;
    // 🆕 标题 tooltip 统一显示「所有段落」的设定摘要（单／多段落同一逻辑）：把每段的条件摘要合并后
    //    挂到便利贴标题文字上，鼠标悬停标题即见全部段落。多段落时每段标题（.vsr-seg-hd）再各挂「该段」条件，
    //    两者并存（用户要求每段也能单独看自己的条件）。
    const titleTipParts = segResults.map((sr, i) => {
      const seg = sr.seg;
      const label = multi
        ? ('段落' + (i + 1) + (seg.title ? '：' + seg.title : '') + '：')
        : (seg.title ? seg.title + '：' : '');
      return label + conditionText(seg);
    });
    base.titleTip = titleTipParts.join('\n');
    let notes = '';
    let html = '';
    const tabBtns = [];
    let segsHtml = '';
    segResults.forEach((sr, i) => {
      const g = sr.groups;
      const segNotes = groupsToMd(g, D);
      const segHtml = groupsToHtml(g, key, D);
      // 🆕 多段落时，把「该段」条件摘要挂到段落标题（.vsr-seg-hd，hover 段落 N 标题即见），
      //    与便利贴标题的「全部段落合并」tooltip 并存——用户要求每段也要能单独看自己的条件。
      const segTip = conditionText(sr.seg);
      let head = '', headHtml = '';
      if (multi) {
        head = segmentHeaderMd(sr.seg, i);
        const hr = D.markdown(D.termDefs(head));
        headHtml = '<div class="vsr-seg-hd"' + (segTip ? ' data-tip="' + D.esc(segTip) + '"' : '') + '>' + hr + '</div>';
      }
      const segInner = headHtml + (headHtml ? '\n' : '') +
        (g.length ? segHtml : D.markdown('> （这个段落目前没抓到任何行）'));
      // 🆕 多段落：每段一个页签按钮 + 一个内容面板（页签方式时只显示 active 面板）
      if (multi) {
        // 🆕 页签按钮只显示「描述」文字、隐藏「段落 N」字眼以节省横向空间；无描述时才回退「段落 N」
        const desc = (sr.seg.title ? String(sr.seg.title).replace(/^#{1,6}\s*/, '').trim() : '');
        const label = desc || ('段落 ' + (i + 1));
        // 🆕 胶囊只挂 data-tip（条件摘要 tooltip，由 CSS ::after 渲染）；不再挂原生 title="label"——
        // 原生 title 只会重复可见文字、且与自定义 tooltip 叠成双气泡，已无意义。
        // 标签文字包进 .vsr-tab-label 内层：省略号截断交給内层做，.vsr-tab 本身保持 overflow:visible，
        // 否则按钮的 overflow:hidden 会把定位在它下方(top:100%)的 ::after tooltip 整个裁掉（看不到）。
        tabBtns.push('<button type="button" class="vsr-tab' + (i === 0 ? ' vsr-active' : '') + '" data-seg="' + i + '"' +
          (segTip ? ' data-tip="' + D.esc(segTip) + '"' : '') + '><span class="vsr-tab-label">' + D.esc(label) + '</span></button>');
        segsHtml += (segsHtml ? '\n' : '') + '<div class="vsr-seg' + (i === 0 ? ' vsr-active' : '') + '" data-seg="' + i + '">' + segInner + '</div>';
      }
      const notesBlock = head + (head ? '\n' : '') + (g.length ? segNotes : '\n\n> （这个段落目前没抓到任何行）');
      notes += (notes ? '\n\n' : '') + notesBlock;
      if (!multi) {
        html += (html ? '\n' : '') + '<div class="vsr-seg">' + segInner + '</div>';
      }
    });
    // 🆕 多段落：包一层 .vsr-display，内含「顺序平铺／页签方式」随时切换控件 + 页签栏 + 内容面板。
    //    两种模式都在同一份 html 里，由便利贴端的 CSS + JS 决定显示哪种（默认顺序平铺，偏好记忆在 localStorage）。
    //    单段落（含 🔔 内置、旧版自定义）维持原样（不加 .vsr-display，无切换控件，零回归）。
    if (multi) {
      const toggle = '<div class="vsr-display-toggle" role="group" aria-label="显示方式">' +
        '<button type="button" class="vsr-mode-btn vsr-mode-flat vsr-active" data-mode="flat">顺序平铺</button>' +
        '<button type="button" class="vsr-mode-btn vsr-mode-tabs" data-mode="tabs">页签方式</button>' +
        '</div>';
      const tabs = '<div class="vsr-tabs">' + tabBtns.join('') + '</div>';
      html = '<div class="vsr-display vsr-mode-flat" data-segs="' + segResults.length + '">' +
        toggle + '\n' + tabs + '\n' + '<div class="vsr-segs">\n' + segsHtml + '\n</div></div>';
    }
    return Object.assign(base, { notes, html });
  }
  function buildRefs(rules, events, deps) {
    const D = makeDeps(deps);
    const out = [];
    normalizeList(rules).forEach((r) => {
      const ref = buildRef(r, events, D);
      if (ref) out.push(ref);
    });
    return out;
  }

  global.ViewStickyRules = {
    KEY_PREFIX: KEY_PREFIX, viewKeyOf: viewKeyOf, isViewKey: isViewKey,
    ROW_TYPES: ROW_TYPES, ROW_TYPE_LABEL: ROW_TYPE_LABEL, MARKERS: MARKERS,
    NOTIFY_DEFAULT_SECONDS: NOTIFY_DEFAULT_SECONDS,
    NOTIFY_MIN_SECONDS: NOTIFY_MIN_SECONDS,
    NOTIFY_MAX_SECONDS: NOTIFY_MAX_SECONDS,
    normalizeNotifySeconds: normalizeNotifySeconds,
    isNotifyRule: isNotifyRule,
    normalizeRule: normalizeRule, normalizeList: normalizeList,
    newRuleId: newRuleId, blankRule: blankRule, builtinRules: builtinRules,
    blankSegment: blankSegment,
    segmentHasCondition: segmentHasCondition, ruleHasCondition: ruleHasCondition,
    conditionText: conditionText, ruleSummary: ruleSummary,
    EMPTY_NOTES: EMPTY_NOTES,
    rowTypeOf: rowTypeOf, collectGroups: collectGroups, groupHeadMd: groupHeadMd,
    groupsToMd: groupsToMd, groupsToHtml: groupsToHtml, taskLineHtml: taskLineHtml,
    buildRef: buildRef, buildRefs: buildRefs
  };
})(typeof window !== 'undefined' ? window : globalThis);
